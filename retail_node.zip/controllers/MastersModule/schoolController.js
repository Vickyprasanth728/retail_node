import { formatDateToYYYYMMDD, formatDateTimeToYYYYMMDDHHMMSS } from '../../Utils/Datetime.js';
import moment from 'moment-timezone';

const currentDate = new Date();
const isoDateString = currentDate.toISOString();

const originalMoment = moment(isoDateString);
const originalDate = originalMoment.toDate();

const formattedDate = formatDateToYYYYMMDD(originalDate);

const formattedDateTime = formatDateTimeToYYYYMMDDHHMMSS(originalDate);

import { db } from '../../config/Database.js';


// Add School
export const AddSchool = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
    await db.query('START TRANSACTION');

    try {
        const {schoolcode, name, address, email, mobileno, createdby } = req.body


        let thisQueryP = ` SELECT schoolcode FROM school WHERE schoolcode = '${schoolcode}' LIMIT 1 `
        const dataP = await db.query(thisQueryP);
        const schoolcodeCheck = dataP[0][0] ? dataP[0][0] : 0

      if (schoolcodeCheck != 0) {

        console.log('School code already exists');
        res.status(404).send({
          status: false,
          message: 'School code already exists',
        });

      } else {

        let thisQuery = ` INSERT INTO school (schoolcode, name, address, email, mobileno, createdAt, updatedAt, createdby) VALUES ('${schoolcode}', '${name}', '${address}', '${email}', '${mobileno}', '${formattedDateTime}', '${formattedDateTime}', '${createdby ? createdby : 0}') `

        const data = await db.query(thisQuery);

        console.log('School added successfully');

        res.status(200).send({
          status: true,
          message: 'School added successfully',
        });
      }

        await db.query('COMMIT');
      } 
      catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });

        await db.query('ROLLBACK');
    }
};
// Get All Schools
export const getAllSchools = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

    try {
         const filters = req.query;

        let thisQuery = ` SELECT s.*, HEX(s.status) as status FROM school as s WHERE s.status != 0 `

        if (filters?.limit) {
          thisQuery += ` limit ${filters?.limit},10 `
        }
        
        const data = await db.query(thisQuery);

        console.log('data', data[0]);

        res.status(200).send({
          status: true,
          message: 'success',
          data: data[0]
        });

      } 
      catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};
// Get School By Id
export const getSchoolById = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

    const ID = req.params.schoolid

    try {

        let thisQuery = ` SELECT s.*, HEX(s.status) as status FROM school as s WHERE s.status != 0 AND s.schoolid = '${ID}' `
        const data = await db.query(thisQuery);

        console.log('data', data[0]);

        res.status(200).send({
          status: true,
          message: 'success',
          data: data[0]
        });

      } 
      catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};
// Update School
export const updateSchool = async (req, res) => {

  await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
  await db.query('START TRANSACTION');

  try {
      const ID = req.params.schoolid

      const {schoolcode, name, address, email, mobileno, updatedby } = req.body


      let thisQueryP = ` SELECT schoolcode FROM school WHERE schoolcode = '${schoolcode}' AND schoolid != '${ID}' LIMIT 1 `
      const dataP = await db.query(thisQueryP);
      const schoolcodeCheck = dataP[0][0] ? dataP[0][0]?.schoolcode : 0

    if (schoolcodeCheck != 0 ) {

      console.log('School code already exists');
      res.status(404).send({
        status: false,
        message: 'School code already exists',
      });

    } else {

      let thisQuery = ` UPDATE school SET schoolcode = '${schoolcode}', name = '${name}', address = '${address}', email = '${email}', mobileno = '${mobileno}', updatedAt = '${formattedDateTime}', updatedby = '${updatedby}' WHERE schoolid = '${ID}' `

      const data = await db.query(thisQuery);

      console.log('School added successfully');

      res.status(200).send({
        status: true,
        message: 'School updated successfully',
      });
    }

      await db.query('COMMIT');
    } 
    catch (error) {
      console.log(error);
      res.status(500).json({ error: 'Internal Server Error', message: error.message });

      await db.query('ROLLBACK');
  }
};
// Delete School
export const deleteSchool = async (req, res) => {

  await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

  try {

      const ID = req.body.schoolid

      let thisQuery  = ` DELETE FROM school WHERE schoolid IN (${ID}) `
      const dataMain = await db.query(thisQuery);

      const data = dataMain[0];
      if (data) {
          res.status(200).send({
              status: true, 
              message: 'Deleted Successfully', 
          });
      }
      else {
          res.status(400).json({status:false, message: 'Delete failed' });
      }

  } catch (error) {
      console.log(error);
      res.status(500).json({ status:false, error: 'Internal Server Error', message: error.message });
  }
};

// Check Unique School Code
export const CheckUniqueSchoolcode = async (req, res) => {

  await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

  const { schoolcode } = req.body

  try {

      let thisQuery = ` SELECT s.* FROM school as s WHERE s.status != 0 AND s.schoolcode = '${schoolcode}' `
      const data = await db.query(thisQuery);

      const datacheck = data[0][0] ? data[0][0]?.schoolcode : 0

      console.log('datacheck', datacheck);

     if (datacheck != 0) {
        res.status(200).send({
          status: true,
          issuccess: true,
          message: 'School code present',
        });
     } else {
        res.status(200).send({
          status: false,
          issuccess: false,
          message: 'School code does not exist',
        });
     }

    } 
    catch (error) {
      console.log(error);
      res.status(500).json({ error: 'Internal Server Error', message: error.message });
  }
};