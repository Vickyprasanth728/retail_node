import { formatDateToYYYYMMDD, formatDateTimeToYYYYMMDDHHMMSS } from '../../Utils/Datetime.js';
import moment from 'moment-timezone';

const currentDate = new Date();
const isoDateString = currentDate.toISOString();

const originalMoment = moment(isoDateString);
const originalDate = originalMoment.toDate();

const formattedDate = formatDateToYYYYMMDD(originalDate);

const formattedDateTime = formatDateTimeToYYYYMMDDHHMMSS(originalDate);
import bcrypt from 'bcrypt';
const saltRounds = 10;
import { db } from '../../config/Database.js';
import Joi from 'joi';

const schema = Joi.object({
    name: Joi.string().min(3).required(),
    email: Joi.string().email().required(),
    mobileno: Joi.string().min(10).max(10).required()
}).unknown(true);

// Add Masters
export const AddMasters = async (req, res) => {
    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
    await db.query('START TRANSACTION');

    try {
        const { ...fields } = req.body;
        const mastername = req.params.mastername;

        let thisQueryCheckP = `SELECT COLUMN_NAME 
        FROM INFORMATION_SCHEMA.COLUMNS 
        WHERE TABLE_NAME = '${mastername}' `;
        
        const columnDataCheck = await db.query(thisQueryCheckP);
        console.log('columnDataCheck', columnDataCheck);

        if(!columnDataCheck[0][0]) {
            console.log(`masters name not found`);
            res.status(404).send({
                status : false,
                message : `masters name not found`
            })

        } else {

        let thisQueryP = `SELECT COLUMN_NAME 
        FROM INFORMATION_SCHEMA.COLUMNS 
        WHERE TABLE_NAME = '${mastername}' 
        AND COLUMN_NAME IN (
        ${
        mastername == 'gst' ? "'name','tax'" : 
        mastername == 'weightmasters' ? "'startweightrange','endweightrange', 'charge'" :
        mastername == 'users' ? "'username', 'password', 'role'" :
        mastername == 'school' ? "'schoolcode', 'mobileno', 'name', 'address', 'email'" :
        mastername == 'color' || 'size' || 'category' || 'grade' || 'gender' ? "'name'" :
        ''})`;
        
        const columnData = await db.query(thisQueryP);
        const uniqueColumnNames = [...new Set(columnData[0].map(item => item.COLUMN_NAME))];

        const fieldsToCheck = Object.keys(fields);
        console.log('uniqueColumnNames', uniqueColumnNames); 
        console.log('fieldsToCheck', fieldsToCheck);
        
        // const missingFields = fieldsToCheck.filter(field => !uniqueColumnNames.includes(field));     
        const missingFields = uniqueColumnNames.filter(field => !fieldsToCheck.includes(field));
        console.log('missingFields', missingFields);

        if (missingFields.length > 0) {
            res.status(400).send({
                status : false,
                message : `The following ${mastername} fields are missing : ${missingFields.join(', ')}`
            })
        } else {

            if (mastername == 'gst') {

                const {name,tax,createdby} = req.body  
                
                let thisQueryExisting = ` SELECT name FROM gst WHERE name = '${name}' `
                const nameExisting = await db.query(thisQueryExisting);

                console.log('nameExisting', nameExisting[0][0]?.name);

                if (nameExisting[0][0]?.name) {
                    res.status(403).send({
                        status : false,
                        message : `GST name already exists`
                    })
                } else {
                    let thisQuery = ` INSERT INTO gst (name, tax, status, createdon, lastmodifiedon, createdby, lastmodifiedby) VALUES ('${name}', '${tax}', '1', '${formattedDateTime}', '${formattedDateTime}', '${createdby ? createdby : 0}', '${createdby ? createdby : 0}') `

                    const data = await db.query(thisQuery);
            
                    console.log('GST added successfully', data[0]);
                    res.status(200).send({
                        status : true,
                        message : `GST added successfully`
                    })
                }
            }
            else if (mastername == 'users') {

                const {username,password,email,mobileno,role,isstaff,createdby} = req.body  
                
                let thisQueryExisting = ` SELECT username FROM users WHERE username = '${username}' `
                const nameExisting = await db.query(thisQueryExisting);

                console.log('nameExisting', nameExisting[0][0]?.name);

                if (nameExisting[0][0]?.name) {
                    res.status(403).send({
                        status : false,
                        message : `Username already exists`
                    })
                } else {
                    const hash = await bcrypt.hash(req.body.password, saltRounds);
                    req.body.password = hash;

                    let thisQuery = ` INSERT INTO users (username, password, email, mobileno, role, isstaff, status, createdAt, updatedAt, createdby, updatedby) VALUES ('${username}', '${req.body.password}', '${email || ''}', '${mobileno || ''}','${role || 52}', '${isstaff}','1', '${formattedDateTime}', '${formattedDateTime}', '${createdby ? createdby : 0}', '${createdby ? createdby : 0}') `

                    const data = await db.query(thisQuery);

                    let thisQuery1 = ` INSERT INTO userrolemap (userid, roleid,status, createdon, createdby, lastmodifiedat, lastmodifiedby) VALUES ('${data[0]}','${role || 52}','1', '${formattedDateTime}', '${createdby ? createdby : 0}', '${formattedDateTime}', '${createdby ? createdby : 0}') `

                    const data1 = await db.query(thisQuery1);
            
                    console.log('Users added successfully', data[0]);
                    res.status(200).send({
                        status : true,
                        message : `Users added successfully`
                    })
                }
            }
            else if (mastername == 'school') {

                const {schoolcode, mobileno, name, address, email,createdAt, gradeid, createdby, updatedAt, updatedby, status} = req.body

                const { error } = schema.validate(req.body);
                console.log('Schema error', error);
                
                if (error) {
                    res.status(400).send({ 
                        status:false,
                        message: error.details[0].message                
                    });
                }
                else {
                console.log('gradeid', gradeid.length);
                const gradeidArray = gradeid.length == 0 ? 0 : gradeid;
                console.log('gradeidArray', gradeidArray);
                
                let thisQueryExisting = ` SELECT schoolcode FROM school WHERE schoolcode = '${schoolcode}' `
                const nameExisting = await db.query(thisQueryExisting);

                console.log('nameExisting', nameExisting[0][0]?.schoolcode);

                if (nameExisting[0][0]?.schoolcode) {
                    res.status(403).send({
                        status : false,
                        message : `School code already exists`
                    })
                } else {
                    let thisQuery = ` INSERT INTO school (schoolcode, mobileno, name, address, email, createdAt, createdby, updatedAt, updatedby, status) VALUES ('${schoolcode}', '${mobileno}', '${name}','${address}', '${email}', '${formattedDateTime}', '${createdby ? createdby : 0 }', '${formattedDateTime}', '${createdby ? createdby : 0}', '1') `

                    const data = await db.query(thisQuery);

                    if (gradeidArray != 0 ) {

                        for (const gradeId of gradeidArray) {
                            let thisQuery = ` INSERT INTO schoolgrademap (schoolid, gradeid) VALUES ('${data[0]}', '${gradeId}') `
                            const data1 = await db.query(thisQuery);
                        }
                    }
            
                    console.log('School added successfully', data[0]);
                    res.status(200).send({
                        status : true,
                        message : `School added successfully`
                    })
                }
                }
            }
            else if (mastername == 'weightmasters') {

                const {startweightrange, endweightrange, charge} = req.body     
                // let thisQueryExisting = ` SELECT weight FROM weightmasters WHERE weight = '${weight}' `
                // const nameExisting = await db.query(thisQueryExisting);

                // console.log('nameExisting', nameExisting[0][0]?.weight);

                // if (nameExisting[0][0]?.weight) {
                //     res.status(403).send({
                //         status : false,
                //         message : `Weight already exists`
                //     })
                // } else {           
                    let thisQuery = ` INSERT INTO weightmasters (startweightrange, endweightrange, charge) VALUES ('${startweightrange}','${endweightrange}', '${charge}') `
                    const data = await db.query(thisQuery);
            
                    console.log('Weight masters added successfully', data[0]);
                    res.status(200).send({
                        status : true,
                        message : `Weight masters successfully`
                    })
                // }
            }
            else if (mastername == 'color' || 'size' || 'category' || 'grade' || 'gender') {

                const {name} = req.body  
                const mainMasterName = mastername == 'color' ? 'color' : mastername == 'size' ? 'size' : mastername == 'category' ? 'category' : mastername == 'grade' ? 'grade' : mastername == 'gender' ? 'gender' : ''
                console.log('mainMasterName', mainMasterName);

                let thisQueryExisting = ` SELECT name FROM ${mainMasterName} WHERE name = '${name}' `
                const nameExisting = await db.query(thisQueryExisting);

                console.log('nameExisting', nameExisting[0][0]?.name);

                if (nameExisting[0][0]?.name) {
                    res.status(403).send({
                        status : false,
                        message : `${name} already exists in ${mainMasterName} masters`
                    })
                } else {

                    let thisQuery = ` INSERT INTO ${mainMasterName} (name) VALUES ('${name}') `
                    const data = await db.query(thisQuery);
            
                    console.log(`${mainMasterName} masters added successfully`, data[0]);
                    res.status(200).send({
                        status : true,
                        message : `${mainMasterName} masters successfully`
                    })
                }
            }
            else {
                console.log(`masters failed to add`);
                res.status(400).send({
                    status : false,
                    message : `masters failed to add`
                })
            }
        }
    }

        await db.query('COMMIT');
    } 
    catch (error) {
        console.log('Internal Server Error', error.errors[0].message);
        await db.query('ROLLBACK');
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};
// Update Masters
export const EditMasters = async (req, res) => {
    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
    await db.query('START TRANSACTION');

    try {
        
        const { ...fields } = req.body;
        const mastername = req.params.mastername;
        const ID = req.params.id;

        console.log('Params : ', mastername, 'ID :', ID);

        let thisQueryCheckP = `SELECT COLUMN_NAME 
        FROM INFORMATION_SCHEMA.COLUMNS 
        WHERE TABLE_NAME = '${mastername}' `;
        
        const columnDataCheck = await db.query(thisQueryCheckP);
        console.log('columnDataCheck', columnDataCheck[0][0]);

        if(!columnDataCheck[0][0]) {
            console.log(`masters name not found`);
            res.status(404).send({
                status : false,
                message : `masters name not found`
            })

        } else {    
        let thisQueryP = `SELECT COLUMN_NAME 
        FROM INFORMATION_SCHEMA.COLUMNS 
        WHERE TABLE_NAME = '${mastername}' 
        AND COLUMN_NAME IN (
        ${
        mastername == 'gst' ? "'name'" : 
        mastername == 'users' ? "''" :
        mastername == 'weightmasters' ? "'charge'" :
        mastername == 'color' || 'size' || 'category' || 'grade' || 'gender' ? "'name'" :
        ''})`;
        const columnData = await db.query(thisQueryP);   

        const uniqueColumnNames = [...new Set(columnData[0].map(item => item.COLUMN_NAME))];

        const fieldsToCheck = Object.keys(fields);
        console.log('uniqueColumnNames', uniqueColumnNames); 
        console.log('fieldsToCheck', fieldsToCheck);
        
        // const missingFields = fieldsToCheck.filter(field => !uniqueColumnNames.includes(field));     
        const missingFields = uniqueColumnNames.filter(field => !fieldsToCheck.includes(field));
        console.log('missingFields', missingFields);

        if (missingFields.length > 0) {
            res.status(400).send({
                status : false,
                message : `The following ${mastername} fields are missing : ${missingFields.join(', ')}`
            })
        } 
        else {

            if (mastername == 'gst') {

                const {name,tax,createdby} = req.body  
                
                let thisQueryExisting = ` SELECT name FROM gst WHERE name = '${name}' AND id != ${ID}`
                const nameExisting = await db.query(thisQueryExisting);

                console.log('nameExisting', nameExisting[0][0]?.name);

                if (nameExisting[0][0]?.name) {
                    res.status(403).send({
                        status : false,
                        message : `GST name already exists`
                    })
                } else {

                    // let thisQuery = ` UPDATE gst SET ${!name ? '' : 'name = ' `${name}`}, ${!cgst ? '' : 'cgst = '  `${cgst}`}, ${!sgst ? '' : 'sgst = ' `${sgst}`}, ${!igst ? '' : 'igst = ' `${igst}`}, lastmodifiedon = '${formattedDateTime}' WHERE id = ${ID} `

                    let thisQuery = `
                    UPDATE gst 
                    SET 
                    ${name ? `name = '${name}',` : ''}
                    ${tax ? `tax = '${tax}',` : ''}
                    lastmodifiedon = '${formattedDateTime}' 
                    WHERE id = ${ID}
                    `;

                    const data = await db.query(thisQuery);
            
                    console.log('GST updated successfully', data[0]);
                    res.status(200).send({
                        status : true,
                        message : `GST updated successfully`
                    })
                }
            }
            else if (mastername == 'users') {

                const {username,password,email,mobileno,role,isstaff, createdby} = req.body     
                let thisQueryExisting = ` SELECT username FROM users WHERE username = '${username}' AND userid != ${ID} `
                const nameExisting = await db.query(thisQueryExisting);

                console.log('nameExisting', nameExisting[0][0]?.username);

                if (nameExisting[0][0]?.username) {
                    res.status(403).send({
                        status : false,
                        message : `Username already exists`
                    })
                } else {          
                    
                    if(password) {
                        const hash = await bcrypt?.hash(req.body.password, saltRounds);
                        req.body.password = hash;
                    }
                   
                    let thisQuery = `
                    UPDATE users 
                    SET 
                    ${username ? `username = '${username}', ` : ''}
                    ${password ? `password = '${req.body.password}', ` : ''}
                    ${email ? `email = '${email}', ` : ''}
                    ${mobileno ? `mobileno = '${mobileno}', ` : ''}
                    ${role ? `role = '${role || 52}', ` : ''}
                    ${isstaff ? `isstaff = '${isstaff}', ` : ''}
                    updatedAt = '${formattedDateTime}'
                    WHERE userid = ${ID}
                    `;
                    const data = await db.query(thisQuery);

                    let thisQuery1 = `
                    UPDATE userrolemap 
                    SET 
                    ${role ? `roleid = '${role || 52}', ` : ''}
                    lastmodifiedby = '${createdby || 0}',
                    lastmodifiedat = '${formattedDateTime}'
                    WHERE userid = ${ID}
                    `;
                    const data1 = await db.query(thisQuery1);
            
                    console.log('User updated successfully', data[0]);
                    res.status(200).send({
                        status : true,
                        message : `User updated successfully`
                    })
                }
            }
            else if (mastername == 'weightmasters') {

                const {startweightrange,endweightrange,charge} = req.body     
                // let thisQueryExisting = ` SELECT weight FROM weightmasters WHERE weight = '${weight}' AND id != ${ID} `
                // const nameExisting = await db.query(thisQueryExisting);

                // console.log('nameExisting', nameExisting[0][0]?.weight);

                // if (nameExisting[0][0]?.weight) {
                //     res.status(403).send({
                //         status : false,
                //         message : `Weight already exists`
                //     })
                // } else {           
                    // let thisQuery = ` UPDATE weightmasters SET weight '${weight}', charge = '${charge}' WHERE id = ${ID} `
                    // const data = await db.query(thisQuery);

                    let thisQuery = `
                    UPDATE weightmasters 
                    SET 
                    ${startweightrange ? `startweightrange = '${startweightrange}',` : ''}
                    ${endweightrange ? `endweightrange = '${endweightrange}',` : ''}
                    ${charge ? `charge = '${charge}' ` : ''}
                    WHERE id = ${ID}
                    `;
                    const data = await db.query(thisQuery);
            
                    console.log('Weight masters updated successfully', data[0]);
                    res.status(200).send({
                        status : true,
                        message : `Weight masters updated successfully`
                    })
                // }
            }
            else if (mastername == 'school') {

                const {schoolcode, mobileno, name, address, email,createdAt, gradeid, createdby, updatedAt, updatedby, status} = req.body 

                const { error } = schema.validate(req.body);

                if (error) {
                    res.status(400).send({ 
                        status:false,
                        message: error.details[0].message                
                    });
                }
                else {

                let thisQueryExisting = ` SELECT schoolcode FROM school WHERE schoolcode = '${schoolcode}' AND schoolid != ${ID} `
                const nameExisting = await db.query(thisQueryExisting);

                console.log('nameExisting', nameExisting[0][0]?.schoolcode);

                console.log('gradeid', gradeid.length);
                const gradeidArray = gradeid.length == 0 ? 0 : gradeid;

                if (nameExisting[0][0]?.schoolcode) {
                    res.status(403).send({
                        status : false,
                        message : `School code already exists`
                    })
                } else {           

                    let thisQuery = `
                    UPDATE school 
                    SET 
                    ${schoolcode ? `schoolcode = '${schoolcode}',` : ''}
                    ${mobileno ? `mobileno = '${mobileno}',` : ''}
                    ${name ? `name = '${name}',` : ''}
                    ${address ? `address = '${address}',` : ''}
                    ${email ? `email = '${email}',` : ''}
                    updatedAt = '${formattedDateTime}' 
                    WHERE schoolid = ${ID}
                    `;
                    const data = await db.query(thisQuery);

                    // if (gradeidArray != 0 ) {
                    //     for (let i = 0; i < gradeidArray.length; i++) {
                    //         const currentGradeId = i + 1;
                    //         const newGradeId = gradeidArray[i];
                            
                    //         let checkQuery = `
                    //             SELECT COUNT(*) as count 
                    //             FROM schoolgrademap 
                    //             WHERE schoolid = ${ID} AND gradeid = ${currentGradeId}
                    //         `;
                            
                    //         const checkData = await db.query(checkQuery);
                    //         console.log('checkData', checkData);
                            
                            
                    //         if (checkData[0][0].count > 0) {
                    //             let updateQuery = `
                    //                 UPDATE schoolgrademap 
                    //                 SET gradeid = ${newGradeId} 
                    //                 WHERE schoolid = ${ID} AND gradeid = ${currentGradeId}
                    //             `;
                    //             await db.query(updateQuery);
                    //         } else {
                    //             let insertQuery = `
                    //                 INSERT INTO schoolgrademap (schoolid, gradeid)
                    //                 VALUES (${ID}, ${newGradeId})
                    //             `;
                    //             await db.query(insertQuery);
                    //         }
                    //     }
                    // }
                    if (gradeidArray && gradeidArray.length > 0) {
                        let fetchQuery = `SELECT * FROM schoolgrademap WHERE schoolid = ${ID}`;
                        const [existingMappings] = await db.query(fetchQuery);
                        const schoolGradeMap = existingMappings.map(row => ({ id: row.id, gradeid: row.gradeid }));
                    
                        for (let i = 0; i < gradeidArray.length; i++) {
                            const currentGradeId = i + 1;
                            const newGradeId = gradeidArray[i];
                            const mapping = schoolGradeMap.find(map => map.gradeid === currentGradeId);
                    
                            if (mapping) {
                                // let updateQuery = `
                                //     UPDATE schoolgrademap 
                                //     SET gradeid = ${newGradeId} 
                                //     WHERE schoolid = ${ID} AND id = ${mapping.id}
                                // `;
                                // await db.query(updateQuery);
                            } else {
                                let insertQuery = `
                                    INSERT INTO schoolgrademap (schoolid, gradeid)
                                    VALUES (${ID}, ${newGradeId})
                                `;
                                await db.query(insertQuery);
                            }
                        }
                    }
                    console.log('School updated successfully', data[0]);
                    res.status(200).send({
                        status : true,
                        message : `school updated successfully`
                    })
                }
                }
            }
            else if (mastername == 'color' || 'size' || 'category' || 'grade' || 'gender') {

                const {name} = req.body  
                const mainMasterName = mastername == 'color' ? 'color' : mastername == 'size' ? 'size' : mastername == 'category' ? 'category' : mastername == 'grade' ? 'grade' : mastername == 'gender' ? 'gender' : ''
                console.log('mainMasterName', mainMasterName);

                let thisQueryExisting = ` SELECT name FROM ${mainMasterName} WHERE name = '${name}' AND id != ${ID} `
                const nameExisting = await db.query(thisQueryExisting);

                console.log('nameExisting', nameExisting[0][0]?.name);

                if (nameExisting[0][0]?.name) {
                    res.status(403).send({
                        status : false,
                        message : `${name} already exists in ${mainMasterName} masters`
                    })
                } else {

                    let thisQuery = ` UPDATE ${mainMasterName} SET name = '${name}' WHERE id = ${ID} `
                    const data = await db.query(thisQuery);
            
                    console.log(`${mainMasterName} masters updated successfully`, data[0]);
                    res.status(200).send({
                        status : true,
                        message : `${mainMasterName} masters updated successfully`
                    })
                }
            }
            else {
                console.log(`masters failed to update`);
                res.status(400).send({
                    status : false,
                    message : `masters failed to update`
                })
            }
        }
        }
        await db.query('COMMIT');
    } 
    catch (error) {
        console.log(error);
        await db.query('ROLLBACK');
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};
// Get Masters
export const GetMasters = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

    const mastername = req.params.mastername;
    const filters = req.query;

    try {

        console.log('Params : ', mastername);

        let thisQueryCheckP = `SELECT COLUMN_NAME 
        FROM INFORMATION_SCHEMA.COLUMNS 
        WHERE TABLE_NAME = '${mastername}' `;
        
        const columnDataCheck = await db.query(thisQueryCheckP);
        console.log('columnDataCheck', columnDataCheck[0][0]);

        if(!columnDataCheck[0][0]) {
            console.log(`masters name not found`);
            res.status(404).send({
                status : false,
                message : `masters name not found`
            })
       
        } else {
            if (mastername == 'gst') {
                const filters = req.query;
                let thisQuery = ` SELECT gst.id, gst.name FROM gst as gst WHERE gst.status != 0 `
                if (filters?.id) { thisQuery += ` AND id = '${filters?.id}' `}
                if (filters?.limit) { thisQuery += ` limit ${filters?.limit},5 `}
                const data = await db.query(thisQuery);
                res.status(200).send({status: true, count: data[0]?.length, message: 'success',data: data[0]});
            }
            else if (mastername == 'weightmasters') {
                const filters = req.query;
                let thisQuery = ` SELECT wm.id, wm.startweightrange, wm.endweightrange, wm.charge FROM weightmasters as wm WHERE wm.id IS NOT NULL `
                if (filters?.id) { thisQuery += ` AND id = '${filters?.id}' `}
                if (filters?.limit) { thisQuery += ` limit ${filters?.limit},5 `}
                const data = await db.query(thisQuery);
                res.status(200).send({status: true, count: data[0]?.length, message: 'success',data: data[0]});
            }
            else if (mastername == 'color') {
                const filters = req.query;
                let thisQuery = ` SELECT col.id, col.name FROM color as col WHERE col.id IS NOT NULL `
                if (filters?.id) { thisQuery += ` AND id = '${filters?.id}' `}
                if (filters?.limit) { thisQuery += ` limit ${filters?.limit},5 `}
                const data = await db.query(thisQuery);
                res.status(200).send({status: true, count: data[0]?.length, message: 'success',data: data[0]});
            }
            else if (mastername == 'size') {
                const filters = req.query;
                let thisQuery = ` SELECT si.id, si.name FROM size as si WHERE si.id IS NOT NULL `
                if (filters?.id) { thisQuery += ` AND id = '${filters?.id}' `}
                if (filters?.limit) { thisQuery += ` limit ${filters?.limit},5 `}
                const data = await db.query(thisQuery);
                res.status(200).send({status: true, count: data[0]?.length, message: 'success',data: data[0]});
            }
            else if (mastername == 'category') {
                const filters = req.query;
                let thisQuery = ` SELECT cat.id, cat.name FROM category as cat WHERE cat.id IS NOT NULL`
                if (filters?.id) { thisQuery += ` AND id = '${filters?.id}' `}
                if (filters?.limit) { thisQuery += ` limit ${filters?.limit},5 `}
                const data = await db.query(thisQuery);
                res.status(200).send({status: true, count: data[0]?.length, message: 'success',data: data[0]});
            }
            else if (mastername == 'gender') {
                const filters = req.query;
                let thisQuery = ` SELECT gen.id, gen.name FROM gender as gen WHERE gen.id IS NOT NULL `
                if (filters?.id) { thisQuery += ` AND id = '${filters?.id}' `}
                if (filters?.limit) { thisQuery += ` limit ${filters?.limit},5 `}
                const data = await db.query(thisQuery);
                res.status(200).send({status: true, count: data[0]?.length, message: 'success',data: data[0]});
            }
            else if (mastername == 'grade') {
                const filters = req.query;
                let thisQuery = ` SELECT gra.id, gra.name FROM grade as gra WHERE gra.id IS NOT NULL `
                if (filters?.id) { thisQuery += ` AND id = '${filters?.id}' `}
                if (filters?.limit) { thisQuery += ` limit ${filters?.limit},5 `}
                const data = await db.query(thisQuery);
                res.status(200).send({status: true, count: data[0]?.length, message: 'success',data: data[0]});
            }
            else if (mastername == 'users') {
                const filters = req.query;
                let thisQuery = ` SELECT us.userid as id, us.password as password,HEX(us.isstaff) as isstaff, us.username as username, us.email as email, us.mobileno as mobileno FROM users as us WHERE us.userid IS NOT NULL `
                if (filters?.id) { thisQuery += ` AND us.userid = '${filters?.id}' `}
                if (filters?.limit) { thisQuery += ` limit ${filters?.limit},5 `}
                const data = await db.query(thisQuery);
                res.status(200).send({status: true, count: data[0]?.length, message: 'success',data: data[0]});
            }
            else if (mastername == 'school') {
                const filters = req.query;
                let thisQuery = ` 
                SELECT sc.schoolid as id, sc.schoolcode, sc.name as name, sc.address as address, sc.email as email, sc.mobileno as mobileno,
                CONCAT('[', GROUP_CONCAT(DISTINCT IFNULL( sgm.gradeid, '')), ']') AS gradeid,
                GROUP_CONCAT(DISTINCT gr.name) as gradename
                FROM school as sc 
                LEFT JOIN schoolgrademap as sgm ON (sc.schoolid = sgm.schoolid)
                LEFT JOIN grade as gr ON (gr.id = sgm.gradeid)
                WHERE sc.schoolid IS NOT NULL
                `
                if (filters?.id) { thisQuery += ` AND sc.schoolid = '${filters?.id}' `}
                thisQuery += `GROUP BY sc.schoolid `
                if (filters?.limit) { thisQuery += ` limit ${filters?.limit},5 `}
                const data = await db.query(thisQuery);
                res.status(200).send({status: true, count: data[0]?.length, message: 'success',data: data[0]});
            }
            else {
                res.status(404).send({status: false, message: 'master name not found'});
            }
        }
      } 
      catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};
// Delete Masters
export const DeleteMasters = async (req, res) => {
    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
    await db.query('START TRANSACTION');

    try {
        const { ...fields } = req.body;
        const mastername = req.params.mastername;
        const ID = req.params.id;

        console.log('Params : ', mastername, 'ID :', ID);
        let thisQueryCheckP = `SELECT COLUMN_NAME 
        FROM INFORMATION_SCHEMA.COLUMNS 
        WHERE TABLE_NAME = '${mastername}' `;
        
        const columnDataCheck = await db.query(thisQueryCheckP);
        console.log('columnDataCheck', columnDataCheck);

        if(!columnDataCheck[0][0]) {
            console.log(`masters name not found`);
            res.status(404).send({
                status : false,
                message : `masters name not found`
            })

        } else {

            if (mastername == 'gst') {

                let thisQueryExisting = ` SELECT id FROM gst WHERE id = ${ID}`
                const nameExisting = await db.query(thisQueryExisting);

                console.log('nameExisting', nameExisting[0][0]?.id);

                if (!nameExisting[0][0]?.id) {
                    res.status(404).send({
                        status : false,
                        message : `GST id : ${ID} not found`
                    })
                } else {

                    let thisQuery = ` DELETE FROM gst WHERE id = ${ID} `;
                    const data = await db.query(thisQuery);
            
                    console.log('GST deleted successfully', data[0]);
                    res.status(200).send({
                        status : true,
                        message : `GST deleted successfully`
                    })
                }
            }
            if (mastername == 'users') {

                let thisQueryExisting = ` SELECT userid FROM users WHERE userid = ${ID}`
                const nameExisting = await db.query(thisQueryExisting);

                console.log('nameExisting', nameExisting[0][0]?.userid);

                if (!nameExisting[0][0]?.userid) {
                    res.status(404).send({
                        status : false,
                        message : `User id : ${ID} not found`
                    })
                } else {

                    let thisQuery = ` DELETE FROM users WHERE userid = ${ID} `;
                    const data = await db.query(thisQuery);
                    let thisQuery1 = ` DELETE FROM userrolemap WHERE userid = ${ID} `;
                    const data1 = await db.query(thisQuery1);
            
                    console.log('User deleted successfully', data[0]);
                    res.status(200).send({
                        status : true,
                        message : `User deleted successfully`
                    })
                }
            }
            else if (mastername == 'weightmasters') {

                let thisQueryExisting = ` SELECT id FROM weightmasters WHERE id = ${ID} `
                const nameExisting = await db.query(thisQueryExisting);

                console.log('nameExisting', nameExisting[0][0]?.id);

                if (!nameExisting[0][0]?.id) {
                    res.status(404).send({
                        status : false,
                        message : `Weight master id : ${ID} not found`
                    })
                } else {           

                    let thisQuery = ` DELETE FROM weightmasters WHERE id = ${ID}`;
                    const data = await db.query(thisQuery);
            
                    console.log('Weight masters deleted successfully', data[0]);
                    res.status(200).send({
                        status : true,
                        message : `Weight masters deleted successfully`
                    })
                }
            }
            else if (mastername == 'school') {

                let thisQueryExisting = ` SELECT schoolid FROM school WHERE schoolid = ${ID} `
                const nameExisting = await db.query(thisQueryExisting);

                console.log('nameExisting', nameExisting[0][0]?.schoolid);

                if (!nameExisting[0][0]?.schoolid) {
                    res.status(404).send({
                        status : false,
                        message : `School id : ${ID} not found`
                    })
                } else {           

                    let thisQuery = ` DELETE FROM school WHERE schoolid = ${ID}`;
                    const data = await db.query(thisQuery);
                    
                    let thisQuery1 = ` DELETE FROM schoolgrademap WHERE schoolid = ${ID}`;
                    const data1 = await db.query(thisQuery1);
            
                    console.log('School deleted successfully', data[0]);
                    res.status(200).send({
                        status : true,
                        message : `School deleted successfully`
                    })
                }
            }
            else if (mastername == 'color' || 'size' || 'category' || 'grade' || 'gender') {

                const {name} = req.body  
                const mainMasterName = mastername == 'color' ? 'color' : mastername == 'size' ? 'size' : mastername == 'category' ? 'category' : mastername == 'grade' ? 'grade' : mastername == 'gender' ? 'gender' : ''
                console.log('mainMasterName', mainMasterName);

                let thisQueryExisting = ` SELECT id FROM ${mainMasterName} WHERE id = ${ID} `
                const nameExisting = await db.query(thisQueryExisting);

                console.log('nameExisting', nameExisting[0][0]?.id);

                if (!nameExisting[0][0]?.id) {
                    res.status(404).send({
                        status : false,
                        message : `${mainMasterName} id : ${ID} not found`
                    })
                } else {

                    let thisQuery = ` DELETE FROM ${mainMasterName} WHERE id = ${ID} `
                    const data = await db.query(thisQuery);
            
                    console.log(`${mainMasterName} masters deleted successfully`, data[0]);
                    res.status(200).send({
                        status : true,
                        message : `${mainMasterName} masters deleted successfully`
                    })
                }
            }
            else {
                console.log(`masters failed to update`);
                res.status(400).send({
                    status : false,
                    message : `masters failed to update`
                })
            }
        // }
        }
        await db.query('COMMIT');
    } 
    catch (error) {
        console.log(error);
        await db.query('ROLLBACK');
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};