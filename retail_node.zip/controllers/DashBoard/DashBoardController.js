import { executeStoredProcedure } from '../../middleware/storeproceduremiddleware.js';
import { formatDateToYYYYMMDD, formatDateTimeToYYYYMMDDHHMMSS } from '../../Utils/Datetime.js';
import moment from 'moment-timezone';
const currentDate = new Date();
const isoDateString = currentDate.toISOString();

const originalMoment = moment(isoDateString);
const originalDate = originalMoment.toDate();

const formattedDate = formatDateToYYYYMMDD(originalDate);
const formattedDateTime = formatDateTimeToYYYYMMDDHHMMSS(originalDate);

//@route      POST /api/v1/DB/AdminTransactionsCount
//@desc       To 
//@access     Private
export const DB_AdminTransactionsCount = async (req, res) => {
    try {
        const { startdate, enddate } = req.body;        
        const DBResults = await executeStoredProcedure('SP_DB_AdminTransactionsCount', [startdate, enddate, '', '']);
        if (DBResults && DBResults.status === true) {
            const Data = JSON.parse(DBResults.data);
            res.status(200).json({ issuccess: true, message: DBResults.message , Data });
        }
        else {
            res.status(400).json({ issuccess: false, message: AdminTransactionsCount.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

//@route      POST /api/v1/DB/SchoolTransactionsCount
//@desc       To 
//@access     Private
export const DB_SchoolTransactionsCount = async (req, res) => {
    try {
        const { schoolid,startdate,enddate} = req.body;        
        const DBResults = await executeStoredProcedure('SP_DB_SchoolTransactionsCount', [schoolid,startdate,enddate, '', '']);
        if (DBResults && DBResults.status === true) {
            const Data = JSON.parse(DBResults.data);
            res.status(200).json({ issuccess: true, message: DBResults.message , Data });
        }
        else {
            res.status(400).json({ issuccess: false, message: DBResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

//@route      POST /api/v1/DB/AdminTransactionsCount
//@desc       To 
//@access     Private
export const DB_AllGetOrderDetails = async (req, res) => {
    try {
        const { index, pageno } = req.body;        
        const DBResults = await executeStoredProcedure('SP_DB_AllGetOrderDetails', [index, pageno, '', '']);
        if (DBResults && DBResults.status === true) {
            const Data = JSON.parse(DBResults.data);
            res.status(200).json({ issuccess: true, message: DBResults.message , Data });
        }
        else {
            res.status(400).json({ issuccess: false, message: DBResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};
//@route      POST /api/v1/DB/AdminTransactionsCount
//@desc       To 
//@access     Private
export const DB_AllGetOrderDetailsByStatus = async (req, res) => {
    try {
        const {  status,pageno ,index} = req.body;              
        const DBResults = await executeStoredProcedure('SP_DB_AllGetOrderDetailsByStatus', [status,pageno , index, '', '']);
        if (DBResults && DBResults.status === true) {
            const Data = JSON.parse(DBResults.data);
            res.status(200).json({ issuccess: true, message: DBResults.message , Data });
        }
        else {
            res.status(400).json({ issuccess: false, message: DBResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};
//@route      POST /api/v1/DB/GetOrderDetailsByOrdernumber
//@desc       To 
//@access     Private
export const DB_GetOrderDetailsByOrdernumber = async (req, res) => {
    try {
        const { userid ,ordernumber} = req.body;        
        const DBResults = await executeStoredProcedure('SP_DB_GetOrderDetailsByOrdernumber', [userid ,ordernumber, '', '']);
        if (DBResults && DBResults.status === true) {
            const Data = JSON.parse(DBResults.data);
            res.status(200).json({ issuccess: true, message: DBResults.message , Data });
        }
        else {
            res.status(400).json({ issuccess: false, message: DBResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};
//@route      POST /api/v1/DB/GetRevenueTrend
//@desc       To 
//@access     Private
export const DB_GetRevenueTrend = async (req, res) => {
    try {
        const { startdate, enddate,status} = req.body;        
        const DBResults = await executeStoredProcedure('SP_DB_GetRevenueTrend', [startdate, enddate,status, '', '']);
        if (DBResults && DBResults.status === true) {
            const Data = JSON.parse(DBResults.data);
            res.status(200).json({ issuccess: true, message: DBResults.message , Data });
        }
        else {
            res.status(400).json({ issuccess: false, message: DBResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};
//@route      POST /api/v1/DB/GetRevenueTrendByDayCount
//@desc       To 
//@access     Private
export const DB_GetRevenueTrendByDayCount = async (req, res) => {
    try {
        const { daycount , status } = req.body;        
        const DBResults = await executeStoredProcedure('SP_DB_GetRevenueTrendByDayCount', [daycount , status, '', '']);
        if (DBResults && DBResults.status === true) {
            const Data = JSON.parse(DBResults.data);
            res.status(200).json({ issuccess: true, message: DBResults.message , Data });
        }
        else {
            res.status(400).json({ issuccess: false, message: DBResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};
//@route      POST /api/v1/DB/GetTopSellingProducts
//@desc       To 
//@access     Private
export const DB_GetTopSellingProducts = async (req, res) => {
    try {
        const { startdate,enddate,limit ,status} = req.body;        
        const DBResults  = await executeStoredProcedure('SP_DB_GetTopSellingProducts', [startdate,enddate,limit,status, '', '']);
        if (DBResults && DBResults.status === true) {
            const Data = JSON.parse(DBResults.data);
            res.status(200).json({ issuccess: true, message: DBResults.message , Data });
        }
        else {
            res.status(400).json({ issuccess: false, message: DBResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};
//@route      POST /api/v1/DB/GetTopSellingProductsByDaycount
//@desc       To 
//@access     Private
export const DB_GetTopSellingProductsByDaycount = async (req, res) => {
    try {
        const { daycount,limit,status} = req.body;        
        const DBResults  = await executeStoredProcedure('SP_DB_GetTopSellingProductsByDayCount', [daycount,limit,status, '', '']);
        if (DBResults && DBResults.status === true) {
            const Data = JSON.parse(DBResults.data);
            res.status(200).json({ issuccess: true, message: DBResults.message , Data });
        }
        else {
            res.status(400).json({ issuccess: false, message: DBResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};
//@route      POST /api/v1/DB/GetTransactionStatus_Chart
//@desc       To 
//@access     Private
export const DB_GetTransactionStatusDistribution = async (req, res) => {
    try {
        const { startdate,enddate,limit} = req.body;        
        const DBResults = await executeStoredProcedure('SP_DB_GetTransactionStatusDistribution', [startdate,enddate,limit, '', '']);
        if (DBResults && DBResults.status === true) {
            const Data = JSON.parse(DBResults.data);
            res.status(200).json({ issuccess: true, message: DBResults.message , Data });
        }
        else {
            res.status(400).json({ issuccess: false, message: DBResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};
