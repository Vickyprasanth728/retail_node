import { executeStoredProcedure } from '../../middleware/storeproceduremiddleware.js';
import { formatDateToYYYYMMDD, formatDateTimeToYYYYMMDDHHMMSS } from '../../Utils/Datetime.js';
import moment from 'moment-timezone';
const currentDate = new Date();
const isoDateString = currentDate.toISOString();
import crypto from 'crypto';

const originalMoment = moment(isoDateString);
const originalDate = originalMoment.toDate();

const formattedDate = formatDateToYYYYMMDD(originalDate);

const formattedDateTime = formatDateTimeToYYYYMMDDHHMMSS(originalDate);

import { db } from '../../config/Database.js';
import path from 'path';
import fs from 'fs';
import mailer from '../../middleware/mailer.model.js';

import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// msarun1999@gmail.com
// $2b$10$YGWT6TQcPT0KoKHco4esTeX.Jo3Bhtj8zV1rudd1VUCdiS2bHPKe6

// Get Order Summary
export const getordersummary = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

    try {
        const filters = req.query;

        const {userid} = req.body
        
        let thisQueryProduct = `
        SELECT COUNT(DISTINCT productid) as product_count
        FROM addtocarttable
        WHERE userid = '${userid}' AND status != 'Ordered'
        `
        const productCountResult = await db.query(thisQueryProduct);
        const productCheck = productCountResult[0][0] ? productCountResult[0][0]?.product_count : 0
    
        if (productCheck != 0) {
            
            let thisQueryOrderSummary = `
            SELECT
            p.productid as productid,
            p.name as name,
            p.description as description,
            COALESCE(v.weight, 0) AS weight,
            (atc.quantity * v.weight) as total_WQ,
            v.id AS variantid,
            p.gst as gst_id,
            gst.name as gst_name,
            gst.tax as gst_tax,
            CAST(COALESCE(v.price, 0) AS SIGNED) AS price,
            COALESCE(atc.quantity, 0) AS quantity,
            (
                SELECT JSON_ARRAYAGG(
                    JSON_OBJECT(
                        'image', pi.image,
                        'imageseq', pi.imageseq,
                        'productid', pi.productid
                    )
                )
                FROM productimage as pi
                WHERE pi.productid IN (p.productid) AND pi.imageseq = 1
                GROUP BY pi.productid

            ) AS images

            FROM addtocarttable AS atc
            LEFT JOIN product AS p ON (atc.productid = p.productid)
            LEFT JOIN variant AS v ON (v.id = atc.variantid)
            LEFT JOIN gst as gst on (gst.id = p.gst)
            WHERE atc.userid = '${userid}' ${filters?.status ? `AND atc.status = '${filters?.status}' ` : `AND atc.status != 'Ordered'`} AND p.productid IS NOT NULL
            GROUP BY atc.atcartid
            `
            const orderSummary = await db.query(thisQueryOrderSummary);

            const totalWQ = orderSummary[0].reduce((sum, item) => sum + item.total_WQ, 0);
            console.log('Total of all total_WQ values:', totalWQ);

            // const shippingChargeQuery = `
            // SELECT charge FROM weightmasters WHERE weight <= ${totalWQ} ORDER BY weight DESC LIMIT 1`;
            const shippingChargeQuery = `
            SELECT id, charge 
            FROM weightmasters 
            WHERE ${totalWQ} BETWEEN startweightrange AND endweightrange 
            ORDER BY id DESC 
            LIMIT 1 `
            const shippingChargeResult = await db.query(shippingChargeQuery);
            const shippingCharge = shippingChargeResult[0][0] ? shippingChargeResult[0][0]?.charge : 0;
            console.log('shippingCharge', shippingCharge);
            
            res.status(200).send({
                status: true,
                count: orderSummary[0]?.length,
                total_weight:totalWQ,
                shipping_charge: shippingCharge,
                message: 'Order summary retrieved successfully',
                data: orderSummary[0]
            });

        } else {
            res.status(404).send({
                status: false,
                message: 'No Data Found',
            });
        }
    } 
    catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
    
};
// Get Order Details
export const getOrderDetails = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

    try {

        const filters = req.query
        const UserID = filters?.userid || 0

        let thisQueryCheckUserExists = `SELECT id FROM transactions WHERE userid = '${filters?.userid}' LIMIT 1`;
        const userExists = await db.query(thisQueryCheckUserExists);

        const userExistCheck = userExists[0][0] ? userExists[0][0]?.id : 0
        console.log('userExistCheck', userExistCheck);

        if (userExistCheck == 0 || !userExistCheck) {
            return res.status(404).json({
                status: false,
                message: 'This user has no orders'
            });
        }

        let thisQuery = `
        SELECT 
        tra.*,
        tra.productid as trans_product_id,
        tra.variant as variantid,
        DATE_FORMAT(tra.createdon, '%Y-%m-%d %H:%i:%s') as createdon,
        (JSON_ARRAY(
                JSON_OBJECT(
                    'productid', p.productid,
                    'name', p.name,
                    'description', p.description,
                    'price', v.price,
                    'quantity', tra.quantity
                )
            )
        ) AS product_details,
        (JSON_ARRAY(
                JSON_OBJECT(
                    'image', pi.image,
                    'imageseq', pi.imageseq,
                    'productid', pi.productid
                )
            )
        ) AS image_details,
         (JSON_ARRAY(
                JSON_OBJECT(
                    'id', v.id,
                    'size', v.size,
                    'color', v.color,
                    'price', v.price,
                    'quantity', v.quantity,
                    'weight', v.weight
                )
            )
        ) AS variant_details,
         (JSON_ARRAY(
                JSON_OBJECT(
                    'ccavenue_transid', tb.ccavenue_transid,
                    'status', tb.status,
                    'tpricegst', tb.tpricegst,
                    'tweight', tb.tweight,
                    'shipping_charges', tb.shipping_charges,
                    'type', tb.type,
                    'actual_price', tb.actual_price,
                    'transaction_price', tb.transaction_price,
                    'payment_type', tb.payment_type
                )
            )
        ) AS billing_details,
        (
            SELECT 
                JSON_OBJECT(
                    'addressid', COALESCE(ad.addressid,''),
                    'address_name', COALESCE(ad.name,''),
                    'fullAddress', COALESCE(ad.fullAddress,''),
                    'locationDetails', COALESCE(ad.locationDetails,''),
                    'landmark', COALESCE(ad.landmark,''),
                    'city', COALESCE(ad.city,''),
                    'state', COALESCE(ad.state,''),
                    'country', COALESCE(ad.country,''),
                    'pincode', COALESCE(ad.pincode,''),
                    'email', COALESCE(ad.email,''),
                    'mobileno', COALESCE(ad.mobileno,''),
                    'alternatemobileno', COALESCE(ad.alternatemobileno,'')
                )
            FROM address as ad
            WHERE ad.addressid IN (tra.addressid)
            GROUP BY ad.addressid
        ) AS address_details
        
        FROM transactions as tra
        LEFT JOIN transaction_billing as tb ON (tb.id = tra.childbillid)
        LEFT JOIN users as us ON (us.userid = tra.userid)
        LEFT JOIN product as p ON (tra.productid = p.productid)
        LEFT JOIN variant as v ON (v.id = tra.variant)
        LEFT JOIN productimage pi ON (pi.productid = p.productid AND pi.imageseq = 1)
        LEFT JOIN address ad ON (ad.addressid = tra.addressid)
        LEFT JOIN gst as gst ON (gst.id = tra.gst_id)
        WHERE tra.id IS NOT NULL
        `
        if (filters?.userid) {
            thisQuery += ` AND tra.userid = '${filters?.userid}' `
        }
        if (filters?.billid) {
            thisQuery += ` AND tra.childbillid = '${filters?.billid}' `
        }

        thisQuery += ` 
        GROUP BY tra.id
        ORDER BY MAX(tra.lastmodifiedat) DESC
        `
        if (filters?.limit) {
            thisQuery += ` limit ${filters?.limit},10 `
        }

        const orders = await db.query(thisQuery);

        return res.status(200).json({
            status: true,
            count:orders[0].length,
            message: 'Order details retrieved successfully',
            data: orders[0]
        });

    } catch (error) {
        console.log('error', error);
        return res.status(500).json({
            status: false,
            message: error.message || 'Internal Server Error'
        });
    }

};
// Get Exchange Transaction
export const getExchangeTransaction = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
    await db.query('START TRANSACTION');

    const TransID = req.params.transactionid;
    const variantID = req.body.variantid;

    try {

        const filters = req.query

        console.log('variantID', variantID);
        
        let newBillID;
        let newTransID;

        if (variantID != undefined) {
            let thisQueryVarQuery = ` UPDATE transactions SET variant = '${variantID}' WHERE transid = '${TransID}' `;
            const varUpdate = await db.query(thisQueryVarQuery);

            let billingInsertQuery = ` INSERT INTO transaction_billing (status, ccavenue_transid) VALUES ('Initiated', ${null})`;
            const billingResult = await db.query(billingInsertQuery);
            newBillID = billingResult[0];

            let thisQueryVarQuery1 = `INSERT INTO transactions (childbillid, variant, online) VALUES ('${newBillID}', '${variantID}', 1) `
            const transResult = await db.query(thisQueryVarQuery1);
            newTransID = transResult[0];
        } 

        let thisQueryCheckUserExists = `SELECT id FROM transactions WHERE transid = '${TransID}' LIMIT 1`;
        const userExists = await db.query(thisQueryCheckUserExists);

        const userExistCheck = userExists[0][0] ? userExists[0][0]?.id : 0
        console.log('userExistCheck', userExistCheck);

        if (userExistCheck == 0 || !userExistCheck) {
            return res.status(404).json({
                status: false,
                message: 'There is no transaction'
            });
        }

        let thisQuery = `
        SELECT 
        tra.*,
        tra.variant as variantid,
        DATE_FORMAT(tra.createdon, '%Y-%m-%d %H:%i:%s') as createdon,
        COALESCE(p.weight, 0) AS weight,
        p.name as name,
        p.description as description,
        gst.name as gst_name,
        gst.tax as gst_tax,
        CAST(COALESCE(v.price, 0) AS SIGNED) AS price,
        (JSON_ARRAY(
                JSON_OBJECT(
                    'ccavenue_transid', tb.ccavenue_transid,
                    'status', tb.status,
                    'tpricegst', tb.tpricegst,
                    'tweight', tb.tweight,
                    'shipping_charges', tb.shipping_charges,
                    'type', tb.type,
                    'actual_price', tb.actual_price,
                    'transaction_price', tb.transaction_price,
                    'payment_type', tb.payment_type
                )
            )
        ) AS billing_details,
        (
            SELECT JSON_ARRAY(
                JSON_OBJECT(
                    'image', pi.image,
                    'imageseq', pi.imageseq,
                    'productid', pi.productid
                )
            )
            FROM productimage as pi
            WHERE pi.productid IN (p.productid) AND pi.imageseq = 1
            GROUP BY pi.productid
        ) AS images


        FROM transactions as tra
        LEFT JOIN transaction_billing as tb ON (tb.id = tra.childbillid)
        LEFT JOIN product AS p ON (p.productid = tra.productid)
        LEFT JOIN variant AS v ON (v.id = tra.variant)
        LEFT JOIN gst as gst ON (gst.id = tra.gst_id)
        WHERE tra.transid = '${TransID}'
        `

        thisQuery += ` 
        GROUP BY tra.id
        ORDER BY MAX(tra.lastmodifiedat) DESC
        `
        const exchangeData = await db.query(thisQuery);
        console.log('exchangeData', exchangeData[0]);

        const paymentLink = `https://www.ccavenue.com/payment?bill_id=${newBillID}`; // Mock URL

            res.status(200).send({
                status: true,
                message: 'Exchange details listed successfully',
                paymentLink: paymentLink,
                billid_new: newBillID,
                transid_new: newTransID,
                data: exchangeData[0]
            });
        await db.query('COMMIT');

            
    } catch (error) {
        console.log('error', error);
        res.status(500).json({
            status: false,
            message: 'Internal Server Error',
            error: error.message,
        });

        await db.query('ROLLBACK');
    }

};
// Buy Now
export const buyNow = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
    await db.query('START TRANSACTION');

    try {
        const { userid, transactionid, addressid, quantity, variantid, tax_amount, gst_id, shipping_charges, total_amount, status } = req.body;

        const productid = req.body.productid
        console.log('productid', productid);
        
        let userCheckQuery = `SELECT userid FROM users WHERE userid = '${userid}' LIMIT 1`;
        const userCheckData = await db.query(userCheckQuery);
        const userExists = userCheckData[0][0] ? userCheckData[0][0]?.userid : 0

        console.log('userExists', userExists);
    
        if (userExists == 0 || !userExists) {
            console.log('User-ID not found');
            return res.status(404).send({
                status: false,
                message: 'User-ID not found',
            });
        }
    
        let productCheckQuery = `SELECT productid FROM product WHERE productid IN (${productid}) LIMIT 1`;
        const productCheckData = await db.query(productCheckQuery);
        const productExists = productCheckData[0][0] ? productCheckData[0][0]?.productid : 0

        console.log('productExists', productExists);

        if (productExists == 0 || !productExists) {
            console.log('Product-ID not found');
            return res.status(404).send({
                status: false,
                message: 'Product-ID not found',
            });
        }

        let variantQuery = ` SELECT * FROM variant WHERE id IN (${variantid || 0}) `
        const variantID = await db.query(variantQuery);
        console.log('variantID data', variantID[0]);  

        const variantCheck = variantID[0][0] ? variantID[0][0]?.id : 0
        const variantPrice = variantID[0][0] ? variantID[0][0]?.price : 0

        if (variantCheck == 0 || !variantCheck) {
            console.log('Variant-ID not found');
            return res.status(404).send({
                status: false,
                message: 'Variant-ID not found',
            });
        }

        let transIdQuery = `SELECT * FROM transactions WHERE transid = '${transactionid}' `;
        const transQuery = await db.query(transIdQuery);
        const transQueryInsert = transQuery[0][0] ? transQuery[0][0]?.transid : 0
        const transQueryProduct = transQuery[0][0] ? transQuery[0][0]?.productid : 0

        console.log('transQueryInsert', transQueryInsert);
        console.log('transQueryProduct', transQueryProduct);

        if (productid != transQueryProduct) {
            console.log('Exchanging with a different product is not allowed');
            return res.status(400).send({
                status: false,
                message: 'Exchanging with a different product is not allowed',
            });
        }

        // space for payment confirmations

        const today = new Date().toISOString().slice(0, 10);
        console.log('today', today);

        let counterQuery = `
        INSERT INTO daily_reset_counter (counter_date, counter_value) VALUES ('${today}', 1) ON DUPLICATE KEY UPDATE counter_value = counter_value + 1 `;
        const counterInsert = await db.query(counterQuery);
    
        let counterSelectQuery = `SELECT counter_value FROM daily_reset_counter WHERE counter_date = '${today}' `;
        const counterData = await db.query(counterSelectQuery);
        const counterValue = counterData[0][0] ? counterData[0][0]?.counter_value : 0
        console.log('counterValue', counterValue);

        const orderNumber = `2CQR-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
        const transId = `Trans-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;

        console.log('orderNumber', orderNumber);
        console.log('transId', transId);

        const gstArray = gst_id[0]
        const taxAmountArray = tax_amount[0]
        
        let transactionInsertQuery = `
        INSERT INTO transactions (productid, userid, transid, addressid, ordernumber, quantity, variant, gst_id, status, online) VALUES ('${productid}', '${userid}', '${transId}', '${addressid}', '${orderNumber}', '${quantity}','${variantid}', '${gstArray}', '${status}', 1)`;
        const transactionResult = await db.query(transactionInsertQuery);

        console.log('transactionResult', transactionResult);

        let transactionBillingQuery = `
        INSERT INTO transaction_billing (trans_id, gst_id, tax_amount, price, shipping_charges, total_amount, createdon, lastmodifiedate) VALUES ('${transId}', '${gstArray}', '${taxAmountArray}', '${variantPrice}', '${shipping_charges}', '${total_amount}', '${formattedDateTime}', '${formattedDateTime}')`;
        const transactionResultBilling = await db.query(transactionBillingQuery);

        console.log('transactionResultBilling', transactionResultBilling);

        let transactionLogQuery = `
        INSERT INTO transactionlog (transtableid, status, createdby) VALUES ('${transactionResult[0]}', '${status}', '${userid}')`;
        const transactionResultLog = await db.query(transactionLogQuery);
        
        console.log('transactionResultLog', transactionResultLog);
        console.log('Transaction inserted successfully'); 

        let variant = variantID[0]?.find(variant => variant.id === variantid);
        
        if (variant) {
            variant.quantity -= quantity;                
            variant.quantity = Math.max(0, variant.quantity);
        }
        
        console.log('finalArray[0]',variantID[0]);

        let variantQuantityQuery = `UPDATE variant SET quantity = '${variantID[0][0]?.quantity}' WHERE id = '${variantID[0][0]?.id}' `
        const variantUpdate = await db.query(variantQuantityQuery);

        const transArrayID = transactionResult?.length != 0 ? transactionResult.join(',') : 0
        console.log('transArrayID', transArrayID);

        let thisQueryOrd = `
        SELECT 
        tra.id,
        tra.transid,
        tra.productid,
        tra.userid,
        us.username,
        tra.ordernumber,
        tra.status,
        tra.createdon,
        tra.quantity, 
        tra.productid as trans_product_id,
        (JSON_ARRAYAGG(
                JSON_OBJECT(
                    'productid', p.productid,
                    'name', p.name,
                    'description', p.description,
                    'price', v.price,
                    'quantity', tra.quantity
                )
            )
        ) AS product_details,
          (JSON_ARRAYAGG(
                JSON_OBJECT(
                    'trans_id', tb.trans_id,
                    'tax_amount', tb.tax_amount,
                    'gst_id', tb.gst_id,
                    'price', tb.price,
                    'shipping_charges', tb.shipping_charges,
                    'total_amount', tb.total_amount,
                    'name', gst.name,
                    'tax', gst.tax
                )
            )
        ) AS billing_details,
        (JSON_ARRAYAGG(
                JSON_OBJECT(
                    'image', pi.image,
                    'imageseq', pi.imageseq,
                    'productid', pi.productid
                )
            )
        ) AS image_details,
        (
            SELECT 
                JSON_OBJECT(
                    'addressid', COALESCE(ad.addressid,''),
                    'address_name', COALESCE(ad.name,''),
                    'fullAddress', COALESCE(ad.fullAddress,''),
                    'locationDetails', COALESCE(ad.locationDetails,''),
                    'landmark', COALESCE(ad.landmark,''),
                    'city', COALESCE(ad.city,''),
                    'state', COALESCE(ad.state,''),
                    'country', COALESCE(ad.country,''),
                    'pincode', COALESCE(ad.pincode,''),
                    'email', COALESCE(ad.email,''),
                    'mobileno', COALESCE(ad.mobileno,''),
                    'alternatemobileno', COALESCE(ad.alternatemobileno,'')
                )
            FROM address as ad
            WHERE ad.addressid IN (tra.addressid)
            GROUP BY ad.addressid
        ) AS address_details
        
        FROM transactions as tra
        LEFT JOIN transaction_billing as tb ON (tra.transid = tb.trans_id)
        LEFT JOIN users as us ON (us.userid = tra.userid)
        LEFT JOIN product as p ON (tra.productid = p.productid)
        LEFT JOIN variant as v ON (v.id = tra.variant)
        LEFT JOIN productimage pi ON (pi.productid = p.productid AND pi.imageseq = 1)
        LEFT JOIN address ad ON (ad.addressid = tra.addressid)
        LEFT JOIN gst as gst ON (gst.id = tb.gst_id)
        WHERE tra.status NOT IN ('instock', 'outofstock')
        AND tra.status IS NOT NULL
        AND tra.userid = '${userid}' AND tra.id IN (${transArrayID})

        GROUP BY tra.id
        ORDER BY MAX(tra.lastmodifiedat) DESC
        `
        const ordersData = await db.query(thisQueryOrd);

        if (transactionid == '' || transactionid != undefined || transactionid == 0) {

            let thisQueryExchange = ` Update transactions SET status = 'exchange' WHERE status = 'Ordered' AND id = '${transactionid}' `
            const exchangeDatai = await db.query(thisQueryExchange);
            console.log('exchangeDatai', exchangeDatai);
            console.log('Transaction status updated to exchange');
        }

        res.status(200).send({
            status: true,
            message: 'Transaction inserted successfully',
            insert_count : ordersData[0]?.length,
            insert_output : ordersData[0]
        });
    
        await db.query('COMMIT');

    } catch (error) {
        console.log('error', error);
        res.status(500).json({
            status: false,
            message: 'Internal Server Error',
            error: error.message,
        });

        await db.query('ROLLBACK');
    }
};
// Email Trigger
async function emailTrigger (orderList) {
    console.log('Initial Email Trigger', orderList[0]);

    // Generate HTML content for each order
    const htmlContent = orderList[0]?.map(order => {
        // const total = order.reduce((sum, item) => sum + item.quantity * item.price, 0).toFixed(2);

            return `
            <div class="order">
                <div class="header" style="background-color: #4CAF50; color: white; padding: 10px 0; text-align: center;">
                    <h1>Order Confirmation</h1>
                    <p>Order Number: #${order?.ordernumber}</p>
                </div>
                <div class="content" style="margin: 20px;">
                    <p>Hi ${order?.username},</p>
                    <p>Thank you for your order! Here are the details:</p>
                    <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
                        <thead>
                            <tr>
                                <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">Item</th>
                                <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">Quantity</th>
                                <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">Shipping charges</th>
                                <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="padding: 8px; border: 1px solid #ddd;">${order?.product_name}</td>
                                <td style="padding: 8px; border: 1px solid #ddd;">${order?.quantity}</td>
                                <td style="padding: 8px; border: 1px solid #ddd;">$${order?.shipping_charges}</td>
                                <td style="padding: 8px; border: 1px solid #ddd;">${order?.status}</td>
                            </tr>
                        </tbody>
                    </table>
                    <p><strong>Total: $${order?.total_amount}</strong></p>
                    <p>If you have any questions, feel free to contact us.</p>
                </div>
                <div class="footer" style="text-align: center; margin-top: 20px; font-size: 0.8em; color: #888;">
                    <p>&copy; ${new Date().getFullYear()} Your Company. All rights reserved.</p>
                </div>
            </div>
            `;
    }).join('');

    const htmlContent1 = `
    <div class="order" style="max-width: 1200px; margin: 0 auto;">
        <div class="header" style="background-color: #4CAF50; color: white; padding: 10px 0; text-align: center;">
            <h1>Order Confirmation</h1>
        </div>
        <div class="content" style="margin: 20px;">
            <p>Hi ${orderList[0][0]?.username},</p>
            <p>Thank you for your order! Here are the details:</p>
            <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
                <thead>
                    <tr>
                        <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">S.No</th>
                        <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">Order Number</th>
                        <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">Item</th>
                        <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">Quantity * Price</th>
                        <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">Status</th>
                        <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">Price</th>
                    </tr>
                </thead>
                <tbody>
                    ${orderList[0]?.map((order, i) => `
                        <tr>
                            <td style="padding: 8px; border: 1px solid #ddd;">${i+1}</td>
                            <td style="padding: 8px; border: 1px solid #ddd;">#${order?.ordernumber}</td>
                            <td style="padding: 8px; border: 1px solid #ddd;">${order?.product_name}</td>
                            <td style="padding: 8px; border: 1px solid #ddd;">${order?.quantity} x ${order?.variant_price}</td>
                            <td style="padding: 8px; border: 1px solid #ddd;">${order?.status}</td>
                            <td style="padding: 8px; border: 1px solid #ddd;">$${(order?.variant_price * order?.quantity || 0).toFixed(2)}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
            <p><strong>Shipping Charges: $${orderList[0][0]?.shipping_charges}</strong></p>
            <p><strong>GST % : $${orderList[0][0]?.tpricegst}</strong></p>
            <p><strong>Total: $${orderList[0][0]?.transaction_price}</strong></p>
            <p>If you have any questions, feel free to contact us.</p>
        </div>
        <div class="footer" style="text-align: center; margin-top: 20px; font-size: 0.8em; color: #888;">
            <p>&copy; ${new Date().getFullYear()} ${process.env.SMS_OTP_COMPANY_NAME}. All rights reserved.</p>
        </div>
    </div> `;
                
    function saveHTMLToFile(htmlContent1, fileName) {
        const filePath = path.join(__dirname, fileName);
        fs.writeFile(filePath, htmlContent1, (err) => {
            if (err) {
            console.error('Error saving HTML file:', err);
            } else {
            console.log(`HTML file saved: ${filePath}`);
            }
        });
    }
    saveHTMLToFile(htmlContent1, 'order-confirmation.html');

    const EmailID = orderList[0][0] ? orderList[0][0]?.email : ""
    console.log('EmailID', EmailID);
        
    const mailOptions = {
        from: 'vickyprasanth728@gmail.com',
        to: `${EmailID}`,
        subject: `Order Confirmation`,
        // text: 'text',
        html: htmlContent1
      };
    console.log('JSON.stringify(mailOptions)', JSON.stringify(mailOptions));
    
      mailer.sendMail(mailOptions, async (error, info) => {
        if (error) {
          console.error("Error sending email:", error);
          let thisQuery = ` INSERT INTO email_test (mail_options, data, email,error,status) VALUES ('${JSON.stringify(mailOptions)}', '${JSON.stringify(orderList[0])}', '${JSON.stringify(EmailID)}', '${JSON.stringify(error)}', 'fail') `
          const data = await db.query(thisQuery); 
        } else {
          let thisQuery = ` INSERT INTO email_test (mail_options, data, email, error, status) VALUES ('${JSON.stringify(mailOptions)}', '${JSON.stringify(orderList[0])}', '${JSON.stringify(EmailID)}','', 'success') `
          const data = await db.query(thisQuery);        
          console.log("Email sent:", info.response);
        }
      });
};
// Get Your Orders
export const getYourOrders = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
    await db.query('START TRANSACTION');

    const UserID = req.params.userid;

    try {

        const filters = req.query

        let thisQueryCheckUserExists = `SELECT id FROM transactions WHERE userid = '${UserID}' LIMIT 1`;
        const userExists = await db.query(thisQueryCheckUserExists);

        const userExistCheck = userExists[0][0] ? userExists[0][0]?.id : 0
        console.log('userExistCheck', userExistCheck);

        if (userExistCheck == 0 || !userExistCheck) {
            return res.status(404).json({
                status: false,
                message: 'This user has no orders'
            });
        }

        let thisQuery = `
        SELECT 
        tra.*,
        tra.variant as variantid,
        gst.name as gst_name,
        gst.tax as gst_tax,
        DATE_FORMAT(tra.createdon, '%Y-%m-%d %H:%i:%s') as createdon,
        (JSON_ARRAYAGG(
                JSON_OBJECT(
                    'productid', p.productid,
                    'name', p.name,
                    'description', p.description,
                    'price', v.price,
                    'quantity', tra.quantity
                )
            )
        ) AS product_details,
        (JSON_ARRAYAGG(
                JSON_OBJECT(
                    'image', pi.image,
                    'imageseq', pi.imageseq,
                    'productid', pi.productid
                )
            )
        ) AS image_details,
        (JSON_ARRAY(
                JSON_OBJECT(
                    'ccavenue_transid', tb.ccavenue_transid,
                    'status', tb.status,
                    'tpricegst', tb.tpricegst,
                    'tweight', tb.tweight,
                    'shipping_charges', tb.shipping_charges,
                    'type', tb.type,
                    'actual_price', tb.actual_price,
                    'transaction_price', tb.transaction_price,
                    'payment_type', tb.payment_type
                )
            )
        ) AS billing_details,
        (JSON_ARRAYAGG(
                JSON_OBJECT(
                    'id', v.id,
                    'size', v.size,
                    'color', v.color,
                    'price', v.price,
                    'quantity', v.quantity,
                    'weight', v.weight
                )
            )
        ) AS variant_details,
        (
            SELECT 
                JSON_OBJECT(
                    'addressid', COALESCE(ad.addressid,''),
                    'address_name', COALESCE(ad.name,''),
                    'fullAddress', COALESCE(ad.fullAddress,''),
                    'locationDetails', COALESCE(ad.locationDetails,''),
                    'landmark', COALESCE(ad.landmark,''),
                    'city', COALESCE(ad.city,''),
                    'state', COALESCE(ad.state,''),
                    'country', COALESCE(ad.country,''),
                    'pincode', COALESCE(ad.pincode,''),
                    'email', COALESCE(ad.email,''),
                    'mobileno', COALESCE(ad.mobileno,''),
                    'alternatemobileno', COALESCE(ad.alternatemobileno,'')
                )
            FROM address as ad
            WHERE ad.addressid IN (tra.addressid)
            GROUP BY ad.addressid
        ) AS address_details
        
        FROM transactions as tra
        LEFT JOIN transaction_billing as tb ON (tb.id = tra.childbillid)
        LEFT JOIN users as us ON (us.userid = tra.userid)
        LEFT JOIN product as p ON (tra.productid = p.productid)
        LEFT JOIN productimage as pi ON (pi.productid = p.productid AND pi.imageseq = 1)
        LEFT JOIN address as ad ON (ad.addressid = tra.addressid)
        LEFT JOIN variant as v ON (v.id = tra.variant)
        LEFT JOIN gst as gst ON (gst.id = tra.gst_id)
        WHERE tra.status NOT IN ('instock', 'outofstock')
        AND tra.status IS NOT NULL
        AND tra.userid = '${UserID}'
        `
        if (filters?.status) {
            thisQuery += ` AND tra.status = '${filters?.status}' `
        }

        thisQuery += ` 
        GROUP BY tra.id
        ORDER BY MAX(tra.lastmodifiedat) DESC
        `
        const productCountResult2 = await db.query(thisQuery);

        if (filters?.limit) {
            thisQuery += ` limit ${filters?.limit},10 `
        }

        const productCountResult = await db.query(thisQuery);
        console.log('productCountResult', productCountResult[0]);

        res.status(200).send({
            status: true,
            count: productCountResult2[0]?.length,
            message: 'your details listed successfully',
            data: productCountResult[0]
        });

    } catch (error) {
        console.log('error', error);
        res.status(500).json({
            status: false,
            message: 'Internal Server Error',
            error: error.message,
        });

        await db.query('ROLLBACK');
    }

};
// Insert Transaction
export const insertTransaction = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
    await db.query('START TRANSACTION');

    try {
        const { userid, addressid, gst_id, tax_amount, quantity,shipping_charges, total_amount, status } = req.body;

        const productid = req.body.productid
        console.log('productid', productid);

        // const productidArray = JSON.parse(productid).length == 0 ? 0 : JSON.parse(productid);
        const productidArray = productid.length == 0 ? 0 : productid;
        console.log('productidArray', productidArray);
        
        let userCheckQuery = `SELECT userid FROM users WHERE userid = '${userid}' LIMIT 1`;
        const userCheckData = await db.query(userCheckQuery);
        const userExists = userCheckData[0][0] ? userCheckData[0][0]?.userid : 0

        console.log('userExists', userExists);
    
        if (userExists == 0 || !userExists) {
            console.log('User-ID not found');
            return res.status(404).send({
                status: false,
                message: 'User-ID not found',
            });
        }
    
        let productCheckQuery = `SELECT productid FROM product WHERE productid IN (${productidArray}) LIMIT 1`;
        const productCheckData = await db.query(productCheckQuery);
        const productExists = productCheckData[0][0] ? productCheckData[0][0]?.productid : 0

        console.log('productExists', productExists);

        if (productExists == 0 || !productExists) {
            console.log('Product-ID not found');
            return res.status(404).send({
                status: false,
                message: 'Product-ID not found',
            });
        }
        // AND status != 'Ordered'

        let getATC = ` SELECT * FROM addtocarttable WHERE userid = '${userid}' AND status != 'Ordered' AND productid IN (${productidArray}) `
        const ATC_ID = await db.query(getATC);
        console.log('ATC_ID data', ATC_ID[0]);      
        
        const ATCEmpty = ATC_ID[0][0] ? ATC_ID[0][0]?.atcartid : 0
        
        if (ATCEmpty == 0 || !ATCEmpty) {
            console.log('Add To Cart Empty');
            return res.status(404).send({
                status: false,
                message: 'Add To Cart Empty',
            });
        }
        
        const variant_array = ATC_ID[0]?.map(i => i.variantid);
        const variantData =  variant_array.length != 0 ? variant_array?.join(',') : 0
        console.log('variant_array', variantData);
        console.log('variant_array_length', variant_array.length);

        let variantQuery = ` SELECT * FROM variant WHERE id IN (${variantData}) `
        const variantID = await db.query(variantQuery);
        console.log('variantID data', variantID[0]);  

        console.log('formattedDateTime', formattedDateTime);
        
        let transactionBillingQuery = `
        INSERT INTO transaction_billing (ccavenue_transid, status, createdon, lastmodifiedate) VALUES (${null},'${status}','${formattedDateTime}','${formattedDateTime}') `;
        const transactionResultBilling = await db.query(transactionBillingQuery);
        const billAutoId = transactionResultBilling[0];
        console.log('transactionResultBilling', transactionResultBilling);

        // let totalPriceGst = 0; 
        // let totalWeight = 0;

        let TBillingPrice = 0;
        let TBillingWeight = 0;
        let TotalGstPercent = 0;

        let index = 0; 

        const Loopatcartid = ATC_ID[0].map(item => item.atcartid);
        console.log('Loopatcartid', Loopatcartid);
        console.log('Add_to_cart_list', ATC_ID[0]);

        const today = new Date().toISOString().slice(0, 10);
        console.log('today', today);

        let counterQuery1 = `
        INSERT INTO daily_reset_counter (counter_date, counter_value_trans) VALUES ('${today}', 1) ON DUPLICATE KEY UPDATE counter_value_trans = counter_value_trans + 1 `;
        const counterInsert1 = await db.query(counterQuery1);

        let counterSelectQuery = `SELECT counter_value_trans FROM daily_reset_counter WHERE counter_date = '${today}' `;
        const counterData = await db.query(counterSelectQuery);
        let counterValue = counterData[0][0] ? counterData[0][0]?.counter_value_trans : 0

        console.log('counterValueTrans', counterValue);
    
        const transId = `Trans-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;

        // for (const productId of productidArray) {
        for (let i=0; i < ATC_ID[0].length; i++ ) {

            // const productVariant = ATC_ID[0].find(item => item.productid === productId);
            const productVariant = ATC_ID[0][i];

            console.log('productVariant', productVariant);
            
            let ATCvariantQuantity = productVariant ? productVariant.quantity : 0;
            const productVariantID = productVariant ? productVariant.variantid : 0;

            const variantList = variantID[0].find(item => item.id === ATC_ID[0][i]?.variantid);
            console.log('variantList', variantList);  

            const productVariantPrice = variantList ? variantList.price : 0;
            const productVariantWeight = variantList ? variantList.weight : 0;
            let productVariantQuantity = variantList ? variantList.quantity : 0;

            console.log('productVariantPrice Total', productVariantPrice, '*' ,ATC_ID[0][i]?.quantity,'=', productVariantPrice * ATC_ID[0][i]?.quantity);
            
            let pgstQuery = ` 
            SELECT
            p.gst as product_gst
            FROM product as p 
            WHERE p.productid = '${ATC_ID[0][i]?.productid}' `
            const PGST = await db.query(pgstQuery);
            console.log('PGST', PGST); 
            const gstArray = PGST[0][0] ? PGST[0][0]?.product_gst : 0
            console.log('PGST_DATA', gstArray); 
            
            // const gstArray = 1;
            // const gstArray1 = (!gst_id || gst_id.length == 0) ? 0 : gst_id[index];
            // const gstArray = gstArray1 == undefined ? 0 : gstArray1
            // console.log('gst_array', gstArray);

            console.log('ATCvariantQuantity', ATCvariantQuantity);  
            console.log('productVariantQuantity', productVariantQuantity);  
    
            // let counterQuery = `
            // INSERT INTO daily_reset_counter (counter_date, counter_value) VALUES ('${today}', 1) ON DUPLICATE KEY UPDATE counter_value = counter_value + 1 `;
            // const counterInsert = await db.query(counterQuery);
        
            // let counterSelectQuery = `SELECT counter_value FROM daily_reset_counter WHERE counter_date = '${today}' `;
            // const counterData = await db.query(counterSelectQuery);
            // let counterValue = counterData[0][0] ? counterData[0][0]?.counter_value : 0
    
            // console.log('counterValue', counterValue);

            // const orderNumber = `2CQR-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
            // const transId = `Trans-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;

            // let transactionInsertQuery = `
            // INSERT INTO transactions (productid, userid, childbillid, status) VALUES ('${productId}', '${userid}', '${transactionResultBilling[0]}','${status || 'Initiated '}')`;
            // const transactionResult = await db.query(transactionInsertQuery);

            
            let TVariantPrice1 = 0;
            let TVariantWeight1 = 0;

            if (productVariantQuantity > 0) {
                let counterQuery = `
                INSERT INTO daily_reset_counter (counter_date, counter_value) VALUES ('${today}', 1) ON DUPLICATE KEY UPDATE counter_value = counter_value + 1 `;
                const counterInsert = await db.query(counterQuery);
            
                let counterSelectQuery = `SELECT counter_value FROM daily_reset_counter WHERE counter_date = '${today}' `;
                const counterData = await db.query(counterSelectQuery);
                let counterValue = counterData[0][0] ? counterData[0][0]?.counter_value : 0
        
                const orderNumber = `2CQR-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
                // const transId = `Trans-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
                let inStockQuantity = Math.min(productVariantQuantity, ATCvariantQuantity);

                console.log('productVariantQuantity', productVariantQuantity);  
                console.log('ATCvariantQuantity', ATCvariantQuantity);  
                console.log('inStockQuantity', inStockQuantity);  

                let TVariantPrice = productVariantPrice * inStockQuantity
                let TVariantWeight = productVariantWeight * inStockQuantity
    
                console.log('TVariantPrice', TVariantPrice);  
                console.log('TVariantWeight', TVariantWeight);  

                TBillingPrice += TVariantPrice;
                TBillingWeight += TVariantWeight;    
                
                TVariantPrice1 += TVariantPrice
                TVariantWeight1 += TVariantWeight

                let inStockQuery = `
                    INSERT INTO transactions (productid, userid, addressid, transid, ordernumber, variant, tpricegst, tweight, childbillid, gst_id, quantity, status, online) 
                    VALUES ('${ATC_ID[0][i]?.productid}', '${userid}', '${addressid}', '${transId}', '${orderNumber}', '${productVariantID}', '${TVariantPrice}', '${TVariantWeight}', '${transactionResultBilling[0]}','${gstArray}','${inStockQuantity}', 'instock',1)
                `;
                const transactionResult = await db.query(inStockQuery);

                let transactionLogQuery = `
                INSERT INTO transactionlog (transtableid, status, createdby) VALUES ('${transactionResult[0]}', 'instock', '${userid}')`;
                const transactionResultLog = await db.query(transactionLogQuery);
                console.log('transactionResultLog', transactionResultLog);

                console.log('jgfhghfgghfh', ATCvariantQuantity,inStockQuantity );
                ATCvariantQuantity -= inStockQuantity;
            }
            
            if (ATCvariantQuantity > 0) {
                let counterQuery = `
                INSERT INTO daily_reset_counter (counter_date, counter_value) VALUES ('${today}', 1) ON DUPLICATE KEY UPDATE counter_value = counter_value + 1 `;
                const counterInsert = await db.query(counterQuery);
            
                let counterSelectQuery = `SELECT counter_value FROM daily_reset_counter WHERE counter_date = '${today}' `;
                const counterData = await db.query(counterSelectQuery);
                let counterValue = counterData[0][0] ? counterData[0][0]?.counter_value : 0
        
                const orderNumber = `2CQR-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
                // const transId = `Trans-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;

                console.log('inStockQuantity', ATCvariantQuantity);  

                let TVariantPrice = productVariantPrice * ATCvariantQuantity
                let TVariantWeight = productVariantWeight * ATCvariantQuantity
    
                console.log('TVariantPrice', TVariantPrice);  
                console.log('TVariantWeight', TVariantWeight);  

                TBillingPrice += TVariantPrice;
                TBillingWeight += TVariantWeight;   
                
                TVariantPrice1 += TVariantPrice
                TVariantWeight1 += TVariantWeight

                let outOfStockQuery = `
                    INSERT INTO transactions (productid, userid, addressid, transid, ordernumber, variant, tpricegst, tweight, childbillid, gst_id, quantity, status, online) 
                    VALUES ('${ATC_ID[0][i]?.productid}', '${userid}', '${addressid}', '${transId}', '${orderNumber}','${productVariantID}', '${TVariantPrice}', '${TVariantWeight}', '${transactionResultBilling[0]}', '${gstArray}', '${ATCvariantQuantity}', 'outofstock', 1)
                `;
                const transactionResult = await db.query(outOfStockQuery);

                let transactionLogQuery = `
                INSERT INTO transactionlog (transtableid, status, createdby) VALUES ('${transactionResult[0]}', 'outofstock', '${userid}')`;
                const transactionResultLog = await db.query(transactionLogQuery);
                console.log('transactionResultLog', transactionResultLog);
            }

            console.log('product Variant Price & Weight ', productVariantPrice, productVariantWeight );

            const GSTChargeQuery = `
            SELECT tax AS total_tax FROM gst WHERE id = ${gstArray} ORDER BY id DESC `;
            const GSTChargeResult = await db.query(GSTChargeQuery);
            let GSTCharge = GSTChargeResult[0][0] ? GSTChargeResult[0][0]?.total_tax : 0;
            // TotalGstPercent += GSTCharge
            const productGSTAmount = (TVariantPrice1 * GSTCharge) / 100;
            console.log('TVariantPrice1', TVariantPrice1);
            
            TotalGstPercent += productGSTAmount;

            console.log('Product GST Amount:', productGSTAmount, 'GST Charge Percent:', GSTCharge);


            // totalPriceGst += productVariantPrice;
            // totalWeight += productVariantWeight;

            // let transactionLogQuery = `
            // INSERT INTO transactionlog (transtableid, status, createdby) VALUES ('${transactionResult[0]}', '${status}', '${userid}')`;
            // const transactionResultLog = await db.query(transactionLogQuery);
            
            // console.log('transactionResultLog', transactionResultLog);

            index++;
        }
        
            console.log('Order initiated successfully'); 

            // const shippingChargeQuery = `
            // SELECT charge FROM weightmasters WHERE weight <= ${TBillingWeight} ORDER BY weight DESC LIMIT 1`;
            const shippingChargeQuery = `
            SELECT id, charge 
            FROM weightmasters 
            WHERE ${TBillingWeight} BETWEEN startweightrange AND endweightrange 
            ORDER BY id DESC 
            LIMIT 1 `
            const shippingChargeResult = await db.query(shippingChargeQuery);
            const shippingCharge = shippingChargeResult[0][0] ? shippingChargeResult[0][0]?.charge : 0;
   
           // Calculate actual price
           const actualPrice = TBillingPrice;
        //    const GSTPrice = (TBillingPrice / TotalGstPercent);
        //    const GSTPrice = (TBillingPrice * TotalGstPercent) / 100;
           const GSTRoundPrice = Math.ceil(TotalGstPercent);
           const shippingChargeINT = parseInt(shippingCharge, 10);
           const transactionPrice = TBillingPrice + GSTRoundPrice + shippingChargeINT;

           console.log('TBillingPrice', TBillingPrice, TBillingWeight);
           console.log('actualPrice = ' , actualPrice, 'GSTRoundPrice = ', GSTRoundPrice, 'transactionPrice = ', transactionPrice, 'TotalGstPercent = ', TotalGstPercent, 'shippingChargeINT', shippingChargeINT, shippingCharge);

           const updateBillingQuery = `
            UPDATE transaction_billing 
            SET tpricegst = '${GSTRoundPrice}', tweight = '${TBillingWeight}', shipping_charges = '${shippingChargeINT}', actual_price = '${TBillingPrice}', transaction_price = '${transactionPrice}', payment_type = 'ccavenue' 
            WHERE id = '${billAutoId}'`;
            const updateBillData = await db.query(updateBillingQuery);

            let bsThisQuery = ` SELECT * FROM business_settings `
            const [BSDATA] = await db.query(bsThisQuery);
            
            const obj = BSDATA.reduce((acc, { option_type, option_value }) => {
                acc[option_type] = option_value;
                return acc;
            }, {});
            
            console.log('obj-data', obj);
            const workingKey = obj.working_key || '';
            const accessCode = obj.access_code || '';
            const merchantId = obj.merchant_id || '';
            const currency = obj.currency || '';
            const amount = transactionPrice || 0;
            const language = obj.language || '';

            const formData = {
                merchant_id: merchantId,
                order_id: billAutoId,
                currency: currency,
                amount: amount,
                userid: userid,
                productid: productid,
                redirect_url: `${obj?.live_node_url}api/v1/Order/updateTransaction`,
                cancel_url: `${obj?.live_node_url}api/v1/Order/cancel_transaction`,
                language: language
            };
  
            const params = new URLSearchParams(formData);
            const bodyData  = params.toString();  
            const encRequest = encrypt(bodyData, workingKey);

            const paymentLink = `https://test.ccavenue.com/transaction/transaction.do?command=initiateTransaction&encRequest=${encRequest}&access_code=${accessCode}`;

            res.status(200).send({
                status: true,
                message: 'Order initiated successfully',
                billAutoId: billAutoId,
                paymentLink: paymentLink
            });

            // const updateProbs = {productidArray, userid, billAutoId, status}

            // updateTransaction()
        
            await db.query('COMMIT');

    } catch (error) {
        console.log('error', error);
        res.status(500).json({
            status: false,
            message: 'Internal Server Error',
            error: error.message,
        });

        await db.query('ROLLBACK');
    }
};
// Update Transaction
export const updateTransaction = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
    await db.query('START TRANSACTION');

    console.log('inside to transaction');
    
    try {

    let bsThisQuery = ` SELECT * FROM business_settings `
    const [BSDATA] = await db.query(bsThisQuery);
    
    const obj = BSDATA.reduce((acc, { option_type, option_value }) => {
        acc[option_type] = option_value;
        return acc;
    }, {});

    const workingKey = obj?.working_key;

    let ccavEncResponse  = '';
    let wncRespCode = req.body.encResp

    console.log('wncRespCode', wncRespCode);
    
    req.on('data', (data) => {
        ccavEncResponse += data;
    });

    const ccavResponseI = decrypt(wncRespCode, workingKey);            
    console.log('ccavResponseI', ccavResponseI);

    req.on('end', () => {
        try {
            // const ccavPOST = qs.parse(ccavEncResponse);
            const encryptedResponse = wncRespCode;
            console.log('hghvgmggcjgm', encryptedResponse);
            
            const ccavResponse = decrypt(encryptedResponse, workingKey);            
            console.log('ihgygygyjj', ccavResponse);

            const pData = `<table border=1 cellspacing=2 cellpadding=2><tr><td>${ccavResponse.replace(/=/gi, '</td><td>').replace(/&/gi, '</td></tr><tr><td>')}</td></tr></table>`;
            const htmlcode = `<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>Response Handler</title></head><body><center><font size="4" color="blue"><b>Response Page</b></font><br>${pData}</center><br></body></html>`;

            res.status(200).send({
              status : true,
              message:'success',
              data: ccavResponse
            });
        } catch (error) {
            console.error("Error during response handling:", error);
            res.status(500).send({
              status : true,
              message:'Internal Server Error : ', error,
            });        
          }
    });

    const paramsCCAResponse = new URLSearchParams(ccavResponseI);
    const data = Object.fromEntries(paramsCCAResponse.entries());
    console.log('CCavResponse Final,', data);

    let thisQueryVerify = ` SELECT 
    tra.*, 
    tb.transaction_price as transaction_price,
    CONCAT('[', GROUP_CONCAT(DISTINCT IFNULL(tra.productid, '')), ']') AS productid
    FROM 
    transactions as tra
    LEFT JOIN transaction_billing as tb ON (tb.id = tra.childbillid)
    WHERE tra.childbillid = '${data?.order_id}' `
    const verifyData = await db.query(thisQueryVerify);

    const billautoid = verifyData[0][0] ? verifyData[0][0]?.childbillid : 0
    const userid = verifyData[0][0] ? verifyData[0][0]?.userid : 0
    const productid = verifyData[0][0] ? verifyData[0][0]?.productid : 0
    const transactionPrice = verifyData[0][0] ? verifyData[0][0]?.transaction_price : 0
    const status = 'success'

        console.log('verifyData', verifyData[0]);
        console.log('billautoid', billautoid, data?.order_id);
        console.log('userid', userid);
        console.log('productid', productid);
        console.log('transactionPrice', transactionPrice,  data?.amount);
        console.log('data?.order_status', data?.order_status);
        console.log('Main data', data);
        

        if (billautoid != data?.order_id) {
            console.log('Mismatching bill-id');
                let errorQuery = `INSERT INTO transaction_error_logs (transactionid, trans_number, error_code, error_message, userid, status, created_at, updated_at) VALUES ('${verifyData[0][0]?.id}', '${verifyData[0][0]?.transid}', '400', 'Mismatching bill-id', '${userid}', 'failure', '${formattedDateTime}', '${formattedDateTime}')`
                const errorLog = await db.query(errorQuery);
                console.log('Error log inserted successfully');

                res.status(400).send({
                    status: false,
                    message: 'Mismatching bill-id',
                });
        }
        else if (transactionPrice != data?.amount) {
            console.log('Mismatching amount');
                let errorQuery = `INSERT INTO transaction_error_logs (transactionid, trans_number, error_code, error_message, userid, status, created_at, updated_at) VALUES ('${verifyData[0][0]?.id}', '${verifyData[0][0]?.transid}', '400', 'Mismatching amount', '${userid}', 'failure', '${formattedDateTime}', '${formattedDateTime}')`
                const errorLog = await db.query(errorQuery);
                console.log('Error log inserted successfully');
            
                res.status(400).send({
                    status: false,
                    message: 'Mismatching amount',
                });
        }
        else if (data?.order_status != 'Success' ) {
            console.log('Ordered Cancelled');
                let errorQuery = `INSERT INTO transaction_error_logs (transactionid, trans_number, error_code, error_message, userid, status, created_at, updated_at) VALUES ('${verifyData[0][0]?.id}', '${verifyData[0][0]?.transid}', '400', 'Ordered Cancelled', '${userid}', 'failure', '${formattedDateTime}', '${formattedDateTime}')`
                const errorLog = await db.query(errorQuery);
                console.log('Error log inserted successfully');
            
                res.status(400).send({
                    status: false,
                    order_status:data?.order_status,
                    message: 'Ordered Cancelled',
                });
        } 
        else {

        // const { billautoid , status, userid} = req.body;
        // const productid = req.body.productid

        // console.log('updateProbs', updateProbs);
        console.log('productid', productid);

        const productidArray = JSON.parse(productid).length == 0 ? 0 : JSON.parse(productid);
        // const productidArray = productid.length == 0 ? 0 : productid;
        console.log('productidArray', productidArray);

        let getATC = ` SELECT * FROM addtocarttable WHERE userid = '${userid}' AND status != 'Ordered' AND productid IN (${productidArray}) `
        const ATC_ID = await db.query(getATC);
        console.log('ATC_ID data', ATC_ID[0]);      
        
        const variant_array = ATC_ID[0]?.map(i => i.variantid);
        const variantData =  variant_array.length != 0 ? variant_array?.join(',') : 0
        console.log('variant_array', variantData);
        console.log('variant_array_length', variant_array.length);

        let variantQuery = ` SELECT * FROM variant WHERE id IN (${variantData}) `
        const variantID = await db.query(variantQuery);
        console.log('variantID data', variantID[0]);  

        let transQuery = ` SELECT * FROM transactions WHERE childbillid = 180 `
        const billStatus = await db.query(transQuery);
    
        let billValueStatus;

        if (billStatus[0].every(status => status === 'instock')) {
            billValueStatus = 'Shipped';
        } else if (billStatus[0].every(status => status === 'outofstock_o')) {
            billValueStatus = 'Pending';
        } else {
            billValueStatus = 'Partially Shipped';
        }
        console.log('billValueStatus', billValueStatus);

        let transactionBillingQuery = ` UPDATE transaction_billing SET ccavenue_transid = '${data?.tracking_id}', billing_status = '${billValueStatus}' ,status = '${status}' WHERE id = '${billautoid}' `;
        const transactionResultBilling = await db.query(transactionBillingQuery);

        let transactionInsertQuery = ` UPDATE transactions SET status = 'Ordered' WHERE childbillid = '${billautoid}' AND status = 'instock' ` ;
        const transactionResult = await db.query(transactionInsertQuery);

        let transactionInsertQuery1 = ` UPDATE transactions SET status = 'outofstock_o' WHERE childbillid = '${billautoid}' AND status = 'outofstock' ` ;
        const transactionResult1 = await db.query(transactionInsertQuery1);
        
        let uAddToCart = `UPDATE addtocarttable SET status = 'Ordered' WHERE userid = '${userid}' AND productid IN (${productidArray}) `
        const addToCartUpdate = await db.query(uAddToCart);

        ATC_ID[0]?.forEach(atcItem => {
            let variant = variantID[0].find(variant => variant.id === atcItem.variantid);
            
            if (variant) {
                variant.quantity -= atcItem.quantity;                
                variant.quantity = Math.max(0, variant.quantity);
            }
        });
        
        console.log('finalArray[0]',variantID[0]);

        for (const atcArray of variantID[0]) {
            console.log('atcArray', atcArray);
            
            let variantQuery = `UPDATE variant SET quantity = '${atcArray.quantity}' WHERE id = '${atcArray.id}' `
            const variantUpdate = await db.query(variantQuery);
        }

        let thisQueryOrd = `
        SELECT 
        tra.id,
        tra.transid,
        tra.productid,
        tra.userid,
        us.username,
        tra.ordernumber,
        tra.status,
        tra.createdon, 
        tra.quantity, 
        tra.productid as trans_product_id,
        (JSON_ARRAY(
                JSON_OBJECT(
                    'productid', p.productid,
                    'name', p.name,
                    'description', p.description,
                    'price', v.price,
                    'quantity', tra.quantity
                )
            )
        ) AS product_details,
        (JSON_ARRAY(
                JSON_OBJECT(
                    'ccavenue_transid', tb.ccavenue_transid,
                    'status', tb.status,
                    'tpricegst', tb.tpricegst,
                    'tweight', tb.tweight,
                    'shipping_charges', tb.shipping_charges,
                    'type', tb.type,
                    'actual_price', tb.actual_price,
                    'transaction_price', tb.transaction_price,
                    'payment_type', tb.payment_type
                )
            )
        ) AS billing_details,
        (JSON_ARRAY(
                JSON_OBJECT(
                    'image', pi.image,
                    'imageseq', pi.imageseq,
                    'productid', pi.productid
                )
            )
        ) AS image_details,
        (
            SELECT 
                JSON_OBJECT(
                    'addressid', COALESCE(ad.addressid,''),
                    'address_name', COALESCE(ad.name,''),
                    'fullAddress', COALESCE(ad.fullAddress,''),
                    'locationDetails', COALESCE(ad.locationDetails,''),
                    'landmark', COALESCE(ad.landmark,''),
                    'city', COALESCE(ad.city,''),
                    'state', COALESCE(ad.state,''),
                    'country', COALESCE(ad.country,''),
                    'pincode', COALESCE(ad.pincode,''),
                    'email', COALESCE(ad.email,''),
                    'mobileno', COALESCE(ad.mobileno,''),
                    'alternatemobileno', COALESCE(ad.alternatemobileno,'')
                )
            FROM address as ad
            WHERE ad.addressid IN (tra.addressid)
            GROUP BY ad.addressid
        ) AS address_details
        
        FROM transactions as tra
        LEFT JOIN transaction_billing as tb ON (tb.id = tra.childbillid)
        LEFT JOIN users as us ON (us.userid = tra.userid)
        LEFT JOIN product as p ON (tra.productid = p.productid)
        LEFT JOIN variant as v ON (v.id = tra.variant)
        LEFT JOIN productimage pi ON (pi.productid = p.productid AND pi.imageseq = 1)
        LEFT JOIN address ad ON (ad.addressid = tra.addressid)
        LEFT JOIN gst as gst ON (gst.id = tra.gst_id)
        WHERE tra.status NOT IN ('instock', 'outofstock')
        AND tra.status IS NOT NULL
        AND tra.userid = '${userid}' AND tra.childbillid IN (${billautoid})
        GROUP BY tra.id, tra.transid, tra.ordernumber, tra.status, tra.createdon, p.name, p.description, p.price, pi.image
        ORDER BY MAX(tra.lastmodifiedat) DESC
        `
        const ordersData = await db.query(thisQueryOrd);

        let orderListQuery = ` SELECT 
        tra.*,
        p.name as product_name,
        us.username as username,
        v.price as variant_price,
        us.email as email,
        tb.tpricegst as tpricegst,
        tb.shipping_charges as shipping_charges,
        tb.actual_price as actual_price,
        tb.transaction_price as transaction_price,
        tb.payment_type as payment_type
        FROM transactions as tra
        LEFT JOIN transaction_billing as tb ON (tb.id = tra.childbillid)
        LEFT JOIN gst as gst ON (gst.id = tra.gst_id)
        LEFT JOIN product as p on (p.productid = tra.productid)
        LEFT JOIN users as us on (us.userid = tra.userid)
        LEFT JOIN variant as v on (v.id = tra.variant)
        WHERE tra.childbillid IN (${billautoid})`
        const orderList = await db.query(orderListQuery);

        console.log('orderList', orderList[0]);

        emailTrigger(orderList)
        await db.query('COMMIT');
        
        // res.status(200).send({
        //     status: true,
        //     message: 'Order placed successfully',
        //     insert_count:ordersData[0]?.length,
        //     insert_output: ordersData[0]
        // });
        // `${obj?.live_react_url}/api/v1/Order/updateTransaction`
        res.redirect(`${obj?.live_react_url}orderdetails?billid=${billautoid}`);
        }
    } catch (error) {
        console.log('error :', error);
        await db.query('ROLLBACK');
    }

};
// update Exchange
export const updateExchange = async (req, res) => {
    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
    await db.query('START TRANSACTION');

    try {
        // const { userid, transactionid, addressid, variantid, tax_amount, gst_id, shipping_charges, total_amount, status, productid } = req.body;
        const { userid, billid_new, transid_old, transid_new, addressid, gst_id, variantid, productid } = req.body;

        console.log('Request Body:', req.body);

        const userCheckQuery = `SELECT userid FROM users WHERE userid = '${userid}' LIMIT 1`;
        const userCheckData = await db.query(userCheckQuery);
        if (!userCheckData[0][0]) {
            return res.status(404).send({ 
                status: false, 
                message: 'User-ID not found' 
            });
        }

        const productCheckQuery = `SELECT productid FROM product WHERE productid = '${productid}' LIMIT 1`;
        const productCheckData = await db.query(productCheckQuery);
        if (!productCheckData[0][0]) {
            return res.status(404).send({ 
                status: false, 
                message: 'Product-ID not found' 
            });
        }

        const variantQuery = `SELECT * FROM variant WHERE id = '${variantid}' LIMIT 1`;
        const variantData = await db.query(variantQuery);
        const variant = variantData[0][0];
        if (!variant) {
            return res.status(404).send({ 
                status: false, 
                message: 'Variant-ID not found' 
            });
        }

        const transQuery = `SELECT * FROM transactions WHERE id = '${transid_old}'`;
        const oldTransaction = await db.query(transQuery);

        console.log('oldTransaction', oldTransaction[0]);
        console.log('variant data', variant);
        
        if (!oldTransaction[0][0]) {
            return res.status(404).send({ 
                status: false, 
                message: 'Transaction not found' 
            });
        }

        if (oldTransaction[0][0]?.status !== 'delivered') {
            return res.status(400).send({ 
                status: false, 
                message: 'Old transaction must be delivered to proceed' 
            });
        }

        // if (productid != oldTransaction[0][0]?.productid) {
        //     return res.status(400).send({ 
        //         status: false, 
        //         message: 'Exchanging with a different product is not allowed' 
        //     });
        // }

        const quantity = oldTransaction[0][0] ? oldTransaction[0][0]?.quantity : 0

        const totalWeight = variant.weight * quantity;
        const totalPrice = variant.price * quantity;
        console.log('total Weight', totalWeight,' = ', variant.weight,' * ', quantity );
        console.log('total price', totalPrice,' = ',  variant.price,' * ',quantity );
        
        const weightChargeQuery = `
            SELECT charge 
            FROM weightmasters 
            WHERE weight <= '${totalWeight}' 
            ORDER BY weight DESC 
            LIMIT 1`;
        const weightChargeData = await db.query(weightChargeQuery);
        const shippingCharge = weightChargeData[0][0]?.charge || 0;
        const newTotalPrice = totalPrice + shippingCharge;

        const oldTotalPrice = oldTransaction[0][0] ? oldTransaction[0][0]?.tpricegst : 0
        const priceDifference = newTotalPrice - oldTotalPrice;
        console.log('newTotalPrice', newTotalPrice, oldTotalPrice );
        console.log('shippingCharge', shippingCharge);
        console.log('priceDifference', priceDifference);

        const gstArray = gst_id[0];

        let billingType, actualPrice, transactionPrice, newBillID;
        if (priceDifference > 0) {
            billingType = 'purchase';
            actualPrice = priceDifference;
            transactionPrice = newTotalPrice;

            const childBillID = oldTransaction[0][0] ? oldTransaction[0][0]?.childbillid : 0
            console.log('inside', oldTransaction[0][0]);
            
            // const updateChildBillQuery = `UPDATE transactions SET childbillid = '${childBillID}' WHERE id = '${transid_old}'`;
            // await db.query(updateChildBillQuery);

            const today = new Date().toISOString().slice(0, 10);
            console.log('today', today);
    
            let counterQuery = `
            INSERT INTO daily_reset_counter (counter_date, counter_value) VALUES ('${today}', 1) ON DUPLICATE KEY UPDATE counter_value = counter_value + 1 `;
            const counterInsert = await db.query(counterQuery);
        
            let counterSelectQuery = `SELECT counter_value FROM daily_reset_counter WHERE counter_date = '${today}' `;
            const counterData = await db.query(counterSelectQuery);
            const counterValue = counterData[0][0] ? counterData[0][0]?.counter_value : 0
    
            console.log('counterValue', counterValue);

            const orderNumber = `2CQR-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
            const transId = `Trans-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
    
            console.log('orderNumber', orderNumber);
            console.log('transId', transId);

            const billingInsertQuery = `
                UPDATE transaction_billing SET status = 'Initiated', ccavenue_transid = ${null}, tpricegst = '${totalPrice}', tweight = '${totalWeight}', shipping_charges = '${shippingCharge}', type = '${billingType}', actual_price = '${actualPrice}', transaction_price = '${transactionPrice}', payment_type = 'ccavenue', parent_bill_id = '${childBillID}', createdon = '${formattedDateTime}', lastmodifiedate = '${formattedDateTime}' WHERE id = '${billid_new}' `
            const billingResult = await db.query(billingInsertQuery);

            console.log('Billing Record Inserted:', billingResult);

            await db.query(`UPDATE transactions SET productid = '${productid}', userid = '${userid}', transid = '${transId}', addressid = '${addressid}', ordernumber = '${orderNumber}', tpricegst = '${totalPrice}', tweight = '${totalWeight}', quantity = '${quantity}', gst_id = '${gstArray}', childbillid = '${billid_new}', status = 'return initiated' WHERE id = '${transid_new}'`)
            
        } else if (priceDifference < 0) {
            billingType = 'refund';
            actualPrice = Math.abs(priceDifference);
            transactionPrice = newTotalPrice;

            const childBillID = oldTransaction[0][0] ? oldTransaction[0][0]?.childbillid : 0

            const today = new Date().toISOString().slice(0, 10);
            console.log('today', today);
    
            let counterQuery = `
            INSERT INTO daily_reset_counter (counter_date, counter_value) VALUES ('${today}', 1) ON DUPLICATE KEY UPDATE counter_value = counter_value + 1 `;
            const counterInsert = await db.query(counterQuery);
        
            let counterSelectQuery = `SELECT counter_value FROM daily_reset_counter WHERE counter_date = '${today}' `;
            const counterData = await db.query(counterSelectQuery);
            const counterValue = counterData[0][0] ? counterData[0][0]?.counter_value : 0
    
            console.log('counterValue', counterValue);

            const orderNumber = `2CQR-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
            const transId = `Trans-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
    
            console.log('orderNumber', orderNumber);
            console.log('transId', transId);

            const billingInsertQuery = `
                UPDATE transaction_billing SET status = 'Initiated', ccavenue_transid = ${null}, tpricegst = '${totalPrice}', tweight = '${totalWeight}', shipping_charges = '${shippingCharge}', type = '${billingType}', actual_price = '${actualPrice}', transaction_price = '${transactionPrice}', parent_bill_id = '${childBillID}' WHERE id = '${billid_new}' `
            const billingResult = await db.query(billingInsertQuery);

            console.log('Refund Billing Record Inserted:', billingResult);

            await db.query(`UPDATE transactions SET productid = '${productid}', userid = '${userid}', transid = '${transId}', addressid = '${addressid}', ordernumber = '${orderNumber}', tpricegst = '${totalPrice}', tweight = '${totalWeight}', quantity = '${quantity}', gst_id = '${gstArray}', childbillid = '${billid_new}', status = 'return initiated' WHERE id = '${transid_new}'`)

        } else {
            console.log('No price difference, proceeding with transaction update.');
        }

        // const updateOldTransactionQuery = `UPDATE transactions SET status = 'return initiated' WHERE transid = '${transactionid}'`;
        // await db.query(updateOldTransactionQuery);

        const updatedQuantity = Math.max(variant.quantity - quantity, 0);
        const updateVariantQuery = `UPDATE variant SET quantity = '${updatedQuantity}' WHERE id = '${variantid}'`;
        await db.query(updateVariantQuery);

        await db.query('COMMIT');
        res.status(200).send({ 
            status: true, 
            message: 'Transaction processed successfully' 
        });
    } catch (error) {
        console.error('Error:', error);
        await db.query('ROLLBACK');
        res.status(500).send({ 
            status: false, 
            message: 'Internal Server Error', 
            error: error.message 
        });
    }
};
// Encrypt function
export const encrypt = (plainText, workingKey) => {
    const m = crypto.createHash('md5');
    m.update(workingKey);  // Hash the workingKey using MD5
    const key = m.digest();  // Get the hash as a binary buffer
    // const iv = Buffer.from('\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f', 'binary'); // 16-byte IV (fixed for CCAvenue)

    // var iv = '\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f';

    const iv = Buffer.from([0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]); // 16-byte IV

    
    const cipher = crypto.createCipheriv('aes-128-cbc', key, iv);  // Use AES-128-CBC mode
    let encoded = cipher.update(plainText, 'utf8', 'hex');
    encoded += cipher.final('hex');
    
    return encoded;
};
// Decrypt function
export const decrypt = (encText, workingKey) => {
  
    const m = crypto.createHash('md5');
    m.update(workingKey);  // Hash the workingKey using MD5
    const key = m.digest();  // Get the hash as a binary buffer
    const iv = Buffer.from('\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f', 'binary'); // 16-byte IV (fixed for CCAvenue)

    const decipher = crypto.createDecipheriv('aes-128-cbc', key, iv);  // Use AES-128-CBC mode
    let decoded = decipher.update(encText, 'hex', 'utf8');
    decoded += decipher.final('utf8');
    
    return decoded;
};

// Get Order Page
export const getOrderPage = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

    try {

        const filters = req.query

        let thisQuery = `
        SELECT 
        tra.id,
        tra.productid,
        tra.userid,
        tra.transid,
        tra.ordernumber,
        tra.childbillid,
        tra.addressid,
        tra.gst_id,
        tra.status,
        IF(tra.online = 1, 'online', 'store') as online,
        gst.name as gst_name,
        gst.tax as total_tax,
        tra.productid as trans_product_id,
        tra.variant as variantid,
        tb.tpricegst as tpricegst,
        tb.tweight as tweight,
        tb.shipping_charges as shipping_charges,
        tb.type as type,
        tb.actual_price as actual_price,
        tb.transaction_price as transaction_price,
        tb.payment_type as payment_type,
        tb.parent_bill_id as parent_bill_id,
        us.email as email,
        DATE_FORMAT(tra.createdon, '%Y-%m-%d %H:%i:%s') as createdon,
        (JSON_ARRAY(
                JSON_OBJECT(
                    'name', '',
                    'email', ''
                )
            )
        ) AS seller,
          (JSON_ARRAY(
                JSON_OBJECT(
                'name', us.username,
                'email', us.email,
                'phone', us.mobileno,
                'address', ad.locationDetails,
                'country', ad.country
                )
            )
        ) AS customer,
        tb.status as financialStatus
        
        FROM transactions as tra
        LEFT JOIN transaction_billing as tb ON (tb.id = tra.childbillid)
        LEFT JOIN users as us ON (us.userid = tra.userid)
        LEFT JOIN product as p ON (tra.productid = p.productid)
        LEFT JOIN variant as v ON (v.id = tra.variant)
        LEFT JOIN productimage pi ON (pi.productid = p.productid AND pi.imageseq = 1)
        LEFT JOIN address ad ON (ad.addressid = tra.addressid)
        LEFT JOIN gst as gst ON (gst.id = tra.gst_id)
        WHERE tra.id IS NOT NULL
        `
        if (filters?.status) {
            thisQuery += ` AND tra.status = '${filters?.status}' `
        }
        if (filters?.id) {
            thisQuery += ` AND tra.ordernumber = '${filters?.id}' `
        }
        if (filters?.transid) {
            thisQuery += ` AND tra.transid = '${filters?.transid}' `
        }
        if (filters?.searchterm) {
            const searchTerm = filters?.searchterm.replace(/'/g, "''");
            thisQuery += ` AND (us.email LIKE '%${searchTerm}%' OR tra.ordernumber LIKE '%${searchTerm}%') `;
        }
        

        thisQuery += ` 
        GROUP BY tra.transid
        ORDER BY MAX(tra.lastmodifiedat) DESC
        `
        if (filters?.limit) {
            thisQuery += ` limit ${filters?.limit},10 `
        }

        const orders = await db.query(thisQuery);

        const Transid = orders[0][0]?.transid?.split(",");


        let finalData;
        if (filters?.transid) {
            let thisQuery1 = ` SELECT
            tra.id,
            tra.transid,
            tra.productid,
            tra.userid,
            tra.ordernumber,
            tra.status,
            tra.createdon, 
            tra.quantity, 
            tra.productid as trans_product_id,
            (JSON_ARRAY(
                    JSON_OBJECT(
                        'productid', p.productid,
                        'name', p.name,
                        'description', p.description,
                        'quantity', tra.quantity
                    )
                )
            ) AS product_details
            FROM transactions as tra
            LEFT JOIN transaction_billing as tb ON (tb.id = tra.childbillid)
            LEFT JOIN product as p ON (tra.productid = p.productid)
            WHERE tra.transid = '${filters?.transid}'
            GROUP BY tra.id
            `
            const orders1 = await db.query(thisQuery1);
    
            console.log('orders1', orders1);
            
            // orders[0][0].transid = Transid;
    
            const OrdersData = orders[0][0]
            const OrderDetails = orders1[0];

            finalData = [{
                ...OrdersData,
                order_details: OrderDetails,
            }];
        } else {
            // finalData = orders[0]
            const finalData1 = orders[0].map(order => ({
                ...order, 
                order_details: []
              }));
              finalData = finalData1
        }


        return res.status(200).json({
            status: true,
            count:orders[0].length,
            message: 'Order page list',
            data: finalData
        });

    } catch (error) {
        console.log('error', error);
        return res.status(500).json({
            status: false,
            message: error.message || 'Internal Server Error'
        });
    }

};
// Update Order Page Status
export const UpdateOrderPageStatus = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

    try {

        const filters = req.query;
        const {status, ordernumber} = req.body
        console.log('Req Body', req.body);

        let orderNumbersArray = ordernumber?.split(',');
        console.log('orderNumbersArray', orderNumbersArray);
        let formattedOrderNumbers = orderNumbersArray.map(orderNumber => `'${orderNumber}'`);
        let result = formattedOrderNumbers.join(',');
        console.log('result', result);
        
        let transQuery = ` SELECT * FROM transactions WHERE ordernumber IN (${result}) `
        const billStatus = await db.query(transQuery);
        const billautoid = billStatus[0][0] ? billStatus[0][0]?.childbillid : 0
        console.log('billautoid', billautoid);
        console.log('billStatus[0][0]?.transid', billStatus[0][0]?.transid);
        console.log('billStatus[0][0]?.ordernumber', billStatus[0][0]?.ordernumber);
        console.log('billStatus', billStatus[0]);

        if (!billStatus[0][0]?.transid) {
            return res.status(404).send({
                status: false,
                message: 'Trans-ID Not found',
            });
        }
        if (!billStatus[0][0]?.ordernumber) {
            return res.status(404).send({
                status: false,
                message: 'order Number Not found',
            });
        }
        
        let billValueStatus;
        console.log('ljllkj', billStatus[0].every(item => item.status == 'Ordered'));
  
        if (billStatus[0].every(item => item.status === 'Ordered')) {
            billValueStatus = 'Shipped';
        } else if (billStatus[0].every(item => item.status === 'outofstock_o')) {
            billValueStatus = 'Pending';
        } else {
            billValueStatus = 'Partially Shipped';
        }
        console.log('billValueStatus', billValueStatus);
  
        let transactionBillingQuery = ` UPDATE transaction_billing SET billing_status = '${billValueStatus}' WHERE id = '${billautoid}' `;
        const transactionResultBilling = await db.query(transactionBillingQuery);

        let thisQuery = ` UPDATE transactions SET status = '${status}' WHERE status = 'Ordered' AND ordernumber IN (${result}) `
        const [orders] = await db.query(thisQuery);

        return res.status(200).json({
            status: true,
            message: 'Order status updated',
            data: [{
                'trans_id':billStatus[0][0]?.transid,
                'trans_bill_id':billautoid,
                'trans_bill_status':billValueStatus,
                'trans_status':status
            }]
        });

    } catch (error) {
        console.log('error', error);
        return res.status(500).json({
            status: false,
            message: error.message || 'Internal Server Error'
        });
    }

};
// Cancel Transaction
export const cancelTransaction = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

    try {
        console.log(`https://retails.2cqr.in/cancelPage`);
        res.redirect(`https://retails.2cqr.in/cancelPage`);
     } catch (error) {
        console.log('error', error);
        return res.status(500).json({
            status: false,
            message: error.message || 'Internal Server Error'
        });
    }
};



























//@route      POST /api/v1/Order/getordersummary
//@desc       To getordersummary
//@access     Public
export const getordersummary1 = async (req, res) => {
    try {
        const { userid} = req.body;
        const OrderResults = await executeStoredProcedure('SP_getordersummary', [userid,'', '']);
        if (OrderResults && OrderResults.status === true) {
            const OrdersData = JSON.parse(OrderResults.data);
            res.status(200).json({ issuccess: true, message: OrderResults.message,OrdersData });
        }
        else {
            res.status(400).json({ issuccess: false, message: OrderResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

//@route      POST /api/v1/Order/insertTransaction
//@desc       To Add Transaction
//@access     Public
// export const insertTransaction = async (req, res) => {
//     try {
//         const { userid,productid,addressid,status} = req.body;
//         const OrderResults = await executeStoredProcedure('SP_InsertTransaction', [userid,productid,addressid,status, '', '']);
//         if (OrderResults && OrderResults.status === true) {
//             res.status(200).json({ issuccess: true, message: OrderResults.message });
//         }
//         else {
//             res.status(400).json({ issuccess: false, message: OrderResults.message });
//         }
//     } catch (error) {
//         console.log(error);
//         res.status(500).json({ error: 'Internal Server Error', message: error.message });
//     }
// };

//@route      POST /api/v1/Order/insertTransaction
//@desc       To Add Transaction
//@access     Public
export const insertTransaction1 = async (req, res) => {
    try {
        const { userid,productid,addressid,status} = req.body;
        const productidJSON = [];
        try {
            if (productid && Array.isArray(productid) && productid.length > 0) {
                console.log(productid);
                for (const code of productid) {
                    const jsonString = JSON.stringify(code);
                    productidJSON.push(jsonString);
                }
                console.log(productidJSON);
            }
        } catch (error) {
            // Handle any errors during conversion, such as invalid data types or circular references
            console.error('Error converting productid to JSON:', error);
        }
        const OrderResults = await executeStoredProcedure('SP_InsertTransactionBulk', [userid,productidJSON,addressid,status, '', '']);
        if (OrderResults && OrderResults.status === true) {
            res.status(200).json({ issuccess: true, message: OrderResults.message });
        }
        else {
            res.status(400).json({ issuccess: false, message: OrderResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

//@route      POST /api/v1/Order/updateTransaction
//@desc       To update Transaction
//@access     Public

export const updateTransaction1 = async (req, res) => {
    try {
        const { transactionId,addressid,status,lastmodifiedby } = req.body;
        const OrderResults = await executeStoredProcedure('SP_UpdateTransaction', [transactionId,addressid,status,lastmodifiedby, '', '']);
        if (OrderResults && OrderResults.status === true) {
            res.status(200).json({ issuccess: true, message: OrderResults.message });
        }
        else {
            res.status(400).json({ issuccess: false, message: OrderResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

//@route      POST /api/v1/Order/GetCancelOrderDetails
//@desc       To Get Cancel OrderDetails
//@access     Public

export const GetCancelOrderDetails = async (req, res) => {
    try {
        const { userid, pageno, limit } = req.body;
        const OrderResults = await executeStoredProcedure('SP_GetCancelOrderDetails', [userid,  limit,pageno, '', '']);
        if (OrderResults && OrderResults.status === true) {
            const OrdersData = JSON.parse(OrderResults.data);
            res.status(200).json({ issuccess: true, message: OrderResults.message, OrdersData, total_pages: OrderResults.total_pages });
        }
        else {
            res.status(400).json({ issuccess: false, message: OrderResults.message });
        }

    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

//@route      POST /api/v1/Order/GetOrderDetails
//@desc       To Get Order Details
//@access     Public
export const GetOrderDetails1 = async (req, res) => {
    try {
        const { userid, pageno, limit } = req.body;
        const OrderResults = await executeStoredProcedure('SP_GetOrderDetails', [userid, limit,pageno,  '', '','']);
        if (OrderResults && OrderResults.status === true) {
            const OrdersData = JSON.parse(OrderResults.data);
            res.status(200).json({ issuccess: true, message: OrderResults.message, OrdersData, totalcount: OrderResults.totalcount });
        }
        else {
            res.status(400).json({ issuccess: false, message: OrderResults.message });
        }

    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};
//@route      POST /api/v1/Order/cancelorder
//@desc       To cancel Order Details
//@access     Public
export const cancelorder = async (req, res) => {
    try {
        const { transtableid } = req.body;
        const OrderResults = await executeStoredProcedure('SP_CancelOrder', [transtableid, '', '']);
        if (OrderResults && OrderResults.status === true) {
            res.status(200).json({ issuccess: true, message: OrderResults.message });
        }
        else {
            res.status(400).json({ issuccess: false, message: OrderResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

//@route      POST /api/v1/Order/cancelorder
//@desc       To Return Order Details
//@access     Public
export const ReturnOrder = async (req, res) => {
    try {
        const { transtableid } = req.body;
        const OrderResults = await executeStoredProcedure('SP_ReturnOrder', [transtableid, '', '']);
        if (OrderResults && OrderResults.status === true) {
            res.status(200).json({ issuccess: true, message: OrderResults.message });
        }
        else {
            res.status(400).json({ issuccess: false, message: OrderResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};
//@route      POST /api/v1/Order/gettrackpackagestatus
//@desc       To get track package status
//@access     Public
export const gettrackpackagestatus = async (req, res) => {
    try {
        const { transtableid } = req.body;
        const OrderResults = await executeStoredProcedure('SP_GetTrackPackageStatus', [transtableid, '', '']);
        if (OrderResults && OrderResults.status === true) {
            const OrdersData = JSON.parse(OrderResults.data);
            res.status(200).json({ issuccess: true, message: OrderResults.message, OrdersData });
        }
        else {
            res.status(400).json({ issuccess: false, message: OrderResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};