import MastersData from "../../models/MastersDataModel.js";

export const getAllMastersData = async (req, res) => {
    try {
        const inst = await MastersData.findAll({
        });
        res.json(inst);
    } catch (error) {
        console.log(error);
    }
}

export const createMastersData = async (req, res) => {
    try {
        const { data } = req.body;

        if (!data || !Array.isArray(data)) {
            return res.status(400).json({ error: 'Invalid data format' });
        }

        for (const entry of data) {
            const { name, masterid, status, createdon, lastmodifiedby, lastmodifieddate, createdby } = entry;

            if (!name || !masterid || !status || !createdon || !createdby) {
                return res.status(400).json({ error: 'Missing required fields in entry' });
            }

            const fileExists = await MastersData.findOne({
                where: {
                    name,
                    masterid,
                    status,
                    createdon,
                    createdby,
                }
            });

            if (fileExists) {
                return res.status(400).json({ error: `Masters Data with name '${name}' already exists` });
            }

            const categoryData = {
                name,
                masterid,
                status,
                createdon,
                createdby,
            };

            if (lastmodifiedby !== undefined) {
                categoryData.lastmodifiedby = lastmodifiedby;
            }

            if (lastmodifieddate !== undefined) {
                categoryData.lastmodifieddate = lastmodifieddate;
            }

            await MastersData.create(categoryData);
        }

        res.json({ msg: "Masters Data Added Successfully" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
};


export const getMastersDataById = async (req, res) => {
    try {
        const response = await MastersData.findOne({
            where: {
                dataid: req.params.dataid
            }
        });
        res.status(200).json(response);
    } catch (error) {
        console.log(error.message);
    }
}

export const getMastersDataByMasterId = async (req, res) => {
    try {
        const response = await MastersData.findAll({
            where: {
                masterid: req.params.masterid
            }
        });
        res.status(200).json(response);
    } catch (error) {
        console.log(error.message);
    }
}

export const updateMastersData = async (req, res) => {
    const { name, lastmodifiedby } = req.body;
    try {
        const updateData = {
            name,
            lastmodifiedby,
            lastmodifieddate: new Date(),
        };

        const condition = {
            where: {
                dataid: req.params.dataid
            }
        };
        const updatedMastersData = await MastersData.update(updateData, condition);
        res.status(200).json({ msg: "Masters Data Updated Successfully" });
    } catch (error) {
        console.log(error.message);
    }
}

export const deleteMastersData = async (req, res) => {
    try {
        await MastersData.destroy({

            where: {
                dataid: req.params.dataid
            }
        });
        res.status(200).json({ msg: "Masters Data Deleted" });
    } catch (error) {
        console.log(error.message);
    }
}

export const deleteMastersDataByMasterid = async (req, res) => {
    try {
        await MastersData.destroy({

            where: {
                masterid: req.params.masterid
            }
        });
        res.status(200).json({ msg: "Masters Data Deleted" });
    } catch (error) {
        console.log(error.message);
    }
}

export const deleteCategoryType = async (req, res) => {
    try {
        await MastersData.destroy({
            where: {
                masterid: req.params.categoryTypeMasterId
            }
        });
        res.status(200).json({ msg: "Category Type Deleted" });
    } catch (error) {
        console.log(error.message);
    }
}