import Category from "../../models/MastersModel.js";
import { Op } from 'sequelize';
import { v4 as uuidv4 } from 'uuid';
import path from 'path';
import multer from 'multer';
import fs from 'fs/promises';
import { log } from "console";

export const getAllCategory = async (req, res) => {
    try {
        const inst = await Category.findAll({
        });
        res.json(inst);
    } catch (error) {
        console.log(error);
    }
}

export const createCategory = async (req, res) => {

    const { mastername, category, createdby, image, status } = req.body;

    // Validate required fields
    if (!mastername || !category || !createdby) {
        return res.status(400).json({ error: 'mastername, category, and createdby are required fields' });
    }

    try {
        // Check if category with the same name already exists
        const existingCategory = await Category.findOne({
            where: {
                mastername
            }
        });

        if (existingCategory) {
            return res.status(400).json({ error: 'Category already exists' });
        }

        let imageBuffer = null;

        if (image) {
            const base64Data = image.replace(/^data:image\/\w+;base64,/, '');

            imageBuffer = Buffer.from(base64Data, 'base64');
        }

        const categoryData = {
            mastername,
            category,
            createdon: new Date(),
            createdby,
            status: '1',
            image: imageBuffer,
        };

        // Handle optional properties
        if (req.body.lastmodifiedby !== undefined) {
            categoryData.lastmodifiedby = req.body.lastmodifiedby;
        }

        if (req.body.lastmodifieddate !== undefined) {
            categoryData.lastmodifieddate = req.body.lastmodifieddate;
        }

        // Create a new category in the database
        await Category.create(categoryData);

        res.json({ msg: 'Category Added Successfully' });
    } catch (error) {
        console.error(error);

        // More specific error handling based on the actual error type
        if (error.name === 'SequelizeValidationError') {
            return res.status(400).json({ error: 'Validation error. Please check your input data.' });
        }

        res.status(500).json({ error: 'Internal Server Error' });
    }
};

export const getCategoryById = async (req, res) => {
    try {
        const response = await Category.findOne({
            where: {
                masterid: req.params.masterid
            }
        });
        res.status(200).json(response);
    } catch (error) {
        console.log(error.message);
    }
}

export const getCategoryByMasterId = async (req, res) => {
    try {
        const response = await Category.findAll({
            where: {
                category: req.params.masterid
            }
        });
        res.status(200).json(response);
    } catch (error) {
        console.log(error.message);
    }
}

export const getSubCategoryById = async (req, res) => {
    try {
        const response = await Category.findAll({
            where: {
                category: req.params.masterid
            }
        });
        res.status(200).json(response);
    } catch (error) {
        console.log(error.message);
    }
}


export const getMainCategory = async (req, res) => {
    try {
        const response = await Category.findAll({
            where: {
                category: '0'
            }
        });
        res.status(200).json(response);
    } catch (error) {
        console.log(error.message);
    }
}

export const getGeneralCategory = async (req, res) => {
    try {
        const response = await Category.findAll({
            where: {
                category: '9998'
            }
        });
        res.status(200).json(response);
    } catch (error) {
        console.log(error.message);
    }
}

export const getSubCategory = async (req, res) => {
    try {
        const response = await Category.findAll({
            where: {
                category: {
                    [Op.ne]: '0'
                }
            }
        });

        res.status(200).json(response);
    } catch (error) {
        console.log(error.message);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}

export const updateCategory = async (req, res) => {
    const { mastername, lastmodifiedby, category, status, image } = req.body;
    let imageBuffer = null;

    if (image) {
        const base64Data = image.replace(/^data:image\/\w+;base64,/, '');

        imageBuffer = Buffer.from(base64Data, 'base64');
    }
    try {
        const updateData = {
            mastername,
            lastmodifiedby,
            category,
            status: '1',
            lastmodifieddate: new Date(),
            image: imageBuffer,
        };

        const condition = {
            where: {
                masterid: req.params.masterid
            }
        };
        const updatedCategory = await Category.update(updateData, condition);
        res.status(200).json({ msg: "Category Updated Successfully" });
    } catch (error) {
        console.log(error.message);
    }
}

export const deleteMainCategory = async (req, res) => {
    try {
        await Category.destroy({
            where: {
                masterid: req.params.masterid
            }
        });
        res.status(200).json({ msg: "Main Category Deleted" });
    } catch (error) {
        console.log(error.message);
    }
}

export const deleteSubCategory = async (req, res) => {
    try {
        await Category.destroy({
            where: {
                masterid: req.params.masterid
            }
        });
        res.status(200).json({ msg: "Sub Category Deleted" });
    } catch (error) {
        console.log(error.message);
    }
}

export const deleteSubCategoryByMasterid = async (req, res) => {
    try {
        await Category.destroy({
            where: {
                category: req.params.masterid
            }
        });
        res.status(200).json({ msg: "Sub Category Deleted" });
    } catch (error) {
        console.log(error.message);
    }
}

export const getSubCategoryByCategory = async (req, res) => {
    try {
        const response = await Category.findOne({
            where: {
                category: req.params.masterid
            }
        });
        res.status(200).json(response);
    } catch (error) {
        console.log(error.message);
    }
}

