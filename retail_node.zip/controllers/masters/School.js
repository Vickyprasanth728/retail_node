import { executeStoredProcedure } from '../../middleware/storeproceduremiddleware.js';
import { formatDateToYYYYMMDD, formatDateTimeToYYYYMMDDHHMMSS } from '../../Utils/Datetime.js';
import moment from 'moment-timezone';
const currentDate = new Date();
const isoDateString = currentDate.toISOString();

const originalMoment = moment(isoDateString);
const originalDate = originalMoment.toDate();

const formattedDate = formatDateToYYYYMMDD(originalDate);

const formattedDateTime = formatDateTimeToYYYYMMDDHHMMSS(originalDate);

//@route      POST /api/v1/cart/AddSchool
//@desc       To Add School
//@access     Private
export const AddSchool = async (req, res) => {
    try {
        const { schoolcode, name, address,email, mobileno, createdby } = req.body;
        const SchoolResults = await executeStoredProcedure('SP_InsertSchool', [schoolcode, name, address,email, mobileno, createdby, '', '']);
        if (SchoolResults && SchoolResults.status === true) {
            console.log(JSON.stringify(SchoolResults));
            res.status(200).json({ issuccess: true, message: SchoolResults.message });
        }
        else {
            res.status(400).json({ issuccess: false, message: SchoolResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ issuccess: false, error: 'Internal Server Error', message: error.message });
    }
};

export const updateSchool = async (req, res) => {
    try {
        const { schoolid, schoolcode, name, address,email, mobileno, lastmodifiedby } = req.body;
        const SchoolResults = await executeStoredProcedure('SP_UpdateSchool', [schoolid, schoolcode, name, address,email, mobileno, lastmodifiedby, '', '']);
        if (SchoolResults && SchoolResults.status === true) {
            console.log(JSON.stringify(SchoolResults));
            res.status(200).json({ issuccess: true, message: SchoolResults.message });
        }
        else {
            res.status(400).json({ issuccess: false, message: SchoolResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ issuccess: false, error: 'Internal Server Error', message: error.message });
    }
};

export const deleteSchool = async (req, res) => {
    try {
        const { schoolid } = req.body;
        const SchoolResults = await executeStoredProcedure('SP_DeleteSchool', [schoolid, '', '']);
        if (SchoolResults && SchoolResults.status === true) {
            console.log(JSON.stringify(SchoolResults));
            res.status(200).json({ issuccess: true, message: SchoolResults.message });
        }
        else {
            res.status(400).json({ issuccess: false, message: SchoolResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ issuccess: false, error: 'Internal Server Error', message: error.message });
    }
};

export const getAllSchools = async (req, res) => {
    try {
        const SchoolResults = await executeStoredProcedure('SP_getschoolcode', []);
        if (SchoolResults && SchoolResults.status === true) {
            const SchoolData = JSON.parse(SchoolResults.data);
            console.log(JSON.stringify(SchoolData));
            res.status(200).json({ issuccess: true, SchoolData });
        }
        else {
            res.status(400).json({ issuccess: false, message: SchoolResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ issuccess: false, error: 'Internal Server Error', error: SchoolResults.message });
    }
};

export const getschoolcode_withPGN = async (req, res) => {
    try {
        const { pageno,limit } = req.body;
        const SchoolResults = await executeStoredProcedure('SP_getschoolcode_withPGN', [pageno,limit, '', '']);
        if (SchoolResults && SchoolResults.status === true) {
            const SchoolData = JSON.parse(SchoolResults.data);
            console.log(JSON.stringify(SchoolData));
            res.status(200).json({ issuccess: true, SchoolData ,totalcount:SchoolResults.totalcount});
        }
        else {
            res.status(400).json({ issuccess: false, message: SchoolResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ issuccess: false, error: 'Internal Server Error', error: SchoolResults.message });
    }
};

export const getSchoolById = async (req, res) => {
    try {
        const { schoolid } = req.body;
        const SchoolResults = await executeStoredProcedure('SP_getschoolcodeByID', [schoolid]);
        if (SchoolResults && SchoolResults.status === true) {
            const SchoolData = JSON.parse(SchoolResults.data);
            console.log(JSON.stringify(SchoolData));
            res.status(200).json({ issuccess: true, SchoolData });
        }
        else {
            res.status(400).json({ issuccess: false, message: SchoolResults.message });
        }

    } catch (error) {
        console.log(error);
        res.status(500).json({ issuccess: false, error: 'Internal Server Error', message: error.message });
    }
};
export const CheckUniqueSchoolcode = async (req, res) => {
    try {
        const { schoolcode } = req.body;
        const SchoolResults = await executeStoredProcedure('SP_CheckUniqueSchoolcode', [schoolcode]);
        if (SchoolResults && SchoolResults.status === false) {
            console.log(JSON.stringify(SchoolResults));
            res.status(400).json({ issuccess: false, message: SchoolResults.message });
        }
        else {
            res.status(200).json({ issuccess: true, message: SchoolResults.message });
        }

    } catch (error) {
        console.log(error);
        res.status(500).json({ issuccess: false, error: 'Internal Server Error', message: error.message });
    }
};
