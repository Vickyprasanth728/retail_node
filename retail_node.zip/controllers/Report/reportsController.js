import { executeStoredProcedure } from '../../middleware/storeproceduremiddleware.js';
import { formatDateToYYYYMMDD, formatDateTimeToYYYYMMDDHHMMSS } from '../../Utils/Datetime.js';
import moment from 'moment-timezone';
const currentDate = new Date();
const isoDateString = currentDate.toISOString();
import crypto from 'crypto';

const originalMoment = moment(isoDateString);
const originalDate = originalMoment.toDate();

const formattedDate = formatDateToYYYYMMDD(originalDate);

const formattedDateTime = formatDateTimeToYYYYMMDDHHMMSS(originalDate);

import { db } from '../../config/Database.js';
import path from 'path';
import fs from 'fs';
import mailer from '../../middleware/mailer.model.js';

import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Transaction Report
export const transactionReport = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

    try {
        const filters = req.query;
            
            let thisQuery = `
            SELECT
            tra.id,
            tra.transid,
            tra.productid,
            tra.userid,
            tra.ordernumber,
            tra.status,
            tra.createdon, 
            tra.quantity, 
            tra.productid as trans_product_id,
            (JSON_ARRAY(
                    JSON_OBJECT(
                        'productid', p.productid,
                        'name', p.name,
                        'description', p.description,
                        'quantity', tra.quantity
                    )
                )
            ) AS product_details,
            (JSON_ARRAY(
                    JSON_OBJECT(
                        'ccavenue_transid', tb.ccavenue_transid,
                        'status', tb.status,
                        'tpricegst', tb.tpricegst,
                        'tweight', tb.tweight,
                        'shipping_charges', tb.shipping_charges,
                        'type', tb.type,
                        'actual_price', tb.actual_price,
                        'transaction_price', tb.transaction_price,
                        'payment_type', tb.payment_type
                    )
                )
            ) AS billing_details
            FROM transactions as tra
            LEFT JOIN transaction_billing as tb ON (tb.id = tra.childbillid)
            LEFT JOIN product as p ON (p.productid = tra.productid)
            ${filters?.school ? `
            LEFT JOIN productschoolmap as psm ON (p.productid = psm.productid)
            LEFT JOIN schoolgrademap as sgm ON (sgm.gradeid = psm.schoolid) ` : ``}
            ${filters?.category ? `
            LEFT JOIN category as cat ON (cat.id = p.masterid) ` : ``}
            WHERE tra.id IS NOT NULL
            `
            if (filters?.status) {
                thisQuery += ` AND tra.status = '${filters?.status}' `
            }
            if (filters?.school) {
                thisQuery += ` AND sgm.schoolid = '${filters?.school}' `
            }
            if (filters?.category) {
                thisQuery += ` AND cat.id = '${filters?.category}' `
            }
            if (filters?.start_date) {
                thisQuery += ` AND DATE(tra.createdon) >= '${filters?.start_date}' `
            }
            if (filters?.end_date) {
                thisQuery += ` AND DATE(tra.createdon) <= '${filters?.end_date}' `
            }
            thisQuery += ` GROUP BY tra.id `
            const [data] = await db.query(thisQuery);

            console.log('data', data);
            
            res.status(200).send({
                status: true,
                count: data?.length,
                message: 'Transaction reports retrieved successfully',
                data: data
            });
    } 
    catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
    
};