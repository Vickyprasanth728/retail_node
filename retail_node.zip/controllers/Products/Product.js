import { executeStoredProcedure } from '../../middleware/storeproceduremiddleware.js';
import { formatDateToYYYYMMDD, formatDateTimeToYYYYMMDDHHMMSS } from '../../Utils/Datetime.js';
import moment from 'moment-timezone';

const currentDate = new Date();
const isoDateString = currentDate.toISOString();

const originalMoment = moment(isoDateString);
const originalDate = originalMoment.toDate();

const formattedDate = formatDateToYYYYMMDD(originalDate);

const formattedDateTime = formatDateTimeToYYYYMMDDHHMMSS(originalDate);

import { db } from '../../config/Database.js';

import path from 'path';
import fs from 'fs';
import puppeteer from 'puppeteer';
import axios from 'axios';

import xlsx from 'xlsx';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import readXlsxFile from 'read-excel-file/node';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

import PDFDocument from 'pdfkit';
import jsPDF from 'jspdf';


// ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION

// (async () => {
//     try {
//         // const puppeteer = require('puppeteer'); // Make sure to require puppeteer
//         const browser = await puppeteer.launch({ headless: false, args: ['--no-sandbox', '--disable-setuid-sandbox'] });
//         const page = await browser.newPage();
        
//         await page.setContent('<h1>Hello World!</h1>');
//         // await page.waitForTimeout(1000); // Wait for 1 second

//         await page.pdf({ path: 'output.pdf', format: 'A4', timeout: 20000 }); // Increased timeout
//         console.log('Success');
        
//         await browser.close();
//     } catch (error) {
//         console.log('Error:', error);
//     }
// })();


//@route      POST /api/v1/Product/AddProduct
//@desc       To AddP roduct
//@access     Private
export const AddProduct1 = async (req, res) => {
    try {
        const { barcode, masterid, name, description, price, gst, discount, productstatus, ispublic, isuniform, createdon, createdby } = req.body;
        const { schoolid, imageseq, image } = req.body;
        const schoolidJSON = [];
        try {
            if (schoolid && Array.isArray(schoolid) && schoolid.length > 0) {
                console.log(schoolid);
                for (const code of schoolid) {
                    const jsonString = JSON.stringify(code);
                    schoolidJSON.push(jsonString);
                }
                console.log(schoolidJSON);
            }
        } catch (error) {
            // Handle any errors during conversion, such as invalid data types or circular references
            console.error('Error converting schoolid to JSON:', error);
        }
        const imageseqJSON = [];
        try {
            if (imageseq && Array.isArray(imageseq) && imageseq.length > 0) {
                console.log(imageseq);
                for (const code of imageseq) {
                    const jsonString = JSON.stringify(code);
                    imageseqJSON.push(jsonString);
                }
                console.log(imageseqJSON);
            }
        } catch (error) {
            // Handle any errors during conversion, such as invalid data types or circular references
            console.error('Error converting imageseq to JSON:', error);
        }

        const imageJSON = [];
        try {
            if (image && Array.isArray(image) && image.length > 0) {
                console.log(image.length);
                for (const code of image) {
                    const jsonString = JSON.stringify(code);
                    imageJSON.push(jsonString);
                }
            }
        } catch (error) {
            // Handle any errors during conversion, such as invalid data types or circular references
            console.error('Error converting image to JSON:', error);
        }
        res.status(301).json({ issuccess: false, message: "Moved" });
        // const ProductResults = await executeStoredProcedure('SP_AddProduct', [barcode, masterid, name, description, price, gst, discount, productstatus, ispublic, isuniform, createdon, createdby, schoolidJSON, imageseqJSON, imageJSON, '', '']);
        // if (ProductResults && ProductResults.status === true) {
        //     console.log(JSON.stringify(ProductResults));
        //     res.status(200).json({ issuccess: true, message: ProductResults.message });
        // }
        // else {
        //     res.status(400).json({ issuccess: false, message: ProductResults.message });
        // }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

//@route      POST /api/v1/Product/AddProductWithSubCatid
//@desc       To Add Product With SubCatid
//@access     Private
export const AddProductWithSubCatid = async (req, res) => {
    try {
        const { barcode, masterid, name, description, price, gst, discount, productstatus, ispublic, isuniform, createdon, createdby } = req.body;
        const { subcategorymasterid, subcategorydataid, schoolid, imageseq, image } = req.body;
        const schoolidJSON = [];
        try {
            if (schoolid && Array.isArray(schoolid) && schoolid.length > 0) {
                console.log(schoolid);
                for (const code of schoolid) {
                    const jsonString = JSON.stringify(code);
                    schoolidJSON.push(jsonString);
                }
                console.log(schoolidJSON);
            }
        } catch (error) {
            // Handle any errors during conversion, such as invalid data types or circular references
            console.error('Error converting schoolid to JSON:', error);
        }
        const subcategorymasteridJSON = [];
        try {
            if (subcategorymasterid && Array.isArray(subcategorymasterid) && subcategorymasterid.length > 0) {
                console.log(subcategorymasterid);
                for (const code of subcategorymasterid) {
                    const jsonString = JSON.stringify(code);
                    subcategorymasteridJSON.push(jsonString);
                }
                console.log(subcategorymasteridJSON);
            }
        } catch (error) {
            // Handle any errors during conversion, such as invalid data types or circular references
            console.error('Error converting subcategorymasterid to JSON:', error);
        }
        const subcategorydataidJSON = [];
        try {
            if (subcategorydataid && Array.isArray(subcategorydataid) && subcategorydataid.length > 0) {
                console.log(subcategorydataid);
                for (const code of subcategorydataid) {
                    const jsonString = JSON.stringify(code);
                    subcategorydataidJSON.push(jsonString);
                }
                console.log(subcategorydataidJSON);
            }
        } catch (error) {
            // Handle any errors during conversion, such as invalid data types or circular references
            console.error('Error converting subcategorydataid to JSON:', error);
        }
        const imageseqJSON = [];
        try {
            if (imageseq && Array.isArray(imageseq) && imageseq.length > 0) {
                console.log(imageseq);
                for (const code of imageseq) {
                    const jsonString = JSON.stringify(code);
                    imageseqJSON.push(jsonString);
                }
                console.log(imageseqJSON);
            }
        } catch (error) {
            // Handle any errors during conversion, such as invalid data types or circular references
            console.error('Error converting imageseq to JSON:', error);
        }

        const imageJSON = [];
        try {
            if (image && Array.isArray(image) && image.length > 0) {
                console.log(image.length);
                for (const code of image) {
                    const jsonString = JSON.stringify(code);
                    imageJSON.push(jsonString);
                }
            }
        } catch (error) {
            // Handle any errors during conversion, such as invalid data types or circular references
            console.error('Error converting image to JSON:', error);
        }
        const parameters =  [barcode, masterid, subcategorymasteridJSON, subcategorydataidJSON, name, description, price, gst, discount, productstatus, ispublic, isuniform, createdon, createdby, schoolidJSON, imageseqJSON, imageJSON, '', ''];
        console.log(JSON.stringify(parameters))
        const ProductResults = await executeStoredProcedure('SP_AddProduct',parameters);
        if (ProductResults && ProductResults.status === true) {
            console.log(JSON.stringify(ProductResults));
            res.status(200).json({ issuccess: true, message: ProductResults.message });
        }
        else {
            res.status(400).json({ issuccess: false, message: ProductResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

//@route      POST /api/v1/Product/updateProduct
//@desc       To update Product
//@access     Private
export const updateProduct1 = async (req, res) => {
    try {
        const { barcode, productid, masterid, name, description, price, gst, discount, productstatus, ispublic, isuniform, lastmodifiedat, lastmodifiedby } = req.body;
        const { schoolid, imageseq, image } = req.body;
        const schoolidJSON = [];
        try {
            if (schoolid && Array.isArray(schoolid) && schoolid.length > 0) {
                console.log(schoolid);
                for (const code of schoolid) {
                    const jsonString = JSON.stringify(code);
                    schoolidJSON.push(jsonString);
                }
                console.log(schoolidJSON);
            }
        } catch (error) {
            // Handle any errors during conversion, such as invalid data types or circular references
            console.error('Error converting schoolid to JSON:', error);
        }
        const imageseqJSON = [];
        try {
            if (imageseq && Array.isArray(imageseq) && imageseq.length > 0) {
                console.log(imageseq);
                for (const code of imageseq) {
                    const jsonString = JSON.stringify(code);
                    imageseqJSON.push(jsonString);
                }
                console.log(imageseqJSON);
            }
        } catch (error) {
            // Handle any errors during conversion, such as invalid data types or circular references
            console.error('Error converting imageseq to JSON:', error);
        }
        const imageJSON = [];
        try {
            if (image && Array.isArray(image) && image.length > 0) {
                console.log(image);
                for (const code of image) {
                    const jsonString = JSON.stringify(code);
                    imageJSON.push(jsonString);
                }
                console.log(imageJSON);
            }
        } catch (error) {
            // Handle any errors during conversion, such as invalid data types or circular references
            console.error('Error converting image to JSON:', error);
        }

        const ProductResults = await executeStoredProcedure('SP_UpdateProduct', [productid, barcode, masterid, name, description, price, gst, discount, productstatus, ispublic, isuniform, lastmodifiedat, lastmodifiedby, schoolidJSON, imageseqJSON, imageJSON, '', '']);
        if (ProductResults && ProductResults.status === true) {
            console.log(JSON.stringify(ProductResults));
            res.status(200).json({ issuccess: true, message: ProductResults.message });
        }
        else {
            res.status(400).json({ issuccess: false, message: ProductResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

export const updateProductwithCat = async (req, res) => {
    try {
        const { barcode, productid, masterid, name, description, price, gst, discount, productstatus, ispublic, isuniform, lastmodifiedat, lastmodifiedby } = req.body;
        const { subcategorymasterid, subcategorydataid, schoolid, imageseq, image } = req.body;
        const subcategorymasteridJSON = [];
        try {
            if (subcategorymasterid && Array.isArray(subcategorymasterid) && subcategorymasterid.length > 0) {
                for (const code of subcategorymasterid) {
                    const jsonString = JSON.stringify(code);
                    subcategorymasteridJSON.push(jsonString);
                }
                console.log(subcategorymasteridJSON);
            }
        } catch (error) {
            console.error('Error converting subcategorymasterid to JSON:', error);
        }
        const subcategorydataidJSON = [];
        try {
            if (subcategorydataid && Array.isArray(subcategorydataid) && subcategorydataid.length > 0) {
                for (const code of subcategorydataid) {
                    const jsonString = JSON.stringify(code);
                    subcategorydataidJSON.push(jsonString);
                }
                console.log(subcategorydataidJSON);
            }
        } catch (error) {
            console.error('Error converting subcategorydataid to JSON:', error);
        }
        const schoolidJSON = [];
        try {
            if (schoolid && Array.isArray(schoolid) && schoolid.length > 0) {
                console.log(schoolid);
                for (const code of schoolid) {
                    const jsonString = JSON.stringify(code);
                    schoolidJSON.push(jsonString);
                }
                console.log(schoolidJSON);
            }
        } catch (error) {
            // Handle any errors during conversion, such as invalid data types or circular references
            console.error('Error converting schoolid to JSON:', error);
        }
        const imageseqJSON = [];
        try {
            if (imageseq && Array.isArray(imageseq) && imageseq.length > 0) {
                console.log(imageseq);
                for (const code of imageseq) {
                    const jsonString = JSON.stringify(code);
                    imageseqJSON.push(jsonString);
                }
                console.log(imageseqJSON);
            }
        } catch (error) {
            // Handle any errors during conversion, such as invalid data types or circular references
            console.error('Error converting imageseq to JSON:', error);
        }
        const imageJSON = [];
        try {
            if (image && Array.isArray(image) && image.length > 0) {
                console.log(image);
                for (const code of image) {
                    const jsonString = JSON.stringify(code);
                    imageJSON.push(jsonString);
                }
                console.log(imageJSON);
            }
        } catch (error) {
            // Handle any errors during conversion, such as invalid data types or circular references
            console.error('Error converting image to JSON:', error);
        }

        const ProductResults = await executeStoredProcedure('SP_UpdateProduct', [productid, barcode, masterid, subcategorymasteridJSON, subcategorydataidJSON, name, description, price, gst, discount, productstatus, ispublic, isuniform, lastmodifiedat, lastmodifiedby, schoolidJSON, imageseqJSON, imageJSON, '', '']);
        if (ProductResults && ProductResults.status === true) {
            console.log(JSON.stringify(ProductResults));
            res.status(200).json({ issuccess: true, message: ProductResults.message });
        }
        else {
            res.status(400).json({ issuccess: false, message: ProductResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

export const deleteProduct = async (req, res) => {
    try {
        const { productid } = req.body;
        const ProductResults = await executeStoredProcedure('SP_DeleteProduct', [productid, '', '']);
        if (ProductResults && ProductResults.status === true) {
            console.log(JSON.stringify(ProductResults));
            res.status(200).json({ issuccess: true, message: ProductResults.message });
        }
        else {
            res.status(400).json({ issuccess: false, message: ProductResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

export const getAllProducts = async (req, res) => {
    try {
        const ProductResults = await executeStoredProcedure('SP_GetProductAll', ['', '']);
        if (ProductResults && ProductResults.status === true) {
            console.log(JSON.stringify(ProductResults));
            const ProductData = JSON.parse(ProductResults.data);
            res.status(200).json({ issuccess: true, message: ProductResults.message, ProductData });
        }
        else {
            res.status(400).json({ issuccess: false, message: ProductResults.message });
        }

    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

export const getGradeBySchoolIdSP = async (req, res) => {
    try {
        const ProductResults = await executeStoredProcedure('SP_GetGradeBySchoolId', ['', '']);
        if (ProductResults && ProductResults.status === true) {
            console.log(JSON.stringify(ProductResults));
            const ProductData = JSON.parse(ProductResults.data);
            res.status(200).json({ issuccess: true, message: ProductResults.message, ProductData });
        }
        else {
            res.status(400).json({ issuccess: false, message: ProductResults.message });
        }

    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};



// getInitSTOREDPROCEDURE
export const getInitSTOREDPROCEDURE = async (req, res) => {
    try {
        const ProductResults = await executeStoredProcedure('getInitAddProdcutDetails', ['', '']);
        console.log(JSON.stringify(ProductResults, null, 2));

        if (ProductResults) {
            console.log(JSON.stringify(ProductResults));
            // const ProductData = JSON.parse(ProductResults);
            const ProductData = JSON.parse(JSON.stringify(ProductResults.result[0]?.result));
            setTimeout(() => {
                res.status(200).json({ issuccess: true, message: ProductResults.message, ProductData });

            }, 1500)
        }
        else {
            res.status(400).json({ issuccess: false, message: ProductResults.message });
        }

    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

















// Get Product List
export const getProductList = async (req, res) => {
    try {
        
        await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

        let thisQueryBarcode = ` SELECT p.* FROM product as p `
        const dataB = await db.query(thisQueryBarcode); 

        console.log(JSON.stringify(dataB[0].length, null, 2));

        // JSON_ARRAYAGG(
        //     JSON_OBJECT(
        //         'imageseq', productimage.imageseq,
        //         'image', productimage.image
        //     )
        // ) AS imageseq

        if (dataB[0].length <= 0) {
            
            res.status(200).send({
                issuccess: false, 
                p_result_status : 'ERROR',
                p_result_message : 'Product does not exists',
              });
        } 
        else {

        let thisQ = `  SELECT
            p.productid,
            p.masterid,
            productschoolmap.schoolid,
            p.name,
            p.description,
            p.price,
            p.gst,
            GROUP_CONCAT(DISTINCT(productimage.imageseq) SEPARATOR '; ') AS imageseq,
            p.productstatus,
            p.createdon,
            p.lastmodifiedate,
            p.lastmodifiedby,
            p.createdby
        FROM
            product p
        LEFT JOIN productschoolmap ON (productschoolmap.productid = p.productid)
        LEFT JOIN productimage ON (productimage.productid = p.productid)
        GROUP BY p.productid
        `

        const thisData = await db.query(thisQ);

        if (thisData) {
            // console.log(JSON.stringify(ProductResults));
            const ProductData = thisData[0];
            // res.status(200).json({ issuccess: true, message: 'success', ProductData });
            res.status(200).send({
                issuccess: true, 
                p_result_status : 'SUCCESS',
                p_result_message : 'Product information retrieved successfully',
                ProductData
            });
        }
        else {
            res.status(400).json({ issuccess: false, message: 'failure' });
        }
    }

    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

// ===========================  ADD PRODUCT API`S ======================================
// Get Grade By School-Id
export const getGradeBySchoolId = async (req, res) => {
    try {
        await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

        const id = req.params.id;

        let thisQuery = `SELECT 
        sgm.id as dataid, 
        sc.schoolid as schoolid, 
        sgm.gradeid as masterdata_id, 
        sc.name as schoolname,
        md.name as name
        FROM school as sc
        LEFT JOIN schoolgrademap as sgm on (sc.schoolid = sgm.schoolid)
        LEFT JOIN mastersdata as md on (md.dataid = sgm.gradeid)
        WHERE sc.schoolid = '${id}' 
        GROUP BY sgm.id
        `

        // let thisQuery = `SELECT 
        // sgm.id as dataid, 
        // sc.schoolid as schoolid, 
        // sgm.gradeid as masterdata_id, 
        // sc.name as schoolname,
        // md.name as name
        // FROM product as p
        // LEFT JOIN productschoolmap as psm on (p.productid = psm.productid)
        // LEFT JOIN schoolgrademap as sgm on (psm.schoolid = sgm.id)
        // LEFT JOIN mastersdata as md on (md.dataid = sgm.gradeid)
        // LEFT JOIN school as sc on (sc.schoolid = sgm.schoolid)
        // WHERE sc.schoolid IN ('${id}') 
        // GROUP BY sgm.id
        // `
        const ProductResults = await db.query(thisQuery);

        console.log(ProductResults[0].length < 0);
        
        if (ProductResults) {
            // console.log(JSON.stringify(ProductResults));

            if (ProductResults[0].length <= 0) {

                const ProductData = ProductResults[0];
                // res.status(200).json({ issuccess: true, message: ProductResults.message, ProductData });
                res.status(200).send({
                    issuccess: false, 
                    message: `school id not found : ${id} `, 
                });

            } else {
                const ProductData = ProductResults[0];
                // res.status(200).json({ issuccess: true, message: ProductResults.message, ProductData });
                res.status(200).send({
                    issuccess: true, 
                    count : ProductData.length,
                    message: ProductResults.message, 
                    ProductData
                });

            }
    
        }
        else {
            res.status(400).json({ issuccess: false, message: ProductResults.message });
        }

    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};
// Get Init Add Product Details
export const getInitAddProductDetails = async (req, res) => {
    try {

        //  category: [{id:1,name:shirts},{id:2, name:pant},{id:3,name:socks}],
        //  school:[{id:1,name:1}],
        //  gender:[{id:5,name:boy}],
        //  size:[{id:1,name:22},{id:2,name:24}],
        //  color:[{id:1,name:red},{id:2,name:green}],
        //  gst:[{id:1,name:No},{id:2,name:5%},{id:3,name:12%],
        
        await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

        let thisQueryCategory = `SELECT 
        m.masterid as id, 
        m.mastername as name
        FROM masters as m
        WHERE m.category = 0
        GROUP BY m.masterid `
        let thisQuery = `SELECT 
        s.schoolid as id, 
        s.name as name
        FROM school as s `
        let thisQueryGender = `SELECT 
        md.dataid as id, 
        md.name as name
        FROM masters as m
        LEFT JOIN mastersdata as md ON (m.masterid = md.masterid)
        WHERE m.mastername = 'Gender'
        GROUP BY md.dataid `
        let thisQueryColor = `SELECT 
        md.dataid as id, 
        md.name as name
        FROM masters as m
        LEFT JOIN mastersdata as md ON (m.masterid = md.masterid)
        WHERE m.mastername = 'Color'
        GROUP BY md.dataid `
        let thisQuerySize = `SELECT 
        md.dataid as id, 
        md.name as name
        FROM masters as m
        LEFT JOIN mastersdata as md ON (m.masterid = md.masterid)
        WHERE m.mastername = 'Size'
        GROUP BY md.dataid `
        let thisQueryGST = `SELECT 
        gst.id as id,
        gst.name as name
        FROM gst as gst
        WHERE gst.status = 1
        GROUP BY gst.id `

        const SchoolData = await db.query(thisQuery);
        const GenderData = await db.query(thisQueryGender);
        const ColorData = await db.query(thisQueryColor);
        const SizeData = await db.query(thisQuerySize);
        const CategoryData = await db.query(thisQueryCategory);
        const GSTData = await db.query(thisQueryGST);

        // console.log(JSON.stringify(GSTData[0], null, 2));

        const Results = { 'category': CategoryData[0], 'school':SchoolData[0], 'gender':GenderData[0], 'color': ColorData[0], 'size' : SizeData[0], 'gst': GSTData[0]}

        if (Results) {
            // console.log(JSON.stringify(ProductResults));
            const ProductData = Results;
            // res.status(200).json({ issuccess: true, message: 'success', ProductData });
            res.status(200).send({
                issuccess: true, 
                message: 'success', 
                count : ProductData.length,
                ProductData
            });
        }
        else {
            res.status(400).json({ issuccess: false, message: 'failure' });
        }

    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};
// Add Product
export const addProduct = async (req, res) => {

    await db.query('START TRANSACTION');
    // [{size: 24, color: "red", price: 550, quantity: 50, imageid: 3, weight: 50},{size: 30, color: "green", price: 1020, quantity: 5}
    // ]

    // [{"size": 24, "color": "red", "price": 550, "quantity": 50, "imageid": 3, "weight": 50},{"size": 30, "color": "green", "price": 1020, "quantity": 5}
    // ]

    try {
        
        const { barcode, masterid, name, description, price, gst, gender, weight, discount, productstatus, published, quantity, createdon, createdby } = req.body;

        const { schoolid, imageseq, schoolgrade } = req.body;

        const variants = req.body.variants
        // const pOutput = JSON.parse(variants);
        const parsedOutput = JSON.parse(variants);
        // const parsedOutput = variants;

        const schoolgradeArray = JSON.parse(schoolgrade).length == 0 ? 0 : JSON.parse(schoolgrade);
        const schoolIdArray = JSON.parse(schoolid).length == 0 ? 0 : JSON.parse(schoolid);

        console.log('schoolgradeArray',schoolgradeArray);
        console.log('schoolIdArray',schoolIdArray);
        console.log('schoolgrade',schoolgrade.length);

        let thisQueryS = ` SELECT DISTINCT sgm.gradeid as gradeid FROM schoolgrademap as sgm WHERE sgm.schoolid IN (${schoolIdArray}) `
        const dataSCH = await db.query(thisQueryS);
        const getSchoolGradeID = dataSCH[0].map(i => i.gradeid)

        let thisQueryGra = ` SELECT DISTINCT sgm.gradeid as gradeid FROM schoolgrademap as sgm WHERE sgm.gradeid IN (${schoolgradeArray}) `
        const dataGra = await db.query(thisQueryGra);
        const getGradeID = dataGra[0].map(i => i.gradeid)
        console.log('getGradeID', getGradeID);
        console.log('getSchoolGradeID', getSchoolGradeID);
        
        const schoolCheck = getGradeID.every(value => getSchoolGradeID.includes(value));
        console.log('schoolCheck', schoolCheck);

        let thisQueryP = ` SELECT p.* FROM product as p WHERE p.name = "${name}" `
        const dataP = await db.query(thisQueryP);

        let thisQueryM = ` SELECT m.* FROM masters as m WHERE m.masterid = "${masterid}" `
        const dataM = await db.query(thisQueryM);

        let thisQueryGST = ` SELECT * FROM gst WHERE id = '${gst}' `
        const dataGST = await db.query(thisQueryGST);

        let thisQueryG = ` SELECT md.* FROM mastersdata as md WHERE md.dataid = "${gender}" `
        const dataG = await db.query(thisQueryG);

        const FieldCheck = dataP[0][0] ? dataP[0][0]?.name : 0
        const masterCheck = dataM[0][0] ? dataM[0][0]?.masterid : 0
        // const schoolCheck = dataS[0][0] ? dataS[0][0]?.schoolid : 0
        const gstCheck = dataGST[0][0] ? dataGST[0][0]?.id : 0
        const genCheck = dataG[0][0] ? dataG[0][0]?.dataid : 0

        if (FieldCheck != 0) {
            console.log(`Product name already exists`);
            res.status(409).send({
                status: false,
                message: `product name already exists`,
            });
        } 
        else if (masterCheck == 0 || masterid == undefined) {
            res.status(404).send({
                status: false,
                message: `master-id not found`,
            });
        }
        else if (genCheck == 0 || gender == undefined) {
            res.status(404).send({
                status: false,
                message: `gender-id not found`,
            });
        }
        else if (gstCheck == 0 || gst == undefined) {
            res.status(404).send({
                status: false,
                message: `gst-id not found`,
            });
        }
        else if (schoolCheck == false || schoolIdArray == 0 || schoolgradeArray == 0) {
            res.status(404).send({
                status: false,
                message: `school not found`,
            });
        }
        else {

        // [{"size":"6","color":"red","price":5.00,"quantity":89,"weight":6}]
        // "[{\"size\":\"6\",\"color\":\"red\",\"price\":5.00,\"quantity\":89,\"weight\":6}]"
        // [ { size: '6', color: 'red', price: 5, quantity: 89, weight: 6 } ]
        // console.log(pOutput);

        // const parsedOutput = JSON.parse(pOutput).map(item => ({
        //     size: item.size,
        //     color: item.color,
        //     price: item.price,
        //     quantity: item.quantity,
        //     ...(item.imageid !== undefined && { imageid: item.imageid }),
        //     ...(item.weight !== undefined && { weight: item.weight })
        //   }));
          
        console.log(parsedOutput);

        let image = "";
  
        if (req.files.image) {
          const extension = req.files.image[0]["mimetype"].split('/')[1]
          image = req.files.image[0]["filename"] + '.' + extension
        }

        let thisQuery = ` INSERT INTO product ( masterid, name, description, price, gst, gender, weight, productstatus, published, quantity, createdon, lastmodifiedate, lastmodifiedby, createdby)
        VALUES ( '${masterid}', "${name}", "${description}", '${price}', '${gst}', '${gender}', '${weight}', "${productstatus ? productstatus : 'instock'}", '${published ? published : 0}', '${quantity}', '${formattedDateTime}', '${formattedDateTime}','${createdby ? createdby : 0}', '${createdby ? createdby : 0}' ) `
 
        const data = await db.query(thisQuery); 

        console.log(data[0]);
        
        const InsertId = data[0]; 

        // let thisQueryNew = `INSERT INTO variant (productid, size) VALUES (${InsertId}, '001') `
        // const dataNew = await db.query(thisQueryNew); 

        const schoolidArr = JSON.parse(schoolgrade);
        const schoolLength = schoolidArr?.length;
        console.log(schoolLength);

        for (const num of schoolidArr) {
            let thisQueryPSM = ` INSERT INTO productschoolmap (productid, schoolid) VALUES ( '${InsertId}', '${num}' ) `
            const dataPSM = await db.query(thisQueryPSM); 
            console.log(num);
        }

        if (req.files.image) {
            if (req.files.image.length > 0) {
                // Parse the image sequence
                const imageseqArr = JSON.parse(imageseq);
                
                for (let i = 0; i < req.files.image.length; i++) {
                    if (req.files.image[i]) {
                        const extension = req.files.image[i]["mimetype"].split('/')[1];
                        const image = `${req.files.image[i]["filename"]}.${extension}`;
                        
                        console.log(image);
                        console.log(req.files.image.length);
                        console.log(imageseqArr.length);
        
                        // Check if we have enough sequence numbers for the images
                        if (imageseqArr.length > i) {
                            const num2 = imageseqArr[i];  // Get the corresponding sequence number
                            const thisQueryPimage = `INSERT INTO productimage (productid, imageseq, image) VALUES ('${InsertId}', '${num2}', '${image}')`;
                            await db.query(thisQueryPimage);
        
                            console.log(num2);
        
                            const currentPath = path.join(process.cwd(), "uploads", req.files.image[i]["filename"]);
                            const destinationPath = path.join(process.cwd(), "uploads/product/image/" + `${InsertId}` + `/${num2}`, image);
                            const baseUrl = path.join(process.cwd(), "uploads/product/image", `${InsertId}`, `${num2}`);
                            fs.mkdirSync(baseUrl, { recursive: true });
        
                            fs.rename(currentPath, destinationPath, function (err) {
                                if (err) {
                                    throw err;
                                } else {
                                    console.log("Successfully image Uploaded!");
                                }
                            });
                        } else {
                            console.warn(`Not enough sequence numbers for image ${image}. Expected index ${i}, but got ${imageseqArr?.length}.`);
                        }
                    }
                }
            }
        }

        // for (const variant of parsedOutput) {
        //     const thisQueryVariant = `
        //         INSERT INTO variant (productid, size, color, price, quantity, imageid, weight)
        //         VALUES (
        //             '${InsertId}',
        //             '${variant?.size}', 
        //             '${variant?.color}', 
        //             '${variant?.price}', 
        //             '${variant?.quantity}', 
        //             '${variant?.imageid != undefined ? variant?.imageid : 0}', 
        //             '${variant?.weight != undefined ? variant?.weight : 0}'
        //         )
        //     `;
        //     const dataVariant = await db.query(thisQueryVariant); 
        // }

        // for (const variant of parsedOutput) {
        //     const size = variant?.size;
        //     const color = variant?.color;
        //     const price = variant?.price;
        //     const quantity = variant?.quantity;
        //     const imageid = variant?.imageid !== undefined ? variant?.imageid : 0;
        //     const weight = variant?.weight !== undefined ? variant?.weight : 0;
        
        //     // Check if the record already exists
        //     const checkQuery = `
        //         SELECT COUNT(*) AS count 
        //         FROM variant 
        //         WHERE productid = '${InsertId}' AND size = '${size}' AND color = '${color}'
        //     `;
        //     const checkResult = await db.query(checkQuery);
        //     console.log('checkResult', checkResult, checkResult[0][0]?.count);
            
            
        //     if (checkResult[0][0]?.count === 0) {
        //         let insertQuery = `
        //             INSERT INTO variant (productid, size, color, price, quantity, imageid, weight)
        //             VALUES (
        //                 '${InsertId}',
        //                 '${size}', 
        //                 '${color}', 
        //                 '${price}', 
        //                 '${quantity}', 
        //                 '${imageid}', 
        //                 '${weight}'
        //             )
        //         `;
        //         const dataVariant = await db.query(insertQuery);
        //     }
        // }

        for (const variant of parsedOutput) {
            // Check if the variant already exists
            let checkVariantQuery = `
                SELECT COUNT(*) as count 
                FROM variant 
                WHERE productid = '${InsertId}' 
                AND size = '${variant?.size}' 
                AND color = '${variant?.color}'
            `;
            const existingVariant = await db.query(checkVariantQuery);
            
            if (existingVariant[0][0].count > 0) {
                return res.status(409).send({
                    status: false,
                    message: `Variant with size : ${variant?.size} and color : ${variant?.color} already exists for this product.`,
                });
            } else {
                const thisQueryVariant = `
                    INSERT INTO variant (productid, size, color, price, quantity, imageid, weight)
                    VALUES (
                        '${InsertId}',
                        '${variant?.size}', 
                        '${variant?.color}', 
                        '${variant?.price}', 
                        '${variant?.quantity}', 
                        '${variant?.imageid != undefined ? variant?.imageid : 0}', 
                        '${variant?.weight != undefined ? variant?.weight : 0}'
                    )
                `;
                await db.query(thisQueryVariant); 
            }
        }
        
        
        // let insertQueryD = ` DELETE FROM variant WHERE productid = ${InsertId} AND size = '001' `
        // const dataDelete = await db.query(insertQueryD);
        
        res.status(200).send({
          issuccess: true, 
          p_result_status : 'SUCCESS',
          p_result_message : 'Product added successfully',
        //   ProductData:dataResult[0]
        });
        await db.query('COMMIT');
      } 
      } 
      catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });

        await db.query('ROLLBACK');
    }
};



// ===========================  UPDATE PRODUCT API`S ======================================
// Update Product
export const updateProduct = async (req, res) => {

    await db.query('START TRANSACTION');

    try {

        const { barcode, masterid, name, description, price, gst, gender, weight, discount, productstatus, published, quantity, createdon, createdby } = req.body;

        const { schoolid, imageseq } = req.body;

        const ProductID = req.params.productid
        console.log('ProductID', ProductID);
        
        let thisQueryP = ` SELECT p.* FROM product as p WHERE p.productid = '${ProductID}' `
        const dataP = await db.query(thisQueryP);

        const productCheck = dataP[0][0] ? dataP[0][0]?.productid : 0
        console.log('productCheck', productCheck);

        if (!productCheck) {
            res.status(404).send({
                status: false,
                message: `product id not found : ${ProductID} `,
            });
        } else {

            let thisQueryP = ` SELECT p.* FROM product as p WHERE p.name = "${name}" AND p.productid != '${ProductID}' `
            const dataP = await db.query(thisQueryP);
    
            let thisQueryM = ` SELECT m.* FROM masters as m WHERE m.masterid = "${masterid}" `
            const dataM = await db.query(thisQueryM);
    
            const SID = JSON.parse(schoolid)
            console.log('SID', SID);
            
            let thisQueryS = ` SELECT s.* FROM school as s WHERE s.schoolid `
            const dataS = await db.query(thisQueryS);
            const schoolInititalCheck = dataS[0].map(i => i.schoolid)
            console.log('schoolInititalCheck',schoolInititalCheck);
    
            const schoolCheck = SID.every(value => schoolInititalCheck.includes(value));
            // SELECT COUNT(DISTINCT schoolid) = (SELECT COUNT(*) FROM (SELECT 19 AS value UNION ALL SELECT 21) AS t) AS all_present
            // FROM school
            // WHERE schoolid IN (19, 21);
    
            let thisQueryGST = ` SELECT * FROM gst WHERE id = '${gst}' `
            const dataGST = await db.query(thisQueryGST);
    
            let thisQueryG = ` SELECT md.* FROM mastersdata as md WHERE md.dataid = "${gender}" `
            const dataG = await db.query(thisQueryG);
    
            const FieldCheck = dataP[0][0] ? dataP[0][0]?.name : 0
            const masterCheck = dataM[0][0] ? dataM[0][0]?.masterid : 0
            // const schoolCheck = dataS[0][0] ? dataS[0][0]?.schoolid : 0
            const gstCheck = dataGST[0][0] ? dataGST[0][0]?.id : 0
            const genCheck = dataG[0][0] ? dataG[0][0]?.dataid : 0
            console.log('schoolCheck', schoolCheck);
    
            if (FieldCheck != 0) {
                console.log(`Product name already exists`);
                res.status(409).send({
                    status: false,
                    message: `product name already exists`,
                });
            } 
            else if (masterCheck == 0 || masterid == undefined) {
                res.status(404).send({
                    status: false,
                    message: `master-id not found`,
                });
            }
            else if (genCheck == 0 || gender == undefined) {
                res.status(404).send({
                    status: false,
                    message: `gender-id not found`,
                });
            }
            else if (gstCheck == 0 || gst == undefined) {
                res.status(404).send({
                    status: false,
                    message: `gst-id not found`,
                });
            }
            else if (schoolCheck == false) {
                res.status(404).send({
                    status: false,
                    message: `school-id not found`,
                });
            }
            else {

            let image = "";

            if (req.files.image) {
                const extension = req.files.image[0]["mimetype"].split('/')[1]
                image = req.files.image[0]["filename"] + '.' + extension
            }

            let thisQuery = ` UPDATE product SET masterid = '${masterid}', name = '${name}', description = '${description}', price = '${price}', gst = '${gst}', gender = '${gender}',  weight = '${weight}', productstatus = '${productstatus}', published = '${published ? published : 0}',  quantity = '${quantity}', lastmodifiedate = '${formattedDateTime}', createdby = '${createdby ? createdby : 0}' WHERE productid = '${ProductID}' `
            

            const data = await db.query(thisQuery);
            console.log(data[0]);

            const variants = req.body.variants
            const parsedOutput = JSON.parse(variants);

            // const schoolidArr = JSON.parse(schoolid);
            // const schoolLength = schoolidArr?.length;

            const schoolidArr = JSON.parse(schoolgrade);
            const schoolLength = schoolidArr?.length;
            console.log(schoolLength);
            
            const dataPSMDelete = await db.query(` DELETE FROM productschoolmap WHERE productid IN (${ProductID}) `); 
            // Update School
            for (const num of schoolidArr) {
                let thisQueryPSM = ` INSERT INTO productschoolmap (productid, schoolid) VALUES ( '${ProductID}', '${num}' ) `
                const dataPSM = await db.query(thisQueryPSM); 
                console.log(num);
            }

            const dataImgDelete = await db.query(` DELETE FROM productimage WHERE productid IN (${ProductID}) `); 
            // Update Image
            if (req.files.image) {
                if (req.files.image.length > 0) {
                    

                    const imageseqArr = JSON.parse(imageseq);
                    
                    for (let i = 0; i < req.files.image.length; i++) {
                        if (req.files.image[i]) {
                            const extension = req.files.image[i]["mimetype"].split('/')[1];
                            const image = `${req.files.image[i]["filename"]}.${extension}`;
                            
                            console.log(image);
                            console.log(req.files.image.length);
                            console.log(imageseqArr.length);
            
                            // Check if we have enough sequence numbers for the images
                            if (imageseqArr.length > i) {
                                const num2 = imageseqArr[i];  // Get the corresponding sequence number
                                const thisQueryPimage = `INSERT INTO productimage (productid, imageseq, image) VALUES ('${ProductID}', '${num2}', '${image}')`;
                                await db.query(thisQueryPimage);
            
                                console.log(num2);
            
                                const currentPath = path.join(process.cwd(), "uploads", req.files.image[i]["filename"]);
                                const destinationPath = path.join(process.cwd(), "uploads/product/image/" + `${ProductID}` + `/${num2}`, image);
                                const baseUrl = path.join(process.cwd(), "uploads/product/image", `${ProductID}`, `${num2}`);
                                fs.mkdirSync(baseUrl, { recursive: true });
            
                                fs.rename(currentPath, destinationPath, function (err) {
                                    if (err) {
                                        throw err;
                                    } else {
                                        console.log("Successfully image Uploaded!");
                                    }
                                });
                            } else {
                                console.warn(`Not enough sequence numbers for image ${image}. Expected index ${i}, but got ${imageseqArr?.length}.`);
                            }
                        }
                    }
                }
            }

            const dataVarDelete = await db.query(` DELETE FROM variant WHERE productid IN (${ProductID}) `); 
            // Update Variants
            for (const variant of parsedOutput) {

                let checkVariantQuery = `
                    SELECT COUNT(*) as count 
                    FROM variant 
                    WHERE productid = '${ProductID}' 
                    AND size = '${variant?.size}' 
                    AND color = '${variant?.color}'
                `;
                const existingVariant = await db.query(checkVariantQuery);
                
                if (existingVariant[0][0].count > 0) {
                    return res.status(409).send({
                        status: false,
                        message: `Variant with size : ${variant?.size} and color : ${variant?.color} already exists for this product.`,
                    });
                } else {
                    const thisQueryVariant = `
                        INSERT INTO variant (productid, size, color, price, quantity, imageid, weight)
                        VALUES (
                            '${ProductID}',
                            '${variant?.size}', 
                            '${variant?.color}', 
                            '${variant?.price}', 
                            '${variant?.quantity}', 
                            '${variant?.imageid != undefined ? variant?.imageid : 0}', 
                            '${variant?.weight != undefined ? variant?.weight : 0}'
                        )
                    `;
                    await db.query(thisQueryVariant); 
                }
            }

            res.status(200).send({
                status: true,
                message: 'product updated successfully',
            });

            await db.query('COMMIT');
        }
    }
    }
    catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });

        await db.query('ROLLBACK');
    }
};



// View Product Details
export const getInitViewProductDetails = async (req, res) => {
    try {
        // "{
        //     status:true,
        //     message:{
        //     products:50,
        //     instock:100,
        //     published:50,
        //     unpublished:50,
        //     data:{
        //     {""id"":1, ""name"":""Socks"", ""price"":100, ""quantity"":10, ""published"":0,""image"":""""},
        //     {""id"":2, ""name"":""Shirts"", ""price"":100, ""quantity"":10, ""published"":0,""image"":""""},
        //     }}
        // }"

        // SELECT a.id, a.name,a.price,a.quantity,a.published,IFNULL(b.image, '') FROM product a left join productimage b on a.id = b.productid where b.imgseq = 1 ORDER BY lastmodifiedon LIMIT 10 offset 0	


        await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

        let filters = req.query

        let thisQuery = `SELECT 
        p.productid as id,
        p.*, 
        gst.name as gst_name,
        pm.imageseq as imageseq,
        pm.image as image,
       (SELECT JSON_ARRAYAGG(
                JSON_OBJECT(
                'id', v.id,
                'size', v.size,
                'color', v.color,
                'price', v.price,
                'quantity', v.quantity,
                'productid', v.productid,
                'weight', v.weight
                )
            )
            FROM variant as v
            WHERE v.productid IN (p.productid)
        ) AS variant_details
        FROM product as p
        LEFT JOIN productschoolmap as psm ON (p.productid = psm.productid)
        LEFT JOIN variant as v ON (p.productid = v.productid)
        LEFT JOIN gst as gst ON (gst.id = p.gst)
        LEFT JOIN productimage as pm ON (p.productid = pm.productid and pm.imageseq = 1)
        WHERE p.productid IS NOT NULL
        `

        if(filters?.product) {
            thisQuery += ` `
        }
        if(filters?.published) {
            thisQuery += ` AND p.published = ${filters?.published} `
        }
        if(filters?.productstatus) {
            thisQuery += ` AND p.productstatus = '${filters?.productstatus}' `
        }

        thisQuery += ` 
        GROUP BY p.productid 
        ORDER BY p.productid DESC 
        `

        if (filters?.limit) {
            thisQuery += ` limit ${filters?.limit},10 `
        }

        let thisQueryInstock = ` SELECT 
        COALESCE(SUM(p.quantity), 0) as count,
        SUM(p.price) as total
        FROM product as p WHERE p.productstatus = 'instock' 
        `
        let thisQueryVariant = ` SELECT 
        SUM(v.quantity) as total
        FROM product as p 
        LEFT JOIN variant as v on (p.productid = v.productid)
        WHERE p.productstatus = 'instock' 
        `
        let thisQueryPublished = ` SELECT COALESCE(COUNT(p.productid), 0) as count FROM product as p WHERE p.published = '1' `
        let thisQueryUnPublished = ` SELECT COALESCE(COUNT(p.productid), 0) as count FROM product as p WHERE p.published = '0' `

        const dataMain = await db.query(thisQuery);
        const dataInstock = await db.query(thisQueryInstock);
        const dataVariantSum = await db.query(thisQueryVariant);
        const dataPublished = await db.query(thisQueryPublished);
        const dataUnPublished = await db.query(thisQueryUnPublished);

        console.log(JSON.stringify(dataInstock[0], null, 2));
       
        const data = dataMain[0];
        if (data) {
            // console.log(JSON.stringify(ProductResults));
            // res.status(200).json({ issuccess: true, message: 'success', ProductData });
            res.status(200).send({
                status: true, 
                message: 'success', 
                product : data?.length,
                instock: dataInstock[0][0]?.count,
                published: dataPublished[0][0]?.count,
                unpublished: dataUnPublished[0][0]?.count,
                total: dataVariantSum[0][0]?.total,
                data
            });
        }
        else {
            res.status(400).json({status:false, message: 'Error specification. Please retry' });
        }

    } catch (error) {
        console.log(error);
        res.status(500).json({ status:false, error: 'Internal Server Error', message: error.message });
    }
};
// Get View Products (Type / Status)
export const getViewProducts = async (req, res) => {
    try {
    
        await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

        const filters = req.query;

        let thisQuery = `SELECT 
        p.productid as id,
        p.*, 
        m.mastername as master_name,
        gst.name as gst_name,
        md.name as gender_name,
        us.username as created_name,
        us1.username as last_modified_name,
        DATE_FORMAT(p.createdon, '%Y-%m-%d %H:%i:%s') as createddate,
        (SELECT imageseq FROM productimage WHERE p.productid = productid AND imageseq = 1 LIMIT 1 ) as imageseq,
        (SELECT image FROM productimage WHERE p.productid = productid AND imageseq = 1 LIMIT 1) as image
        FROM product as p
        LEFT JOIN productimage as pm ON (p.productid = pm.productid)
        LEFT JOIN masters as m ON (p.masterid = m.masterid)
        LEFT JOIN gst as gst ON (p.gst = gst.id)
        LEFT JOIN mastersdata as md on (md.dataid = p.gender)
        LEFT JOIN users as us on (p.createdby = us.userid)
        LEFT JOIN users as us1 on (p.lastmodifiedby = us1.userid)
        WHERE p.productid IS NOT NULL 
        `

        // STATUS
        if (filters?.status == 'product') {
            thisQuery += ` `
        }
        if (filters?.status == 'instock') {
            thisQuery += ` AND p.productstatus = 'instock' `
        }
        if (filters?.status == 'published') {
            thisQuery += ` AND p.published = 1 `
        }
        if (filters?.status == 'unpublished') {
            thisQuery += ` AND p.published = 0 `
        }

        // SEARCH TERMS
        if (filters?.searchterm) {
            thisQuery += ` AND p.name LIKE '%${filters?.searchterm}%' `
        }
 
        thisQuery += `
        GROUP BY p.productid 
        ORDER BY p.productid DESC
        `

        if (filters?.limit) {
            thisQuery += ` limit ${filters?.limit},10 `
        }

        const dataMain = await db.query(thisQuery);
        // console.log(JSON.stringify(dataMain[0], null, 2));
       
        const data = dataMain[0];

        const productRows = data.map(item => `
            <tr>
                <td>${item?.productid}</td>
                <td><img src="${`http://localhost:5001/uploads/product/image/678/1/6dfc509280cc9bf376566c52c29a784b.jpeg`}" alt="${item.name}" style="width: 50px; height: auto;"></td>
                <td>${item?.name}</td>
                <td>${item?.description}</td>
                <td>${item?.price}</td>
            </tr>
        `).join('');

        // TYPE == EXCEL
        if(filters?.type == 'excel') {
            try {
                // const worksheet = xlsx.utils.json_to_sheet(data);
                // const workbook = xlsx.utils.book_new();
            
                // xlsx.utils.book_append_sheet(workbook, worksheet, 'Sheet1');
                // const outputPath = path.join('output.xlsx');
                // xlsx.writeFile(workbook, outputPath);
                // console.log('File written successfully');

                const selectedFields = data.map((item, i) => ({
                    "sl.no": i+1,
                    "product name": item?.name,
                    "description": item?.description,
                    "price": item?.price,
                    "category": item?.master_name,
                    "gender": item?.gender_name,
                    "gst": item?.gst_name,
                    "weight": item?.weight,
                    "quantity": item?.quantity,
                    "status": item?.productstatus,
                    "published": item?.published == 0 ? 'OFF' : 'ON',
                    "created by": item?.created_name,
                    "last modified by": item?.last_modified_name,
                    "created date": item?.createddate,
                }));

                console.log('selectedFields', selectedFields);

                const workbook = xlsx.utils.book_new();
                const worksheet = xlsx.utils.json_to_sheet(selectedFields);
                xlsx.utils.book_append_sheet(workbook, worksheet, 'Sheet1');
            
                const buffer = xlsx.write(workbook, { bookType: 'xlsx', type: 'buffer' });
            
                res.setHeader('Content-Disposition', 'attachment; filename=output.xlsx');
                res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                console.log('File written successfully');
            
                return res.send(buffer);

            } catch (error) {
                console.error('Error writing file:', error);
            }
        }
        // TYPE == PDF
        if(filters?.type == 'pdf') {
            try {
            console.log('Initial PDF Generated');

            // const browser = await puppeteer.launch();
            const browser = await puppeteer.launch({ headless: true, args: ['--no-sandbox', '--disable-setuid-sandbox'] });
            const page = await browser.newPage();
            await page.setContent(`  
            <html>
            <head>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    margin: 20px;
                }
                h1 {
                    text-align: center;
                }
                .table-responsive {
                    overflow-x: auto;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                }
                th, td {
                    border: 1px solid #ddd;
                    padding: 8px;
                    text-align: left;
                }
                th {
                    background-color: #f2f2f2;
                }
            </style>
            </head>
            <body>
            <h1>Product List</h1>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Image</th>
                            <th>Product Name</th>
                            <th>Description</th>
                            <th>Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${productRows}
                    </tbody>
                </table>
            </div>
            </body>
            </html>`);

        const outputPath = path.join(__dirname, 'output.pdf');
        await page.pdf({ path: outputPath, format: 'A4', timeout: 6000 });

        await browser.close();
        const pdfBuffer = fs.readFileSync(outputPath);

        res.setHeader('Content-Disposition', 'attachment; filename=output.pdf');
        res.setHeader('Content-Type', 'application/pdf');
        return res.send(pdfBuffer);

        } catch (error) {
                console.error('PDF ERROR:', error);
                console.log('Pdf not generated');
            }
        }

        if(filters?.type == 'pdf1') {
            try {
            console.log('One PDF Generated');

            const doc = new PDFDocument();
            doc.pipe(fs.createWriteStream('output.pdf'));
            doc.fontSize(25).text(`  
            <html>
            <head>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    margin: 20px;
                }
                h1 {
                    text-align: center;
                }
                .table-responsive {
                    overflow-x: auto;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                }
                th, td {
                    border: 1px solid #ddd;
                    padding: 8px;
                    text-align: left;
                }
                th {
                    background-color: #f2f2f2;
                }
            </style>
            </head>
            <body>
            <h1>Product List</h1>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Image</th>
                            <th>Product Name</th>
                            <th>Description</th>
                            <th>Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${productRows}
                    </tbody>
                </table>
            </div>
            </body>
            </html>`, 100, 100);
            doc.end();
            console.log('Final PDF Generated');
            

        } catch (error) {
                console.error('PDF ERROR 1 : ', error);
                console.log('Pdf 1 not generated');
            }
        }

        if (data) {
            // res.status(200).json({ issuccess: true, message: 'success', ProductData });
            res.status(200).send({
                status: true, 
                message: 'success', 
                count : data?.length,
                data
            });
        }
        else {
            res.status(400).json({status:false, message: 'Error specification. Please retry' });
        }

    } catch (error) {
        console.log(error);
        res.status(500).json({ status:false, error: 'Internal Server Error', message: error.message });
    }
};
// Delete Products
export const deleteProducts = async (req, res) => {
    try {

        await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

        let ID = req.body.productid

        let thisQuery  = ` DELETE FROM product `;
            thisQuery += " WHERE productid IN (" + ID + ") "

        let thisQuery2 = ` DELETE FROM productimage `
            thisQuery2 += " WHERE productid IN (" + ID + ") "

        let thisQuery3 = ` DELETE FROM productschoolmap `
            thisQuery3 += " WHERE productid IN (" + ID + ") "

        let thisQuery4 = ` DELETE FROM variant `
            thisQuery4 += " WHERE productid IN (" + ID + ") "
            
        const dataMain = await db.query(thisQuery);
        const dataMain2 = await db.query(thisQuery2);
        const dataMain3 = await db.query(thisQuery3);
        const dataMain4 = await db.query(thisQuery4);

        const data = dataMain[0];
        if (data) {
            res.status(200).send({
                status: true, 
                message: 'Deleted Successfully', 
            });
        }
        else {
            res.status(400).json({status:false, message: 'Delete failed' });
        }

    } catch (error) {
        console.log(error);
        res.status(500).json({ status:false, error: 'Internal Server Error', message: error.message });
    }
};


// Get Init Customer Dashboard Details
export const getinitCustomerDashboard = async (req, res) => {
    try {
       
        await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

        const UserID = req.params.id;

        let thisQueryUsers = ` SELECT us.* FROM users as us WHERE us.status = 1 AND us.userid = '${UserID}' `
        const dataUsers = await db.query(thisQueryUsers);

        const userCheck = dataUsers[0][0] ? dataUsers[0][0]?.userid : 0
        console.log('userCheck', userCheck);

        if (!userCheck) {
            res.status(404).send({
                status: false, 
                message: `user id not found : ${UserID} `,
            });
        }

        else {

        let thisQuery = `
        SELECT sc.schoolid as id, sc.name as name 
        FROM school as sc
        LEFT JOIN usersschoolmap usm on (sc.schoolid = usm.schoolid)
        LEFT JOIN users us on (us.userid = usm.userid)
        WHERE us.userid = '${UserID}'
        GROUP BY usm.schoolid
        `

        let thisQueryAddToCart = `
        SELECT COALESCE(COUNT(atc.userid), 0) as count
        FROM addtocarttable as atc
        LEFT JOIN users us on (us.userid = atc.userid)
        WHERE us.userid = '${UserID}' AND atc.status != 'Ordered'
        GROUP BY atc.userid
        `
        const dataSchool = await db.query(thisQuery);
        const dataATC = await db.query(thisQueryAddToCart);
        
        const schoolID = dataSchool[0]?.length != 0 ? dataSchool[0]?.map(i => i.id).join(',') : 0
        console.log('schoolID', schoolID);
        console.log('dataSchool', dataSchool[0].length);
        
        let thisQueryPSM = `
        SELECT COALESCE(COUNT(p.productid), 0) as count
        FROM productschoolmap as psm
        LEFT JOIN product as p on (p.productid = psm.productid)
        WHERE psm.schoolid IN (${schoolID})
        `
        const dataPSM = await db.query(thisQueryPSM);

        let thisQueryS = ` 
        SELECT 
        sgm.id as id,
        sgm.schoolid as schoolid,
        GROUP_CONCAT(DISTINCT md.name) as name
        FROM schoolgrademap as sgm
        LEFT JOIN mastersdata as md on (md.dataid = sgm.gradeid)
        WHERE sgm.schoolid IN (${schoolID})
        GROUP BY sgm.gradeid
        `
        const dataS = await db.query(thisQueryS);


        let thisQueryMain = `
        SELECT 
        p.productid as productid,
        p.name as name,
        p.price as price,
        p.gender as genderid,
        md.name as gender,

        (SELECT imageseq FROM productimage WHERE p.productid = productid AND imageseq = 1 LIMIT 1 ) as imageseq,
        (SELECT COALESCE(image, '') FROM productimage WHERE p.productid = productid AND imageseq = 1 LIMIT 1) as image,

        CONCAT('[', GROUP_CONCAT(DISTINCT IFNULL(sgm.gradeid, '')), ']') AS grades,
        CONCAT('[', GROUP_CONCAT(DISTINCT IFNULL(sgm.id, '')), ']') AS grade_array

        FROM product as p
        LEFT JOIN productimage as pm on (p.productid = pm.productid)
        LEFT JOIN productschoolmap as psm on (p.productid = psm.productid)
        LEFT JOIN schoolgrademap as sgm on (psm.schoolid = sgm.id)
        LEFT JOIN mastersdata as md on (md.dataid = p.gender)
        LEFT JOIN masters as m on (m.masterid = md.masterid AND m.mastername = 'Gender')
        WHERE p.published = 1 and sgm.schoolid IN (${schoolID})
        GROUP BY p.productid
        ORDER BY p.lastmodifiedate
        `
        const dataMain = await db.query(thisQueryMain);

        const Results = {
            school : dataSchool[0], // user-id against school count
            addtocart: dataATC[0][0]?.count || [], // user-id against add to cart count --> incart check
            grade : dataS[0], 
            productcount: dataPSM[0][0]?.count || [] // school id against product count --> published no check
        }

        const data1 = Results;
        if (data1) {
            // console.log(JSON.stringify(ProductResults));
            // res.status(200).json({ issuccess: true, message: 'success', ProductData });
            res.status(200).send({
                status: true, 
                message: data1,
                data : dataMain[0]
            });
        }
        else {
            res.status(400).json({status:false, message: 'Error specification. Please retry' });
        }
    }
    } catch (error) {
        console.log(error);
        res.status(500).json({ status:false, error: 'Internal Server Error', message: error.message });
    }
};


// GET -- Single Product Detail
export const getSingleProductDetail = async (req, res) => {
    try {
       
        await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

        const ProductID = req.params.productid;

        let thisQueryProduct = ` SELECT p.* FROM product as p WHERE p.productid = '${ProductID}' `
        const dataProduct = await db.query(thisQueryProduct);

        const productCheck = dataProduct[0][0] ? dataProduct[0][0]?.productid : 0
        console.log('productCheck', productCheck);

        if (!productCheck) {
            res.status(404).send({
                status: false, 
                message: `product id not found : ${ProductID} `,
            });
        }
        else {
        
        let thisQuery = `
        SELECT 
        p.productid as productid,
        p.masterid as masterid, 
        p.name as name,
        p.description as description, 
        p.price as price, 
        p.gst as gst, 
        p.gender as gender, 
        p.weight as weight, 
        p.productstatus as productstatus, 
        p.published as published, 
        p.quantity as quantity, 
        p.createdon as createdon,  
        p.lastmodifiedate as lastmodifiedate,  
        p.lastmodifiedby as lastmodifiedby,  
        p.createdby as createdby,
        GROUP_CONCAT(DISTINCT IFNULL(sc.schoolid, '')) as schoolid,
        GROUP_CONCAT(DISTINCT IFNULL(psm.schoolid, '')) as schoolgradeid,
        GROUP_CONCAT(DISTINCT IFNULL(sgm.gradeid, '')) as gradeid,
        GROUP_CONCAT(DISTINCT IFNULL(md.name, '')) as gradename
        FROM product as p
        LEFT JOIN variant as v on (p.productid = v.productid)
        LEFT JOIN productschoolmap as psm on FIND_IN_SET(p.productid,psm.productid)>0
        LEFT JOIN schoolgrademap as sgm on FIND_IN_SET(psm.schoolid,sgm.id)>0
        LEFT JOIN school as sc on (sgm.schoolid = sc.schoolid)
        LEFT JOIN mastersdata as md on (md.dataid = sgm.gradeid)
        WHERE p.productid = '${ProductID}'
        GROUP BY p.productid
        `
        const data = await db.query(thisQuery);

        const schoolgradeid = data[0][0]?.schoolgradeid?.split(",");
        const gradeid = data[0][0]?.gradeid?.split(",");
        const gradename = data[0][0]?.gradename?.split(",");   
        const schoolid = data[0][0]?.schoolid?.split(",");   

        console.log('initial data', data[0]);
        

        let thisQueryImg = ` SELECT
        p.productid as productid,
        pm.imageseq as imageseq,
        pm.image as image
        FROM product as p
        LEFT JOIN productimage as pm on (p.productid = pm.productid)
        WHERE pm.productid = ${ProductID}
        GROUP BY pm.imageseq
        `
        const dataImg = await db.query(thisQueryImg);

        let thisQueryV = ` SELECT
        v.id as variantid,
        p.productid as productid,
        v.size as size,
        v.color as color,
        v.price as price,
        v.quantity as quantity,
        pm.imageseq as imageseq,
        pm.image as image
        FROM product as p
        LEFT JOIN variant as v on (p.productid = v.productid)
        LEFT JOIN productimage as pm on (v.productid = pm.productid AND pm.imageseq = 1)
        WHERE v.productid = ${ProductID}
        GROUP BY v.id
        `
        const dataV = await db.query(thisQueryV);

        data[0][0].schoolgradeid = schoolgradeid;
        data[0][0].gradeid = gradeid;
        data[0][0].gradename = gradename;
        data[0][0].schoolid = schoolid;

        console.log('data[0]', data[0]);

        const productData = data[0][0];
        const images = dataImg[0];
        const variants = dataV[0];
        const finalData = [{
            ...productData,
            images: images,
            variants: variants,
        }];

        if (data) {
            // console.log(JSON.stringify(ProductResults));
            // res.status(200).json({ issuccess: true, message: 'success', ProductData });
            res.status(200).send({
                status: true, 
                message: 'success',
                data : finalData
            });
        }
        else {
            res.status(400).json({status:false, message: 'Error specification. Please retry' });
        }
    }
    } catch (error) {
        console.log(error);
        res.status(500).json({ status:false, error: 'Internal Server Error', message: error.message });
    }
};
// POST -- Add To Cart
export const addToCart = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
    await db.query('START TRANSACTION');

    try {

        const userid = req.body.userid || 0;
        const productid = req.body.productid || 0;
        const variantid = req.body.variantid || 0;
        const quantity = req.body.quantity || 0;

        if (userid == 0 || productid == 0) {

            res.status(400).send({
                status: false, 
                message :  `${userid == 0 && productid == 0 ? 'Both user-id & product-id required.' : userid == 0 ? 'user-id cannot be empty' : productid == 0 ? 'product-id cannot be empty' : '' } `,
            });

        } else {

        let thisQueryCheck = ` SELECT act.*, SUM(quantity) as sum_quantity 
        FROM addtocarttable as act 
        WHERE act.userid = '${userid}' AND act.productid = '${productid}' AND act.variantid = '${variantid}' AND act.status = 'incart' GROUP BY act.atcartid `
        const dataCheck = await db.query(thisQueryCheck); 
        const existingCheck = dataCheck[0][0] ? dataCheck[0][0]?.atcartid : 0

        console.log('dataCheck', dataCheck[0]);
        console.log('existingCheck', existingCheck);

        if (existingCheck == 0) {
            let thisQuery = ` INSERT INTO addtocarttable (userid, productid, variantid, quantity)
            VALUES ( '${userid}', '${productid}','${variantid}',${quantity}) `
    
            const data = await db.query(thisQuery); 
            console.log(data[0]);
        
            res.status(200).send({
              status: true, 
              message : 'Added successfully',
            });

        } else {

            const SumQuantity = dataCheck[0][0]?.sum_quantity  
            const TotalQuantity = parseInt(SumQuantity) + parseInt(quantity)
            console.log('TotalQuantity', SumQuantity + " + " + quantity , TotalQuantity);

            let thisQuery = `UPDATE addtocarttable SET quantity = '${TotalQuantity}' WHERE userid = '${userid}' AND productid = '${productid}' AND variantid = '${variantid}' AND status = 'incart' `
    
            const data = await db.query(thisQuery); 
            // console.log(data[0]);
        
            res.status(200).send({
              status: true, 
              message : 'Update successfully',
            });
        }
    }
     
        await db.query('COMMIT');
      } 
      catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });

        await db.query('ROLLBACK');
    }
};
// GET -- Add to Cart -- by UserID
export const addToCartUserID = async (req, res) => {
    try {
       
        await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

        const UserID = req.params.userid;
        const filters = req.query;

        let thisQueryUser = ` SELECT us.* FROM users as us WHERE us.status = 1 AND us.userid = '${UserID}' `
        const dataUser = await db.query(thisQueryUser);

        const UserCheck = dataUser[0][0] ? dataUser[0][0]?.userid : 0
        console.log('UserCheck', UserCheck);

        if (!UserCheck) {
            res.status(404).send({
                status: false, 
                message: `User id not found : ${UserID} `,
            });
        }

        else {

        let thisQuery = `
        SELECT 
        atc.atcartid as atcartid,
        p.productid as productid,
        p.name as name,
        p.gst as gst_id,
        gst.name as gst_name,
        p.weight as weight,
        us.username as username,
        v.size as size,
        v.color as color,
        v.price as price,
        v.quantity as variant_quantity,
        atc.quantity as quantity,
        pm.imageseq as imageseq,
        pm.image as image
        FROM addtocarttable as atc
        LEFT JOIN users as us on (us.userid = atc.userid)
        LEFT JOIN product as p on (p.productid = atc.productid)
        LEFT JOIN gst as gst on (gst.id = p.gst)
        LEFT JOIN productimage as pm on (p.productid = pm.productid AND pm.imageseq = 1)
        LEFT JOIN variant as v on (atc.variantid = v.id)
        WHERE us.userid = '${UserID}' ${filters?.status ? `AND atc.status = '${filters?.status}' ` : `AND atc.status != 'Ordered'`}
        GROUP BY atc.atcartid
        `
        const data = await db.query(thisQuery);

        if (data) {
            // console.log(JSON.stringify(ProductResults));
            // res.status(200).json({ issuccess: true, message: 'success', ProductData });
            res.status(200).send({
                status: true, 
                message: 'success',
                count: data[0]?.length,
                data : data[0]
            });
        }
        else {
            res.status(400).json({status:false, message: 'Error specification. Please retry' });
        }
    }
    } catch (error) {
        console.log(error);
        res.status(500).json({ status:false, error: 'Internal Server Error', message: error.message });
    }
};
// DELETE -- Add To Cart
export const deleteAddToCart = async (req, res) => {
    try {

        await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

        const ID = req.params.atcartid

        let thisQueryATC = ` SELECT atc.* FROM addtocarttable as atc WHERE atc.atcartid = '${ID}' `
        const dataATC = await db.query(thisQueryATC);

        const ATCCheck = dataATC[0][0] ? dataATC[0][0]?.atcartid : 0
        console.log('ATCCheck', ATCCheck);

        if (!ATCCheck) {
            res.status(404).send({
                status: false,
                message: `id not found : ${ID} `,
            });
        } else {

            let thisQuery = ` DELETE FROM addtocarttable WHERE atcartid IN (${ID}) `;
            // thisQuery += " WHERE atcartid IN (" + ID + ") "

            const dataMain = await db.query(thisQuery);

            const data = dataMain[0];
            if (data) {
                res.status(200).send({
                    status: true,
                    message: 'Deleted Successfully',
                });
            }
            else {
                res.status(400).json({ status: false, message: 'Delete failed' });
            }
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ status: false, error: 'Internal Server Error', message: error.message });
    }
};
// UPDATE -- Update Quantity -- Add To Cart
export const updateATCQuantity = async (req, res) => {
    try {

        await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

        const ID = req.params.atcartid

        let thisQueryATC = ` SELECT atc.* FROM addtocarttable as atc WHERE atc.atcartid = '${ID}' `
        const dataATC = await db.query(thisQueryATC);

        const ATCCheck = dataATC[0][0] ? dataATC[0][0]?.atcartid : 0
        console.log('ATCCheck', ATCCheck);

        if (!ATCCheck) {
            res.status(404).send({
                status: false,
                message: `add to cart-id not found : ${ID} `,
            });
        } else {

            let thisQuery = ` UPDATE addtocarttable SET quantity = '${req.body.quantity}' WHERE atcartid = ${ID} `            

            const dataMain = await db.query(thisQuery);

            const data = dataMain[0];
            if (data) {
                res.status(200).send({
                    status: true,
                    message: 'Updated Successfully',
                });
            }
            else {
                res.status(400).json({ status: false, message: 'update failed' });
            }
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ status: false, error: 'Internal Server Error', message: error.message });
    }
};


export const updateProductPublished = async (req, res) => {
    try {

        await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

        const ID = req.params.productid

        let thisQuery = ` SELECT p.* FROM product as p WHERE p.productid = '${ID}' `
        const data = await db.query(thisQuery);

        const ProductCheck = data[0][0] ? data[0][0]?.productid : 0
        const Published = data[0][0] ? data[0][0]?.published : 0
        console.log('ProductCheck', ProductCheck);
        console.log('Published', Published);

        if (!ProductCheck) {
            res.status(404).send({
                status: false,
                message: `product-id not found : ${ID} `,
            });
        } else {

            let thisQuery = ` UPDATE product SET published = '${Published == 0 ? 1 : 0}' WHERE productid = ${ID} `            

            const dataMain = await db.query(thisQuery);

            const data = dataMain[0];
            if (data) {
                res.status(200).send({
                    status: true,
                    message: `Updated Successfully - Published : ${Published == 0 ? 'NO' : 'OFF'}`,
                });
            }
            else {
                res.status(400).json({ status: false, message: 'update failed' });
            }
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ status: false, error: 'Internal Server Error', message: error.message });
    }
};


// Download image
async function downloadImage(imageUrl, folderPath, fileName) {
    try {
        // Create the folder if it doesn't exist
        if (!fs.existsSync(folderPath)) {
            fs.mkdirSync(folderPath, { recursive: true });
        }

        // Get the image response
        const response = await axios.get(imageUrl, {
            responseType: 'arraybuffer', // Ensure we get the image as a buffer
        });

        // Set the file path
        const filePath = path.join(folderPath, fileName);

        // Write the file to the filesystem
        fs.writeFileSync(filePath, response.data);

        console.log(`Image saved to ${filePath}`);
    } catch (error) {
        console.error('Error downloading the image:', error);
    }
};

// BULK PRODUCT IMPORT 
export const uploadFile = async (req, res) => {

    await db.query('START TRANSACTION');

    try {
        const rows = await readXlsxFile('./uploads/' + req.file.filename);
        const rowing = [];

        console.log('rowing', rowing);
        rows.shift();

        const processedData = [];

        for (const row of rows) {

            const MschoolName = `${row[0]}`
            const MgradeName = `${row[1]}`
            const MmasterName = `${row[2]}`
            const MproductName = `${row[3]}`
            const MgenderName = `${row[4]}`
            const Mprice = `${row[5]}`
            const Mgst = `${row[6]}`
            const Mweight = `${row[7]}`
            const Mquantity = `${row[8]}`
            const Mdescription = `${row[9]}`

            const imageUrl = `${row[10]}`;
            const imageSeq = `${row[11]}`;

            const MvariantSize = `${row[12]}`
            const MvariantColor = `${row[13]}`
            const MvariantPrice = `${row[14]}`
            const MvariantQuantity = `${row[15]}`
            const MvariantImageSeq = `${row[16]}`
            const MvariantWeight = `${row[17]}`


            const schoolArrays = MschoolName?.split(',');
            const schoolResult = schoolArrays.map(school => `'${school}'`).join(',');
            console.log('schoolResult1', schoolResult);

            const schoolName = await db.query(`SELECT schoolid FROM school WHERE name IN (${schoolResult}) `);
            
            const SID = schoolName[0]?.map(i => i.schoolid);

            console.log('SID', SID);
            console.log('SID LENGTH', SID?.length);
           
            const gradeName = await db.query(`
                SELECT md.dataid as dataid
                FROM mastersdata as md
                WHERE md.name = '${MgradeName}'
                `);
            const gradeID = gradeName[0][0] ? gradeName[0][0].dataid : 0;

            const masterName = await db.query(`SELECT masterid FROM masters WHERE mastername = '${MmasterName}' LIMIT 1`);
            const masterID = masterName[0][0] ? masterName[0][0].masterid : 0;

            const genderName = await db.query(`SELECT dataid FROM mastersdata WHERE name = '${MgenderName}' LIMIT 1`);
            const genderID = genderName[0][0] ? genderName[0][0].dataid : 0;

            const gstName = await db.query(`SELECT id FROM gst WHERE name = '${Mgst}' LIMIT 1`);
            const gstID = gstName[0][0] ? gstName[0][0]?.id : 0;

            console.log('school name', SID, MschoolName);
            console.log('grade', MgradeName, gradeID);
            console.log('masters', MmasterName, masterID);
            console.log('product name', MproductName);
            console.log('gender name', MgenderName, genderID);
            console.log('price', Mprice);
            console.log('gst', Mgst, gstID);
            console.log('weight', Mweight);
            console.log('quantity', Mquantity);
            console.log('description', Mdescription);  
            console.log('image Url', imageUrl);  
            console.log('image Seq', imageSeq);  
            console.log('variant size', MvariantSize);  
            console.log('variant color', MvariantColor);  
            console.log('variant price', MvariantPrice);  
            console.log('variant quantity', MvariantQuantity);  
            console.log('variant image seq', MvariantImageSeq);  
            console.log('variant weight', MvariantWeight);  

            const MschoolNameArray = MschoolName?.split(',');

            const imageUrlArray = imageUrl?.split(',');
            const imageSeqArray = imageSeq?.split(',');

            const MvariantSizeArray = MvariantSize?.split(',');
            const MvariantColorArray = MvariantColor?.split(',');
            const MvariantPriceArray = MvariantPrice?.split(',');
            const MvariantQuantityArray = MvariantQuantity?.split(',');
            const MvariantImageSeqArray = MvariantImageSeq?.split(',');
            const MvariantWeightArray = MvariantWeight?.split(',');

            
            console.log('MschoolNameArray', MschoolNameArray, MschoolNameArray?.length);
            console.log('imageUrlArray', imageUrlArray, imageUrlArray?.length);
            console.log('imageSeqArray', imageSeqArray, imageSeqArray?.length);
            console.log('MvariantSizeArray', MvariantSizeArray, MvariantSizeArray?.length);
            console.log('MvariantColorArray', MvariantColorArray, MvariantColorArray?.length);
            console.log('MvariantPriceArray', MvariantPriceArray, MvariantPriceArray?.length);
            console.log('MvariantQuantityArray', MvariantQuantityArray, MvariantQuantityArray?.length);
            console.log('MvariantImageSeqArray', MvariantImageSeqArray, MvariantImageSeqArray?.length);
            console.log('MvariantWeightArray', MvariantWeightArray, MvariantWeightArray?.length);

            let thisQueryP = ` SELECT p.* FROM product as p WHERE p.name = "${MproductName}" `
            const dataP = await db.query(thisQueryP);

            let thisQueryM = ` SELECT m.* FROM masters as m WHERE m.masterid = "${masterID}" `
            const dataM = await db.query(thisQueryM);
            
            let thisQueryS = ` SELECT s.* FROM school as s WHERE s.schoolid `
            const dataS = await db.query(thisQueryS);
            const schoolInititalCheck = dataS[0].map(i => i.schoolid)
            console.log('schoolInititalCheck',schoolInititalCheck);
    
            const schoolCheck = SID.every(value => schoolInititalCheck.includes(value));
            // const schoolCheck = SID.length == 0 ? false : SID.every(value => schoolInititalCheck.includes(value));
    
            let thisQueryGST = ` SELECT * FROM gst WHERE id = '${gstID}' `
            const dataGST = await db.query(thisQueryGST);
    
            let thisQueryG = ` SELECT md.* FROM mastersdata as md WHERE md.dataid = "${genderID}" `
            const dataG = await db.query(thisQueryG);
    
            const FieldCheck = dataP[0][0] ? dataP[0][0]?.name : 0
            const masterCheck = dataM[0][0] ? dataM[0][0]?.masterid : 0
            const gstCheck = dataGST[0][0] ? dataGST[0][0]?.id : 0
            const genCheck = dataG[0][0] ? dataG[0][0]?.dataid : 0
            console.log('schoolCheck', schoolCheck);
        
            if (FieldCheck !== 0 || masterCheck == 0 || MmasterName == undefined || gstCheck == 0 || Mgst == undefined || genCheck == 0 || MgenderName == undefined || schoolCheck == false || gradeID == 0 || MgradeName == undefined) {

                const errorMessages = [];
                if (FieldCheck != 0) {
                    errorMessages.push('Product name already exists');
                }
                if (masterCheck == 0 || MmasterName === undefined) {
                    errorMessages.push('Master not found');
                }
                if (gstCheck == 0 || Mgst === undefined) {
                    errorMessages.push('GST not found');
                }
                if (genCheck == 0 || MgenderName === undefined) {
                    errorMessages.push('Gender not found');
                }
                if (schoolCheck == false) {
                    errorMessages.push('Schools not found');
                }
                if (gradeID == 0 || MgradeName == undefined) {
                    errorMessages.push('grade not found');
                }
                
                const errorCheck = errorMessages.join(', '); 
                console.log('ErrorCheck', errorCheck);

                processedData.push({
                    'school name' : MschoolName,
                    'master name' : MmasterName,
                    'product name': MproductName,
                    'gender name': MgenderName,
                    'price': Mprice,
                    'gst': Mgst,
                    'weight': Mweight,
                    'quantity': Mquantity,
                    'description': Mdescription,
                    'images': imageUrl,
                    'imageseq': imageSeq,
                    'variant size': MvariantSize,
                    'variant color': MvariantColor,
                    'variant price': MvariantPrice,
                    'variant quantity': MvariantQuantity,
                    'variant image seq': MvariantImageSeq,
                    'variant weight': MvariantWeight,
                    // 'Errors': errorCheck,
                });

                // const worksheet = xlsx.utils.json_to_sheet(processedData);
                // const workbook = xlsx.utils.book_new();
            
                // xlsx.utils.book_append_sheet(workbook, worksheet, 'Sheet1');
                // // const outputPath = path.join('successfull_excel.xlsx');
                // const outputPath = path.join(__dirname, 'successfull_excel.xlsx');
                // xlsx.writeFile(workbook, outputPath);
                // console.log('File written successfully');

                // console.log('processedData', processedData);

                // const worksheet = xlsx.utils.json_to_sheet(processedData);
                // const workbook = xlsx.utils.book_new();
                // xlsx.utils.book_append_sheet(workbook, worksheet, 'Sheet1');
            
                // const buffer = xlsx.write(workbook, { bookType: 'xlsx', type: 'buffer' });
            
                // res.setHeader('Content-Disposition', 'attachment; filename=unsuccessfull_excel.xlsx');
                // res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                // console.log('File written successfully');
            
                // return res.send(buffer);

            }  
            else {

            let thisQuery = `INSERT INTO product (masterid, name, description, price, gst, gender, weight, productstatus, published, quantity, createdon, lastmodifiedate, lastmodifiedby, createdby) VALUES ('${masterID}', "${MproductName}", "${Mdescription}", ${Mprice}, '${gstID}', '${genderID}', '${Mweight}', 'instock', '0', '${Mquantity}', '${formattedDateTime}', '${formattedDateTime}','0', '0')`;
            const data = await db.query(thisQuery);

            const InsertId = data[0];
            console.log('data', data);
            console.log('InsertId', InsertId);

            // School excel insert
            for (let i = 0; i < SID.length; i++) {
                const schoolID = SID[i];

                let thisQueryPSM = ` INSERT INTO productschoolmap (productid, schoolid) VALUES ( '${InsertId}', '${schoolID}' ) `
                const dataPSM = await db.query(thisQueryPSM); 
            }
            // Image excel insert
            for (let i = 0; i < imageSeqArray.length; i++) {

                const seq = imageSeqArray[i];
                const url = imageUrlArray[i];

                const imgName = path.basename(url);    

                const thisQueryPimage = `INSERT INTO productimage (productid, imageseq, image) VALUES ('${InsertId}', '${seq}', '${imgName}')`;
                const data2 = await db.query(thisQueryPimage);

                const extension = path.extname(url) || '.jpg';
                const baseDir = path.join(process.cwd(), "uploads", "product", "image", `${InsertId}`, `${seq}`);

                console.log('imgNameimgNameimgName', imgName);

                fs.mkdirSync(baseDir, { recursive: true });

                const localImgPath = path.join(baseDir);
                console.log('localImgPath', localImgPath);
            
                try {
                    await downloadImage(url, localImgPath, imgName);
                } catch (error) {
                    console.error('Error downloading the image:', error);
                }
            }
            // Variants excel insert
            for (let i = 0; i < MvariantSizeArray.length; i++) {

                const SizeArray = MvariantSizeArray[i];
                const ColorArray = MvariantColorArray[i];
                const PriceArray = MvariantPriceArray[i];
                const QuantityArray = MvariantQuantityArray[i];
                const ImageSeqArray = MvariantImageSeqArray[i];
                const WeightArray = MvariantWeightArray[i];

                const thisQueryV = `INSERT INTO variant (productid, size, color, price, quantity, imageid, weight) 
                VALUES ('${InsertId}', '${SizeArray}', '${ColorArray}', '${PriceArray}', '${QuantityArray}','${ImageSeqArray}','${WeightArray}')`;
                const data3 = await db.query(thisQueryV);
            }

            // rowing.push(data);
        }

        console.log("rowing", rowing);
        }

        console.log('processedData', processedData);

        const worksheet = xlsx.utils.json_to_sheet(processedData);
        const workbook = xlsx.utils.book_new();
        xlsx.utils.book_append_sheet(workbook, worksheet, 'Sheet1');
    
        const buffer = xlsx.write(workbook, { bookType: 'xlsx', type: 'buffer' });
    
        res.setHeader('Content-Disposition', 'attachment; filename=output.xlsx');
        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        console.log('File written successfully');
    
        // return res.send(buffer);
        res.status(200).send({
            status: true,
            message: 'Bulk product imported successfully',
            data: buffer
        });

        await db.query('COMMIT');

    } catch (error) {
        console.error('Error uploading file:', error);
        await db.query('ROLLBACK');
    }
};


export const uploadFile1 = async (req, res) => {
    try {
        const rows = await readXlsxFile('./uploads/' + req.file.filename);
        const rowing = [];

        console.log('rowing', rowing);
        rows.shift();

        for (const row of rows) {

            const MschoolName = `${row[0]}`
            const MmasterName = `${row[1]}`
            const MproductName = `${row[2]}`
            const MgenderName = `${row[3]}`
            const Mprice = `${row[4]}`
            const Mgst = `${row[5]}`
            const Mweight = `${row[6]}`
            const Mquantity = `${row[7]}`
            const Mdescription = `${row[8]}`

            const imageUrl = `${row[9]}`;
            const imageSeq = `${row[10]}`;

            const MvariantSize = `${row[11]}`
            const MvariantColor = `${row[12]}`
            const MvariantPrice = `${row[13]}`
            const MvariantQuantity = `${row[14]}`
            const MvariantImageSeq = `${row[15]}`
            const MvariantWeight = `${row[16]}`

            const schoolName = await db.query(`SELECT schoolid FROM school WHERE name = '${MschoolName}' LIMIT 1`);
            const schoolID = schoolName[0][0] ? schoolName[0][0].schoolid : 0;

            const masterName = await db.query(`SELECT masterid FROM masters WHERE mastername = '${MmasterName}' LIMIT 1`);
            const masterID = masterName[0][0] ? masterName[0][0].masterid : 0;

            const genderName = await db.query(`SELECT dataid FROM mastersdata WHERE name = '${MgenderName}' LIMIT 1`);
            const genderID = genderName[0][0] ? genderName[0][0].dataid : 0;

            console.log('school name', schoolID, MschoolName);
            console.log('masters', MmasterName, masterID);
            console.log('product name', MproductName);
            console.log('gender name', MgenderName, genderID);
            console.log('price', Mprice);
            console.log('gst', Mgst);
            console.log('weight', Mweight);
            console.log('quantity', Mquantity);
            console.log('description', Mdescription);  
            console.log('image Url', imageUrl);  
            console.log('image Seq', imageSeq);  
            console.log('variant size', MvariantSize);  
            console.log('variant color', MvariantColor);  
            console.log('variant price', MvariantPrice);  
            console.log('variant quantity', MvariantQuantity);  
            console.log('variant image seq', MvariantImageSeq);  
            console.log('variant weight', MvariantWeight);  

            const MschoolNameArray = MschoolName?.split(',');

            const imageUrlArray = imageUrl?.split(',');
            const imageSeqArray = imageSeq?.split(',');

            const MvariantSizeArray = MvariantSize?.split(',');
            const MvariantColorArray = MvariantColor?.split(',');
            const MvariantPriceArray = MvariantPrice?.split(',');
            const MvariantQuantityArray = MvariantQuantity?.split(',');
            const MvariantImageSeqArray = MvariantImageSeq?.split(',');
            const MvariantWeightArray = MvariantWeight?.split(',');

            
            console.log('MschoolNameArray', MschoolNameArray, MschoolNameArray?.length);
            console.log('imageUrlArray', imageUrlArray, imageUrlArray?.length);
            console.log('imageSeqArray', imageSeqArray, imageSeqArray?.length);
            console.log('MvariantSizeArray', MvariantSizeArray, MvariantSizeArray?.length);
            console.log('MvariantColorArray', MvariantColorArray, MvariantColorArray?.length);
            console.log('MvariantPriceArray', MvariantPriceArray, MvariantPriceArray?.length);
            console.log('MvariantQuantityArray', MvariantQuantityArray, MvariantQuantityArray?.length);
            console.log('MvariantImageSeqArray', MvariantImageSeqArray, MvariantImageSeqArray?.length);
            console.log('MvariantWeightArray', MvariantWeightArray, MvariantWeightArray?.length);

            // let thisQuery = `INSERT INTO product (masterid, name, description, price, gst, gender, weight, productstatus, published, quantity, createdon, createdby) VALUES ('${MmasterName}', "${MproductName}", "${Mdescription}", ${Mprice}, ${Mgst}, ${MgenderName}, ${Mweight}, 'instock', '0', '${Mquantity}', '${formattedDateTime}', '0')`;
            // const data = await db.query(thisQuery);

            const InsertId = 23;
            console.log('InsertId', InsertId);

            // School excel insert
            for (let i = 0; i < MschoolNameArray.length; i++) {
                const schoolID = MschoolNameArray[i];

                // let thisQueryPSM = ` INSERT INTO productschoolmap (productid, schoolid) VALUES ( '${InsertId}', '${schoolID}' ) `
                // const dataPSM = await db.query(thisQueryPSM); 
            }
            // Image excel insert
            for (let i = 0; i < imageSeqArray.length; i++) {

                const seq = imageSeqArray[i];
                const url = imageUrlArray[i];

                const imgName = path.basename(url);    

                // const thisQueryPimage = `INSERT INTO productimage (productid, imageseq, image) VALUES ('${InsertId}', '${seq}', '${imgName}')`;
                // const data2 = await db.query(thisQueryPimage);

                const extension = path.extname(url) || '.jpg';
                const baseDir = path.join(process.cwd(), "uploads", "product", "image", `${InsertId}`, `${seq}`);

                console.log('imgNameimgNameimgName', imgName);

                fs.mkdirSync(baseDir, { recursive: true });

                const localImgPath = path.join(baseDir);
                console.log('localImgPath', localImgPath);
            
                try {
                    await downloadImage(url, localImgPath, imgName);
                } catch (error) {
                    console.error('Error downloading the image:', error);
                }
            }
            // Variants excel insert
            for (let i = 0; i < MvariantSizeArray.length; i++) {

                const SizeArray = MvariantSizeArray[i];
                const ColorArray = MvariantColorArray[i];
                const PriceArray = MvariantPriceArray[i];
                const QuantityArray = MvariantQuantityArray[i];
                const ImageSeqArray = MvariantImageSeqArray[i];
                const WeightArray = MvariantWeightArray[i];

                // const thisQueryV = `INSERT INTO variant (productid, size, color, price, quantity, imageid, weight) 
                // VALUES ('${InsertId}', '${SizeArray}', '${ColorArray}', '${PriceArray}', '${QuantityArray}','${ImageSeqArray}', ,'${WeightArray}')`;
                // const data3 = await db.query(thisQueryV);
            }

            // rowing.push(data);
        }

        console.log("rowing", rowing);

        res.status(200).send({
            status: true,
            message: 'Bulk product imported successfully',
        });
    } catch (error) {
        console.error('Error uploading file:', error);
        res.status(500).send({
            status: false,
            message: 'Error uploading file',
        });
    }
};

// export const uploadFile = (async (req, res) => {
//     // const query = util.promisify;
//     readXlsxFile('./uploads/' + req.file.filename).then(async (rows) => {
  
//         const rowing = [];
//         console.log('rowing', rowing);

//         rows.shift();
//         rows.map(async (row, i) => {
     
//         const schoolName = await db.query(`select schoolid from school where name = '${row[0]}' limit 1`);
//         const schoolID = schoolName[0][0] ? schoolName[0][0]?.schoolid : 0

//         const masterName = await db.query(`select masterid from masters where mastername = '${row[1]}' limit 1`);
//         const masterID = masterName[0][0] ? masterName[0][0]?.masterid : 0

//         const genderName = await db.query(`select dataid from mastersdata where name = '${row[3]}' limit 1`);
//         const genderID = genderName[0][0] ? genderName[0][0]?.dataid : 0

//         console.log('school name', `${row[0]}`, schoolID);
//         console.log('masters', `${row[1]}`, masterID);
//         console.log('product name', `${row[2]}`);
//         console.log('gender name', `${row[3]}`, genderID);
//         console.log('price', `${row[4]}`);
//         console.log('weight', `${row[5]}`);
//         console.log('quantity', `${row[6]}`);
//         console.log('description', `${row[7]}`);  

//         const imagePath = row[8];

//         const imgName = path.basename(imagePath);
//         const localImgPath = path.join(__dirname, 'uploads', imgName);
//         console.log('localImgPath', localImgPath);
        
//         fs.copyFileSync(imagePath, localImgPath); 

       
//         //   let thisQuery = ` INSERT INTO product (masterid, name, description, price, gst, gender, weight, productstatus, published, quantity, createdon,  createdby)
//         //   VALUES ( '${row[0]}', '${productid}','${variantid}',${quantity}) `
  
//         // const data = await db.query(thisQuery); 

//         const InsertId = 23
//         console.log('InsertId', InsertId);      


//         // return rowing.push(data);
//       });
  
//      console.log("rowing", rowing);
  
//         res.status(200).send({
//           status: 200,
//           message: 'Bulk product imported successfully',
//         });
//     });
// });

// async function downloadImage(imageUrl, folderPath, fileName) {
//     try {
//         // Create the folder if it doesn't exist
//         if (!fs.existsSync(folderPath)) {
//             fs.mkdirSync(folderPath, { recursive: true });
//         }

//         // Get the image response
//         const response = await axios.get(imageUrl, {
//             responseType: 'arraybuffer', // Ensure we get the image as a buffer
//         });

//         // Set the file path
//         const filePath = path.join(folderPath, fileName);

//         // Write the file to the filesystem
//         fs.writeFileSync(filePath, response.data);

//         console.log(`Image saved to ${filePath}`);
//     } catch (error) {
//         console.error('Error downloading the image:', error);
//     }
// }

// // Example usage
// const imageUrl = 'https://picsum.photos/200';
// const folderPath = path.join(__dirname, 'uploads')
// const fileName = 'downloaded_image.jpg';

// downloadImage(imageUrl, folderPath, fileName);






























export const getAllProductsByPGN = async (req, res) => {
    try {
        const { pageno, limit } = req.body;
        const ProductResults = await executeStoredProcedure('SP_GetProductAll_withPGN', [pageno, limit, '', '']);
        if (ProductResults && ProductResults.status === true) {
            console.log(JSON.stringify(ProductResults));
            const ProductData = JSON.parse(ProductResults.data);
            res.status(200).json({ issuccess: true, message: ProductResults.message, ProductData, totalcount: ProductResults.totalcount });
        }
        else {
            res.status(400).json({ issuccess: false, message: ProductResults.message });
        }

    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};
export const getProductById = async (req, res) => {
    try {
        const { productid } = req.body;
        const ProductResults = await executeStoredProcedure('SP_GetProductByProductid', [productid, '', '']);
        if (ProductResults && ProductResults.status === true) {
            const ProductData = JSON.parse(ProductResults.data);
            res.status(200).json({ issuccess: true, message: ProductResults.message, ProductData });
        }
        else {
            res.status(400).json({ issuccess: false, message: ProductResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};


export const searchproduct = async (req, res) => {
    try {
        const { searchterm } = req.body;
        const ProductResults = await executeStoredProcedure('SP_SearchProduct', [searchterm, '', '']);
        if (ProductResults && ProductResults.status === true) {
            console.log(JSON.stringify(ProductResults));
            const ProductData = JSON.parse(ProductResults.data);
            res.status(200).json({ issuccess: true, message: ProductResults.message, ProductData });
        }
        else {
            res.status(400).json({ issuccess: false, message: ProductResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

export const SearchProductMinidetailsFilters = async (req, res) => {
    try {
        const { dataid, masterid } = req.body;
        const ProductResults = await executeStoredProcedure('SP_SearchProductMinidetailsFilters', [dataid, masterid, '', '']);
        if (ProductResults && ProductResults.status === true) {
            console.log(JSON.stringify(ProductResults));
            const ProductData = JSON.parse(ProductResults.data);
            res.status(200).json({ issuccess: true, message: ProductResults.message, ProductData });
        }
        else {
            res.status(400).json({ issuccess: false, message: ProductResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

export const SearchProductMinidetailsSchool = async (req, res) => {
    try {
        const { userid } = req.body;
        const ProductResults = await executeStoredProcedure('SP_SearchProductMinidetailsSchool', [userid, '', '']);
        if (ProductResults && ProductResults.status === true) {
            console.log(JSON.stringify(ProductResults));
            const ProductData = JSON.parse(ProductResults.data);
            res.status(200).json({ issuccess: true, message: ProductResults.message, ProductData });
        }
        else {
            res.status(400).json({ issuccess: false, message: ProductResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

export const InitProduct = async (req, res) => {
    try {
        const ProductResults = await executeStoredProcedure('SP_initproductapi', ['', '']);
        if (ProductResults && ProductResults.status === true) {
            console.log(JSON.stringify(ProductResults));
            const ProductData = JSON.parse(ProductResults.data);
            res.status(200).json({ issuccess: true, message: ProductResults.message, ProductData });
        }
        else {
            res.status(400).json({ issuccess: false, message: ProductResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};


export const GetProductwithimage = async (req, res) => {
    try {
        const ProductResults = await executeStoredProcedure('SP_GetProductwithimage', ['', '']);
        if (ProductResults && ProductResults.status === true) {
            const ProductData = JSON.parse(ProductResults.data);
            res.status(200).json({ issuccess: true, message: ProductResults.message, ProductData });
        }
        else {
            res.status(400).json({ issuccess: false, message: ProductResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

export const getbriefproductdetails = async (req, res) => {
    try {
        const { productid } = req.body;
        const ProductResults = await executeStoredProcedure('SP_getbriefproductdetails', [productid, '', '']);
        if (ProductResults && ProductResults.status === true) {
            const ProductData = JSON.parse(ProductResults.data);
            res.status(200).json({ issuccess: true, message: ProductResults.message, ProductData });
        }
        else {
            res.status(400).json({ issuccess: false, message: ProductResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

export const getminmaxprice = async (req, res) => {
    try {
        const ProductResults = await executeStoredProcedure('SP_getminmaxprice', ['', '']);
        if (ProductResults && ProductResults.status === true) {
            const ProductData = JSON.parse(ProductResults.data);
            res.status(200).json({ issuccess: true, message: ProductResults.message, ProductData });
        }
        else {
            res.status(400).json({ issuccess: false, message: ProductResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

export const searchproductother = async (req, res) => {
    try {
        const { masterid, subdataid ,limit,pageno} = req.body;
        const masteridJSON = [];
        try {
            if (masterid && Array.isArray(masterid) && masterid.length > 0) {
                console.log(masterid);
                for (const code of masterid) {
                    const jsonString = JSON.stringify(code);
                    masteridJSON.push(jsonString);
                }
                console.log(masteridJSON);
            }
        } catch (error) {
            // Handle any errors during conversion, such as invalid data types or circular references
            console.error('Error converting masterid to JSON:', error);
        }
        const subdataidJSON = [];
        try {
            if (subdataid && Array.isArray(subdataid) && subdataid.length > 0) {
                console.log(subdataid);
                for (const code of subdataid) {
                    const jsonString = JSON.stringify(code);
                    subdataidJSON.push(jsonString);
                }
                console.log(subdataidJSON);
            }
        } catch (error) {
            // Handle any errors during conversion, such as invalid data types or circular references
            console.error('Error converting subdataid to JSON:', error);
        }
        const ProductResults = await executeStoredProcedure('SP_searchproductother', [masteridJSON,subdataidJSON,limit,pageno, '', '']);
        if (ProductResults && ProductResults.status === true) {
            console.log(JSON.stringify(ProductResults));
            const ProductData = JSON.parse(ProductResults.data);
            res.status(200).json({ issuccess: true, message: ProductResults.message, ProductData });
        }
        else {
            res.status(400).json({ issuccess: false, message: ProductResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

export const searchproductschool = async (req, res) => {
    try {
        const { userid ,masterid, subdataid ,limit,pageno } = req.body;
        const masteridJSON = [];
        try {
            if (masterid && Array.isArray(masterid) && masterid.length > 0) {
                console.log(masterid);
                for (const code of masterid) {
                    const jsonString = JSON.stringify(code);
                    masteridJSON.push(jsonString);
                }
                console.log(masteridJSON);
            }
        } catch (error) {
            // Handle any errors during conversion, such as invalid data types or circular references
            console.error('Error converting masterid to JSON:', error);
        }
        const subdataidJSON = [];
        try {
            if (subdataid && Array.isArray(subdataid) && subdataid.length > 0) {
                console.log(subdataid);
                for (const code of subdataid) {
                    const jsonString = JSON.stringify(code);
                    subdataidJSON.push(jsonString);
                }
                console.log(subdataidJSON);
            }
        } catch (error) {
            // Handle any errors during conversion, such as invalid data types or circular references
            console.error('Error converting subdataid to JSON:', error);
        }
        const ProductResults = await executeStoredProcedure('SP_searchproductschool', [userid, masteridJSON,subdataidJSON,limit,pageno, '', '']);
        if (ProductResults && ProductResults.status === true) {
            console.log(JSON.stringify(ProductResults));
            const ProductData = JSON.parse(ProductResults.data);
            res.status(200).json({ issuccess: true, message: ProductResults.message, ProductData });
        }
        else {
            res.status(400).json({ issuccess: false, message: ProductResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};