import { formatDateToYYYYMMDD, formatDateTimeToYYYYMMDDHHMMSS } from '../../Utils/Datetime.js';
import moment from 'moment-timezone';

const currentDate = new Date();
const isoDateString = currentDate.toISOString();

const originalMoment = moment(isoDateString);
const originalDate = originalMoment.toDate();

const formattedDate = formatDateToYYYYMMDD(originalDate);

const formattedDateTime = formatDateTimeToYYYYMMDDHHMMSS(originalDate);

import { db } from '../../config/Database.js';

// SALES API`S
// Sales Dashboard
export const salesDashboard = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

    const mastername = req.params.mastername;
    const filters = req.query;

    try {

        let thisQuery = ` SELECT
        COUNT(CASE WHEN online = 1 THEN 0 END) AS online_sales,
        COUNT(CASE WHEN online = 0 THEN 0 END) AS store_sales
        FROM transactions
        `
        const totalSales = await db.query(thisQuery)
        console.log('totalSales', totalSales[0]);
        

        const onlineSales = totalSales[0][0] ? totalSales[0][0].online_sales : 0;
        const storeSales = totalSales[0][0] ? totalSales[0][0].store_sales : 0;
        const totalSalesSum = parseInt(onlineSales) + parseInt(storeSales);

        let thisQueryMonth = `
        SELECT 
          month_list.month,
            COUNT(CASE WHEN online = 1 THEN 0 END) AS online_sales,
            COUNT(CASE WHEN online = 0 THEN 0 END) AS store_sales
        FROM (
          SELECT 'Jan' AS month UNION
          SELECT 'Feb' UNION
          SELECT 'Mar' UNION
          SELECT 'Apr' UNION
          SELECT 'May' UNION
          SELECT 'Jun' UNION
          SELECT 'Jul' UNION
          SELECT 'Aug' UNION
          SELECT 'Sep' UNION
          SELECT 'Oct' UNION
          SELECT 'Nov' UNION
          SELECT 'Dec'
        ) AS month_list
        LEFT JOIN transactions ON DATE_FORMAT(createdon, '%b') = month_list.month
        GROUP BY month_list.month
        ORDER BY FIELD(month_list.month, 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec') `

        let thisQueryDay = `  SELECT 
        DATE(createdon) AS day,
        COUNT(CASE WHEN online = 1 THEN 0 END) AS online_sales,
        COUNT(CASE WHEN online = 0 THEN 0 END) AS store_sales
        FROM transactions
        GROUP BY DATE(createdon)
        ORDER BY DATE(createdon) DESC `

        const salesByMonth = await db.query(thisQueryMonth)
        const salesByDay = await db.query(thisQueryDay)

        let thisQuery1 = `
        SELECT 
        DATE(createdon) AS day,
        COUNT(CASE WHEN online = 1 THEN 0 END) AS online_sales,
        COUNT(CASE WHEN online = 0 THEN 0 END) AS store_sales
        FROM transactions
        WHERE DATE(createdon) = DATE(NOW())
        GROUP BY DATE(createdon) `

        const todayData = await db.query(thisQuery1)
        console.log('todayData', todayData);

        res.status(200).send({
            status: true,
            data: {
                online_sales: onlineSales,
                store_sales: storeSales,
                total_sales: totalSalesSum,
                sales_by_month: salesByMonth[0],
                sales_by_day: salesByDay[0],
                today_data: todayData[0] 
              },
        })
    } 
      catch (error) {
        console.log(error);
        res.status(500).send({ 
            error: 'Internal Server Error', 
            message: error.message 
        });
    }
};
// Sales Bar Chart
export const salesBarChart = async (req, res) => {
    const { start_date, end_date } = req.query;
  
    try {
      let thisQuery = `
        SELECT 
        DATE_FORMAT(createdon, '%Y-%m') AS month,
        COUNT(CASE WHEN online = 1 THEN 0 END) AS online_sales,
        COUNT(CASE WHEN online = 0 THEN 0 END) AS store_sales
        FROM transactions
        WHERE id IS NOT NULL `
        if (start_date && end_date) {
            thisQuery += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}'`
        }
        thisQuery += `
        GROUP BY DATE_FORMAT(createdon, '%Y-%m')
        ORDER BY DATE_FORMAT(createdon, '%Y-%m') ASC `
      
      const salesData = await db.query(thisQuery, [start_date, end_date]);
  
      const months = [];
      const onlineSales = [];
      const storeSales = [];
  
      salesData[0].forEach(row => {
        const month = new Date(row.month + "-01").toLocaleString('default', { month: 'long' });
        months.push(month);
        onlineSales.push(row.online_sales);
        storeSales.push(row.store_sales);
      });
  
      res.status(200).send({
        status: "success",
        data: {
          months,
          online_sales: onlineSales,
          store_sales: storeSales
        }
      });
    } catch (error) {
      console.log(error);
      res.status(500).send({
        status: "error",
        message: error.message
      });
    }
};
// Sales Line Chart
export const salesLineChart1 = async (req, res) => {
  const { start_date, end_date } = req.query;

  try {
      let dailySalesQuery = `
      SELECT 
          DATE(createdon) AS day,
          COUNT(*) AS daily_sales
      FROM transactions
      WHERE id IS NOT NULL
      `;
      
      if (start_date && end_date) {
          dailySalesQuery += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}' `;
      }
      
      dailySalesQuery += `
      GROUP BY DATE(createdon)
      ORDER BY DATE(createdon) ASC
      `;

      let monthlySalesQuery = `
      SELECT 
          DATE_FORMAT(createdon, '%Y-%m') AS month,
          COUNT(*) AS monthly_sales
      FROM transactions
      WHERE id IS NOT NULL
      `;
      
      if (start_date && end_date) {
          monthlySalesQuery += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}' `;
      }

      monthlySalesQuery += `
      GROUP BY DATE_FORMAT(createdon, '%Y-%m')
      ORDER BY DATE_FORMAT(createdon, '%Y-%m') ASC
      `;

      const dailySalesData = await db.query(dailySalesQuery);
      const monthlySalesData = await db.query(monthlySalesQuery);

      const months = [
          "Jan", "Feb", "Mar", "Apr", "May", "Jun",
          "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
      ];

      // const dailySales = dailySalesData[0].map(row => row.daily_sales || 0);

      // const monthlySales = Object.fromEntries(months.map(month => [month, 0]));
      // monthlySalesData[0].forEach(row => {
      //   const monthIndex = new Date(row.month + "-01").getMonth();
      //   monthlySales[months[monthIndex]] = row.monthly_sales || 0;
      // });
      const monthlySales = months.map(month => {
          const monthRow = monthlySalesData[0].find(row => {
              const date = new Date(row.month + "-01");
              return date.toLocaleString("default", { month: "short" }) === month;
          });
          return monthRow ? monthRow.monthly_sales : 0;
      });

      let thisQuery = `
      SELECT 
      DATE_FORMAT(createdon, '%Y-%m') AS month,
      COUNT(CASE WHEN online = 1 THEN 0 END) AS online_sales,
      COUNT(CASE WHEN online = 0 THEN 0 END) AS store_sales
      FROM transactions
      WHERE id IS NOT NULL `
      if (start_date && end_date) {
          thisQuery += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}'`
      }
      thisQuery += `
      GROUP BY DATE_FORMAT(createdon, '%Y-%m')
      ORDER BY DATE_FORMAT(createdon, '%Y-%m') ASC `
    
    const salesData = await db.query(thisQuery, [start_date, end_date]);

      let thisQuery1 = `
      SELECT 
      DATE(createdon) AS day,
      COUNT(CASE WHEN online = 1 THEN 0 END) AS online_sales,
      COUNT(CASE WHEN online = 0 THEN 0 END) AS store_sales
      FROM transactions
      WHERE id IS NOT NULL `
      if (start_date && end_date) {
          thisQuery1 += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}'`
      }
      thisQuery1 += `
      GROUP BY DATE(createdon)
      ORDER BY DATE(createdon) ASC `
    
    const salesData1 = await db.query(thisQuery1, [start_date, end_date]);

    // const months1 = [];
    // const onlineSales = [];
    // const storeSales = [];

    // salesData[0].forEach(row => {
    //   const month = new Date(row.month + "-01").toLocaleString('default', { month: 'long' });
    //   months1.push(month);
    //   onlineSales.push(row.online_sales);
    //   storeSales.push(row.store_sales);
    // });

    const monthlyOnlineSales = {};
    const monthlyStoreSales = {};
    const detailedSales = [];

    months.forEach(month => {
      monthlyOnlineSales[month] = 0;
      monthlyStoreSales[month] = 0;
    });

    salesData[0].forEach(row => {
      const date = new Date(row.month + "-01");
      const monthName = date.toLocaleString("default", { month: "short" });
      monthlyOnlineSales[monthName] = row.online_sales || 0;
      monthlyStoreSales[monthName] = row.store_sales || 0;

      detailedSales.push({
        month: monthName,
        online_sales: row.online_sales || 0,
        store_sales: row.store_sales || 0
      });
    });

    months.forEach(month => {
      if (!detailedSales.some(row => row.month === month)) {
        detailedSales.push({
          month,
          online_sales: 0,
          store_sales: 0
        });
      }
    });

    detailedSales.sort((a, b) => months.indexOf(a.month) - months.indexOf(b.month));

      const monthlySales1 = Object.fromEntries(months.map(month => [month, 0]));
      monthlySalesData[0].forEach(row => {
        const monthIndex = new Date(row.month + "-01").getMonth();
        monthlySales1[months[monthIndex]] = row.monthly_sales || 0;
      });
      
      const onlinemonthlySales = Object.fromEntries(months.map(month => [month, 0]));
      salesData[0].forEach(row => {
        const monthIndex = new Date(row.month + "-01").getMonth();
        onlinemonthlySales[months[monthIndex]] = row.online_sales || 0;
      });
      const storemonthlySales = Object.fromEntries(months.map(month => [month, 0]));
      salesData[0].forEach(row => {
        const monthIndex = new Date(row.month + "-01").getMonth();
        storemonthlySales[months[monthIndex]] = row.store_sales || 0;
      });

      res.status(200).send({
          status: "success",
          data: {
              months,
              // daily_sales: dailySalesData[0],
              // monthly_sales: monthlySales1,
              // monthly_online_sales: onlinemonthlySales,
              // monthly_store_sales: storemonthlySales,
              detailed_daily_sales: salesData1[0],
              detailed_monthly_sales: detailedSales

          },
      });
  } catch (error) {
      console.log(error);
      res.status(500).send({
          status: "error",
          message: error.message,
      });
  }
};
export const salesLineChart = async (req, res) => {
  const { start_date, end_date } = req.query;

  try {
      let dailySalesQuery = `
      SELECT 
          DATE(createdon) AS day,
          COUNT(*) AS daily_sales
      FROM transactions
      WHERE id IS NOT NULL
      `;
      
      if (start_date && end_date) {
          dailySalesQuery += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}' `;
      }
      
      dailySalesQuery += `
      GROUP BY DATE(createdon)
      ORDER BY DATE(createdon) ASC
      `;

      let monthlySalesQuery = `
      SELECT 
          DATE_FORMAT(createdon, '%Y-%m') AS month,
          COUNT(*) AS monthly_sales
      FROM transactions
      WHERE id IS NOT NULL
      `;
      
      if (start_date && end_date) {
          monthlySalesQuery += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}' `;
      }

      monthlySalesQuery += `
      GROUP BY DATE_FORMAT(createdon, '%Y-%m')
      ORDER BY DATE_FORMAT(createdon, '%Y-%m') ASC
      `;

      const dailySalesData = await db.query(dailySalesQuery);
      const monthlySalesData = await db.query(monthlySalesQuery);

      const months = [
          "Jan", "Feb", "Mar", "Apr", "May", "Jun",
          "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
      ];

      // const dailySales = dailySalesData[0].map(row => row.daily_sales || 0);

      // const monthlySales = Object.fromEntries(months.map(month => [month, 0]));
      // monthlySalesData[0].forEach(row => {
      //   const monthIndex = new Date(row.month + "-01").getMonth();
      //   monthlySales[months[monthIndex]] = row.monthly_sales || 0;
      // });
      const monthlySales = months.map(month => {
          const monthRow = monthlySalesData[0].find(row => {
              const date = new Date(row.month + "-01");
              return date.toLocaleString("default", { month: "short" }) === month;
          });
          return monthRow ? monthRow.monthly_sales : 0;
      });

      let thisQuery = `
      SELECT 
      DATE_FORMAT(createdon, '%Y-%m') AS month,
      COUNT(CASE WHEN online = 1 THEN 0 END) AS online_sales,
      COUNT(CASE WHEN online = 0 THEN 0 END) AS store_sales
      FROM transactions
      WHERE id IS NOT NULL `
      if (start_date && end_date) {
          thisQuery += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}'`
      }
      thisQuery += `
      GROUP BY DATE_FORMAT(createdon, '%Y-%m')
      ORDER BY DATE_FORMAT(createdon, '%Y-%m') ASC `
    
    const salesData = await db.query(thisQuery, [start_date, end_date]);

      let thisQuery1 = `
      SELECT 
      DATE(createdon) AS day,
      COUNT(CASE WHEN online = 1 THEN 0 END) AS online_sales,
      COUNT(CASE WHEN online = 0 THEN 0 END) AS store_sales
      FROM transactions
      WHERE id IS NOT NULL `
      if (start_date && end_date) {
          thisQuery1 += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}'`
      }
      thisQuery1 += `
      GROUP BY DATE(createdon)
      ORDER BY DATE(createdon) ASC `
    
    const salesData1 = await db.query(thisQuery1, [start_date, end_date]);

    // const months1 = [];
    // const onlineSales = [];
    // const storeSales = [];

    // salesData[0].forEach(row => {
    //   const month = new Date(row.month + "-01").toLocaleString('default', { month: 'long' });
    //   months1.push(month);
    //   onlineSales.push(row.online_sales);
    //   storeSales.push(row.store_sales);
    // });

      const monthlySales1 = Object.fromEntries(months.map(month => [month, 0]));
      monthlySalesData[0].forEach(row => {
        const monthIndex = new Date(row.month + "-01").getMonth();
        monthlySales1[months[monthIndex]] = row.monthly_sales || 0;
      });
      
      const onlinemonthlySales = Object.fromEntries(months.map(month => [month, 0]));
      salesData[0].forEach(row => {
        const monthIndex = new Date(row.month + "-01").getMonth();
        onlinemonthlySales[months[monthIndex]] = row.online_sales || 0;
      });
      const storemonthlySales = Object.fromEntries(months.map(month => [month, 0]));
      salesData[0].forEach(row => {
        const monthIndex = new Date(row.month + "-01").getMonth();
        storemonthlySales[months[monthIndex]] = row.store_sales || 0;
      });

      res.status(200).send({
          status: "success",
          data: {
              months,
              daily_sales: dailySalesData[0],
              monthly_sales: monthlySales1,
              monthly_online_sales: onlinemonthlySales,
              monthly_store_sales: storemonthlySales,
              daily_overall_sales: salesData1[0]  
          },
      });
  } catch (error) {
      console.log(error);
      res.status(500).send({
          status: "error",
          message: error.message,
      });
  }
};

// Sales Percentage
export const salesPercentage = async (req, res) => {
  const { start_date, end_date } = req.query;

  try {
      let salesQuery = `
      SELECT
          COUNT(CASE WHEN online = 1 THEN 1 END) AS online_sales,
          COUNT(CASE WHEN online != 1 THEN 1 END) AS store_sales
      FROM transactions WHERE id IS NOT NULL
      `;

      if (start_date && end_date) {
        salesQuery += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}' `;
    }

      const salesData = await db.query(salesQuery);

      const onlineSales = salesData[0][0]?.online_sales || 0;
      const storeSales = salesData[0][0]?.store_sales || 0;
      const totalSales = onlineSales + storeSales;

      const onlineSalesPercentage = totalSales ? ((onlineSales / totalSales) * 100).toFixed(2) : 0;
      const storeSalesPercentage = totalSales ? ((storeSales / totalSales) * 100).toFixed(2) : 0;

      res.status(200).send({
          status: "success",
          data: {
              online_sales_percentage: parseFloat(onlineSalesPercentage),
              store_sales_percentage: parseFloat(storeSalesPercentage),
          },
      });
  } catch (error) {
      console.log(error);
      res.status(500).send({
          status: "error",
          message: error.message,
      });
  }
};
// Sales Dashboard List
export const salesDashboardList = async (req, res) => {
  const { start_date, end_date, limit } = req.query;

  try {
    let thisQueryData = ` SELECT
    tra.id, 
    tra.transid, 
    tra.ordernumber, 
    tra.childbillid as billid, 
    us.username as customer_name,
    DATE_FORMAT(tra.createdon , '%Y-%m-%d') as purchase_date,
    IF(online = 1, 'online', 'store') as billing_mode,
    tb.payment_type as payment_method,
    tra.status as transaction_status,
    tb.status as billing_status,
    tb.transaction_price as transaction_price
    FROM transactions as tra
    LEFT JOIN users as us on (us.userid = tra.userid)
    LEFT JOIN transaction_billing as tb on (tb.id = tra.childbillid)
    WHERE tra.id IS NOT NULL
    `

    if (start_date && end_date) {
      thisQueryData += ` AND DATE(tra.createdon) BETWEEN '${start_date}' AND '${end_date}' `;
    }

    thisQueryData += `    
    GROUP BY tra.id
    ORDER BY tra.id DESC `

    if (limit) {
      thisQueryData += ` limit ${limit},10 `
    }

    const data = await db.query(thisQueryData);
    console.log('dataaaa', data[0]);

    res.status(200).send({
        status: "success",
        data:data[0]
    });

  } catch (error) {
      console.log(error);
      res.status(500).send({
          status: "error",
          message: error.message,
      });
  }
};


// PRODUCT API`S
// Product Dashboard

export const productDashboard = async (req, res) => {

  await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

  const mastername = req.params.mastername;
  const filters = req.query;

  try {

      let thisQuery = ` 
      SELECT SUM(quantity) as instock 
      FROM variant
      `
      const totalSales = await db.query(thisQuery)
      console.log('totalSales', totalSales[0][0]?.instock);

      let thisQuery2 = ` 
      SELECT COUNT(productid) as total_products 
      FROM product
      `
      const totalSales2 = await db.query(thisQuery2)
      console.log('totalSales2', totalSales2[0]);
      

      let thisQuery1 = ` 
      SELECT SUM(quantity) as out_of_stock 
      FROM transactions 
      WHERE status = 'outofstock_o'
      `
      const totalSales3 = await db.query(thisQuery1);
      console.log('totalSales3', totalSales3[0]);
      
      const instock = totalSales[0][0] ? totalSales[0][0]?.instock : 0;
      const totalProducts = totalSales2[0][0] ? totalSales2[0][0]?.total_products : 0;
      const outOfStock = totalSales3[0][0] ? totalSales3[0][0]?.out_of_stock : 0;

    let thisQueryMonth1 = ` SELECT 
      month_list.month,
      COALESCE(instock_data.instock, 0) AS instock,
      COALESCE(out_of_stock_data.out_of_stock, 0) AS out_of_stock
      FROM (
          SELECT 'Jan' AS month UNION
          SELECT 'Feb' UNION
          SELECT 'Mar' UNION
          SELECT 'Apr' UNION
          SELECT 'May' UNION
          SELECT 'Jun' UNION
          SELECT 'Jul' UNION
          SELECT 'Aug' UNION
          SELECT 'Sep' UNION
          SELECT 'Oct' UNION
          SELECT 'Nov' UNION
          SELECT 'Dec'
      ) AS month_list

      LEFT JOIN (
          SELECT 
              DATE_FORMAT(v.createdon, '%b') AS month,
              SUM(v.quantity) AS instock
          FROM variant v
          GROUP BY DATE_FORMAT(v.createdon, '%b')
      ) AS instock_data ON month_list.month = instock_data.month

      LEFT JOIN (
          SELECT 
              DATE_FORMAT(t.createdon, '%b') AS month,
              SUM(t.quantity) AS out_of_stock
          FROM transactions t
          WHERE t.status = 'outofstock_o'
          GROUP BY DATE_FORMAT(t.createdon, '%b')
      ) AS out_of_stock_data ON month_list.month = out_of_stock_data.month

    ORDER BY FIELD(month_list.month, 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec')`

    const salesByMonth1 = await db.query(thisQueryMonth1)

      let thisQueryDay = `  SELECT 
      DATE(createdon) AS day,
      SUM(quantity) as instock 
      FROM variant
      GROUP BY DATE(createdon)
      ORDER BY DATE(createdon) DESC `
      const salesByDay = await db.query(thisQueryDay)

      let thisQueryDay1 = `  SELECT 
      DATE(createdon) AS day,
      SUM(quantity) as out_of_stock 
      FROM transactions
      WHERE status = 'outofstock_o'
      GROUP BY DATE(createdon)
      ORDER BY DATE(createdon) DESC `

      const salesByDay1 = await db.query(thisQueryDay1)

      const dataMap = new Map();
      salesByDay[0].forEach(row => {
        const day = row.day;
        if (!dataMap.has(day)) {
          dataMap.set(day, { day, instock: 0, out_of_stock: 0 });
        }
        dataMap.get(day).instock = parseInt(row.instock) || 0;
      });
      
      salesByDay1[0].forEach(row => {
        const day = row.day;
        if (!dataMap.has(day)) {
          dataMap.set(day, { day, instock: 0, out_of_stock: 0 });
        }
        dataMap.get(day).out_of_stock = parseInt(row.out_of_stock) || 0;
      });

      const overallData = Array.from(dataMap.values()).sort((a, b) => new Date(b.day) - new Date(a.day));

      let thisQueryPublish = `  SELECT 
      COUNT(CASE WHEN published = '1' THEN 0 END) AS published,
      COUNT(CASE WHEN published = '0' THEN 0 END) AS unpublished
      FROM product `
      const PublishData = await db.query(thisQueryPublish)

      res.status(200).send({
          status: true,
          data: {
              total_products: totalProducts,
              instock: instock,
              out_of_stock: outOfStock,
              sales_by_month: salesByMonth1[0],
              // sales_by_day_instock: salesByDay[0],
              // sales_by_day_outofstock: salesByDay1[0],
              sales_by_day: overallData,
              published_data:PublishData[0]
            },
      })
  } 
    catch (error) {
      console.log(error);
      res.status(500).send({ 
          error: 'Internal Server Error', 
          message: error.message 
      });
  }
};
// Product Bar Chart
export const productBarChart1 = async (req, res) => {
  const { start_date, end_date } = req.query;

  try {
    let thisQuery = `
      SELECT 
      DATE_FORMAT(createdon, '%Y-%m') AS month,
      SUM(quantity) as instock 
      FROM variant
      WHERE id IS NOT NULL `
      if (start_date && end_date) {
          thisQuery += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}'`
      }
      thisQuery += `
      GROUP BY DATE_FORMAT(createdon, '%Y-%m')
      ORDER BY DATE_FORMAT(createdon, '%Y-%m') ASC `
    
    const salesData = await db.query(thisQuery, [start_date, end_date]);

    let thisQuery1 = `
      SELECT 
      DATE_FORMAT(createdon, '%Y-%m') AS month,
      SUM(quantity) as out_of_stock 
      FROM transactions
      WHERE status = 'outofstock_o' `
      if (start_date && end_date) {
          thisQuery1 += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}'`
      }
      thisQuery1 += `
      GROUP BY DATE_FORMAT(createdon, '%Y-%m')
      ORDER BY DATE_FORMAT(createdon, '%Y-%m') ASC `
    
    const salesData1 = await db.query(thisQuery1, [start_date, end_date]);

    console.log('salesData', salesData[0]);
    console.log('salesData1', salesData1[0]);


    const months = [];
    const instockD = [];
    const outOfStockD = [];

    salesData[0].forEach(row => {
      const month = new Date(row.month + "-01").toLocaleString('default', { month: 'long' });
      months.push(month);
      instockD.push(row.instock);
    });
    salesData1[0].forEach(row => {
      const month = new Date(row.month + "-01").toLocaleString('default', { month: 'long' });
      months.push(month);
      outOfStockD.push(row.out_of_stock);
    });

    // const months = [
    //   "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    //   "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    // ];

    // const instockD = Object.fromEntries(months.map(month => [month, 0]));
    // const outOfStockD = Object.fromEntries(months.map(month => [month, 0]));

    // salesData[0].forEach(row => {
    //   const monthIndex = new Date(row.month + "-01").getMonth();
    //   instockD[months[monthIndex]] = row.instock|| 0;
    // });
    // salesData[0].forEach(row => {
    //   const monthIndex = new Date(row.month + "-01").getMonth();
    //   outOfStockD[months[monthIndex]] = row.out_of_stock|| 0;
    // });

    res.status(200).send({
      status: "success",
      data: {
        months,
        instock: instockD,
        out_of_stock: outOfStockD
      }
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      status: "error",
      message: error.message
    });
  }
};
export const productBarChart = async (req, res) => {
  const { start_date, end_date } = req.query;

  try {
    // Query to fetch instock data
    let instockQuery = `
      SELECT
        DATE_FORMAT(createdon, '%Y-%m') AS month,
        SUM(quantity) as instock
      FROM variant
      WHERE id IS NOT NULL
    `;
    if (start_date && end_date) {
      instockQuery += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}'`;
    }
    instockQuery += `
      GROUP BY DATE_FORMAT(createdon, '%Y-%m')
      ORDER BY DATE_FORMAT(createdon, '%Y-%m') ASC
    `;

    const instockData = await db.query(instockQuery);

    // Query to fetch out_of_stock data
    let outOfStockQuery = `
      SELECT
        DATE_FORMAT(createdon, '%Y-%m') AS month,
        SUM(quantity) as out_of_stock
      FROM transactions
      WHERE status = 'outofstock_o'
    `;
    if (start_date && end_date) {
      outOfStockQuery += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}'`;
    }
    outOfStockQuery += `
      GROUP BY DATE_FORMAT(createdon, '%Y-%m')
      ORDER BY DATE_FORMAT(createdon, '%Y-%m') ASC
    `;

    const outOfStockData = await db.query(outOfStockQuery);

    // Combine the data into a single dataset
    const dataMap = new Map();

    // Populate instock data
    instockData[0].forEach(row => {
      const month = new Date(row.month + "-01").toLocaleString('default', { month: 'long' });
      if (!dataMap.has(month)) {
        dataMap.set(month, { instock: 0, out_of_stock: 0 });
      }
      dataMap.get(month).instock = row.instock || 0;
    });

    // Populate out_of_stock data
    outOfStockData[0].forEach(row => {
      const month = new Date(row.month + "-01").toLocaleString('default', { month: 'long' });
      if (!dataMap.has(month)) {
        dataMap.set(month, { instock: 0, out_of_stock: 0 });
      }
      dataMap.get(month).out_of_stock = row.out_of_stock || 0;
    });

    // Convert map to arrays
    const months = Array.from(dataMap.keys());
    const instockD = months.map(month => dataMap.get(month).instock);
    const outOfStockD = months.map(month => dataMap.get(month).out_of_stock);

    res.status(200).send({
      status: "success",
      data: {
        months,
        instock: instockD,
        out_of_stock: outOfStockD
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).send({
      status: "error",
      message: error.message
    });
  }
};

// Product Line Chart
export const productLineChart = async (req, res) => {
  const { start_date, end_date } = req.query;

  try {
    let instockQuery = `
      SELECT 
          DATE_FORMAT(createdon, '%Y-%m') AS month,
          SUM(quantity) as instock_count 
      FROM variant
      WHERE id IS NOT NULL
    `;
    if (start_date && end_date) {
      instockQuery += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}' `;
    }
    instockQuery += `
      GROUP BY month
      ORDER BY month ASC
    `;

    let outofstockQuery = `
      SELECT 
          DATE_FORMAT(createdon, '%Y-%m') AS month,
          SUM(quantity) as out_of_stock_count 
      FROM transactions
      WHERE status = 'outofstock_o'
    `;
    if (start_date && end_date) {
      outofstockQuery += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}' `;
    }
    outofstockQuery += `
      GROUP BY month
      ORDER BY month ASC
    `;

    const inStockData = await db.query(instockQuery);
    const outOfStockData = await db.query(outofstockQuery);

    const months = [
      "Jan", "Feb", "Mar", "Apr", "May", "Jun",
      "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    ];

    const inStockD = Object.fromEntries(months.map(month => [month, 0]));
    const outOfStockD = Object.fromEntries(months.map(month => [month, 0]));

    inStockData[0].forEach(row => {
      const monthIndex = new Date(row.month + "-01").getMonth();
      inStockD[months[monthIndex]] = row.instock_count || 0;
    });

    outOfStockData[0].forEach(row => {
      const monthIndex = new Date(row.month + "-01").getMonth();
      outOfStockD[months[monthIndex]] = row.out_of_stock_count || 0;
    });

    res.status(200).send({
      status: "success",
      data: {
        months,
        instock: inStockD,
        out_of_stock: outOfStockD,
      },
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      status: "error",
      message: error.message,
    });
  }
};
// Product Percentage
export const productPercentage = async (req, res) => {
  const { start_date, end_date } = req.query;

  try {
      let salesQuery = `
      SELECT
        SUM(quantity) as instock 
      FROM variant WHERE id IS NOT NULL
      `;

      if (start_date && end_date) {
        salesQuery += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}' `;
      }

      const data = await db.query(salesQuery);
      let salesQuery1 = `
      SELECT
        SUM(quantity) as out_of_stock 
      FROM transactions 
      WHERE status = 'outofstock_o'
      `;

      if (start_date && end_date) {
        salesQuery1 += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}' `;
      }

      const data1 = await db.query(salesQuery1);

      const instock_count = data[0][0]?.instock || 0;
      const out_of_stock_count = data1[0][0]?.out_of_stock || 0;
      const totalCount = parseInt(instock_count) + parseInt(out_of_stock_count);

      console.log('instock_count', instock_count);
      console.log('out_of_stock_count', out_of_stock_count);
      console.log('totalCount', totalCount);

      let inStockPercentage = totalCount ? ((parseInt(instock_count) / totalCount) * 100) : 0;
      let outOfStockPercentage = totalCount ? ((parseInt(out_of_stock_count) / totalCount) * 100) : 0;

      console.log('outOfStockPercentage', outOfStockPercentage);
      
      inStockPercentage = Math.floor(inStockPercentage);
      outOfStockPercentage = 100 - inStockPercentage;

      console.log("inStockPercentage final:", inStockPercentage); // 99
      console.log("outOfStockPercentage final:", outOfStockPercentage); // 1

      res.status(200).send({
          status: "success",
          data: {
            instock_percentage:inStockPercentage,
            out_of_stock_percentage:outOfStockPercentage,
          },
      });
  } catch (error) {
      console.log(error);
      res.status(500).send({
          status: "error",
          message: error.message,
      });
  }
};
// Product Dashboard List
export const productDashboardList = async (req, res) => {
  const { start_date, end_date, limit } = req.query;

  try {
    let thisQueryData = ` SELECT
    p.productid, 
    p.name, 
    p.description, 
    p.productstatus as productstatus, 
    DATE_FORMAT(p.createdon , '%Y-%m-%d') as created_date,
    IF(published = 1, 'ON', 'OFF') as published,
    gen.name as gender_name,
    (SELECT JSON_ARRAYAGG(
        JSON_OBJECT(
            'id', id,
            'size', size,
            'color', color,
            'price', price,
            'quantity', quantity,
            'weight', weight
        )
      )
      FROM variant 
      WHERE variant.productid = p.productid

    ) AS variant_details,
    (SELECT JSON_ARRAYAGG(
        JSON_OBJECT(
            'image', pi.image,
            'imageseq', pi.imageseq,
            'productid', pi.productid
        )
      )
      FROM productimage as pi
      WHERE pi.productid IN (p.productid) AND pi.imageseq = 1
    ) AS images
    FROM product as p
    LEFT JOIN gender as gen on (gen.id = p.gender)
    WHERE p.productid IS NOT NULL
    `

    if (start_date && end_date) {
      thisQueryData += ` AND DATE(p.createdon) BETWEEN '${start_date}' AND '${end_date}' `;
    }

    thisQueryData += `    
    GROUP BY p.productid
    ORDER BY p.productid DESC `

    if (limit) {
      thisQueryData += ` limit ${limit},10 `
    }

    const data = await db.query(thisQueryData);
    console.log('dataaaa', data[0]);

    res.status(200).send({
        status: "success",
        data:data[0]
    });

  } catch (error) {
      console.log(error);
      res.status(500).send({
          status: "error",
          message: error.message,
      });
  }
};















// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++=
// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++=
// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++=
// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++=

// export const productDashboard = async (req, res) => {

//   await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

//   const mastername = req.params.mastername;
//   const filters = req.query;

//   try {

//       let thisQuery = ` SELECT
//       COUNT(productid) as total_products,
//       COUNT(CASE WHEN productstatus = 'instock' THEN 0 END) AS instock,
//       COUNT(CASE WHEN productstatus != 'instock' THEN 0 END) AS out_of_stock
//       FROM product
//       `
//       const totalSales = await db.query(thisQuery)
//       console.log('totalSales', totalSales[0]);
      

//       const totalProducts = totalSales[0][0] ? totalSales[0][0].total_products : 0;
//       const instock = totalSales[0][0] ? totalSales[0][0].instock : 0;
//       const outOfStock = totalSales[0][0] ? totalSales[0][0].out_of_stock : 0;

//       let thisQueryMonth = `
//       SELECT 
//         month_list.month,
//           COUNT(CASE WHEN productstatus = 'instock' THEN 0 END) AS instock,
//           COUNT(CASE WHEN productstatus != 'instock' THEN 0 END) AS out_of_stock
//       FROM (
//         SELECT 'Jan' AS month UNION
//         SELECT 'Feb' UNION
//         SELECT 'Mar' UNION
//         SELECT 'Apr' UNION
//         SELECT 'May' UNION
//         SELECT 'Jun' UNION
//         SELECT 'Jul' UNION
//         SELECT 'Aug' UNION
//         SELECT 'Sep' UNION
//         SELECT 'Oct' UNION
//         SELECT 'Nov' UNION
//         SELECT 'Dec'
//       ) AS month_list
//       LEFT JOIN product ON DATE_FORMAT(createdon, '%b') = month_list.month
//       GROUP BY month_list.month
//       ORDER BY FIELD(month_list.month, 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec') `

//       let thisQueryDay = `  SELECT 
//       DATE(createdon) AS day,
//         COUNT(CASE WHEN productstatus = 'instock' THEN 0 END) AS instock,
//         COUNT(CASE WHEN productstatus != 'instock' THEN 0 END) AS out_of_stock
//       FROM product
//       GROUP BY DATE(createdon)
//       ORDER BY DATE(createdon) DESC `

//       const salesByMonth = await db.query(thisQueryMonth)
//       const salesByDay = await db.query(thisQueryDay)


// let thisQueryPublish = `  SELECT 
// COUNT(CASE WHEN published = '1' THEN 0 END) AS published,
// COUNT(CASE WHEN published = '0' THEN 0 END) AS unpublished
// FROM product `
// const PublishData = await db.query(thisQueryPublish)
//       res.status(200).send({
//           status: true,
//           data: {
//               total_products: totalProducts,
//               instock: instock,
//               out_of_stock: outOfStock,
//               sales_by_month: salesByMonth[0],
//               sales_by_day: salesByDay[0],
//               published_data:PublishData[0]
//             },
//       })
//   } 
//     catch (error) {
//       console.log(error);
//       res.status(500).send({ 
//           error: 'Internal Server Error', 
//           message: error.message 
//       });
//   }
// };
// // Product Bar Chart
// export const productBarChart = async (req, res) => {
//   const { start_date, end_date } = req.query;

//   try {
//     let thisQuery = `
//       SELECT 
//       DATE_FORMAT(createdon, '%Y-%m') AS month,
//         COUNT(CASE WHEN productstatus = 'instock' THEN 0 END) AS instock,
//         COUNT(CASE WHEN productstatus != 'instock' THEN 0 END) AS out_of_stock
//       FROM product
//       WHERE productid IS NOT NULL `
//       if (start_date && end_date) {
//           thisQuery += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}'`
//       }
//       thisQuery += `
//       GROUP BY DATE_FORMAT(createdon, '%Y-%m')
//       ORDER BY DATE_FORMAT(createdon, '%Y-%m') ASC `
    
//     const salesData = await db.query(thisQuery, [start_date, end_date]);

//     const months = [];
//     const instockD = [];
//     const outOfStockD = [];

//     salesData[0].forEach(row => {
//       const month = new Date(row.month + "-01").toLocaleString('default', { month: 'long' });
//       months.push(month);
//       instockD.push(row.instock);
//       outOfStockD.push(row.out_of_stock);
//     });

//     // const months = [
//     //   "Jan", "Feb", "Mar", "Apr", "May", "Jun",
//     //   "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
//     // ];

//     // const instockD = Object.fromEntries(months.map(month => [month, 0]));
//     // const outOfStockD = Object.fromEntries(months.map(month => [month, 0]));

//     // salesData[0].forEach(row => {
//     //   const monthIndex = new Date(row.month + "-01").getMonth();
//     //   instockD[months[monthIndex]] = row.instock|| 0;
//     // });
//     // salesData[0].forEach(row => {
//     //   const monthIndex = new Date(row.month + "-01").getMonth();
//     //   outOfStockD[months[monthIndex]] = row.out_of_stock|| 0;
//     // });

//     res.status(200).send({
//       status: "success",
//       data: {
//         months,
//         instock: instockD,
//         out_of_stock: outOfStockD
//       }
//     });
//   } catch (error) {
//     console.log(error);
//     res.status(500).send({
//       status: "error",
//       message: error.message
//     });
//   }
// };
// // Product Line Chart
// export const productLineChart = async (req, res) => {
//   const { start_date, end_date } = req.query;

//   try {
//     let instockQuery = `
//       SELECT 
//           DATE_FORMAT(createdon, '%Y-%m') AS month,
//           COUNT(*) AS instock_count
//       FROM product
//       WHERE productid IS NOT NULL AND productstatus = 'instock'
//     `;
//     if (start_date && end_date) {
//       instockQuery += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}' `;
//     }
//     instockQuery += `
//       GROUP BY month
//       ORDER BY month ASC
//     `;

//     let outofstockQuery = `
//       SELECT 
//           DATE_FORMAT(createdon, '%Y-%m') AS month,
//           COUNT(*) AS out_of_stock_count
//       FROM product
//       WHERE productid IS NOT NULL AND productstatus != 'instock'
//     `;
//     if (start_date && end_date) {
//       outofstockQuery += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}' `;
//     }
//     outofstockQuery += `
//       GROUP BY month
//       ORDER BY month ASC
//     `;

//     const inStockData = await db.query(instockQuery);
//     const outOfStockData = await db.query(outofstockQuery);

//     const months = [
//       "Jan", "Feb", "Mar", "Apr", "May", "Jun",
//       "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
//     ];

//     const inStockD = Object.fromEntries(months.map(month => [month, 0]));
//     const outOfStockD = Object.fromEntries(months.map(month => [month, 0]));

//     inStockData[0].forEach(row => {
//       const monthIndex = new Date(row.month + "-01").getMonth();
//       inStockD[months[monthIndex]] = row.instock_count || 0;
//     });

//     outOfStockData[0].forEach(row => {
//       const monthIndex = new Date(row.month + "-01").getMonth();
//       outOfStockD[months[monthIndex]] = row.out_of_stock_count || 0;
//     });

//     res.status(200).send({
//       status: "success",
//       data: {
//         months,
//         instock: inStockD,
//         out_of_stock: outOfStockD,
//       },
//     });
//   } catch (error) {
//     console.log(error);
//     res.status(500).send({
//       status: "error",
//       message: error.message,
//     });
//   }
// };
// // Product Percentage
// export const productPercentage = async (req, res) => {
//   const { start_date, end_date } = req.query;

//   try {
//       let salesQuery = `
//       SELECT
//         COUNT(CASE WHEN productstatus = 'instock' THEN 0 END) AS instock,
//         COUNT(CASE WHEN productstatus != 'instock' THEN 0 END) AS out_of_stock
//       FROM product WHERE productid IS NOT NULL
//       `;

//       if (start_date && end_date) {
//         salesQuery += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}' `;
//     }

//       const data = await db.query(salesQuery);

//       const instock_count = data[0][0]?.instock || 0;
//       const out_of_stock_count = data[0][0]?.out_of_stock || 0;
//       const totalCount = instock_count + out_of_stock_count;

//       const inStockPercentage = totalCount ? ((instock_count / totalCount) * 100).toFixed(2) : 0;
//       const outOfStockPercentage = totalCount ? ((out_of_stock_count / totalCount) * 100).toFixed(2) : 0;

//       res.status(200).send({
//           status: "success",
//           data: {
//             instock_percentage: parseFloat(inStockPercentage),
//             out_of_stock_percentage: parseFloat(outOfStockPercentage),
//           },
//       });
//   } catch (error) {
//       console.log(error);
//       res.status(500).send({
//           status: "error",
//           message: error.message,
//       });
//   }
// };
// // Product Dashboard List
// export const productDashboardList = async (req, res) => {
//   const { start_date, end_date, limit } = req.query;

//   try {
//     let thisQueryData = ` SELECT
//     p.productid, 
//     p.name, 
//     p.description, 
//     p.productstatus as productstatus, 
//     DATE_FORMAT(p.createdon , '%Y-%m-%d') as created_date,
//     IF(published = 1, 'ON', 'OFF') as published,
//     gen.name as gender_name,
//     (SELECT JSON_ARRAYAGG(
//         JSON_OBJECT(
//             'id', id,
//             'size', size,
//             'color', color,
//             'price', price,
//             'quantity', quantity,
//             'weight', weight
//         )
//       )
//       FROM variant 
//       WHERE variant.productid = p.productid

//     ) AS variant_details,
//     (SELECT JSON_ARRAYAGG(
//         JSON_OBJECT(
//             'image', pi.image,
//             'imageseq', pi.imageseq,
//             'productid', pi.productid
//         )
//       )
//       FROM productimage as pi
//       WHERE pi.productid IN (p.productid) AND pi.imageseq = 1
//     ) AS images
//     FROM product as p
//     LEFT JOIN gender as gen on (gen.id = p.gender)
//     WHERE p.productid IS NOT NULL
//     `

//     if (start_date && end_date) {
//       thisQueryData += ` AND DATE(p.createdon) BETWEEN '${start_date}' AND '${end_date}' `;
//     }

//     thisQueryData += `    
//     GROUP BY p.productid
//     ORDER BY p.productid DESC `

//     if (limit) {
//       thisQueryData += ` limit ${limit},10 `
//     }

//     const data = await db.query(thisQueryData);
//     console.log('dataaaa', data[0]);

//     res.status(200).send({
//         status: "success",
//         data:data[0]
//     });

//   } catch (error) {
//       console.log(error);
//       res.status(500).send({
//           status: "error",
//           message: error.message,
//       });
//   }
// };