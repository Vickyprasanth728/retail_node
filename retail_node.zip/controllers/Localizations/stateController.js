import { formatDateToYYYYMMDD, formatDateTimeToYYYYMMDDHHMMSS } from '../../Utils/Datetime.js';
import moment from 'moment-timezone';

const currentDate = new Date();
const isoDateString = currentDate.toISOString();

const originalMoment = moment(isoDateString);
const originalDate = originalMoment.toDate();

const formattedDate = formatDateToYYYYMMDD(originalDate);

const formattedDateTime = formatDateTimeToYYYYMMDDHHMMSS(originalDate);

import { db } from '../../config/Database.js';

// Get State Dropdown
export const getStateDropdown = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

    try {

        let thisQuery = ` SELECT * FROM states_names `
        const data = await db.query(thisQuery);

        res.status(200).send({
          status: true,
          message: 'success',
          data: data[0]
        });

      } 
      catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};