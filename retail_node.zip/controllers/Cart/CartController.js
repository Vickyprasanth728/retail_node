import {executeStoredProcedure } from '../../middleware/storeproceduremiddleware.js';
import { formatDateToYYYYMMDD, formatDateTimeToYYYYMMDDHHMMSS } from '../../Utils/Datetime.js';
import moment from 'moment-timezone';
const currentDate = new Date();
const isoDateString = currentDate.toISOString();

const originalMoment = moment(isoDateString);
const originalDate = originalMoment.toDate();

const formattedDate = formatDateToYYYYMMDD(originalDate);

const formattedDateTime = formatDateTimeToYYYYMMDDHHMMSS(originalDate);

//@route      POST /api/v1/cart/AddtoCart
//@desc       To AddtoCart
//@access     Private
export const AddtoCart = async (req, res) => {
    try {
        const { userid, productid } = req.body;
        const CartResults = await executeStoredProcedure('SP_Addtocart', [userid, productid, '', '']);
        if (CartResults && CartResults.status === true) {
            res.status(200).json({ issuccess: true, message: CartResults.message });
        }
        else {
            res.status(400).json({ issuccess: false, message: CartResults.message });
        }

    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

//@route      POST /api/v1/cart/updateCart
//@desc       To updateCart
//@access     Private
export const updateCart = async (req, res) => {
    try {
        const { cartid, cartstatus } = req.body;
        const cartidsJson = [];
        if (cartid && Array.isArray(cartid) && cartid.length > 0) {
            console.info(cartid);
            for (const code of cartid) {
              const jsonString = JSON.stringify(code);
              cartidsJson.push(jsonString);
            }
            console.info(cartidsJson);
          }
        const CartResults = await executeStoredProcedure('SP_UpdateCart', [cartidsJson, cartstatus, '', '']);
        if (CartResults && CartResults.status === true) {
            res.status(200).json({ issuccess: true, message: CartResults.message });
        }
        else {
            res.status(400).json({ issuccess: false, message: CartResults.message });
        }

    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

//@route      POST /api/v1/cart/GetCardbyUserId
//@desc       To Get Card by UserId
//@access     Public
export const GetCardbyUserId = async (req, res) => {
    try {
        const { userid, pageno, limit } = req.body;
        const CartResults = await executeStoredProcedure('SP_getaddtocart', [userid, pageno, limit, '', '']);
        if (CartResults && CartResults.status === true) {
            const CartData = JSON.parse(CartResults.data);
            res.status(200).json({ issuccess: true, message: CartResults.message, CartData });
        }
        else {
            res.status(400).json({ issuccess: false, message: CartResults.message });
        }

    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

// //@route      POST /api/v1/cart/quantityadd
// //@desc       To updateCart
// //@access     Private
// export const quantityadd = async (req, res) => {
//     try {
//         const { useid ,productid} = req.body;        
//         const CartResults = await executeStoredProcedure('SP_quantityadd', [useid ,productid, '', '']);
//         if (CartResults && CartResults.status === true) {
//             res.status(200).json({ issuccess: true, message: CartResults.message });
//         }
//         else {
//             res.status(400).json({ issuccess: false, message: CartResults.message });
//         }

//     } catch (error) {
//         console.log(error);
//         res.status(500).json({ error: 'Internal Server Error', message: error.message });
//     }
// };

// //@route      POST /api/v1/cart/quantityremove
// //@desc       To updateCart
// //@access     Private
// export const quantityremove = async (req, res) => {
//     try {
//         const { useid ,productid} = req.body;        
//         const CartResults = await executeStoredProcedure('SP_quantityremove', [useid ,productid, '', '']);
//         if (CartResults && CartResults.status === true) {
//             res.status(200).json({ issuccess: true, message: CartResults.message });
//         }
//         else {
//             res.status(400).json({ issuccess: false, message: CartResults.message });
//         }

//     } catch (error) {
//         console.log(error);
//         res.status(500).json({ error: 'Internal Server Error', message: error.message });
//     }
// };

//@route      POST /api/v1/cart/quantityremove
//@desc       To updateCart
//@access     Private
export const quantity = async (req, res) => {
    try {
        const { useid ,productid,quantity} = req.body;        
        const CartResults = await executeStoredProcedure('SP_quantity', [useid ,productid,quantity, '', '']);
        if (CartResults && CartResults.status === true) {
            res.status(200).json({ issuccess: true, message: CartResults.message });
        }
        else {
            res.status(400).json({ issuccess: false, message: CartResults.message });
        }

    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};