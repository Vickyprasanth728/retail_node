import Sequelize from 'sequelize';
import bcrypt from 'bcrypt';
import jwt from "jsonwebtoken";
import dotenv from 'dotenv';
import { executeStoredProcedure} from '../../middleware/storeproceduremiddleware.js';
import User from '../../models/UsersModel.js';
import UserLog from '../../models/LogModel.js';
import UserStatus from '../../models/UserStatus.js';
import { formatDateToYYYYMMDD, formatDateTimeToYYYYMMDDHHMMSS } from '../../Utils/Datetime.js';

dotenv.config();

import moment from 'moment-timezone';

const currentDate = new Date();
const isoDateString = currentDate.toISOString();
const originalMoment = moment(isoDateString);
const originalDate = originalMoment.toDate();
const formattedDate = formatDateToYYYYMMDD(originalDate);
const formattedDateTime = formatDateTimeToYYYYMMDDHHMMSS(originalDate);


//@route      POST /api/v1/users/signup
//@desc       To SignUp
//@access     Public
async function signUpUser(req, res) {
  const { body } = req;
  const { username, password, name, address, email, mobileno, schoolcode } = body;
  try {
    const schoolcodesJson = [];
    try {
      if (schoolcode && Array.isArray(schoolcode) && schoolcode.length > 0) {
        console.info(schoolcode);
        for (const code of schoolcode) {
          const jsonString = JSON.stringify(code);
          schoolcodesJson.push(jsonString);
        }
        console.info(schoolcodesJson);
      }
    } catch (error) {
      // Handle any errors during conversion, such as invalid data types or circular references
      console.error('Error converting schoolcode to JSON:', error);
    }
    const salt = await bcrypt.genSalt(10);
    const temppassword = await bcrypt.hash(password, salt);
    const parameters = [username, temppassword, name, address, email, mobileno, schoolcodesJson, '', ''];
    const userResults = await executeStoredProcedureExperimental('SP_SignUpUserWithSchool', parameters);
    if (userResults && userResults.status === true) {
      res.status(200).json({ issuccess: true, message: userResults.message });
    }
    else {
      res.status(401).json({ issuccess: false, message: userResults.message });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ issuccess: false, error: 'Internal Server Error', message: error.message });
  }
}

//@route      POST /api/v1/users/signup
//@desc       To SignUp
//@access     Public
async function signUpUserwithAddress(req, res) {
  const { body } = req;
  const { username, password, name, email, mobileno, schoolcode , address1,address2,address3,address4,address5,address6,address7,address8,landmark,city,state,country,pincode,alterphno,isprimary,iswork,addressstatus,createdby,createdon} = body;
  try {
    const schoolcodesJson = [];
    try {
      if (schoolcode && Array.isArray(schoolcode) && schoolcode.length > 0) {
        console.info(schoolcode);
        for (const code of schoolcode) {
          const jsonString = JSON.stringify(code);
          schoolcodesJson.push(jsonString);
        }
        console.info(schoolcodesJson);
      }
    } catch (error) {
      // Handle any errors during conversion, such as invalid data types or circular references
      console.error('Error converting schoolcode to JSON:', error);
    }
    const salt = await bcrypt.genSalt(10);
    const temppassword = await bcrypt.hash(password, salt);
    const parameters = [username, temppassword, name,email, mobileno, schoolcodesJson,address1,address2,address3,address4,address5,address6,address7,address8,landmark,city,state,country,pincode,alterphno,isprimary,iswork,addressstatus,createdby,createdon, '', ''];
    console.log(JSON.stringify(parameters));
    const userResults = await executeStoredProcedure('SP_SignUpUserWithSchoolandAddress', parameters);
    console.log(JSON.stringify(userResults));
    if (userResults && userResults.status === true) {
      console.log('userResults', userResults);
      
      res.status(200).json({ issuccess: true, message: userResults.message });
    }
    else {
      res.status(401).json({ issuccess: false, message: userResults.message });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ issuccess: false, error: 'Internal Server Error', message: error.message });
  }
}

//@route      POST /api/v1/users/signin
//@desc       To Signin
//@access     Public
async function signIn(req, res) {
  const { username, password } = req.body;

  try {
    if (!username) {
      return res.status(400).json({ success: false, message: 'Enter the username carefully' });
    }

    const user = await User.findOne({
      where: {
        username,
        status: {
          [Sequelize.Op.not]: 0,
        },
      },
      include: [{ model: UserStatus }],
    });
     if (!user) {
       return res.status(400).json({ issuccess: false,  message: 'Invalid login credentials', });
     }

    const userStatus = user?.user_status || {}; // Use an empty object if user.user_status is null
    // const [updatedUserStatus, created] = await UserStatus.findOrCreate({
    //   where: { username },
    //   defaults: { loginAttempts: 1 },
    // });

    // if (!created) {
    //   await updatedUserStatus.increment('loginAttempts', { by: 1 });
    //   console.info('Row updated.');
    // } else {
    //   console.info('Row inserted.');
    // }
    // if (userStatus.loginBlockedUntil !== null) {
    //   const blockedUntilDate = new Date(userStatus.loginBlockedUntil);
    //   console.log(blockedUntilDate);
    //   console.log(userStatus.loginBlockedUntil);
    //   if (blockedUntilDate > formattedDateTime) {
    //     return res.status(403).json({ issuccess: false, message: 'Account blocked. Try again after 10 Minutes.' });
    //   }
    // }
    // const blockedUntil = formattedDateTime + 600000; // Block for 10 Minutes
    // if (userStatus.loginAttempts && userStatus.loginAttempts >= 4) {      
    //   console.log(new Date(blockedUntil)); // This should print the correct blockedUntil date

    //   await UserStatus.update(
    //     { loginAttempts: 0, loginBlockedUntil: blockedUntil },
    //     { where: { username } }
    //   );
    //   return res.status(403).json({ issuccess: false, message: 'Account blocked. Try again after 10 Minutes.' });
    // }

    // // If the login attempts exceed the limit, return a response without resetting the attempts count
    // if (userStatus.loginAttempts >= 4) {
    //   return res.status(403).json({ issuccess: false, message: 'Account blocked. Try again after 10 Minutes.' });
    // }

    const passwordMatch = await bcrypt.compare(password, user.password);

    if (!passwordMatch) {
      // const [updatedUserStatus, created] = await UserStatus.findOrCreate({
      //   where: { username },
      //   defaults: { loginAttempts: 1 },
      // });

      // if (!created) {
      //   await updatedUserStatus.increment('loginAttempts', { by: 1 });
      //   console.info('Row updated.');
      // } else {
      //   console.info('Row inserted.');
      // }

      return res.status(401).json({
        issuccess: false,
        message: 'Invalid login credentials',
        //loginAttempts: updatedUserStatus.loginAttempts,
      });
    }

    try {
      await UserLog.create({
        userid: user.userid,
        lastlogin: formattedDateTime.toString(),
      });
      console.log('UserLog entry created successfully.');
    } catch (error) {
      console.error('Error creating UserLog entry:', error);
    }
    const accessToken = jwt.sign({ userId: user.userid, Email: user.email , Isstaff: user.isstaff }, process.env.ACCESS_TOKEN_SECRET, {
      expiresIn: process.env.ACCESS_TOKEN_EXPIRY,
    });
    const refreshToken = jwt.sign({ userId: user.userid, Email: user.email , Isstaff: user.isstaff }, process.env.REFRESH_TOKEN_SECRET, {
      expiresIn: process.env.REFRESH_TOKEN_EXPIRY,
    });
    // First, try to find the record
    const existingUserStatus = await UserStatus.findOne({ where: { username } });

    if (existingUserStatus) {
      // Update the existing record
      await existingUserStatus.update({
        loginAttempts: 0,
        refresh_token: refreshToken,
        loginBlockedUntil: null
      });
    } else {
      // Insert a new record
      await UserStatus.create({
        username,
        loginAttempts: 0,
        refresh_token: refreshToken,
        loginBlockedUntil: null
      });
    }

    let AddressData = null;
    const AddressResults = await executeStoredProcedure('SP_getaddressdetail', [user.userid, '', '']);
    if (AddressResults && AddressResults.status === true) {
      AddressData = JSON.parse(AddressResults.data);
    }
    let UserRoleData = null;
    const UserRoleResults = await executeStoredProcedure('SP_GetUserRoleDetailsByUserID', [user.userid, '', '']);
    if (UserRoleResults && UserRoleResults.status === true) {
      UserRoleData = JSON.parse(UserRoleResults.data);
    }
    res.status(200).json({
      issuccess: true,
      accessToken,
      isstaff: user.isstaff,
      name: user.name,
      address: AddressData,
      RoleDetails :UserRoleData,
      email: user.email,
      mobileno: user.mobileno,
      lastlogin: formattedDateTime,
      loginAttempts: userStatus.loginAttempts,
      userid: user.userid,
    });
  } catch (error) {
    console.error(error.message);
    res.status(500).json({ issuccess: false, message: 'Internal Server Error', error: error.message });
  }
}

async function getUsernamebyMobile(req, res) {
  try {
    const user = await User.findOne({
      where: { mobileno: req.params.mobileno },
      attributes: { exclude: ['password'] },
    });

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.status(200).json(user);
  } catch (error) {
    console.error('Error getting user by mobileno:', error);
    res.status(500).json({ message: 'Internal Server Error', error: error.message });
  }

}


//@route      POST /api/v1/users/usernameunique
//@desc       check if username is unique
//@access     Public

async function checkUsernameUnique(req, res) {
  try {
    const { username } = req.body;
    const isUsernameUnique = !(await User.findOne({ where: { username }, attributes: { exclude: ['password'] }, attributes: ['username'] }));
    res.json({ issuccess: isUsernameUnique });
  } catch (error) {
    console.error(error);
    res.status(500).json({ issuccess: false, Message: 'Internal Server Error', error: error.message });
  }
}


//@route      POST /api/v1/users/mobilenounique
//@desc       Check the Mobile No is Unique
//@access     Public
async function checkMobileNoUnique(req, res) {
  try {
    const { mobileno } = req.body;
    const isUsernameUnique = !(await User.findOne({ where: { mobileno }, attributes: { exclude: ['password'] }, attributes: ['mobileno'], }));

    res.json({ issuccess: isUsernameUnique });
  } catch (error) {
    console.error(error);
    res.status(500).json({ issuccess: false, Message: 'Internal Server Error', error: error.message });
  }
}

//@route      POST /api/v1/users/otpAuth
//@desc       Check the Mobile No is Unique
//@access     Public
async function CheckotpAuth(req, res) {
  try {
    const { mobileno } = req.body;
    const otpaccessToken = jwt.sign({ mobileno :mobileno }, process.env.ACCESS_TOKEN_SECRET, {
      expiresIn: process.env.ACCESS_TOKEN_EXPIRY,
    });
    res.json({ issuccess: true, otpaccessToken });
  } catch (error) {
    console.error(error);
    res.status(500).json({ issuccess: false, Message: 'Internal Server Error', error: error.message });
  }
}

//@route      POST /api/v1/users/emailunique
//@desc       Check the email is Unique
//@access     Public
async function checkEmailUnique(req, res) {
  try {
    const { email } = req.body;
    const checkEmailUnique = !(await User.findOne({ where: { email }, attributes: { exclude: ['password'] }, attributes: ['email'], }));

    res.json({ issuccess: checkEmailUnique });
  } catch (error) {
    console.error(error);
    res.status(500).json({ issuccess: false, Message: 'Internal Server Error', error: error.message });
  }
}

//@route      GET /api/v1/users/get/count
//@desc       Get Single Users
//@access     Private
async function getUserCount(req, res) {
  try {
    const userCount = await User.count(); // Use count method for Sequelize
    res.send({
      userCount: userCount,
    });
  } catch (error) {
    console.error('Error getting user count:', error);
    res.status(500).json({ message: 'Internal Server Error', error: error.message });
  }
}

//@route      GET /api/v1/users
//@desc       Get all Users
//@access     Private
async function getUsers(req, res) {
  try {
    const users = await User.findAll({
      attributes: { exclude: ['password'] },
    });
    res.status(200).json({ count: users.length, success: true, users });
  } catch (error) {
    console.error('Error getting users:', error);
    res.status(500).json({ message: 'Internal Server Error', error: error.message });
  }
}

//@route      GET /api/v1/users/:id
//@desc       Get Single Users
//@access     Private
async function getUser(req, res) {
  try {
    const user = await User.findByPk(req.params.id, {
      attributes: { exclude: ['password'] },
    });
    if (!user) return res.status(404).json({ message: 'User not found' });
    res.status(200).json(user);
  } catch (error) {
    console.error('Error getting user by ID:', error);
    res.status(500).json({ message: 'Internal Server Error', error: error.message });
  }
}

//@route      POST /api/v1/user/GetUserDetailsbyID
//@desc       To GetUserDetailsbyID
//@access     Private
export const GetUserDetailsbyID = async (req, res) => {
  try {
  const { body } = req;
  console.log(req);
  const { userid } = body;
  const UserResults = await executeStoredProcedureExperimental('SP_GetUserDetailsbyID', [userid, '', '']);
  if (UserResults && UserResults.status === true) {
      const UserData = JSON.parse(UserResults.data);
      res.status(200).json({ issuccess: true, message: UserResults.message, UserData });
  }
  else {
      res.status(400).json({ issuccess: false, message: UserResults.message });
  }

} catch (error) {
  console.log(error);
  res.status(500).json({ error: 'Internal Server Error', message: error.message });
}
}


// async function forgetPassword (req,res,next){
//   try{
//       //Fetch mobileno
//       const mobileno = req.body.mobileno;
//       //Validation Check
//       if(!mobileno){
//           return res.status(400).json({
//               success : false,
//               message : 'Enter the mobileno Carefully'
//           })
//       }
//       //Looking For User
//       const user = await User.findOne({ mobileno: mobileno });

//       //if User Does't exist with this mobileno
//       if(!user){
//           return res.status(400).json({
//               success : false,
//               message : `This Mobile No: ${mobileno} is not Registered With Us Enter a Valid Mobile No `
//           })
//       }
//       // const refreshToken = jwt.sign({ userId: user.id, Email: user.email }, process.env.REFRESH_TOKEN_SECRET, {
//       //   expiresIn: '1d',
//       // });
//       // //Adding Token in User Details
//       // const updatedDetails = await User.findOneAndUpdate(
//       //     { mobileno: mobileno },
//       //     {
//       //       refresh_token: refreshToken,
//       //   lastlogin: formattedDate,
//       //   logout: formattedDate,
//       //   loginAttempts: 0,
//       //   loginBlockedUntil: null,
//       //     },
//       //     { new: true }
//       // );
//       // console.log(updatedDetails);
//       // const smsResponse = await sendOTP;
//       //   //Return succesful Response with the Token for Reseting Password
//       // return smsResponse;
//   }   
//   catch(err){
//       console.log(err);
//       return res.status(500).json({
//           success : false,
//           message : 'Something went wrong while User Forget Password'
//       })
//   }
// }

async function resetPassword(req, res, next) {
  try {
    //Fetching Details for Reset Password
    const { mobileno, newPassword, confirmNewPassword } = req.body;


    //Validation Check
    if (!newPassword || !confirmNewPassword) {
      return res.status(400).json({
        success: false,
        message: 'Enter the Details Carefully'
      })
    }

    //Checking Both Password are Same or Not
    if (newPassword !== confirmNewPassword) {
      return res.status(400).json({
        success: false,
        message: "Password and Confirm Password Does not Match",
      })
    }
    // Find the user by email in the database
    const user = await User.findOne({
      where: { mobileno: mobileno },
    });
    // Check if the provided password matches the hashed password in the database
    const passwordMatch = await bcrypt.compare(newPassword, user.password);
    if (passwordMatch) {
      return res.status(401).json({
        issuccess: false,
        message: 'New password cannot be the same as your old password.'
      })
    }
    //If all Going Right then Hash the New Password
    let hashPass;
    try {
      //Hasing the Password Using Bcrypt
      hashPass = await bcrypt.hash(newPassword, 10);

    }
    catch (err) {
      console.log(err);
      return res.status(500).json({
        issuccess: false,
        message: 'Internal Server Problem while Hashing Password'
      })
    }

    // Now, you can update the password using Sequelize's update method
    const [updatedUser] = await User.update(
      { password: hashPass },
      {
        where: { mobileno: mobileno },
        returning: true, // To get the updated record
      }
    );

    res.status(200).json({
      issuccess: true,
      data: updatedUser,
      message: 'The password has been successfully reset.'
    });
  }
  catch (err) {
    console.log(err);
    return res.json({
      issuccess: false,
      message: `Some Error in Updating the Password`,
    })
  }
}

//@route      POST /api/v1/users/logout
//@desc       To logout
//@access     Public
export const Logout = async (req, res) => {
  const refreshToken = req.cookies.refreshToken;
  if (!refreshToken) {
    return res.sendStatus(204);
  }
  try {
    const user = await UserStatus.findOne({ where: { refresh_token: refreshToken } });
    if (!user) {
      return res.sendStatus(204);
    }
    // Nullify the user's refresh token
    await UserStatus.update({ refresh_token: null }, { where: { email: user.email } });
    await UserLog.update({
      logout: formattedDateTime.toString(),
    }, {
      where: {
        userid: user.userid
      }
    });
    res.clearCookie('refreshToken');
    return res.sendStatus(200);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

export const refreshToken = async (req, res) => {
  try {
    const refreshToken = req.cookies.refreshToken;
    if (!refreshToken) return res.sendStatus(401);
    // Step 1: Query UserStatus table based on refresh_token
    const userStatusRecord = await UserStatus.findOne({
      where: {
        refresh_token: refreshToken
      }
    });
    if (!userStatusRecord) return res.sendStatus(403);
    // Step 2: If UserStatus record is found, retrieve associated User
    let user;
    if (userStatusRecord) {
      user = await User.findOne({
        where: {
          username: userStatusRecord.username
        }
      });
    }
    if (!user) return res.sendStatus(403);
    jwt.verify(refreshToken, process.env.REFRESH_TOKEN_SECRET, (err, decoded) => {
      if (err) return res.sendStatus(403);
      const userId = user.userId;
      const name = user.name;
      const email = user.email;
      const accessToken = jwt.sign({ userId, name, email }, process.env.ACCESS_TOKEN_SECRET, {
        expiresIn: '1d'
      });
      res.json({ accessToken });
    });
  } catch (error) {
    console.log(error);
  }
}

export { signUpUser, signIn, resetPassword, getUser, getUsers, getUsernamebyMobile, getUserCount, checkUsernameUnique, checkMobileNoUnique, checkEmailUnique ,signUpUserwithAddress,CheckotpAuth};
