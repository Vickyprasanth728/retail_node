import Sequelize from 'sequelize';
import bcrypt from 'bcrypt';
import jwt from "jsonwebtoken";
import dotenv from 'dotenv';
import { executeStoredProcedure} from '../../middleware/storeproceduremiddleware.js';
import User from '../../models/UsersModel.js';
import UserLog from '../../models/LogModel.js';
import UserStatus from '../../models/UserStatus.js';
import { formatDateToYYYYMMDD, formatDateTimeToYYYYMMDDHHMMSS } from '../../Utils/Datetime.js';

dotenv.config();

import moment from 'moment-timezone';

const currentDate = new Date();
const isoDateString = currentDate.toISOString();
const originalMoment = moment(isoDateString);
const originalDate = originalMoment.toDate();
const formattedDate = formatDateToYYYYMMDD(originalDate);
const formattedDateTime = formatDateTimeToYYYYMMDDHHMMSS(originalDate);

import { db } from '../../config/Database.js';
const saltRounds = 10;
// $2b$10$5PWTLmD/6eYKcRE.FNfAku/AWC7YT95mjTeMSDbrhEV2Pkf9CcnE.


export const signIn = async (req, res) => {
    const { username, password } = req.body;

    console.log('username', username);
    
    try {
        if (!username || !password) {
            res.status(401).send({
              status:false,
              message: `${!username && !password ? 'Both username & password required.' : username == '' ? 'username required' : password == '' ? 'password required' : '' } `,
            });
            return;
          }

          let thisQuery = `SELECT us.* FROM users as us WHERE us.username = '${username}' AND us.status != 0 `
          const data = await db.query(thisQuery);
          console.log('Initial data', data[0]);

          const userCheck = data[0][0] ? data[0][0]?.userid : 0
          console.log('userCheck',userCheck);
          
          if (userCheck == 0) {
            res.status(401).send({
                status: false,
                message: "Invalid login credentials",
              });
              return;

          } else {

            const match = await bcrypt.compare(password, data[0][0]?.password);
            console.log('match', match);
            
            if(match) {

                try {
                    let thisQuery1 = ` INSERT INTO userlog (userid, lastlogin) VALUES ('${userCheck}','${formattedDateTime}') `
                    await db.query(thisQuery1);
                    console.log('log created successfully');

                } catch (error) {
                    console.log('log creating error', error);
                }

                const buffer = Buffer.from([0x01]);
                const BufferIsstaff = buffer.readInt8(data[0][0]?.Isstaff);
                
                console.log('BufferIsstaff', BufferIsstaff);

                const accessToken = jwt.sign({ 
                  userId: data[0][0]?.userid, 
                  Email: data[0][0]?.email, 
                  mobileno: data[0][0]?.mobileno, 
                  Isstaff: BufferIsstaff 
                }, 
                  process.env.ACCESS_TOKEN_SECRET, 
                {
                  expiresIn: process.env.ACCESS_TOKEN_EXPIRY,
                });
                const refreshToken = jwt.sign({ 
                  userId: data[0][0]?.userid, 
                  Email: data[0][0]?.email, 
                  mobileno: data[0][0]?.mobileno, 
                  Isstaff: BufferIsstaff
                }, 
                  process.env.REFRESH_TOKEN_SECRET, 
                {
                  expiresIn: process.env.REFRESH_TOKEN_EXPIRY,
                });

                let thisQuery2 = ` SELECT * FROM user_status WHERE username = '${username}' `
                const userStatus = await db.query(thisQuery2);
                const userStatusID =  userStatus[0][0] ?  userStatus[0][0]?.id : 0
                console.log('userStatusID', userStatusID);

                const loginBlockedUntil = null

                if (userStatusID != 0) {

                    let thisQuery3 = ` UPDATE user_status SET loginAttempts = '0', refresh_token = '${refreshToken}' , loginBlockedUntil = ${loginBlockedUntil} WHERE username = '${username}' `
                    await db.query(thisQuery3);

                } else {
                    let thisQuery3 = ` INSERT INTO user_status (username, loginAttempts, refresh_token, loginBlockedUntil) VALUES ('${username}', 0, '${refreshToken}', ${loginBlockedUntil}) `
                    await db.query(thisQuery3);
                }

                let thisQueryaddress = `SELECT addressid, name, locationdetails, fulladdress, Landmark, city, state, country, pincode, email, mobileno 
                FROM address WHERE userid = '${data[0][0]?.userid}' `;
                const addressData = await db.query(thisQueryaddress);

                let thisQueryroleDetails = `
                SELECT
                    u.userid as userid,
                    r.rolesid as rolesid,
                    r.name as role_name,
                    r.role as role,
                    r.status as role_status,
                    r.defaultmodule as default_module_id,
                    COALESCE(usm.schoolid, '') as schoolid
                FROM users u
                LEFT JOIN userrolemap as urm ON (u.userid = urm.userid)
                LEFT JOIN roles as r ON (urm.roleid = r.rolesid)
                LEFT JOIN usersschoolmap as usm ON (u.userid = usm.userid)
                WHERE u.userid = '${data[0][0]?.userid}' `;

            const roleData = await db.query(thisQueryroleDetails);

            console.log('roleData', roleData[0]);

                res.status(200).json({
                    issuccess: true,
                    accessToken: accessToken,
                    refreshToken: refreshToken,
                    userid: data[0][0]?.userid,
                    name: data[0][0]?.name,
                    email: data[0][0]?.email,
                    mobileno: data[0][0]?.mobileno,
                    isstaff: BufferIsstaff == 1 ? true : false,
                    address: addressData[0],
                    RoleDetails :roleData[0],
                    lastlogin: formattedDateTime,
                    loginAttempts: userStatus?.loginAttempts,
                  });
                
            } else {
                res.status(403).send({
                  status: false,
                  message: "Incorrect password",
                });
              }
          }
        
     } catch (error) {
      res.status(500).send({
        status : false,
        message: 'Internal Server Error', error: error.message
      });
    }
}

export const changePassword = async (req, res) => {
  try {

      const hash = await bcrypt.hash(req.body.password, saltRounds);
      req.body.password = hash;

      const userIdFetch = await db.query(`SELECT us.* FROM users as us WHERE us.username = '${req.body.username}' `);

      const match = await bcrypt.compare(req.body.oldpassword, userIdFetch[0][0]?.password);
      console.log("match", match);
      console.log("hash", hash);

      const user_verification = userIdFetch[0][0] ? userIdFetch[0][0]?.userid : 0
      console.log('user_verificationnnnnnnnnnnn', user_verification);

      console.log('userIdFetch[0][0]?.password', userIdFetch[0][0]?.password);
      console.log('oldpassword', req.body.oldpassword);
      console.log('password', req.body.password);

        if (!match) {
          res.status(200).send({
            status: 400,
            message: `Wrong old password.`
          });

        }
        else {
          const num = await db.query(` UPDATE users SET password = '${req.body.password}' WHERE username = '${req.body.username}' `)
          console.log('nummmm', num);
          
          if (num) {
            res.status(200).send({
              status: 200,
              message: "Updated successfully."
            });
          } else {
            res.status(200).send({
              status: 404,
              message: `Cannot update with id `
            });
          }
        }
      }
  catch (error) {
    res.status(500).send({
      message: error.message,
    });
  }
}


export const getUsernamebyMobile = async (req, res) => {
  try {
    
    const mobileno = req.params.mobileno
    
    let thisQuery = ` SELECT * FROM users WHERE mobileno = '${mobileno}' and status !=0 `
    const user = await db.query(thisQuery);
    console.log('Initial data',user[0]);

    const userMobCheck = user[0][0] ? user[0][0]?.userid : 0
    console.log('userMobCheck : ',userMobCheck);
    
    if (userMobCheck == 0) {
      res.status(404).send({
        status: false,
        message: "User not found",
      });
    } else {
      res.status(200).send({
        status: true,
        message: "success",
        data : user[0]
      });
    }

  } catch (error) {
    res.status(500).send({
      status : false,
      message: 'Internal Server Error', error: error.message
    });
  }

}

export const getUserDetailsByUserId = async (req, res) => {
  try {
    const UserID = req.params.userid; 

    let thisUserQuery = `SELECT userid FROM users WHERE userid = '${UserID}' LIMIT 1`;
    const userCheckResult = await db.query(thisUserQuery);

    if (!userCheckResult[0][0]) {
        return res.status(404).send({
          status: false,
          message: 'User not found',
        });
    }
    else {
      const thisQueryUserDetails = `
      SELECT
        u.userid,
        u.username,
        u.name,
        u.email,
        u.mobileno,
        r.rolesid AS roleid,
        r.name AS role_name,
        BIN(r.role) AS role,
        r.defaultmodule AS default_module_id,
        u.isstaff,
        u.status,
        (
          SELECT JSON_ARRAY(
            JSON_OBJECT(
              'addressid', a.addressid,
              'name', a.name,
              'fulladdress', a.fulladdress,
              'locationdetails', a.locationdetails,
              'Landmark', a.Landmark,
              'city', a.city,
              'state', a.state,
              'country', a.country,
              'pincode', a.pincode,
              'email', a.email,
              'mobileno', a.mobileno,
              'alternatemobileno', a.alternatemobileno,
              'isprimary', a.isprimary,
              'iswork', a.iswork,
              'status', a.status
            )
          )
          FROM address a
          WHERE u.userid = a.userid
        ) AS addresses,
        GROUP_CONCAT(DISTINCT m.name) AS module_names,
        GROUP_CONCAT(DISTINCT m.moduleid) AS module_ids
      FROM
        users u
      LEFT JOIN userrolemap urm ON (u.userid = urm.userid)
      LEFT JOIN roles r ON (urm.roleid = r.rolesid)
      LEFT JOIN usermodulemap umm ON (u.userid = umm.userid)
      LEFT JOIN module m ON (umm.moduleid = m.moduleid)
      WHERE
        u.userid = ${UserID}
      GROUP BY
        u.userid,
        u.username,
        u.name,
        u.email,
        u.mobileno,
        r.rolesid,
        r.name,
        u.isstaff,
        u.status
    `;

      const userDetailsResult = await db.query(thisQueryUserDetails);
      res.status(200).send({
        status: true,
        message: 'User details retrieved successfully',
        data: userDetailsResult[0],
      });
    }

  } catch (error) {
    res.status(500).send({
      status: 'ERROR',
      message: 'Internal Server Error',
      error: error.message,
    });
  }
};
