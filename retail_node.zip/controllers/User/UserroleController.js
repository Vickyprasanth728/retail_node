import { executeStoredProcedure } from '../../middleware/storeproceduremiddleware.js';
import { formatDateToYYYYMMDD, formatDateTimeToYYYYMMDDHHMMSS } from '../../Utils/Datetime.js';
import moment from 'moment-timezone';
const currentDate = new Date();
const isoDateString = currentDate.toISOString();

const originalMoment = moment(isoDateString);
const originalDate = originalMoment.toDate();

const formattedDate = formatDateToYYYYMMDD(originalDate);

const formattedDateTime = formatDateTimeToYYYYMMDDHHMMSS(originalDate);

export const CreateRole = async (req, res) => {
    try {
        const { rolename,role,defaultmodule} = req.body; 
        const RoleResults = await executeStoredProcedure('SP_CreateRole', [rolename,role,defaultmodule, '', '']);

        if (RoleResults && RoleResults.status === true) {
            res.status(200).json({ issuccess: true, message: RoleResults.message });
        } else {
            res.status(400).json({ issuccess: false, message: RoleResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

export const deleteRole = async (req, res) => {
    try {
        const { roleid } = req.body; 
        const RoleResults = await executeStoredProcedure('SP_DeleteRole', [roleid,'', '']);

        if (RoleResults && RoleResults.status === true) {
            res.status(200).json({ issuccess: true, message: RoleResults.message });
        } else {
            res.status(400).json({ issuccess: false, message: RoleResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

export const UpdateRole = async (req, res) => {
    try {
        const { roleid ,rolename,role,defaultmodule,lastmodifiedby} = req.body; 
        const RoleResults = await executeStoredProcedure('SP_UpdateRole', [roleid ,rolename,role,defaultmodule,lastmodifiedby, '', '']);

        if (RoleResults && RoleResults.status === true) {
            res.status(200).json({ issuccess: true, message: RoleResults.message });
        } else {
            res.status(400).json({ issuccess: false, message: RoleResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

export const getroledetail = async (req, res) => {
    try {
        const RoleResults = await executeStoredProcedure('SP_GetRoleDetails', ['', '']);
        if (RoleResults && RoleResults.status === true) {
            const RoleData = JSON.parse(RoleResults.data);
            res.status(200).json({ issuccess: true, message: RoleResults.message ,RoleData});
        } else {
            res.status(400).json({ issuccess: false, message: RoleResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

// export const getmoduledetail = async (req, res) => {
//     try {
//         const RoleResults = await executeStoredProcedure('SP_GetModuleDetails', ['', '']);
//         if (RoleResults && RoleResults.status === true) {
//             const moduleData = JSON.parse(RoleResults.data);
//             res.status(200).json({ issuccess: true, message: RoleResults.message ,moduleData});
//         } else {
//             res.status(400).json({ issuccess: false, message: RoleResults.message });
//         }
//     } catch (error) {
//         console.log(error);
//         res.status(500).json({ error: 'Internal Server Error', message: error.message });
//     }
// };

export const GetRoleDetailsByID = async (req, res) => {
    try {
        const {roleid} = req.body; 
        const RoleResults = await executeStoredProcedure('SP_GetRoleDetailsByID', [roleid, '', '']);
        const RoleData = JSON.parse(RoleResults.data);
        if (RoleResults && RoleResults.status === true) {
            res.status(200).json({ issuccess: true, message: RoleResults.message,RoleData });
        } else {
            res.status(400).json({ issuccess: false, message: RoleResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};


// export const RemoveRoleFromUser = async (req, res) => {
//     try {
//         const {userid, roleid} = req.body; 
//         const RoleResults = await executeStoredProcedure('SP_RemoveRoleFromUser', [userid, roleid, '', '']);
//         if (RoleResults && RoleResults.status === true) {
//             res.status(200).json({ issuccess: true, message: RoleResults.message });
//         } else {
//             res.status(400).json({ issuccess: false, message: RoleResults.message });
//         }
//     } catch (error) {
//         console.log(error);
//         res.status(500).json({ error: 'Internal Server Error', message: error.message });
//     }
// };

// export const UpdateUserRole = async (req, res) => {
//     try {
//         const {userid, oldroleid,newrolesid} = req.body; 
//         const RoleResults = await executeStoredProcedure('SP_UpdateUserRole', [userid, oldroleid, newrolesid,'', '']);

//         if (RoleResults && RoleResults.status === true) {
//             res.status(200).json({ issuccess: true, message: RoleResults.message });
//         } else {
//             res.status(400).json({ issuccess: false, message: RoleResults.message });
//         }
//     } catch (error) {
//         console.log(error);
//         res.status(500).json({ error: 'Internal Server Error', message: error.message });
//     }
// };