import { executeStoredProcedure } from '../../middleware/storeproceduremiddleware.js';
import { formatDateToYYYYMMDD, formatDateTimeToYYYYMMDDHHMMSS } from '../../Utils/Datetime.js';
import moment from 'moment-timezone';
const currentDate = new Date();
const isoDateString = currentDate.toISOString();

const originalMoment = moment(isoDateString);
const originalDate = originalMoment.toDate();

const formattedDate = formatDateToYYYYMMDD(originalDate);

const formattedDateTime = formatDateTimeToYYYYMMDDHHMMSS(originalDate);

import { db } from '../../config/Database.js';

export const InsertAddress = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
    await db.query('START TRANSACTION');

    try {
        const { userid, name, fullAddress, locationDetails, landmark, city, state, country, pincode, email, mobileno, alternatemobileno, isprimary, iswork, status, createdby, createdon, lastmodifiedby, lastmodifiedate} = req.body || 0;

        if (!userid || !name || !fullAddress  || !city || !state || !country || !pincode || !email || !mobileno) {
            res.status(400).send({
                status: false,
                message: `${
                    !userid ? 'User ID is required.' : 
                    !name ? 'Name is required.' :
                    !fullAddress ? 'Full address is required.' :
                    !city ? 'City is required.' :
                    !state ? 'State is required.' :
                    !country ? 'Country is required.' :
                    !pincode ? 'Pincode is required.' :
                    !email ? 'Email is required.' :
                    !mobileno ? 'Mobile no is required.' :
                    ''}`,
            });
            console.log('Address not inserted');

        } else {

        let insertQuery = `
        INSERT INTO address (
            userid, name, fullAddress, locationDetails, landmark, city, state, country, pincode, email, mobileno, alternatemobileno, isprimary, iswork, status, createdby, createdon, lastmodifiedby, lastmodifiedate
        )
        VALUES (
            '${userid}', '${name}', '${fullAddress}', '${locationDetails}', '${landmark}', '${city}', '${state}', '${country}',
            '${pincode}', '${email}', '${mobileno}', '${alternatemobileno}', '${isprimary}', '${iswork}', '${status}',
            '${userid == 0 ? 0 : userid}', '${formattedDateTime}', '${userid == 0 ? 0 : userid}', '${formattedDateTime}' 
        ) `

        const result = await db.query(insertQuery);

        if (result[0]) {
            res.status(200).send({
                status: true,
                message: 'Address inserted successfully',
            });
            console.log('Address inserted successfully');
        } else {
            res.status(400).send({
                status: false,
                message: 'Address not inserted',
            });
            console.log('Address not inserted');
        }

        await db.query('COMMIT');
    }
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({
            status: false,
            message: 'Internal Server Error',
            error: error.message,
        });

        await db.query('ROLLBACK');
    }
};




//@route      POST /api/v1/user/address/InsertAddress
//@desc       To InsertAddress
//@access     Public
export const InsertAddress1 = async (req, res) => {
    try {
        const { userid, name, Address1, Address2, Address3, Address4, Address5, Address6, Address7, Address8, Landmark, city, state, country, pincode, email, mobileno, alternatemobileno, isprimary, iswork, status, createdby, createdon } = req.body;
        const AddressResults = await executeStoredProcedure('SP_InsertAddress', [userid, name, Address1, Address2, Address3, Address4, Address5, Address6, Address7, Address8, Landmark, city, state, country, pincode, email, mobileno, alternatemobileno, isprimary, iswork, status, createdby, createdon, '', '']);
        if (AddressResults && AddressResults.status === true) {
            res.status(200).json({ issuccess: true, message: AddressResults.message });
        }
        else {
            res.status(400).json({ issuccess: false, message: AddressResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

//@route      POST /api/v1/user/address/updateAddress
//@desc       To update Address
//@access     Public
export const updateAddress = async (req, res) => {
    try {
        const { addressid, userid, name, Address1, Address2, Address3, Address4, Address5, Address6, Address7, Address8, Landmark, city, state, country, pincode, email, mobileno, alternatemobileno, isprimary, iswork, status, updatedby, updatedon } = req.body;
        const AddressResults = await executeStoredProcedure('SP_UpdateAddress', [addressid, userid, name, Address1, Address2, Address3, Address4, Address5, Address6, Address7, Address8, Landmark, city, state, country, pincode, email, mobileno, alternatemobileno, isprimary, iswork, status, updatedby, updatedon, '', '']);
        if (AddressResults && AddressResults.status === true) {
            res.status(200).json({ issuccess: true, message: AddressResults.message });
        }
        else {
            res.status(400).json({ issuccess: false, message: AddressResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

//@route      POST /api/v1/user/address/deleteAddress
//@desc       To delete Address
//@access     Public
export const deleteAddress = async (req, res) => {
    try {
        const { addressid, userid } = req.params; // Retrieve values from request parameters
        const AddressResults = await executeStoredProcedure('SP_DeleteAddress', [addressid, userid, '', '']);

        if (AddressResults && AddressResults.status === true) {
            res.status(200).json({ issuccess: true, message: AddressResults.message });
        } else {
            res.status(400).json({ issuccess: false, message: AddressResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

//@route      POST /api/v1/user/address/getaddressdetailByuserid
//@desc       To get address detail By userid
//@access     Public
export const getaddressdetailByuserid = async (req, res) => {
    try {
        const { userid } = req.body;
        const AddressResults = await executeStoredProcedure('SP_getaddressdetail', [userid, '', '']);
        if (AddressResults && AddressResults.status === true) {
            const AddressData = JSON.parse(AddressResults.data);
            res.status(200).json({ issuccess: true, message: AddressResults.message, AddressData });
        }
        else {
            res.status(400).json({ issuccess: false, message: AddressResults.message });
        }

    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

//@route      POST /api/v1/user/address/getaddress_withPGN
//@desc       To get address with PGN
//@access     Public
export const getaddress_withPGN = async (req, res) => {
    try {
        const { userid, pageno, limit } = req.body;
        const AddressResults = await executeStoredProcedure('SP_getaddress_withPGN', [userid, pageno, limit, '', '']);
        if (AddressResults && AddressResults.status === true) {
            const AddressData = JSON.parse(AddressResults.data);
            res.status(200).json({ issuccess: true, message: AddressResults.message, AddressData, totalcount: AddressResults.totalcount });
        }
        else {
            res.status(400).json({ issuccess: false, message: AddressResults.message });
        }

    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

//@route      POST /api/v1/user/address/getAddressById
//@desc       To get Address By Id
//@access     Public
export const getAddressById = async (req, res) => {
    try {
        const { addressid } = req.body;
        const AddressResults = await executeStoredProcedure('SP_getAddressById', [addressid, '', '']);
        if (AddressResults && AddressResults.status === true) {
            const AddressData = JSON.parse(AddressResults.data);
            res.status(200).json({ issuccess: true, message: AddressResults.message, AddressData });
        }
        else {
            res.status(400).json({ issuccess: false, message: AddressResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

//@route      POST /api/v1/user/address/getaddressdetailByDefault
//@desc       To get address detail By Default
//@access     Public
export const getaddressdetailByDefault = async (req, res) => {
    try {
        const { userid } = req.body;
        const AddressResults = await executeStoredProcedure('SP_getdefaultdetail', [userid, '', '']);
        if (AddressResults && AddressResults.status === true) {
            const AddressData = JSON.parse(AddressResults.data);
            res.status(200).json({ issuccess: true, message: AddressResults.message, AddressData });
        }
        else {
            res.status(400).json({ issuccess: false, message: AddressResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};