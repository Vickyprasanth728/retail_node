import Sequelize from 'sequelize';
import bcrypt from 'bcrypt';
import jwt from "jsonwebtoken";
import dotenv from 'dotenv';
import { executeStoredProcedure } from '../../middleware/storeproceduremiddleware.js';
import { formatDateToYYYYMMDD, formatDateTimeToYYYYMMDDHHMMSS } from '../../Utils/Datetime.js';
dotenv.config();

import moment from 'moment-timezone';

const currentDate = new Date();
const isoDateString = currentDate.toISOString();
const originalMoment = moment(isoDateString);
const originalDate = originalMoment.toDate();
const formattedDate = formatDateToYYYYMMDD(originalDate);
const formattedDateTime = formatDateTimeToYYYYMMDDHHMMSS(originalDate);


//@route      POST /api/v1/staff/createstaff
//@desc       To createstaff
//@access     Private
export const createstaff = async (req, res) => {
  try {
  const { body } = req;
  const { username, password, name, email, mobileno,roleid,address1,address2,address3,address4,address5,address6,address7,address8,landmark,city,state,country,pincode,alterphno,isprimary,iswork,addressstatus,schoolcode,createdby,createdon} = body;
  const schoolcodesJson = [];
  try {
    if (schoolcode && Array.isArray(schoolcode) && schoolcode.length > 0) {
      console.info(schoolcode);
      for (const code of schoolcode) {
        const jsonString = JSON.stringify(code);
        schoolcodesJson.push(jsonString);
      }
      console.info(schoolcodesJson);
    }
  } catch (error) {
    // Handle any errors during conversion, such as invalid data types or circular references
    console.error("Error converting schoolcode to JSON:", error);
  }  
  const salt = await bcrypt.genSalt(10);
    const temppassword = await bcrypt.hash(password, salt);
    const parameters = [username, temppassword, name,email, mobileno,roleid,address1,address2,address3,address4,address5,address6,address7,address8,landmark,city,state,country,pincode,alterphno,isprimary,iswork,addressstatus,createdby,createdon,schoolcodesJson, '', ''];
    console.log(JSON.stringify(parameters));
    const userResults = await executeStoredProcedure('SP_AddStaff', parameters);
    console.log(JSON.stringify(userResults));
    if (userResults && userResults.status === true) {
      res.status(200).json({ issuccess: true, message: userResults.message });
    }
    else {
      res.status(401).json({ issuccess: false, message: userResults.message });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ issuccess: false, error: 'Internal Server Error', message: error.message });
  }
}

//@route      POST /api/v1/staff/updatestaff
//@desc       To updatestaff
//@access     Private
export const updatestaff = async (req, res) => {
  try {
  const { body } = req;
  const { userid,addressid,username, name, email, mobileno, oldroleid,newroleid,address1,address2,address3,address4,address5,address6,address7,address8,landmark,city,state,country,pincode,alterphno,isprimary,iswork,addressstatus,schoolcode,updatedby,updatedon} = body;
  const schoolcodesJson = [];
  try {
    if (schoolcode && Array.isArray(schoolcode) && schoolcode.length > 0) {
      console.info(schoolcode);
      for (const code of schoolcode) {
        const jsonString = JSON.stringify(code);
        schoolcodesJson.push(jsonString);
      }
      console.info(schoolcodesJson);
    }
  } catch (error) {
    // Handle any errors during conversion, such as invalid data types or circular references
    console.error("Error converting schoolcode to JSON:", error);
  }    
  //const salt = await bcrypt.genSalt(10);
  // const temppassword = await bcrypt.hash(password, salt);
    const parameters = [userid,addressid,username, name,email, mobileno,oldroleid,newroleid, address1,address2,address3,address4,address5,address6,address7,address8,landmark,city,state,country,pincode,alterphno,isprimary,iswork,addressstatus,updatedby,updatedon,schoolcodesJson, '', ''];
    console.log(JSON.stringify(parameters));
    const userResults = await executeStoredProcedure('SP_UpdateStaff', parameters);
    console.log(JSON.stringify(userResults));
    if (userResults && userResults.status === true) {
      res.status(200).json({ issuccess: true, message: userResults.message });
    }
    else {
      res.status(401).json({ issuccess: false, message: userResults.message });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ issuccess: false, error: 'Internal Server Error', message: error.message });
  }
}

//@route      POST /api/v1/staff/deletestaff
//@desc       To deletestaff
//@access     Private
export const deletestaff = async (req, res) => {
  try {
  const { body } = req;
  const { userid } = body;
  const parameters = [userid,'',''];
    const userResults = await executeStoredProcedure('SP_DeleteStaff', parameters);
    if (userResults && userResults.status === true) {
      res.status(200).json({ issuccess: true, message: userResults.message });
    }
    else {
      res.status(401).json({ issuccess: false, message: userResults.message });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ issuccess: false, error: 'Internal Server Error', message: error.message });
  }
}
