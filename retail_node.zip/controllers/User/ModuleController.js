import { executeStoredProcedure } from '../../middleware/storeproceduremiddleware.js';
import { formatDateToYYYYMMDD, formatDateTimeToYYYYMMDDHHMMSS } from '../../Utils/Datetime.js';
import moment from 'moment-timezone';
const currentDate = new Date();
const isoDateString = currentDate.toISOString();
const originalMoment = moment(isoDateString);
const originalDate = originalMoment.toDate();
const formattedDate = formatDateToYYYYMMDD(originalDate);
const formattedDateTime = formatDateTimeToYYYYMMDDHHMMSS(originalDate);

//@route      POST /api/v1/cart/CreateModule
//@desc       To get address detail By Default
//@access     Public
export const CreateModule = async (req, res) => {
    try {
        const { Modulename} = req.body; 
        const ModuleResults = await executeStoredProcedure('SP_InsertModule', [Modulename,'', '']);
        if (ModuleResults && ModuleResults.status === true) {
            res.status(200).json({ issuccess: true, message: ModuleResults.message });
        } else {
            res.status(400).json({ issuccess: false, message: ModuleResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

export const deleteModule = async (req, res) => {
    try {
        const { Moduleid } = req.body; 
        const ModuleResults = await executeStoredProcedure('SP_DeleteModule', [Moduleid,'', '']);
        if (ModuleResults && ModuleResults.status === true) {
            res.status(200).json({ issuccess: true, message: ModuleResults.message });
        } else {
            res.status(400).json({ issuccess: false, message: ModuleResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

export const UpdateModule = async (req, res) => {
    try {
        const { Moduleid ,Modulename,lastmodifiedby} = req.body; 
        const ModuleResults = await executeStoredProcedure('SP_UpdateModule', [Moduleid ,Modulename,lastmodifiedby, '', '']);
        if (ModuleResults && ModuleResults.status === true) {
            res.status(200).json({ issuccess: true, message: ModuleResults.message });
        } else {
            res.status(400).json({ issuccess: false, message: ModuleResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

export const getModuledetailbyID = async (req, res) => {
    try {
        const { Moduleid } = req.body;
        const ModuleResults = await executeStoredProcedure('SP_GetModuleByID', [Moduleid,'', '']);
        if (ModuleResults && ModuleResults.status === true) {
            const ModuleData = JSON.parse(ModuleResults.data);
            res.status(200).json({ issuccess: true, message: ModuleResults.message ,ModuleData});
        } else {
            res.status(400).json({ issuccess: false, message: ModuleResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

export const getmoduledetail = async (req, res) => {
    try {
        const ModuleResults = await executeStoredProcedure('SP_GetModuleDetails', ['', '']);
        if (ModuleResults && ModuleResults.status === true) {
            const moduleData = JSON.parse(ModuleResults.data);
            res.status(200).json({ issuccess: true, message: ModuleResults.message ,moduleData});
        } else {
            res.status(400).json({ issuccess: false, message: ModuleResults.message });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};
