import { db } from '../../config/Database.js';
import Stripe from 'stripe';
const stripe = Stripe('sk_test_4eC39HqLyjWDarjtT1zdp7dc');
import axios from 'axios'
import crypto from 'crypto';


export const createPaymentStripe = async (req, res) => {
    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

    const {amount,currency,payment_method,confirm} = req.body
    console.log('req.body', req.body);
    
    try {
        const paymentIntent = await stripe.paymentIntents.create({
            amount: amount,
            currency: currency,
            payment_method: payment_method,
            confirm: confirm,
        });
        res.status(200).send({
          status: true,
          message: 'success',
          clientSecret: paymentIntent.client_secret
        });
      } 
      catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });
    }
};

// const generateChecksum = (data) => {
//   return crypto.createHash('sha256').update(data + workingKey).digest('hex');
// };

// access_code: ATXU82GA85BC88UXCB  
// Working key: A8E538339FBC4700F0FC1F9FF0498FF4  
// merchant_id: 204980

// const workingKey = 'A8E538339FBC4700FOFC1F9FF0498FF4';
// const accessCode = 'AVXU82GA85BC88UXCB';
// const merchantId = 204980; 

const workingKey = 'A8E538339FBC4700F0FC1F9FF0498FF4';
const accessCode = 'ATXU82GA85BC88UXCB';
const merchantId = 204980; 

const generateChecksum = (params) => {
  const { order_id, reference_no, amount, status } = params;
  const dataString = [
    order_id,
    reference_no,
    amount,
    status,
    workingKey,
  ].join('|');

  return crypto.createHash('sha256').update(dataString).digest('hex'); 
};

export const createPaymentCCA = async (req, res) => {
  try {
    const { orderId, amount, billingName, billingEmail } = req.body;

    if (!orderId || !amount || !billingName || !billingEmail) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // const ccavenueUrl = 'https://www.ccavenue.com/transaction/transaction.do?command=initiateTransaction';
    const ccavenueUrl = 'https://secure.ccavenue.com/transaction/transaction.do?command=initiateTransaction';
    const ccavenueUrl_test = 'https://test.ccavenue.com/transaction/transaction.do?command=initiateTransaction';

    // const paymentData = {
    //   merchant_id: merchantId,
    //   access_code: accessCode,
    //   order_id: orderId,
    //   amount: amount,
    //   billing_name: billingName,
    //   billing_email: billingEmail,
    //   redirect_url: 'https://retails.2cqr.in/test',
    // };
    const paymentData = {
      merchant_id: "204980",
      order_id: "1234",
      currency: "INR",
      amount: "500.00",
      redirect_url: "www.2cqr.in/test",
      cancel_url: "www.2cqr.in/test",
      language: "EN"
  };

    const checksum = generateChecksum(paymentData.order_id + paymentData.amount);
    paymentData.checksum = checksum;

    console.log('Generated Payment Data:', paymentData);

    axios.post(ccavenueUrl_test, paymentData)
    .then((response) => {
      // res.json({ redirectUrl: response.data });
      res.status(200).send({
        status : true,
        message : 'Payment successfully',
        redirectUrl: response.data
      });
    })
    .catch((error) => {
      res.status(500).send({
        status : false,
        message : 'Payment initiation failed', error
      });
    });

  } catch (error) {
    console.error('Internal Error:', error);
    res.status(500).json({ error: 'Internal Server Error', message: error.message });
  }
};

export const CCAList = async (req, res) => {

  try {
    const { status, checksum, order_id, reference_no, amount } = req.body;

    console.log('req.body', req.body);
    
    
    const generatedChecksum = generateChecksum(req.body);  
    console.log('generatedChecksum', generatedChecksum, checksum);
    if (generatedChecksum !== checksum) {
      // return res.status(400).send('Checksum validation failed');
      res.status(400).send({
        status: false,
        message: 'Checksum validation failed',
      });  
    } else {

    if (status == 'Success') {
      console.log(`Payment Successful for Order ID: ${order_id}, Amount: ${amount}`);
      res.status(200).send({
        status: true,
        message: 'Payment Successful',
        data: `Payment Successful for Order ID: ${order_id}, Amount: ${amount}`
      });  
    } else {
      console.log(`Payment Failed for Order ID: ${order_id}, Amount: ${amount}`);
      res.status(400).send({
        status: true,
        message: 'Payment Failed',
        data: `Payment Failed for Order ID: ${order_id}, Amount: ${amount}`
      });     
    }
  }

  } catch (error) {
    console.error('Error processing payment response:', error);
    res.status(500).send({
      status: false,
      error: error,
    });  
  }

}

















export const createPaymentCCA1 = async (req, res) => {
  await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

  const {amount,redirectUrl,cancelUrl, merchant_id, access_code, working_key} = req.body
  console.log('req.body', req.body);

  const urlLink = req.body.urlLink || 'https://www.ccavenue.com/apis/servlet/DoWebTransaction'
  
  try {
      if (!amount || !merchant_id || !access_code || !working_key) {
        return res.status(400).json({ error: 'Missing required fields' });
      }

      const paymentData = {
        amount: amount,
        redirectUrl: redirectUrl || 'http://yourwebsite.com/response',
        cancelUrl: cancelUrl || 'http://yourwebsite.com/cancel',
      };

      const ccaData = {
        amount: paymentData.amount,
        redirect_url: paymentData.redirectUrl,
        cancel_url: paymentData.cancelUrl,
        merchant_id: merchant_id,
        access_code: access_code,
        working_key: working_key,
      };
      
      axios.post(urlLink, ccaData)
      .then((response) => {
          console.log('response', response);
          res.send(response.data);
      })
      .catch((error) => {
          console.error('error', error);
          res.status(500).send({
            status: false,
            message :'Error processing payment',
            error: error,
          });
      });
    } 
    catch (error) {
      console.log(error);
      res.status(500).json({ error: 'Internal Server Error', message: error.message });
  }
};