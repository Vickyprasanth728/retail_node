// import { DataTypes } from 'sequelize';
// import { db } from '../config/Database.js';

// const Product = db.define('product', {
//     productid: {
//         type: DataTypes.BIGINT,
//         primaryKey: true,
//         autoIncrement: true,
//     },
//     masterid: {
//         type: DataTypes.BIGINT,
//         defaultValue: true,
//     },
//     name: {
//         type: DataTypes.STRING,
//         defaultValue: true,
//     },
//     price: {
//         type: DataTypes.FLOAT,
//         defaultValue: true,
//     },
//     gst: {
//         type: DataTypes.BIGINT,
//         defaultValue: true,
//     },
//     gender: {
//         type: DataTypes.BIGINT,
//         defaultValue: true,
//     },
//     weight: {
//         type: DataTypes.FLOAT,
//         defaultValue: true,
//     },
//     description: {
//         type: DataTypes.TEXT,
//         defaultValue: true,
//     },
//     published: {
//         type: DataTypes.INTEGER,
//         defaultValue: 0,
//     },
//     quantity: {
//         type: DataTypes.INTEGER,
//         defaultValue: true,
//     },
//     productstatus: {
//         type: DataTypes.INTEGER,
//         defaultValue: 1,
//     },
//     createdby: {
//         type: DataTypes.BIGINT,
//         defaultValue: true,
//     },
//     createdAt: {
//         type: DataTypes.DATE,
//         defaultValue: DataTypes.NOW,
//         field: 'createdon'
//     },
//     lastmodifiedby: {
//         type: DataTypes.BIGINT,
//         defaultValue: true,
//     },
//     updatedAt: {
//         type: DataTypes.DATE,
//         defaultValue: DataTypes.NOW,
//         field: 'lastmodifiedon'
//     },
// });

// export default Product;
