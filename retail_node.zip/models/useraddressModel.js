import { DataTypes } from 'sequelize';
import db from '../../config/Database.js';
import userModel from ('..models/UsersModel.js')

const UserAddress = db.define(
    'user_address', {
        user_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            references: {
                model: userModel,
                key: 'id',
            },
        },
        house_no: {
            type: DataTypes.TEXT,
            allowNull: false,
        },
        colony: {
            type: DataTypes.TEXT,
            allowNull: true,
        },
        pin_code: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        landmark: {
            type: DataTypes.TEXT,
            allowNull: true,
        },
        state: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        city: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        phone: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        alternatePhone: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        is_work: {
            type: DataTypes.INTEGER,
            allowNull: false,
            comment: '1-Home, 2-Work',
        },
    }, {
        timestamps: true,
        tableName: 'user_address',
    }
)
export default UserAddress;