import { DataTypes } from 'sequelize';
import { db } from '../config/Database.js';
import UserStatus from './UserStatus.js';

const User = db.define('user', {
  userid: {
    type: DataTypes.BIGINT,
    primaryKey: true,
    autoIncrement: true,
  },
  username: {
    type: DataTypes.STRING(100),
    allowNull: false,
    unique: true,
  },
  password: {
    type: DataTypes.STRING(60),
    allowNull: false,
  },
  name: {
    type: DataTypes.STRING(100),
  },
  email: {
    type: DataTypes.STRING(50),
  },
  mobileno: {
    type: DataTypes.STRING(10),
    allowNull: false,
    validate: {
      isNumeric: true,
      customValidator(value) {
        if (value.length < 10 || value.length > 11) {
          throw new Error(
            'Mobile number cannot be less than 10 characters or greater than 11 characters'
          );
        }
      },
    },
  },
  role: {
    type: DataTypes.STRING(10),
  },
  isstaff: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
  },
  status: {
    type: DataTypes.BOOLEAN,
    defaultValue: true,
  },
  createdAt: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  },
  updatedAt: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  },
  createdby: {
    type: DataTypes.BIGINT,
  },
  updatedby: {
    type: DataTypes.BIGINT,
  },
});

User.belongsTo(User, { foreignKey: 'createdby', as: 'creator' });
User.belongsTo(User, { foreignKey: 'updatedby', as: 'updater' });
User.belongsTo(UserStatus, { foreignKey: 'username', sourceKey: 'username' });

export default User;
