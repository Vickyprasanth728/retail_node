import { DataTypes } from 'sequelize';
import db from '../config/Database.js';
import User from './UsersModel.js';

const UserLog = db.define(
  'userlog',
  {
    userid: {
      type: DataTypes.BIGINT,
      allowNull: true,
      references: {
        model: User,
        key: 'userid',
      },
    },
    logintime: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    logouttime: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  },
  {
    timestamps: false, // Disable timestamps for createdAt and updatedAt
    tableName: 'userlog',
  }
);

export default UserLog;
