// otpModel.js
import { DataTypes } from 'sequelize';
import {db} from '../config/Database.js';

const MastersData = db.define('mastersdata', {
    dataid: {
        type: DataTypes.BIGINT,
        primaryKey: true,
        autoIncrement: true,
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    masterid: {
        type: DataTypes.BIGINT,
        allowNull: false,
    },
    status: {
        type: DataTypes.INTEGER,
        defaultValue: 1,
    },
    createdon: {
        type: DataTypes.DATE,
        allowNull: false,
    },
    createdby: {
        type: DataTypes.BIGINT,
        allowNull: false,
    },
    lastmodifiedby: {
        type: DataTypes.BIGINT,
        allowNull: true,
        defaultValue: null,
    },

    lastmodifieddate: {
        type: DataTypes.DATE,
        allowNull: true,
        defaultValue: null,
    },

},
    {
        freezeTableName: true,
        timestamps: false,
    });


export default MastersData;
