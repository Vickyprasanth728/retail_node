import { DataTypes } from 'sequelize';
import { db } from '../config/Database.js';

const Product = db.define('variant', {
    id: {
        type: DataTypes.BIGINT,
        primaryKey: true,
        autoIncrement: true,
    },
    productid: {
        type: DataTypes.BIGINT,
        allowNull: true
    },
    size: {
        type: DataTypes.STRING,
        allowNull: true
    },
    color: {
        type: DataTypes.STRING,
        allowNull: true
    },
    price: {
        type: DataTypes.FLOAT,
        allowNull: true
    },
    quantity: {
        type: DataTypes.STRING,
        allowNull: true
    },
    imageid: {
        type: DataTypes.BIGINT,
        allowNull: true
    },
    weight: {
        type: DataTypes.FLOAT,
        allowNull: true
    },
    status: {
        type: DataTypes.INTEGER,
        defaultValue: 1,
    },
    createdby: {
        type: DataTypes.BIGINT,
        defaultValue: true,
    },
    createdAt: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
        field: 'createdon'
    },
    lastmodifiedby: {
        type: DataTypes.BIGINT,
        defaultValue: true,
    },
    updatedAt: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
        field: 'lastmodifiedon'
    },
});

export default Product;
