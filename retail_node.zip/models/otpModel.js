// otpModel.js
import { DataTypes } from 'sequelize';
import { db } from '../config/Database.js';

const OTP = db.define('otptable', {
  id: {
    type: DataTypes.BIGINT,
    primaryKey: true,
    autoIncrement: true,
  },
  mobileno: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  // email: {
  //   type: DataTypes.STRING,
  //   allowNull: false,
  // },
  otpcode: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  validity: {
    type: DataTypes.DATE,
    allowNull: false,
  },
  status: {
    type: DataTypes.BOOLEAN,
    defaultValue: 0,
  },
  transtime: {
    type: DataTypes.STRING,
    allowNull: true,
  },
},
  {
    freezeTableName: true,
    timestamps: false, // Disable timestamps for createdAt and updatedAt
  });


export default OTP;
