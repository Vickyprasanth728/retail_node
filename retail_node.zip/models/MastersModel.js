// otpModel.js
import { DataTypes } from 'sequelize';
import { db, connectDB } from '../config/Database.js';

const Category = db.define('masters', {
    masterid: {
        type: DataTypes.BIGINT,
        primaryKey: true,
        autoIncrement: true,
    },
    mastername: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    category: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    addmaster: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    status: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    view: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    image: {
        type: DataTypes.BLOB('long'),
        allowNull: true,
    },
    createdon: {
        type: DataTypes.DATE,
        allowNull: false,
    },
    createdby: {
        type: DataTypes.BIGINT,
        allowNull: false,
    },
    lastmodifiedby: {
        type: DataTypes.BIGINT,
        allowNull: false,
        defaultValue: 'defaultValue',
    },

    lastmodifieddate: {
        type: DataTypes.DATE,
        allowNull: true,
        defaultValue: null,
    },


},
    {
        freezeTableName: true,
        timestamps: false,
    });


export default Category;
