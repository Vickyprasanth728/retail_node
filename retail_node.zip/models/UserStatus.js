import { DataTypes } from 'sequelize';
import { db } from '../config/Database.js';
import User from './UsersModel.js';

const UserStatus = db.define('user_status', {
  id: {
    type: DataTypes.BIGINT(19),
    autoIncrement: true,
  },
  username: {
    type: DataTypes.STRING(100),
    primaryKey: true,
    allowNull: true,
  },
  loginAttempts: {
    type: DataTypes.BIGINT(19),
    defaultValue: 0,
  },
  lockedAt: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  loginBlockedUntil: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  refresh_token: {
    type: DataTypes.STRING(500),
    allowNull: true,
    collate: 'utf8mb4_0900_ai_ci',
  },
  
},{
    tableName: 'user_status', // Specify the correct table name here
  });

export default UserStatus;
