import { DataTypes } from 'sequelize';
import { db } from '../config/Database.js';

const schoolGradeMap = db.define('schoolgrademap', {
  id: {
    type: DataTypes.BIGINT,
    primaryKey: true,
    autoIncrement: true,
  },
  grade_id: {
    type: DataTypes.BIGINT,
    defaultValue: true,
  },
  school_id: {
    type: DataTypes.BIGINT,
    defaultValue: true,
  },
  createdAt: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  },
  updatedAt: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  },
  createdby: {
    type: DataTypes.BIGINT,
  },
  updatedby: {
    type: DataTypes.BIGINT,
  },
});

export default schoolGradeMap;
