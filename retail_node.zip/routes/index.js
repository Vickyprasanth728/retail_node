// Import necessary modules
import express from "express";
import multer from 'multer';
import userRoutes from "../routes/v1/UserRoutes.js";
import TuserRoutes from "../routes/v1/TUserRoutes.js";
import categoryRoutes from "../routes/v1/CategoryRoutes.js";
import ProductRoutes from "../routes/v1/ProductsRoutes.js";
import SchoolRoutes from "../routes/v1/SchoolRoutes.js";
import CartRoutes from "../routes/v1/CartRoutes.js";
import OrderRoutes from "../routes/v1/orderRoutes.js";
import userRoleRoutes from "../routes/v1/UserRoleRouter.js";
import staffRoutes from "../routes/v1/staffRoutes.js";
import ModuleRoutes from "../routes/v1/ModuleRoutes.js";
import DashBoardRoutes from "../routes/v1/DashBoardRoutes.js";
import StateRoutes from "../routes/v1/stateRoutes.js";
import PaymentRoutes from "../routes/v1/paymentsRoutes.js";
import MasterRoutes from "../routes/v1/mastersRoutes.js";
import DashBoardRoute from "../routes/v1/dashboardRoute.js";
import ReportsRoute from "../routes/v1/ReportsRoutes.js";
const router = express.Router();

router.use("/v1/users", userRoutes);
router.use("/v1/users1", TuserRoutes);
router.use("/v1/users/role", userRoleRoutes);
router.use("/v1/users/Module", ModuleRoutes);
router.use("/v1/staff", staffRoutes);
router.use("/v1/category", categoryRoutes);
router.use("/v1/product", ProductRoutes);
router.use("/v1/school", SchoolRoutes);
router.use("/v1/cart", CartRoutes);
router.use("/v1/Order", OrderRoutes);
router.use("/v1/DB", DashBoardRoutes);
router.use("/v1/state", StateRoutes);
router.use("/v1/payment", PaymentRoutes);
router.use("/v1/masters", MasterRoutes);
router.use("/v1/reports", ReportsRoute);
router.use("/v1", DashBoardRoute);

const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

export default router;
