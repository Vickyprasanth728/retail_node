// userRoutes.js
import express from "express";
import bodyParser from 'body-parser';
import { VerifyToken, admin } from '../../middleware/authmiddleware.js';
// import { apiLogs } from "../../middleware/logmiddleware.js";

import multer from 'multer';
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 5242880
  },
  fileFilter(req, file, cb) {
    if (!file.originalname.match(/\.(jpg|jpeg|pdf|xlsx|png)$/)) {
      return cb(new Error('Please upload a Image'))
    }
    cb(undefined, true)
  }
})

import { AddProduct1, AddProductWithSubCatid, updateProduct1, updateProductwithCat, deleteProduct, getAllProducts, getProductById,getbriefproductdetails, InitProduct, GetProductwithimage, SearchProductMinidetailsSchool, SearchProductMinidetailsFilters, searchproduct, getAllProductsByPGN,getminmaxprice,searchproductother,searchproductschool, getGradeBySchoolId, getInitAddProductDetails, addProduct, getProductList, getInitViewProductDetails, deleteProducts, getViewProducts, getinitCustomerDashboard, getSingleProductDetail, addToCart, addToCartUserID, deleteAddToCart, updateProduct, updateATCQuantity, uploadFile, updateProductPublished} from "../../controllers/Products/Products12.js";

const router = express.Router();
router.use(bodyParser.json());
// router.use(apiLogs);

router.post('/addProduct1', VerifyToken, AddProduct1);
router.post('/AddProductWithSubCatid', VerifyToken, AddProductWithSubCatid);
router.post('/updateProductwithCat', VerifyToken, updateProductwithCat);
router.put('/updateProduct1', VerifyToken, updateProduct1);
router.delete('/deleteProduct1', VerifyToken, deleteProduct);

router.post('/productbyid', VerifyToken, getProductById);
router.post('/getbriefproductdetails', VerifyToken, getbriefproductdetails);
router.get('/getallproduct1', VerifyToken, getAllProducts);

router.get('/getallproduct', getProductList);
router.get('/getGradeBySchoolId/:id', getGradeBySchoolId);
router.get('/getInitAddProductDetails', getInitAddProductDetails);
// router.post('/addProduct', addProduct);
router.post('/addProduct', upload.fields([
  { name: "image", maxCount: 10 },
  { name: "variant_image", maxCount: 10 },
]), function (req, res, next) {
  addProduct(req, res, next)
});
router.put('/updateProduct/:productid', upload.fields([
  { name: "image", maxCount: 10 },
  { name: "variant_image", maxCount: 10 },

]), function (req, res, next) {
  updateProduct(req, res, next)
});

router.get('/getInitViewProductDetails', getInitViewProductDetails);
router.post('/getViewProducts', getViewProducts);
router.delete('/deleteProduct', deleteProducts);

router.get('/getinitCustomerDashboard/:id', getinitCustomerDashboard);

router.get('/getsingleproductdetail/:productid', getSingleProductDetail);
router.post('/addtocart', addToCart);
router.get('/getaddtocart/:userid', addToCartUserID);
router.delete('/deleteaddtocart/:atcartid', deleteAddToCart);
router.put('/updateQuantityATC/:atcartid', updateATCQuantity);
router.put('/updateProductPublished/:productid', updateProductPublished);

router.post('/bulk_product_upload', upload.single("uploadfile"), uploadFile);

router.post('/getallproductwithpgn', VerifyToken, getAllProductsByPGN);
router.get('/initproduct', VerifyToken, InitProduct);
router.post('/getproductwithimage', VerifyToken, GetProductwithimage);
router.post('/SearchProductminidetailsschool', VerifyToken, SearchProductMinidetailsSchool);
router.post('/SearchProductMinidetailsFilters', VerifyToken, SearchProductMinidetailsFilters);
router.post('/searchproduct', VerifyToken, searchproduct);

router.get('/getminmaxprice', VerifyToken, getminmaxprice);
router.post('/searchproductother',VerifyToken,  searchproductother);
router.post('/searchproductschool', VerifyToken,  searchproductschool);

export default router;