// userRoutes.js
import express from "express";
import bodyParser from 'body-parser';
import { VerifyToken, admin } from '../../middleware/authmiddleware.js';
import { apiLogs } from "../../middleware/logmiddleware.js";

import {CreateModule,deleteModule,UpdateModule,getmoduledetail,getModuledetailbyID} from "../../controllers/User/ModuleController.js";

const router = express.Router();
router.use(bodyParser.json());
router.use(apiLogs);

router.post('/CreateModule', VerifyToken, CreateModule);
// router.post('/deleteModule', VerifyToken, deleteModule);
router.post('/UpdateModule',VerifyToken,  UpdateModule);
router.post('/getModuledetailbyID', VerifyToken, getModuledetailbyID);
router.get('/getmoduledetail',VerifyToken,  getmoduledetail);

export default router;