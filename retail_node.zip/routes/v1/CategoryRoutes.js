// userRoutes.js
import express from "express";
import bodyParser from 'body-parser';
import { VerifyToken, admin } from '../../middleware/authmiddleware.js';
import { apiLogs } from "../../middleware/logmiddleware.js";
import { createCategory, deleteMainCategory, deleteSubCategory, deleteSubCategoryByMasterid, getAllCategory, getCategoryById, getCategoryByMasterId, getGeneralCategory, getMainCategory, getSubCategory, getSubCategoryByCategory, getSubCategoryById, updateCategory } from "../../controllers/masters/Category.js";
import { createMastersData, deleteCategoryType, deleteMastersData, deleteMastersDataByMasterid, getAllMastersData, getMastersDataById, getMastersDataByMasterId, updateMastersData } from "../../controllers/masters/MastersData.js";

const router = express.Router();

// const upload = multer({ storage });
// Use body-parser middleware to parse JSON requests
router.use(bodyParser.json());
router.use(apiLogs);
//masters 
router.get('/getcategory', VerifyToken, getAllCategory);
router.post('/createcategory', VerifyToken, createCategory);
router.get('/categorybyid/:masterid', VerifyToken, getCategoryById);
router.get('/maincategory/:category', VerifyToken, getMainCategory); //category 0
router.get('/generalcategory/:category', VerifyToken, getGeneralCategory);
router.get('/subcategory', VerifyToken, getSubCategory);
router.post('/updatecategory/:masterid', VerifyToken, updateCategory);
router.delete('/deletemaincategory/:masterid', VerifyToken, deleteMainCategory);
router.get('/subcategorybyid/:masterid', VerifyToken, getSubCategoryById);
router.delete('/deletesubcategory/:masterid', VerifyToken, deleteSubCategory);
router.delete('/deletesubcategorybymasterid/:masterid', VerifyToken, deleteSubCategoryByMasterid);
router.get('/subcategorybycategory/:masterid', VerifyToken, getSubCategoryByCategory);
//masters data
router.get('/getmastersdata', VerifyToken, getAllMastersData);
router.post('/createmastersdata', VerifyToken, createMastersData);
router.get('/categorybymasterid/:masterid', getCategoryByMasterId);
router.get('/mastersdatabyid/:dataid', VerifyToken, getMastersDataById);
router.get('/mastersdatabymasterid/:masterid', VerifyToken, getMastersDataByMasterId);
router.post('/updatemastersdata/:dataid', VerifyToken, updateMastersData);
router.delete('/deletemastersdata/:dataid', VerifyToken, deleteMastersData);
router.delete('/deletemasterdatabymasterid/:masterid', VerifyToken, deleteMastersDataByMasterid);
router.delete('/deletecategorytype/:categoryTypeMasterId', VerifyToken, deleteCategoryType);

export default router;
