// userRoutes.js
import express from "express";
import bodyParser from 'body-parser';
import { VerifyToken, admin } from '../../middleware/authmiddleware.js';
import { apiLogs } from "../../middleware/logmiddleware.js";

import {CreateRole,deleteRole,UpdateRole,GetRoleDetailsByID,getroledetail} from "../../controllers/User/UserroleController.js";

const router = express.Router();
router.use(bodyParser.json());
router.use(apiLogs);

router.post('/CreateRole', VerifyToken, CreateRole);
router.post('/deleteRole', VerifyToken, deleteRole);
router.post('/UpdateRole',VerifyToken,  UpdateRole);
router.get('/getroledetail', VerifyToken, getroledetail);
router.post('/GetRoleDetailsByID',VerifyToken,  GetRoleDetailsByID);
export default router;