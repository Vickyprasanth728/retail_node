import express from "express";
import bodyParser from 'body-parser';
import { VerifyToken, admin } from '../../middleware/authmiddleware.js';

import { getStateDropdown } from "../../controllers/Localizations/stateController.js";

const router = express.Router();
router.use(bodyParser.json());

router.get('/get_state_dropdown', getStateDropdown);

export default router;
