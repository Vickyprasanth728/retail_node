import express from "express";
import bodyParser from 'body-parser';
import { VerifyToken, admin } from '../../middleware/authmiddleware.js';

import { createPaymentStripe, createPaymentCCA, CCAList } from "../../controllers/Payments/paymentController.js";

const router = express.Router();
router.use(bodyParser.json());

router.post('/create_payment_stripe',VerifyToken, createPaymentStripe);
router.post('/create_payment_cca',VerifyToken, createPaymentCCA);
// router.post('/ccavenue/response', CCAList);


export default router;