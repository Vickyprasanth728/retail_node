import express from "express";
import bodyParser from 'body-parser';
import { VerifyToken, admin } from '../../middleware/authmiddleware.js';

import { transactionReport } from "../../controllers/Report/reportsController.js";

const router = express.Router();
router.use(bodyParser.json());


router.get('/transactions_reports',VerifyToken, transactionReport);

export default router;