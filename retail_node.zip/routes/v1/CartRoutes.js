// userRoutes.js
import express from "express";
import bodyParser from 'body-parser';
import { VerifyToken, admin } from '../../middleware/authmiddleware.js';
import { apiLogs } from "../../middleware/logmiddleware.js";
import { GetCardbyUserId, updateCart, AddtoCart,quantity} from "../../controllers/Cart/CartController.js";

const router = express.Router();
// Use body-parser middleware to parse JSON requests
router.use(bodyParser.json());
router.use(apiLogs);

router.post('/AddtoCart', VerifyToken, AddtoCart);
router.post('/updateCart', VerifyToken, updateCart);
router.post('/GetCardbyUserId',VerifyToken, GetCardbyUserId);
router.post('/quantity',VerifyToken, quantity);
export default router;