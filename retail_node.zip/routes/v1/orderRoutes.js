// userRoutes.js
import express from "express";
import bodyParser from 'body-parser';
import { VerifyToken, admin } from '../../middleware/authmiddleware.js';
// import { apiLogs } from "../../middleware/logmiddleware.js";

import {gettrackpackagestatus,getordersummary, insertTransaction, updateTransaction1,GetCancelOrderDetails, getOrderDetails,cancelorder,ReturnOrder, getYourOrders, buyNow, getExchangeTransaction, updateExchange, updateTransaction, getOrderPage, UpdateOrderPageStatus, cancelTransaction} from "../../controllers/Order/ordercontroller.js";

const router = express.Router();
router.use(bodyParser.json());
// router.use(apiLogs);


router.post('/insertTransaction',VerifyToken, insertTransaction);
router.post('/updateTransaction', updateTransaction);
router.post('/getordersummary', VerifyToken, getordersummary);
router.post('/getOrderDetails',VerifyToken, getOrderDetails);
router.post('/getYourOrders/:userid',VerifyToken, getYourOrders);
router.post('/buyNow',VerifyToken, buyNow);
router.post('/updateExchange',VerifyToken, updateExchange);
router.post('/get_exchange_transaction/:transactionid',VerifyToken, getExchangeTransaction);
router.get('/getOrderPage',VerifyToken, getOrderPage);
router.put('/update_order_status',VerifyToken, UpdateOrderPageStatus);
router.post('/cancel_transaction', cancelTransaction);


router.post('/gettrackpackagestatus',VerifyToken,  gettrackpackagestatus);
router.post('/updateTransaction1', VerifyToken, updateTransaction1);
router.post('/GetCancelOrderDetails', VerifyToken, GetCancelOrderDetails);
router.post('/cancelorder', VerifyToken, cancelorder);
router.post('/ReturnOrder',VerifyToken,  ReturnOrder);

export default router;