// userRoutes.js
import express from "express";
import bodyParser from 'body-parser';
import { VerifyToken, admin } from '../../middleware/authmiddleware.js';
// import { apiLogs } from "../../middleware/logmiddleware.js";

import { AddMasters, GetMasters, EditMasters, DeleteMasters} from "../../controllers/MastersModule/masterController.js";

const router = express.Router();
// Use body-parser middleware to parse JSON requests
router.use(bodyParser.json());
// router.use(apiLogs);


router.post('/addMasters/:mastername',VerifyToken, AddMasters);
router.post('/viewMasters/:mastername', VerifyToken, GetMasters);
router.post('/editMasters/:mastername/:id', VerifyToken, EditMasters);
router.delete('/deleteMasters/:mastername/:id', VerifyToken, DeleteMasters);



export default router;