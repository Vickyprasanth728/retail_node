// userRoutes.js
import express from "express";
import bodyParser from 'body-parser';
import { VerifyToken, admin } from '../../middleware/authmiddleware.js';
import { apiLogs } from "../../middleware/logmiddleware.js";
import {createstaff,updatestaff,deletestaff } from '../../controllers/User/staffController.js'
const router = express.Router();
// Use body-parser middleware to parse JSON requests
router.use(bodyParser.json());
router.use(apiLogs);
// Define the route
router.post('/createstaff', VerifyToken, createstaff);
router.post('/updatestaff',VerifyToken, updatestaff);
router.post('/deletestaff',VerifyToken, deletestaff);

export default router;
