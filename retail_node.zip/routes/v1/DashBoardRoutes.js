// userRoutes.js
import express from "express";
import bodyParser from 'body-parser';
import { VerifyToken, admin } from '../../middleware/authmiddleware.js';
import { apiLogs } from "../../middleware/logmiddleware.js";
import { DB_AdminTransactionsCount,DB_AllGetOrderDetails,DB_AllGetOrderDetailsByStatus,DB_GetOrderDetailsByOrdernumber,DB_GetRevenueTrend,DB_GetRevenueTrendByDayCount,DB_GetTopSellingProducts,DB_GetTopSellingProductsByDaycount,DB_GetTransactionStatusDistribution,DB_SchoolTransactionsCount} from "../../controllers/DashBoard/DashBoardController.js";

const router = express.Router();
router.use(bodyParser.json());
router.use(apiLogs);

// Define routes
router.get('/AdminTransactionsCount',DB_AdminTransactionsCount);
router.get('/AllGetOrderDetails',  DB_AllGetOrderDetails);
router.get('/AllGetOrderDetailsByStatus', DB_AllGetOrderDetailsByStatus);
router.get('/GetOrderDetailsByOrdernumber', DB_GetOrderDetailsByOrdernumber);
router.get('/GetRevenueTrend',  DB_GetRevenueTrend);
router.get('/GetRevenueTrendByDayCount',  DB_GetRevenueTrendByDayCount);
router.get('/GetTopSellingProducts',  DB_GetTopSellingProducts);
router.get('/GetTopSellingProductsByDaycount',  DB_GetTopSellingProductsByDaycount);
router.get('/GetTransactionStatusDistribution',DB_GetTransactionStatusDistribution);
router.get('/SchoolTransactionsCount',  DB_SchoolTransactionsCount);
export default router;