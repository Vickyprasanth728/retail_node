// userRoutes.js
import express from "express";
import bodyParser from 'body-parser';
import { VerifyToken, admin } from '../../middleware/authmiddleware.js';
// import { apiLogs } from "../../middleware/logmiddleware.js";

import { salesDashboard, salesBarChart, salesLineChart, salesPercentage, productDashboard, productBarChart, productLineChart, productPercentage, salesDashboardList, productDashboardList} from "../../controllers/DashboardModule/dashboardController.js";

const router = express.Router();
// Use body-parser middleware to parse JSON requests
router.use(bodyParser.json());
// router.use(apiLogs);

router.get('/sales/dashboardlist',VerifyToken, salesDashboardList);
router.post('/sales/dashboard',VerifyToken, salesDashboard);
router.post('/sales/barchart',VerifyToken, salesBarChart);
router.post('/sales/linechart',VerifyToken, salesLineChart);
router.post('/sales/salespercentage',VerifyToken, salesPercentage);

router.post('/products/dashboard',VerifyToken, productDashboard);
router.post('/products/barchart',VerifyToken, productBarChart);
router.post('/products/linechart',VerifyToken, productLineChart);
router.post('/products/productpercentage',VerifyToken, productPercentage);
router.get('/products/dashboardlist',VerifyToken, productDashboardList);


export default router;