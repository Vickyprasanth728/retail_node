// userRoutes.js
import express from "express";
import bodyParser from 'body-parser';
import { signUpUser, signIn, Logout, refreshToken, getUser, getUsers, getUserCount, checkUsernameUnique, checkMobileNoUnique, checkEmailUnique, resetPassword, getUsernamebyMobile, signUpUserwithAddress,GetUserDetailsbyID ,CheckotpAuth} from "../../controllers/User/UserController.js";
import { InsertAddress, updateAddress, deleteAddress, getaddressdetailByuserid, getAddressById, getaddressdetailByDefault, getaddress_withPGN } from "../../controllers/User/AddressController.js"
import { verifyOTP, sendOTP } from '../../middleware/otpmiddleware.js';
import { VerifyToken,OtpVerifyToken, admin } from '../../middleware/authmiddleware.js';
// import { apiLogs } from "../../middleware/logmiddleware.js";

const router = express.Router();
// Use body-parser middleware to parse JSON requests
router.use(bodyParser.json());
// router.use(apiLogs);
// Define the route
//router.post('/signup', signUpUser);
router.post('/signUpUserwithAddress', signUpUserwithAddress);
router.post('/send-otp',OtpVerifyToken, sendOTP); 
router.post('/verify-otp',OtpVerifyToken, verifyOTP);
router.post('/CheckotpAuth', CheckotpAuth);
router.post('/resetpassword',OtpVerifyToken, resetPassword);

router.post('/usernameunique', checkUsernameUnique);
router.post('/mobilenounique', checkMobileNoUnique);
router.post('/emailunique', checkEmailUnique);
// Define the route
router.post('/signin', signIn);
router.post('/Logout', Logout);
router.get('/token', refreshToken);


router.get('/getcount', VerifyToken, getUserCount);
router.get('/getallusers', VerifyToken, getUsers);
router.get('/users/:id', VerifyToken, getUser);
router.post('/GetUserDetailsbyID',VerifyToken, GetUserDetailsbyID);
router.get("/getUsername/:mobileno", getUsernamebyMobile);

router.post('/address/insertaddress', VerifyToken, InsertAddress);
router.post('/address/updateaddress', VerifyToken, updateAddress);
router.delete('/address/deleteaddress/:addressid/:userid', VerifyToken, deleteAddress);

router.post('/address/getaddressdetailbyuserid', VerifyToken, getaddressdetailByuserid);
router.get('/address/getaddress_withPGN', VerifyToken, getaddress_withPGN);
router.post('/address/getaddressbyid', VerifyToken, getAddressById);
router.get('/address/getaddressdetailbydefault', VerifyToken, getaddressdetailByDefault);

export default router;
