// userRoutes.js
import express from "express";
import bodyParser from 'body-parser';
import { VerifyToken, admin } from '../../middleware/authmiddleware.js';
// import { apiLogs } from "../../middleware/logmiddleware.js";

// import { AddSchool, deleteSchool, getAllSchools, getSchoolById, updateSchool, CheckUniqueSchoolcode,getschoolcode_withPGN } from "../../controllers/masters/School.js";

import { AddSchool, getAllSchools, getSchoolById, updateSchool, deleteSchool, CheckUniqueSchoolcode} from "../../controllers/MastersModule/schoolController.js";

const router = express.Router();
// Use body-parser middleware to parse JSON requests
router.use(bodyParser.json());
// router.use(apiLogs);



router.post('/AddSchool',VerifyToken, AddSchool);
router.get('/getAllSchools', VerifyToken, getAllSchools);
router.get('/getSchoolById/:schoolid', VerifyToken, getSchoolById);
router.put('/updateSchool/:schoolid', VerifyToken, updateSchool);
router.delete('/deleteSchool/:schoolid', VerifyToken, deleteSchool);
router.post('/CheckUniqueSchoolcode',CheckUniqueSchoolcode);



// router.get('/getAllSchools', VerifyToken, getAllSchools);
// router.get('/getschoolcode_withPGN', VerifyToken, getschoolcode_withPGN);
// router.post('/AddSchool',VerifyToken,  AddSchool);
// router.post('/getSchoolById', VerifyToken, getSchoolById);
// router.post('/CheckUniqueSchoolcode',CheckUniqueSchoolcode);
// router.post('/updateSchool', VerifyToken, updateSchool);
// router.delete('/deleteSchool', VerifyToken, deleteSchool);



export default router;