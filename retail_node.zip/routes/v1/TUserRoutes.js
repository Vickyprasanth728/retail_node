import express from "express";
import bodyParser from 'body-parser';
import {signIn, changePassword, getUsernamebyMobile, getUserDetailsByUserId} from "../../controllers/User/TUserController.js";
import { } from "../../controllers/User/AddressController.js"
import { verifyOTP, sendOTP } from '../../middleware/otpmiddleware.js';
import { VerifyToken,OtpVerifyToken, admin } from '../../middleware/authmiddleware.js';

const router = express.Router();
router.use(bodyParser.json());

router.post('/signin1', signIn);
router.put('/change_password', changePassword);
router.get("/getUsername/:mobileno", getUsernamebyMobile);
router.get("/getUserDetailsbyID/:userid", getUserDetailsByUserId);

router.post('/send-otp',OtpVerifyToken, sendOTP); 
router.post('/verify-otp',OtpVerifyToken, verifyOTP);


export default router;
