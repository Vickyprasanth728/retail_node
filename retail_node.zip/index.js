import express from "express";
import cookieParser from "cookie-parser";
//import listEndpoints from 'express-list-endpoints';
import cors from "cors";
import routes from "./routes/index.js";
import dotenv from 'dotenv';
import { db, connectDB } from './config/Database.js';
import toobusy from 'toobusy-js';
import crypto from 'crypto';
import qs from 'qs';
// import {postReq} from './ccv/ccavRequestHandler.js';
// import {postRes} from './ccv/ccavResponseHandler.js';
dotenv.config();
const app = express();

connectDB();
//middlewares
// Enable CORS for specific route(s)
const allowedOrigin = process.env.ALLOWED_ORIGIN || 'http://localhost:3000';

app.use(cors({
  credentials: true,
  origin: allowedOrigin,
  methods: "GET,HEAD,PUT,PATCH,POST,DELETE",
  preflightContinue: false,
  allowedHeaders: "Origin, X-Requested-With, Content-Type, Accept, Authorization",
}));

import { fileURLToPath } from 'url';
import { dirname } from 'path';
import path from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

global.__basedir = __dirname;
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.use(function (req, res, next) {
  // Your custom headers
  res.header("Access-Control-Allow-Origin", allowedOrigin);
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

app.use(cookieParser());

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: false }));
// app.use(express.raw({ type: 'application/x-www-form-urlencoded', limit: '10mb' }));
app.use(function(req, res, next) {
  if (toobusy()) {
      // log if you see necessary
      res.status(503).send("Server Too Busy");
  } else {
  next();
  }
});
app.set('view engine', 'ejs');

app.set('views', path.join(__dirname, 'views'));
// Use the router
app.use("/api", routes);

// Get a list of all available routes
// const routesendUrl = listEndpoints(app);
// console.log(JSON.stringify(routesendUrl));

app.get('/', function (req, res) {
  return res.send({ issuccess: true, message: `Server is running on port ${process.env.PORT}.` });
});


app.post('/ccvPayment', function (req, res) {
  console.log('req', req.body.encResp);

  const workingKey = '0BF202BFD501907C9D76C5443211629C';

    let ccavEncResponse  = '';
    let wncRespCode = req.body.encResp

    console.log('wncRespCode', wncRespCode);
    
    req.on('data', (data) => {
        ccavEncResponse += data;
    });

    const ccavResponseI = decrypt(wncRespCode, workingKey);            
    console.log('ccavResponseI', ccavResponseI);

    req.on('end', () => {
        try {
            // const ccavPOST = qs.parse(ccavEncResponse);
            const encryptedResponse = wncRespCode;
            console.log('hghvgmggcjgm', encryptedResponse);
            
            const ccavResponse = decrypt(encryptedResponse, workingKey);            
            console.log('ihgygygyjj', ccavResponse);

            const pData = `<table border=1 cellspacing=2 cellpadding=2><tr><td>${ccavResponse.replace(/=/gi, '</td><td>').replace(/&/gi, '</td></tr><tr><td>')}</td></tr></table>`;
            const htmlcode = `<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>Response Handler</title></head><body><center><font size="4" color="blue"><b>Response Page</b></font><br>${pData}</center><br></body></html>`;

            res.status(200).send({
              status : true,
              message:'success',
              data: ccavResponse
            });
        } catch (error) {
            console.error("Error during response handling:", error);
            res.status(500).send({
              status : true,
              message:'Internal Server Error : ', error,
            });        
          }
    });

    const paramsCCAResponse = new URLSearchParams(ccavResponseI);
    const data = Object.fromEntries(paramsCCAResponse.entries());
    console.log('CCavResponse Final,', data);

  // return res.send({ issuccess: true, message: `Server is running on port ${process.env.PORT}.` });
  // return res.redirect('/dashboard1');
  return res.redirect('http://localhost:3000/orderdetails?userid=202');
});

app.get('/about', function (req, res){
  console.log(' path.join(__dirname,',  path.join(__dirname,'ccv', 'public', 'dataFrom.html'));
  
  // res.render( path.join(__dirname,'ccv', 'public', 'dataFrom.html'));
  const filePath = path.join(__dirname, 'ccv', 'public', 'dataFrom.html');
  console.log('File Path:', filePath); // Log the file path to check if it's correct
  res.sendFile(filePath); 
});

// app.post('/ccavRequestHandler', function (request, response){ 
//   postReq(request, response);
// });


// app.post('/ccavResponseHandler', function (request, response){
//     postRes(request, response);
// });

// CCAvenue Credentials
// const workingKey = 'A8E538339FBC4700FOFC1F9FF0498FF4'; // Put in the 32-Bit key shared by CCAvenues.
// const accessCode = 'AVXU82GA85BC88UXCB'; // Put in the Access Code shared by CCAvenues.
// const merchantId = 204980; 
// const orderId = 'Ord90uuff787'; 
// const currency = 'INR'; 
// const amount = 670.00; 
// const redirect_url = 'https://2cqr.retails.in/test';
// const cancel_url = 'https://2cqr.retails.in/test';
// const language = 'EN';


// Middleware to parse incoming JSON and URL-encoded data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Encrypt function
export const encrypt = (plainText, workingKey) => {
    const m = crypto.createHash('md5');
    m.update(workingKey);  // Hash the workingKey using MD5
    const key = m.digest();  // Get the hash as a binary buffer
    // const iv = Buffer.from('\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f', 'binary'); // 16-byte IV (fixed for CCAvenue)

    // var iv = '\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f';

    const iv = Buffer.from([0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]); // 16-byte IV

    
    const cipher = crypto.createCipheriv('aes-128-cbc', key, iv);  // Use AES-128-CBC mode
    let encoded = cipher.update(plainText, 'utf8', 'hex');
    encoded += cipher.final('hex');
    
    return encoded;
};

// export const encrypt = async (plainText, workingKey) => {

// 	var m = crypto.createHash('md5');
//     	m.update(workingKey);
//    	var key = m.digest('binary');
//       	var iv = '\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f';	
// 	var cipher = crypto.createCipheriv('aes-128-cbc', key, iv);
// 	var encoded = cipher.update(plainText,'utf8','hex');
// 	encoded += cipher.final('hex');
//     	return encoded;
// };

// Decrypt function
export const decrypt = (encText, workingKey) => {
  
    const m = crypto.createHash('md5');
    m.update(workingKey);  // Hash the workingKey using MD5
    const key = m.digest();  // Get the hash as a binary buffer
    const iv = Buffer.from('\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f', 'binary'); // 16-byte IV (fixed for CCAvenue)

    const decipher = crypto.createDecipheriv('aes-128-cbc', key, iv);  // Use AES-128-CBC mode
    let decoded = decipher.update(encText, 'hex', 'utf8');
    decoded += decipher.final('utf8');
    
    return decoded;
};


// Handle CCAvenue request
export const postReq = async (req, res) => {
    let body = '';
    // const workingKey = 'A8E538339FBC4700FOFC1F9FF0498FF4';
    // const accessCode = 'AVXU82GA85BC88UXCB'; 

    // const workingKey = 'A8E538339FBC4700F0FC1F9FF0498FF4';
    // const accessCode = 'ATXU82GA85BC88UXCB';

    const workingKey = '0BF202BFD501907C9D76C5443211629C';
    const accessCode = 'ATAD06LK05BU10DAUB';

  //   const formData = {
  //     merchant_id: merchantId,
  //     order_id: orderId,
  //     currency: currency,
  //     amount: amount,
  //     redirect_url: redirect_url,
  //     cancel_url: cancel_url,
  //     language: language
  // };

    const formData = {
      merchant_id: "204980",
      order_id: "Order-YUIYui89879-2024",
      currency: "INR",
      amount: "4000.00",
      redirect_url: "http://localhost:5001/ccvPayment",
      // redirect_url: "https://retails.2cqr.in/dashboard",
      cancel_url: "http://localhost:5001/ccvPayment",
      // cancel_url: "https://retails.2cqr.in/dashboard",
      language: "EN"
  };
  
    const params = new URLSearchParams(formData);

    req.on('data', (data) => {
        body += data;
    });

    req.on('end', () => {
        try {
          const bodyData  = params.toString();  
            const encRequest = encrypt(bodyData, workingKey);
            
            const formbody = `
                <form id="nonseamless" method="post" name="redirect" action="https://test.ccavenue.com/transaction/transaction.do?command=initiateTransaction">
                    <input type="hidden" id="encRequest" name="encRequest" value="${encRequest}">
                    <input type="hidden" name="access_code" id="access_code" value="${accessCode}">
                    <script language="javascript">
                        document.redirect.submit();
                    </script>
                </form>
            `;
            
            res.status(200).send(formbody);
        } catch (error) {
            console.error("Error during transaction request:", error);
            res.status(500).send("<h1>Internal Server Error</h1>");
        }
    });
};

// Handle CCAvenue response
export const postRes = async (req, res) => {

  const workingKey = '0BF202BFD501907C9D76C5443211629C';

    let ccavEncResponse  = '';
    
    req.on('data', (data) => {
        ccavEncResponse += data;
    });

    req.on('end', () => {
        try {
            // const ccavPOST = qs.parse(ccavEncResponse);
            const encryptedResponse = '9038372a4881a10f6a602d0937cc48a3aa782245791ce71c71a33244d5daa3e57e23dbfa0942a1db906bb51923aa06c079f716a8638accda6f697a83968ced62bcffc333ba373844402230e7d2067c75a2f37762fe79e094e62b2d293b3438248bab2e12fa66c5a2730b2c418c7a6344882ddde65cadb3ec2958a7647acf7f1a69e71bcecebb70c60f9ab724df30a6512d1dbbb375d325fcb2ce39711af6386b415cbafb0c2e82eedfeafa47f07e09884a16c751d0bb2c52ff074a51888505516478ae39e5aee98383a0f24ab0b240b7fc5e17636a5b6c94172258a710646f2dd51e785ce4b18728aa3fb5c2ddda39c570b4202480901688751467b43dc10ace83b6226494878afe5d0055500aeb58574f0c64333e94cbc7007e7273797a4be2860439ba26f2d729b434bca2439ecca6673ed8b3c1cffd17c123115d6a975a4bd5b192781385570f076e442ecca822fb468f22b08cf50edf905ce962ead5e733f3ed10fc647452e5b324eaa8313fa4ebad6196d5180a05e75e44eaac8bcf030c7071ab9f920d224c79915c4db16a43f43b440fa1cae3dfd0560db3799ace5f845a57d69966b87065a1e2f30f15da6a3b7966dbc892c19c63294e3d05d60702ffa5cffd59171aa23112af23ece89ab0e29e021388b1c27eac30bcd39099fc533822d5d807c5259d480c62bec2b808be715dbc2757c4d28c9262f2a2d1d0098798ae7518e735c79b3cae16d4b21a1ca1c7566db22e730beccb422fd0380f57c766379f7bcddcbdcbd380e3eff69edc171bb314beb3ad0223c4838359af84832dc822822aa15feed809e1aa5ea229fe774e66d8916a449e77ec5db7a2e2fb569c71ad3a5c67ccaa2ede6fb36073ea5cd44e4ae9018d06bf9cf5db4ae0f67ae59b1320fa79d9f69ca4b7f27607bd9fd9f487a064062ab492bbb1591eeca384896ce16b0a755b2b0be908fdec56d6aba1ba65b3baf5285f83d56774e9157c77810d767a8e2ad2c88dd297ae6faadfcd18b4e7a55997a6fdf690d7fc02e3ee0fad4899aa25fbf3070fff955e147b0597537550';
            console.log('hghvgmggcjgm');
            
            const ccavResponse = decrypt(encryptedResponse, workingKey);            
            console.log('ihgygygyjj', ccavResponse);

            const pData = `<table border=1 cellspacing=2 cellpadding=2><tr><td>${ccavResponse.replace(/=/gi, '</td><td>').replace(/&/gi, '</td></tr><tr><td>')}</td></tr></table>`;
            const htmlcode = `<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>Response Handler</title></head><body><center><font size="4" color="blue"><b>Response Page</b></font><br>${pData}</center><br></body></html>`;

            res.status(200).send(htmlcode);
        } catch (error) {
            console.error("Error during response handling:", error);
            res.status(500).send("<h1>Internal Server Error</h1>");
        }
    });
};

// // Serve the HTML form page
// app.get('/about', (req, res) => {
//     const filePath = path.join(__dirname, 'ccv', 'public', 'dataFrom.html');
//     console.log('File Path:', filePath);
//     res.sendFile(filePath);
// });

// Define POST routes
app.post('/ccavRequestHandler', postReq);
app.post('/ccavResponseHandler', postRes);


// Not found error handler
app.use(function (req, res, next) {
  res.status(404).send("Sorry, can't find that! " + `Not found - ${req.originalUrl}`)
})

// Error handling middleware
app.use(function (err, req, res, next) {
  console.error(err); // Log the error details
  const statusCode = err.statusCode || 500;
  const message = err.message || 'Something went wrong';

  if (message == 'File too large') {
    res.status(200).json({
      error: true,
      message: message + ' & ' + 'File size exceeds the limit of 5 MB',
    });
    console.log('error message', message);
  } else {
  
  res.status(statusCode).json({
    errorStatus: true,
    message: message,
  });
}

});

console.log('process.env.PORT', process.env.PORT);

// Set port, listen for requests
const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}.`);
});
