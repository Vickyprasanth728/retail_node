import http from 'http';
import fs from 'fs';
import {encrypt, decrypt} from './ccavutil.js';
import qs from 'querystring';

// exports.postReq = function(request,response){
// export const postReq = async (request, response) => {

//     var body = '',
// 	workingKey = '',	//Put in the 32-Bit key shared by CCAvenues.
// 	accessCode = '',	//Put in the Access Code shared by CCAvenues.
// 	encRequest = '',
// 	formbody = '';
				
//     request.on('data', function (data) {
// 	body += data;
// 	encRequest = encrypt(body,workingKey); 
// 	formbody = '<form id="nonseamless" method="post" name="redirect" action="https://secure.ccavenue.com/transaction/transaction.do?command=initiateTransaction"/> <input type="hidden" id="encRequest" name="encRequest" value="' + encRequest + '"><input type="hidden" name="access_code" id="access_code" value="' + accessCode + '"><script language="javascript">document.redirect.submit();</script></form>';
//     });
				
//     request.on('end', function () {
//         response.writeHeader(200, {"Content-Type": "text/html"});
// 	response.write(formbody);
// 	response.end();
//     });
//    return; 
// };

export const postReq = async (request, response) => {
    let body = '',
        workingKey = 'A8E538339FBC4700FOFC1F9FF0498FF4', // Put in the 32-Bit key shared by CCAvenues.
        accessCode = 'AVXU82GA85BC88UXCB', // Put in the Access Code shared by CCAvenues.
        encRequest = '',
        formbody = '';
    
    request.on('data', function (data) {
        body += data;
    });

    request.on('end', function () {
        try {
            // Assuming encrypt() function is implemented to encrypt the body with the workingKey
            encRequest = encrypt(body, workingKey); // Encrypt the body (ensure encrypt function works)
            
            // Create the form body HTML
            formbody = `
                <form id="nonseamless" method="post" name="redirect" action="https://secure.ccavenue.com/transaction/transaction.do?command=initiateTransaction">
                    <input type="hidden" id="encRequest" name="encRequest" value="${encRequest}">
                    <input type="hidden" name="access_code" id="access_code" value="${accessCode}">
                    <script language="javascript">
                        document.redirect.submit();
                    </script>
                </form>
            `;
            
            // Send the response back
            response.writeHead(200, { "Content-Type": "text/html" });
            response.write(formbody);
            response.end();
        } catch (error) {
            console.error("Error during transaction request:", error);
            response.writeHead(500, { "Content-Type": "text/html" });
            response.write("<h1>Internal Server Error</h1>");
            response.end();
        }
    });
};