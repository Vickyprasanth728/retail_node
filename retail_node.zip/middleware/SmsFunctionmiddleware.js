import axios from 'axios';
import dotenv from 'dotenv';
import { executeStoredProcedure } from '../middleware/storeproceduremiddleware.js';
import { formatDateToYYYYMMDD, formatDateTimeToYYYYMMDDHHMMSS } from '../Utils/Datetime.js';
import moment from 'moment-timezone';
dotenv.config();


const currentDate = new Date();
const isoDateString = currentDate.toISOString();

const originalMoment = moment(isoDateString);
const originalDate = originalMoment.toDate();

const formattedDate = formatDateToYYYYMMDD(originalDate);
const formattedDateTime = formatDateTimeToYYYYMMDDHHMMSS(originalDate);

import { db } from '../config/Database.js';


async function sendSmsFunction1(mobileno, message,otpcode) {
  try {
    const apiUrl = process.env.SMS_API_BASE_URL;
    const apiStatusUrl = process.env.SMS_API_STATUS_URL;
    const username = process.env.SMS_API_USERNAME;
    const password = process.env.SMS_API_PASSWORD;
    const senderId = process.env.SMS_API_SENDER_ID;
    const route = process.env.SMS_API_ROUTE;
   
    const params = new URLSearchParams({
      username,
      password,
      sender_id: senderId,
      route,
      phonenumber: mobileno,
      message,
    });
    const broadcastId = await axios.get(apiUrl, { params });
    try {
      const params = new URLSearchParams({
        username,
        password,
        phonenumber: mobileno,
        broadcastid: broadcastId.data,
        date: formattedDate,
      });
      const smsResponse = await axios.get(apiStatusUrl, { params });
      // Respond based on SMS response
      if (smsResponse.data === "delivered" || smsResponse.data === "Submitted to SMSC") {
        console.log('SMS sent successfully');
        const SP_parameters = [mobileno,'',otpcode,formattedDateTime, 1 ,'','']
        const LogResults = await executeStoredProcedure('SP_insertsmsotplog', SP_parameters);
        console.log(LogResults);
        return { issuccess: true, message: 'SMS sent successfully', error: smsResponse.data };
      } else {
        console.error('Failed to send SMS:', smsResponse.data);
        const SP_parameters = [mobileno,'',otpcode ,formattedDateTime, 0 ,'','']
        const LogResults = await executeStoredProcedure('SP_insertsmsotplog', SP_parameters);
        console.log(LogResults);
        return { issuccess: false, message: 'Failed to send SMS', error: smsResponse.data };
      }
    } catch (error) {
      console.error('Error checking SMS status:', error);
      return { issuccess: false, message: 'Error checking SMS status', error: error.message };
    }

  } catch (error) {
    console.error('Error sending SMS:', error.message);
    return { issuccess: false, message: 'Failed to send SMS', error: error.message };
  }
}

async function sendSmsFunction(mobileno, message, otpcode) {
  try {

    const currentDateTime = new Date();
    
    const transtime = new Date(currentDateTime.toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }));
    const validity = new Date(currentDateTime.setMinutes(currentDateTime.getMinutes() + 10));

    console.log('transtimeq', transtime);
    console.log('validityq', validity);
    const apiUrl = process.env.SMS_API_BASE_URL;
    const apiStatusUrl = process.env.SMS_API_STATUS_URL;
    const username = process.env.SMS_API_USERNAME;
    const password = process.env.SMS_API_PASSWORD;
    const senderId = process.env.SMS_API_SENDER_ID;
    const route = process.env.SMS_API_ROUTE;
   
    const params = new URLSearchParams({
      username,
      password,
      sender_id: senderId,
      route,
      phonenumber: mobileno,
      message,
    });
    const broadcastId = await axios.get(apiUrl, { params });
    try {
      const params = new URLSearchParams({
        username,
        password,
        phonenumber: mobileno,
        broadcastid: broadcastId.data,
        date: formattedDate,
      });
      const smsResponse = await axios.get(apiStatusUrl, { params });
      console.log('smsResponse', smsResponse.data);
      
      if (smsResponse.data === "delivered" || smsResponse.data === "Submitted to SMSC") {
        console.log('SMS sent successfully');
        // const SP_parameters = [mobileno,'',otpcode,formattedDateTime, 1 ,'','']
        // const LogResults = await executeStoredProcedure('SP_insertsmsotplog', SP_parameters);

          let LogResults;
          const isValidMobile = /^[0-9]{10}$/.test(mobileno);
    
          if (!isValidMobile) {
            return res.status(400).send({
              status: false,
              message: 'Invalid mobile number format'
            });
          }
          try {
            let userQuery = `SELECT * FROM users WHERE mobileno = '${mobileno}' AND status != 0`;
            const user = await db.query(userQuery);
        
            console.log('Initial data', user[0]);
        
            const userMobCheck = user[0][0] ? user[0][0]?.userid : 0;
            console.log('userMobCheck : ', userMobCheck);
        
            if (userMobCheck == 0) {
              throw new Error("User not found");
            }
        
            let otpCheckQuery = `SELECT 1 FROM otpsmslog WHERE mobileno = '${mobileno}' AND otpcode = '${otpcode}'`;
            const otpCheck = await db.query(otpCheckQuery);
        
            if (otpCheck[0].length > 0) {
              let updateOtpQuery = `
                UPDATE otpsmslog
                SET senttime = '${validity.toISOString()}', status = 1
                WHERE mobileno = '${mobileno}' AND otpcode = '${otpcode}'
              `;
              LogResults = await db.query(updateOtpQuery);
        
              console.log('Record update successfully');
    
            } else {
              let insertOtpQuery = `
                INSERT INTO otpsmslog (mobileno, email, otpcode, senttime, status)
                VALUES ('${mobileno}', '', '${otpcode}', '${validity.toISOString()}', 1)
              `;
              LogResults = await db.query(insertOtpQuery);
        
              console.log('Record inserted successfully');
            }
        
          } 
          catch (error) {
            console.error('Error processing OTP:', error);
            return res.status(500).send({
              status: false,
              message: 'Internal server error'
            });
          }

          console.log('LogResults', LogResults);
          
        return { status: true, message: 'SMS sent successfully', };
    
      } 
      else {
        console.error('Failed to send SMS:', smsResponse.data);
        // const SP_parameters = [mobileno,'',otpcode ,formattedDateTime, 0 ,'','']
        // const LogResults = await executeStoredProcedure('SP_insertsmsotplog', SP_parameters);

        let LogResults;
        const isValidMobile = /^[0-9]{10}$/.test(mobileno);
  
        if (!isValidMobile) {
          return res.status(400).send({
            status: false,
            message: 'Invalid mobile number format'
          });
        }
        try {
          let userQuery = `SELECT * FROM users WHERE mobileno = '${mobileno}' AND status != 0`;
          const user = await db.query(userQuery);
      
          console.log('Initial data', user[0]);
      
          const userMobCheck = user[0][0] ? user[0][0]?.userid : 0;
          console.log('userMobCheck : ', userMobCheck);
      
          if (userMobCheck == 0) {
            throw new Error("User not found");
          }
      
          let otpCheckQuery = `SELECT 1 FROM otpsmslog WHERE mobileno = '${mobileno}' AND otpcode = '${otpcode}'`;
          const otpCheck = await db.query(otpCheckQuery);
      
          if (otpCheck[0].length > 0) {
            let updateOtpQuery = `
              UPDATE otpsmslog
              SET senttime = '${validity.toISOString()}', status = 0
              WHERE mobileno = '${mobileno}' AND otpcode = '${otpcode}'
            `;
            LogResults = await db.query(updateOtpQuery);
      
            console.log('Record update successfully');
  
          } else {
            let insertOtpQuery = `
              INSERT INTO otpsmslog (mobileno, email, otpcode, senttime, status)
              VALUES ('${mobileno}', '', '${otpcode}', '${validity.toISOString()}', 0)
            `;
            LogResults = await db.query(insertOtpQuery);
      
            console.log('Record inserted successfully');
          }
      
        } 
        catch (error) {
          console.error('Error processing OTP:', error);
          return res.status(500).send({
            status: false,
            message: 'Internal server error'
          });
        }
        console.log('LogResults', LogResults);
        return { issuccess: false, message: 'Failed to send SMS', error: smsResponse.data };
      }
    } catch (error) {
      console.error('Error checking SMS status:', error);
      return { issuccess: false, message: 'Error checking SMS status', error: error.message };
    }

  } catch (error) {
    console.error('Error sending SMS:', error.message);
    return { issuccess: false, message: 'Failed to send SMS', error: error.message };
  }
}


async function checkSmsStatus(mobileno, broadcastId) {
  try {
    const apiUrl = process.env.SMS_API_BASE_URL;
    const username = process.env.SMS_API_USERNAME;
    const password = process.env.SMS_API_PASSWORD;
    
    const params = new URLSearchParams({
      username,
      password,
      phonenumber: mobileno,
      broadcastid: broadcastId,
      date: formattedDate,
    });
    const response = await axios.get(apiUrl, { params });
    return response;
  } catch (error) {
    console.error('Error checking SMS status:', error);
    return { issuccess: false, message: 'Error checking SMS status', error: error };
  }
}

async function sendSmsFunctionGet(mobileno, message) {
  try {
    const apiUrl = process.env.SMS_API_BASE_URL;
    const apiKey = process.env.SMS_API_KEY;

    const response = await axios.get(apiUrl, {
      params: {
        to: mobileno,
        message: message,
        apiKey: apiKey,
        // Add any other required parameters here
      },
    });

    if (response.data.success) {
      console.log('SMS sent successfully');
      return { success: true, message: 'SMS sent successfully' };
    } else {
      console.error('Failed to send SMS:', response.data.error);
      return { success: false, message: 'Failed to send SMS', error: response.data.error };
    }
  } catch (error) {
    console.error('Error sending SMS:', error.message);
    return { success: false, message: 'Error sending SMS', error: error.message };
  }
}
export default sendSmsFunction;
