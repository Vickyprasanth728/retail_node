import winston from 'winston';
const { combine, timestamp, printf } = winston.format;

// Define a custom log format
const logFormat = printf(({ level, message, timestamp }) => {
  return `${timestamp} [${level}]: ${message}`;
});

const getMonthYear = () => {
  const currentDate = new Date();
  const year = currentDate.getFullYear();
  const month = String(currentDate.getMonth() + 1).padStart(2, '0');
  return `_${year}_${month}`;
};


// Create a logger
// const logger = winston.createLogger({
//   level: 'info',
//   format: combine(
//     timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }), // Customize the timestamp format
//     logFormat
//   ),
//   transports: [
//     new winston.transports.Console(), // Enable console logging
//     new winston.transports.File({
//       filename: `logs/APIReqRes/combined_${getMonthYear()}.log`, // Log file with month and year
//     }),
//   ],
//   exceptionHandlers: [
//     new winston.transports.File({
//       filename: `logs/ErrorLog/ErrorLog_${getMonthYear()}.log`, // Exception log file with month and year
//       format: combine(
//         timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }), // Customize the timestamp format for exceptions
//         logFormat
//       ),
//     }),
//   ],
// });

const apiLogs = function(req, res, next) {
//     const currentDateTime = new Date().toISOString();    
//     console.log(currentDateTime) ;
//     logger.info(`API Path - Path: ${req.path}`);
//     logger.info(`API Inputs - Body: ${JSON.stringify(req.body)}\n`);
//     logger.info(`API Inputs - Query: ${JSON.stringify(req.query)}\n`);
//     next();
//   };


// if (process.env.NODE_ENV === 'development') {
//   console.log = (...args) => logger.info.call(logger, ...args);
//   console.info = (...args) => logger.info.call(logger, ...args);
//   console.warn = (...args) => logger.warn.call(logger, ...args);
//   console.error = (...args) => logger.error.call(logger, ...args);
//   console.debug = (...args) => logger.debug.call(logger, ...args);
  
// }
// if (process.env.NODE_ENV === 'production') {
  
}

export {apiLogs};
