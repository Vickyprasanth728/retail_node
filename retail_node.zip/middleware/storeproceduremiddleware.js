import { Sequelize } from "sequelize";
import mysql from 'mysql2/promise';
import { db } from '../config/Database.js';
async function Test_executeStoredProcedure(procedureName, parameters) {
    const dbSts = {
        status: false,
        data: null,
        message: false,
        totalcount: 0,
        Obj: null,
        err: null,
    };
    try {
        const results = await db.query(`CALL ${procedureName}(${parameters.map(() => '?').join(', ')})`, {
            replacements: parameters,
            type: Sequelize.QueryTypes.RAW,
        });
        console.log(results);
        dbSts.data = results;
        dbSts.message = results[0].message;
        dbSts.status = true;
    } catch (error) {
        console.error(error);
        // Handle error and set appropriate properties in dbSts
        dbSts.err = error.toString();
    }
    return dbSts;
}
// Function to convert a string to a JavaScript Date object
function parseDate(str) {
    return new Date(str);
}
async function executeStoredProcedure(procedureName, model) {
    const dbSts = {
        status: false,
        data: null,
        totalcount: 0,
        message: '',
        Object: null,
        error: null,
    };
    //console.log('Model Length ' + model.length);

    try {
        const connection = await mysql.createConnection({
            host: process.env.DB_HOST,
            user: process.env.DB_USER,
            password: process.env.DB_PASSWORD,
            database: process.env.DB_DATABASE,
        });
        const SQLQuery = `SELECT PARAMETER_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH, PARAMETER_MODE
        FROM information_schema.parameters
        WHERE SPECIFIC_NAME = '${procedureName}'
        GROUP BY PARAMETER_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH, PARAMETER_MODE
        ORDER BY MIN(ORDINAL_POSITION);`;
        const [parameterRows] = await connection.execute(SQLQuery);
        const sqlParams = [];
        if (parameterRows.length > 0) {
            let outputIndex = -1;
            for (let i = 0; i < parameterRows.length; i++) {
                const paramName = parameterRows[i].PARAMETER_NAME;
                const dataType = parameterRows[i].DATA_TYPE;
                const paramMode = parameterRows[i].PARAMETER_MODE;
                const direction = paramMode.includes('IN') ? 'IN' : 'OUT';
                let size = 8;
                if (dataType.includes('varchar')) {
                    size = parameterRows[i].CHARACTER_MAXIMUM_LENGTH || 255;
                }                
                let value = model[i];
                let escapedvalue = mysql.escape(value);
                // console.log("Values :");
                // console.log(JSON.stringify(value));
                // console.log("Escaped Values :");
                // console.log(JSON.stringify(escapedvalue));
                if (direction === 'OUT') {
                    outputIndex = i;
                }
                // Handle different data types
                switch (dataType) {
                    case 'varchar':
                        // For varchar, ensure the value is a string
                        value = String(value);
                        // value = mysql.escape(value);
                        break;
                    case 'datetime':
                        value = parseDate(value);
                        break;
                    case 'date':
                        value = parseDate(value);
                        break;
                    case 'bit':
                        value = value === '1' ? 1 : 0;
                        break;
                    case 'int':
                        value = parseInt(value, 10);
                        break;
                    case 'float':                       
                        value = parseFloat(value);
                        break;
                    case 'decimal':
                        value = parseFloat(value);
                        break;
                    case 'json':
                        try {
                            const correctedString = `[${value}]`;
                            const parsedArray = JSON.parse(correctedString);
                            value = parsedArray;
                        } catch (error) {
                            console.error('Error creating or parsing JSON array:', error);
                        }
                        break;
                }
                sqlParams.push({
                    name: paramName,
                    type: dataType,
                    value,
                    direction,
                    size,
                });
            }
        }
        
        // Sanitize parameters
        // const sanitizedParams = sqlParams.map(param => (param.value !== undefined ? mysql.escape(param.value) : null));

        // const placeholders = Array(sanitizedParams.length).fill('?').join(', ');

        // const query = `CALL ${procedureName}(${placeholders})`;

        // const [results, metadata] = await connection.execute(query, sanitizedParams);

        const [results, metadata] = await connection.execute(
            `CALL ${procedureName}(${sqlParams.map(param => (param.value !== undefined ? '?' : 'NULL')).join(', ')})`,
            sqlParams.map(param => (param.value !== undefined ? param.value : null))
        );      
        if (process.env.NODE_ENV === 'development') {
        console.log(JSON.stringify(results));
        }
        const resultArray = Array.isArray(results) && results.length > 0 ? results[0] : [];
        const resultArrayData = Array.isArray(results) && results.length > 0 ? results[1] : [];
        const resultObject = resultArray[0];
        dbSts.data = JSON.stringify(resultArrayData);
        dbSts.message = resultObject.message;
        dbSts.totalcount = resultObject.totalcount;
        dbSts.status = resultObject.status === 'SUCCESS';
        connection.end();
    } catch (error) {
        console.error(error);
        if (process.env.NODE_ENV === 'development') {
        dbSts.message = error.message;
        }
        else if(process.env.NODE_ENV === 'production') {
        dbSts.message = 'Internal Server Error';
        }
    }
    return dbSts;
}
export {executeStoredProcedure };
