import nodeMailer from 'nodemailer';

async function sendMail(options) {
  try {
    const transporter = nodeMailer.createTransport({
      // host: process.env.SMTP_HOST,
      // port: process.env.SMTP_PORT,
      service: process.env.SMTP_SERVICE,
      auth: {
        user: process.env.SMTP_MAIL,
        pass: process.env.SMTP_PASSWORD,
      },
    });
    const mailOptions = {
      from: process.env.SMTP_MAIL,
      to: options.email,
      subject: options.subject,
      text: options.message,
      html: options.html,
    };
    // Use await to wait for the promise to resolve
    //await transporter.sendMail(mailOptions);
    console.log('body: ', mailOptions);
    const info = await transporter.sendMail(mailOptions);
    if (!info.messageId) return resolve({ status: false })
    console.log('Email sent successfully', mailOptions);
    return true;
    //return res.status(200).json({ status: true, messageId: info.messageId ,message: 'Email sent successfully'});
    // No need to handle response here, return a success message
    //return { message: 'Email sent successfully' };
  } catch (error) {
    // Handle the error and return an error message
    console.error('Error sending email:', error.message);
    return false;
    //return res.status(401).json({issuccess: false , message: error.message });
  }
}

export default sendMail;
