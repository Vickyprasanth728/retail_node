import OTP from '../models/otpModel.js';
import sendSmsFunction from '../middleware/SmsFunctionmiddleware.js';
import { executeStoredProcedure } from '../middleware/storeproceduremiddleware.js';
import sendMail from "../middleware/sendMailMiddleware.js";
import { formatDateToYYYYMMDD, formatDateTimeToYYYYMMDDHHMMSS } from '../Utils/Datetime.js';
import moment from 'moment-timezone';
import User from '../models/UsersModel.js';
const currentDate = new Date();
const isoDateString = currentDate.toISOString();
const originalMoment = moment(isoDateString);
const originalDate = originalMoment.toDate();
const formattedDate = formatDateToYYYYMMDD(originalDate);
const formattedDateTime = formatDateTimeToYYYYMMDDHHMMSS(originalDate);

// SET p_transtime = CONVERT_TZ(NOW(), '+00:00', '+05:30');
// SET p_validity = CONVERT_TZ(DATE_ADD(NOW(), INTERVAL 10 MINUTE), '+00:00', '+05:30');

import { db } from '../config/Database.js';

import path from 'path';
import fs from 'fs';
import mailer from '../middleware/mailer.model.js';

import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { availableMemory } from 'process';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

//@route      GET /api/v1/users/send-otp
//@desc       Get Single Users
//@access     Private

async function sendOTP(req, res) {
  const { body } = req;
  const { mobileno, otpforuse } = body;
  try {
    console.log(mobileno, otpforuse)
    if (!mobileno) {
      return res.status(400).json({
        success: false,
        message: 'Enter the Details Carefully'
      })
    }
    const result = await getOTPUsage(otpforuse);
    if (result !== null) {
      console.log(result);
      if (otpforuse !== 'SUP') {
        const user = await User.findOne({ where: { mobileno: mobileno } });
        if (!user && user === null) {
          return res.status(400).json({
            issuccess: false,
            message: `Mobile no : ${mobileno} not found `
          })
        }
      }
    } else {
      return res.status(400).json({
        issuccess: false,
        message: 'Invalid request'
      });
    }
    // Generate and save OTP
    const otpcode = await generateAndSaveOTP(mobileno);
    if (otpcode === null) {
      return res.status(500).json({ issuccess: false, error: 'Internal Server Error', message: "generating and saving OTP" });
    }
    // Construct SMS template
    const smsOtpTemplate = process.env.SMS_OTP_TEMPLATE
      //.replace("#field1#", username)
      .replace("#field1#", otpcode)
      .replace("#field2#", result);
    // Send SMS
    const smsResponse = await sendSmsFunction(mobileno, smsOtpTemplate, otpcode);
    return res.status(smsResponse.issuccess ? 200 : 500).json(smsResponse);
  } catch (error) {
    console.log(error);
    console.error('Error sending OTP:', error.message);
    res.status(500).json({ success: false, error: 'Internal Server Error', message: error.message });
  }
}

async function getOTPUsage(otpforuse) {
  let OTPUSAGE = '';
  if (otpforuse === 'RPWD') {
    OTPUSAGE = 'Reset Password';
  } else if (otpforuse === 'FPWD') {
    OTPUSAGE = 'Forget password';
  } else if (otpforuse === 'SUP') {
    OTPUSAGE = 'Sign Up';
  } else if (otpforuse === 'SIN') {
    OTPUSAGE = 'Sign In';
  } else {
    // Invalid otpforuse value
    return null;
  }
  return OTPUSAGE;
}


async function generateAndSaveOTP1(mobileno) {
  // Generate random 6-digit OTP
  const otpcode = Math.floor(100000 + Math.random() * 900000);
  try {
    const SP_OTPparameters = [mobileno, otpcode]
    const otpDataResults = await executeStoredProcedure('SP_GenerateOrUpdateOTP', SP_OTPparameters);
    if (otpDataResults && otpDataResults.status === true) {
      const SP_parameters = [mobileno, '', otpcode, formattedDateTime, 0, '', '']
      const LogResults = await executeStoredProcedure('SP_insertsmsotplog', SP_parameters);      
    return otpcode; // Return the generated OTP
    }
    else {
      // Handle errors (e.g., log, throw)
      console.error(error);
      console.error('Error generating and saving OTP:', error);
      return null; // Return null in case of an error
    }
  } catch (error) {
    // Handle errors (e.g., log, throw)
    console.error(error);
    console.error('Error generating and saving OTP:', error);    
  }
  return null; // Return null in case of an error
}

async function generateAndSaveOTP(mobileno) {
  const otpcode = Math.floor(100000 + Math.random() * 900000);
  try {
    const currentDateTime = new Date();

    const transtime = new Date(currentDateTime.toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }));
    const validity = new Date(currentDateTime.setMinutes(currentDateTime.getMinutes() + 10));

    console.log('transtimeq', transtime);
    console.log('validityq', validity);
  
    let userQuery = `SELECT userid FROM users WHERE mobileno = '${mobileno}' and status !=0 `;
    const userResult = await db.query(userQuery);
    const user = userResult[0][0];
    
    if (!user) {
      throw new Error("User not found");
    }
  
    const userId = user.userid;
    
    let otpDataResults;
    let otpCheckQuery = `SELECT COUNT(*) AS count FROM otptable WHERE mobileno = '${mobileno}'`;
    const otpCheckResult = await db.query(otpCheckQuery);
    const recordCount = otpCheckResult[0][0] ? otpCheckResult[0][0]?.count : 0
  
    if (recordCount > 0) {
      let updateQuery = `
        UPDATE otptable
        SET 
        otpcode = '${otpcode}', 
        validity = '${validity.toISOString()}', 
        transtime = '${transtime.toISOString()}', 
        userid = ${userId}, 
        status = 1
        WHERE mobileno = '${mobileno}'
        ORDER BY id DESC LIMIT 1
      `;
      otpDataResults = await db.query(updateQuery);
    } 
    else {
      let insertQuery = `
        INSERT INTO 
        otptable 
        (mobileno, otpcode, validity, transtime, userid)
        VALUES 
        ('${mobileno}', '${otpcode}', '${validity.toISOString()}', '${transtime.toISOString()}', ${userId})
      `;
      otpDataResults = await db.query(insertQuery);
    }

    console.log('otpcode', otpcode);

    if (otpDataResults) {
     
      const isValidMobile = /^[0-9]{10}$/.test(mobileno);

      if (!isValidMobile) {
        return res.status(400).send({
          status: false,
          message: 'Invalid mobile number format'
        });
      }

      try {
        let userQuery = `SELECT * FROM users WHERE mobileno = '${mobileno}' AND status != 0`;
        const user = await db.query(userQuery);
    
        console.log('Initial data', user[0]);
    
        const userMobCheck = user[0][0] ? user[0][0]?.userid : 0;
        console.log('userMobCheck : ', userMobCheck);
    
        if (userMobCheck == 0) {
          throw new Error("User not found");
        }
    
        let otpCheckQuery = `SELECT 1 FROM otpsmslog WHERE mobileno = '${mobileno}' AND otpcode = '${otpcode}'`;
        const otpCheck = await db.query(otpCheckQuery);
    
        if (otpCheck[0].length > 0) {
          let updateOtpQuery = `
            UPDATE otpsmslog
            SET senttime = '${validity.toISOString()}', status = 0
            WHERE mobileno = '${mobileno}' AND otpcode = '${otpcode}'
          `;
          await db.query(updateOtpQuery);
    
          console.log('Record update successfully');

        } else {
          let insertOtpQuery = `
            INSERT INTO otpsmslog (mobileno, email, otpcode, senttime, status)
            VALUES ('${mobileno}', '', '${otpcode}', '${validity.toISOString()}', 0)
          `;
          await db.query(insertOtpQuery);
    
          console.log('Record inserted successfully');
        }
    
      } catch (error) {
        console.error('Error processing OTP:', error);
        return res.status(500).send({
          status: false,
          message: 'Internal server error'
        });
      }

    return otpcode; 
    }
    else {
      console.error('Error generating and saving OTP');
      return null;
    }

  } catch (error) {
    console.error('Error generating and saving OTP:', error);
    return {
      status: false,
      message: error.message
    };
  }
}


async function verifyOTP1(req, res, next) {
  const { body } = req;
  const { mobileno, otpcode } = body;

  try {
    const SP_OTPparameters = [mobileno, otpcode]
    const otpDataResults = await executeStoredProcedure('SP_VerifyOTP', SP_OTPparameters);
    console.log(JSON.stringify(otpDataResults) + "Check");
    if (otpDataResults && otpDataResults.status === true) {
      const SP_parameters = [mobileno, '', otpcode, formattedDateTime, 1, '', '']
      const LogResults = await executeStoredProcedure('SP_insertsmsotplog', SP_parameters);
     return res.status(200).json({ issuccess: true, message: otpDataResults.message });
    }
    else {
      return res.status(400).json({ issuccess: false, message: otpDataResults.message });
    }
  } catch (error) {
    console.error('Error verifying OTP:', error.message);
    return res.status(500).json({ issuccess: false, message: 'Internal Server Error' });
  }
}

async function emailTrigger (orderList) {
  console.log('Initial Email Trigger', orderList[0]);

  // Generate HTML content for each order

  const htmlContent1 = `<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome Successfully</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        h1 {
            color: #28a745;
            font-size: 2.5em;
        }
        p {
            font-size: 1.2em;
            color: #555;
        }
        .btn {
            padding: 10px 20px;
            font-size: 1em;
            color: white;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }
        .btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Welcome, [User Name]!</h1>
        <p>You have successfully completed the action. We are glad to have you with us!</p>
        <a href="homepage.html" class="btn">Go to Dashboard</a>
    </div>

</body>
</html>
 `;
              
  function saveHTMLToFile(htmlContent1, fileName) {
      const filePath = path.join(__dirname, fileName);
      fs.writeFile(filePath, htmlContent1, (err) => {
          if (err) {
          console.error('Error saving HTML file:', err);
          } else {
          console.log(`HTML file saved: ${filePath}`);
          }
      });
  }
  saveHTMLToFile(htmlContent1, 'order-confirmation.html');

  const EmailID = orderList[0][0] ? orderList[0][0]?.email : ""
  console.log('EmailID', EmailID);
      
  const mailOptions = {
      from: 'vickyprasanth728@gmail.com',
      to: `${EmailID}`,
      subject: `Order Confirmation`,
      // text: 'text',
      html: htmlContent1
    };
  console.log('JSON.stringify(mailOptions)', JSON.stringify(mailOptions));
  
    mailer.sendMail(mailOptions, async (error, info) => {
      if (error) {
        console.error("Error sending email:", error);
        let thisQuery = ` INSERT INTO email_test (mail_options, data, email,error,status) VALUES ('${JSON.stringify(mailOptions)}', '${JSON.stringify(orderList[0])}', '${JSON.stringify(EmailID)}', '${JSON.stringify(error)}', 'fail') `
        const data = await db.query(thisQuery); 
      } else {
        let thisQuery = ` INSERT INTO email_test (mail_options, data, email, error, status) VALUES ('${JSON.stringify(mailOptions)}', '${JSON.stringify(orderList[0])}', '${JSON.stringify(EmailID)}','', 'success') `
        const data = await db.query(thisQuery);        
        console.log("Email sent:", info.response);
      }
    });
};
async function verifyOTP12(req, res, next) {
  const { body } = req;
  const { mobileno, otpcode } = body;

  const p_transtime = new Date().toLocaleString("en-US", { timeZone: "Asia/Kolkata" });

  try {
    // const SP_OTPparameters = [mobileno, otpcode]
    // const otpDataResults = await executeStoredProcedure('SP_VerifyOTP', SP_OTPparameters);

    let otpQuery = `
    SELECT DATE_FORMAT(validity, '%Y-%m-%d %H:%i:%s') as validity 
    FROM otptable 
    WHERE mobileno = '${mobileno}' AND otpcode = '${otpcode}' AND status = 1 
    ORDER BY id DESC LIMIT 1 
    `
    const otpResult = await db.query(otpQuery);
    const v_validity = otpResult[0][0] ? otpResult[0][0]?.validity : 0

    console.log('v_validity', v_validity);
    console.log('new Date(v_validity)', new Date(v_validity));
    console.log('new Date(p_transtime)', new Date(p_transtime));
    console.log('formattedDateTime', formattedDateTime);

    if (v_validity > formattedDateTime) {
      console.log('im in');
      const updateOTPTB = await db.query(`UPDATE otptable SET status = 0 WHERE mobileno = '${mobileno}' AND otpcode = '${otpcode}'`);
    } 
    else {
      console.log('im out');
    }

    hhjhvjh

    if (otpDataResults) {
     
      const isValidMobile = /^[0-9]{10}$/.test(mobileno);

      if (!isValidMobile) {
        return res.status(400).send({
          status: false,
          message: 'Invalid mobile number format'
        });
      }

      try {
        let userQuery = `SELECT * FROM users WHERE mobileno = '${mobileno}' AND status != 0`;
        const user = await db.query(userQuery);
    
        console.log('Initial data', user[0]);
    
        const userMobCheck = user[0][0] ? user[0][0]?.userid : 0;
        console.log('userMobCheck : ', userMobCheck);
    
        if (userMobCheck == 0) {
          throw new Error("User not found");
        }
    
        let otpCheckQuery = `SELECT 1 FROM otpsmslog WHERE mobileno = '${mobileno}' AND otpcode = '${otpcode}'`;
        const otpCheck = await db.query(otpCheckQuery);
    
        if (otpCheck[0].length > 0) {
          let updateOtpQuery = `
            UPDATE otpsmslog
            SET senttime = '${validity.toISOString()}', status = 0
            WHERE mobileno = '${mobileno}' AND otpcode = '${otpcode}'
          `;
          await db.query(updateOtpQuery);
    
          console.log('Record update successfully');

        } else {
          let insertOtpQuery = `
            INSERT INTO otpsmslog (mobileno, email, otpcode, senttime, status)
            VALUES ('${mobileno}', '', '${otpcode}', '${validity.toISOString()}', 0)
          `;
          await db.query(insertOtpQuery);
    
          console.log('Record inserted successfully');
        }
    
      } catch (error) {
        console.error('Error processing OTP:', error);
        return res.status(500).send({
          status: false,
          message: 'Internal server error'
        });
      }

    return otpcode; 
    }
    else {
      console.error('Error generating and saving OTP');
      return null;
    }
    
  } catch (error) {
    console.error('Error verifying OTP:', error.message);
    return res.status(500).json({ issuccess: false, message: 'Internal Server Error' , error : error.message});
  }
}
async function verifyOTP(req, res, next) {
  try {
      const { mobileno, otpcode } = req.body;

      const currentTime = new Date();
      let resultStatus = '';
      let resultMessage = '';

      // Verify the OTP validity
      const otpQuery = `
          SELECT DATE_FORMAT(validity, '%Y-%m-%d %H:%i:%s') as validity 
          FROM otptable 
          WHERE mobileno = '${mobileno}' AND otpcode = '${otpcode}' AND STATUS = 1 
          ORDER BY id DESC LIMIT 1
      `;
      const [otpResult] = await db.query(otpQuery);
      const currentT = `
         SELECT DATE_FORMAT(CONVERT_TZ(NOW(), '+00:00','+5:30'), '%Y-%m-%d %H:%i:%s') AS current_datetime
      `;
      const [currentTData] = await db.query(currentT);
      console.log('otpResult[0]?.validity', otpResult[0]?.validity);
      console.log('otpResult[0]', new Date(otpResult[0]?.validity));
      console.log('formattedDateTime', formattedDateTime);
      console.log('currentTData', currentTData[0]?.current_datetime)
      const otpInvaild = otpResult[0]?.validity <= formattedDateTime;
      const otpInvaild1 = otpResult[0]?.validity <= currentTData[0]?.current_datetime;
      console.log('otpInvaild', otpInvaild);
      console.log('otpInvaild1', otpInvaild1);

      if (otpResult.length === 0 || (otpInvaild == true || otpInvaild1 == true)) {
          resultStatus = 'ERROR';
          resultMessage = otpResult.length === 0 ? 'Invalid OTP or OTP expired' : 'OTP expired';
          return res.status(400).json({ status: resultStatus, message: resultMessage });
      }
      
      const tempDataQuery = `
        SELECT json_data 
        FROM temp_register 
        WHERE mobileno = '${mobileno}' AND deleted_at IS NULL 
        LIMIT 1
          `;
      const [tempDataResult] = await db.query(tempDataQuery);
      console.log('tempDataResult', tempDataResult);

      // Mark OTP as used and temp_register entry as deleted
      await db.query(`UPDATE otptable SET STATUS = 0 WHERE mobileno = '${mobileno}' AND otpcode = '${otpcode}'`);
      await db.query(`UPDATE temp_register SET deleted_at = CURRENT_TIMESTAMP WHERE mobileno = '${mobileno}' AND deleted_at IS NULL`);

      // if (tempDataResult.length === 0) {
      //     resultStatus = 'ERROR';
      //     resultMessage = 'User Details Not Found. Try Again Later.';
      //     return res.status(400).json({ status: resultStatus, message: resultMessage });
      // }

      // const jsonData = JSON.parse(tempDataResult[0].json_data);

      console.log('tempDataResult.length', tempDataResult.length);
      

      if (tempDataResult.length == 0) {
          resultStatus = 'SUCCESS';
          resultMessage = 'OTP verification successful';
          res.status(200).json({ status: resultStatus, message: resultMessage });
          console.log('Verify otp');
          
      } else {
      const jsonData = tempDataResult[0].json_data;
      console.log('jsonData', jsonData);

      console.log('Create User');

      // Extract JSON data
      const {
        username, password, name, email, schoolcodes, fullAddress, locationDetails,
        landmark, city, state, country, pincode, alternatemobileno
      } = jsonData;

      const v_status = 1;

      // let userUpdateQuery = `
      //   UPDATE users SET password = '${password}' WHERE username = '${username}' `;
      // const userUpdateResult = await db.query(userUpdateQuery);

        const userInsertResult = await db.query(
        `INSERT INTO users (username, password, name, email, mobileno) VALUES ('${username}','${password}', '${name}', '${email}', '${mobileno}')`,
        );
  
        const v_user_id = userInsertResult[0];

        for (const code of schoolcodes) {
            const schoolResult = await db.query(`SELECT schoolid FROM school WHERE schoolcode = '${code}' `);
            if (schoolResult[0].length > 0) {
                const schoolId = schoolResult[0][0].schoolid;
                await db.query(
                    `INSERT IGNORE INTO usersschoolmap (userid, schoolid) VALUES ('${v_user_id}', '${schoolId}')`,
                );
            }
        }

        await db.query(
            `INSERT INTO address (
                userid, name, fullAddress, locationDetails, landmark, city, state, country, 
                pincode, email, mobileno, alternatemobileno, status, 
                createdby, createdon, lastmodifiedby, lastmodifiedate
            ) VALUES ('${v_user_id}', '${name}', '${fullAddress}', '${locationDetails}', '${landmark}', '${city}', '${state}', '${country}', '${pincode}', '${email}', '${mobileno}', '${alternatemobileno}', '${v_status}', '${v_user_id}', '${formattedDateTime}', '${v_user_id}', '${formattedDateTime}')`
        );

        const roleResult = await db.query(`SELECT rolesid FROM roles WHERE name = 'online' LIMIT 1`);
        if (roleResult[0]?.length > 0) {
            const p_roleid = roleResult[0][0]?.rolesid;
            await db.query(`INSERT INTO userrolemap (userid, roleid) VALUES ('${v_user_id}', '${p_roleid}')`);
        } else {
            return res.status(400).json({ status: "ERROR", message: 'Role "online" not found' });
        }

      resultStatus = 'SUCCESS';
      resultMessage = 'OTP verification successful';

      emailTrigger(jsonData)

      res.status(200).json({ status: resultStatus, message: resultMessage });
    }

  } catch (error) {
      console.error('Error in verifyOTP:', error);
      res.status(500).json({ status: 'ERROR', message: 'Internal Server Error', error: error.message });
  }
};


// async function sendOTPviaMail(req, res, next) {
//   try {
//     if (!Object.keys(req.body).length) {
//       res.status(400).json({ status: false, message: "Invalid Request" });
//     }
//     if (!req.body.email) {
//       const err = new Error('Please enter email address');
//       err.statusCode = 400;
//       throw err
//     }
//     const email = req.body.email.toLowerCase()
//     let valid = await emailValidation({ email: email })
//     if (!valid.status) {
//       const err = new Error(valid.errors);
//       err.statusCode = 400;
//       throw err
//     }
//     // Store OTP in otptable
//     const validity = formattedDateTime;
//     validity.setMinutes(validity.getMinutes() + 10); // Set validity to 10 minutes
//     // Generate random 6-digit OTP
//     const otpcode = Math.floor(100000 + Math.random() * 900000);
//     const otp = {
//       email: email,
//       otp: otpcode,
//       validity: validity, // 
//       subject: 'Your OTP Code for Login', // Specify the subject for the email
//       message: `Your OTP code is: ${otpcode}. It will expire in 10 minutes. Please do not share it with anybody`, // Specify the text/content for the email
//     };
//     const sendEmail = await sendMail({ ...otp })
//     console.info(sendEmail);
//     if (!sendEmail) {
//       res.status(400).json({ status: false, message: "Unable to send OTP mail" });
//     }
//     const mobileno = '0987456123';
//     let otpDetails = await OTP.create({ mobileno, email, otpcode, validity });
//     res.status(201).send({ status: true, message: "OTP sucessfully sent to email" })
//   } catch (error) {
//     console.info(error)
//     next(error)
//   }
// };

// async function verifyOTPviaMail(req, res, next) {
//   try {
//     if (!Object.keys(req.body).length) {
//       const err = new Error('Invalid Request');
//       err.statusCode = 400;
//       throw err
//     }
//     let otpData = {
//       email: req.body.email.toLowerCase(),
//       otp: req.body.otp,
//     }
//     let valid = await validateOTP({ ...otpData })
//     if (!valid.status) {
//       const err = new Error(valid.errors);
//       err.statusCode = 400;
//       throw err
//     }
//     const email = otpData.email;
//     const otpcode = otpData.otp;
//     const otpDetails = await await OTP.findOne({
//       where: {
//         email,
//         otpcode,
//         status: 0, // Ensure OTP is not used yet
//       },
//     });
//     console.log(otpDetails);
//     if (otpDetails) {
//       let currentTime = new Date().getTime();
//       let diff = otpDetails.validity - currentTime;
//       if (diff < 0) {
//         res.status(401).json({ status: false, message: "The OTP has expired. Please request a new OTP." });
//       } else {
//         // Step 3: Update OTP status
//         await otpDetails.update({ status: 1 });
//         // Proceed to the next middleware
//         // next();
//         res.status(200).json({ status: true, message: "OTP is successfully verified" });
//       }
//     } else {
//       res.status(401).json({ status: false, message: "Invalid OTP" });
//     }
//   } catch (error) {
//     console.log(error)
//     next(error)
//   }
// };

export { sendOTP, verifyOTP};

