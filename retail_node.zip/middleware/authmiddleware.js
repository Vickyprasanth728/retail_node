import jwt from 'jsonwebtoken';
import User from '../models/UsersModel.js';
import CryptoJS from 'crypto-js';

async function VerifyToken(req, res, next) {  
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    try {
      const token = req.headers.authorization && req.headers.authorization.startsWith('Bearer') ?
      req.headers.authorization.split(' ')[1] : null;
      
    if (!token || token ===null ) {
      return res.status(401).json({issuccess: false, error:"Access denied. Token not provided."});
    }
    const decoded = jwt.verify(token, process.env.ACCESS_TOKEN_SECRET);
    if (!decoded.Email) {
      return res.status(401).json({issuccess: false, error:"Access denied. Invalid token." });
    }
    const user = await User.findOne({ where: {  email: decoded.Email }, attributes: { exclude: ['password'] }});
    if (!user) {
      return res.status(401).json({issuccess: false, error:"Access denied. User not found."});
    }
    if (!user.userid !== !decoded.userId) {
      return res.status(401).json({issuccess: false, error:"Error 001 -illegel Access denied. Not authorized."});
    }    
    req.user =user;
    next();
    } catch (error) {
      console.error(error);
      res.status(401).json({ issuccess: false, error: 'Not authorized, token failed', message: error.message });
    }
  }
  else
  {
    return res.status(401).json({issuccess: false, error:"Access denied. Token not provided."});
  }
}

async function admin(req, res, next) {
  try {
    const token = req.headers.authorization && req.headers.authorization.startsWith('Bearer') ?
      req.headers.authorization.split(' ')[1] : null;
      if (!token || token ===null) {
      return res.status(401).json({issuccess: false, error:"Access denied. Token not provided."});
    }
    const decoded = jwt.verify(token, process.env.ACCESS_TOKEN_SECRET);
    if (!decoded.userId) {
      return res.status(401).json({issuccess: false, error:"Access denied. Invalid token." });
    }
    if (!decoded.Email) {
      return res.status(401).json({issuccess: false, error:"Access denied. User not found."});
    }
    const user = await User.findOne({ where: {  email: decoded.Email }, attributes: { exclude: ['password'] }});    
    if (!user.isstaff) {
      return res.status(403).json({issuccess: false, error:"Not Authorized. Admin access required."});
    }
    if (!user.userid !== !decoded.userId) {
      return res.status(401).json({issuccess: false, error:"illegel Access denied. Not authorized."});
    }
    req.user =user;
    next();
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({issuccess: false, error:"Access denied. Token has expired."});
    } else {
      return res.status(401).json({issuccess: false, error:"Access denied. Invalid token."});
    }
  }
}

async function OtpVerifyToken(req, res, next) {
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    try {
      const token = req.headers.authorization && req.headers.authorization.startsWith('Bearer') ?
      req.headers.authorization.split(' ')[1] : null;
      if (!token || token ===null) {
      return res.status(401).json({issuccess: false, error:"Access denied. Token not provided."});
    }
    const decoded = jwt.verify(token, process.env.ACCESS_TOKEN_SECRET);
    if (!decoded.mobileno) {
      return res.status(401).json({issuccess: false, error:"Access denied. Invalid token." });
    }
    const user = await User.findOne({ where: {  mobileno: decoded.mobileno }, attributes: { exclude: ['password'] }});
    if (!user) {
      return res.status(401).json({issuccess: false, error:"Access denied. User not found.-1"});
    }
    if (!user.mobileno !== !decoded.mobileno) {
      return res.status(401).json({issuccess: false, error:"Error 001 -illegel Access denied. Not authorized."});
    }    
    req.user =user;
    next();
    } catch (error) {
      console.error(error);
      res.status(401).json({ issuccess: false, error: 'Not authorized, token failed', message: error.message });
    }
  }
}

const decryptPayload = (req, res, next) => {
  try {
    console.log(JSON.stringify(req.body));
    const bytes = CryptoJS.AES.decrypt(req.body.value, process.env.AES_ENC_SECRET);
    req.body = JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
    next();
  } catch (error) {
    console.error(error);
    res.status(500).json({ isSuccess: false, error: 'Payload decryption failed', message: error.message });
  }
};

// async function signIn(req, res) {
//   const { encryptedData } = req.body;
//   const decryptedData = decryptPayload(encryptedData, "encryptionKey");

//   console.log(decryptedData);

//   try {
//     // Define the password variable by accessing it from decryptedData
//     const { username, password } = decryptedData;

export { VerifyToken,OtpVerifyToken, admin,decryptPayload};