-- phpMyAdmin SQL Dump
-- version 5.1.1deb5ubuntu1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 02, 2024 at 04:52 PM
-- Server version: 8.0.40-0ubuntu0.22.04.1
-- PHP Version: 8.1.2-1ubuntu2.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `2cqr_retail`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`cqr`@`%` PROCEDURE `AssociateUserWithSchool` (IN `p_userid` BIGINT, IN `p_schoolcode` NVARCHAR(10))  BEGIN
    DECLARE school_id BIGINT;

    
    SELECT schoolid INTO school_id FROM school WHERE schoolcode = p_schoolcode;

    
    IF school_id IS NOT NULL THEN
        
        IF NOT EXISTS (SELECT 1 FROM usersschoolmap WHERE userid = p_userid AND schoolid = school_id) THEN
            
            INSERT INTO usersschoolmap (userid, schoolid) VALUES (p_userid, school_id);
            SELECT 'User created successfully' AS message;
        END IF;
     
     
    END IF;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `CheckSchoolCodes` (IN `p_schoolcodes` JSON, OUT `p_result_status` VARCHAR(20), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE idx INT DEFAULT 0;
    DECLARE total INT;
    DECLARE code VARCHAR(255);
    DECLARE school_id INT;
    DECLARE v_all_schools_valid BOOLEAN DEFAULT TRUE;
    DECLARE invalid_code VARCHAR(255) DEFAULT '';

    -- Initialize the result status and message
    SET p_result_status = 'SUCCESS';
    SET p_result_message = 'All school codes are valid';

    -- Get the length of the JSON array
    SET total = JSON_LENGTH(p_schoolcodes);

    -- Debugging: Print the input data
    SELECT p_schoolcodes AS INPUTDATA;

    -- Loop through each school code in the JSON array
    WHILE idx < total DO
        -- Extract the school code from the JSON array
        SET code = JSON_UNQUOTE(JSON_EXTRACT(p_schoolcodes, CONCAT('$[', idx, ']')));

        -- Check if the school code exists in the school table
        SELECT schoolid INTO school_id FROM school WHERE schoolcode = code;

        -- If the school code is not found, set the result status and message, and exit the loop
        IF school_id IS NULL THEN
            SET v_all_schools_valid = FALSE;
            SET invalid_code = code;
            SET idx = total; -- Exit the loop
        END IF;

        -- Increment the index to move to the next school code
        SET idx = idx + 1;
    END WHILE;

    -- Set the final status and message based on the validity of all school codes
    IF v_all_schools_valid THEN
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'All school codes are valid';
    ELSE
        SET p_result_status = 'FAILURE';
        SET p_result_message = CONCAT('School Code Not Found: ', invalid_code);
    END IF;

    -- Return the result status and message
    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `getInitAddProdcutDetails` ()  BEGIN

    CREATE TEMPORARY TABLE temp_category (
        id INT,
        name VARCHAR(255)
    );

    CREATE TEMPORARY TABLE temp_school (
        id INT,
        name VARCHAR(255)
    );

    CREATE TEMPORARY TABLE temp_gender (
        id INT,
        name VARCHAR(255)
    );

    CREATE TEMPORARY TABLE temp_size (
        id INT,
        name VARCHAR(255)
    );

    CREATE TEMPORARY TABLE temp_color (
        id INT,
        name VARCHAR(255)
    );

    CREATE TEMPORARY TABLE temp_gst (
        id INT,
        name VARCHAR(255)
    );


    INSERT INTO temp_category
    SELECT masterid AS id, mastername AS name FROM masters WHERE category = 0;

    INSERT INTO temp_school
    SELECT schoolid AS id, name FROM school WHERE status = 1;

    INSERT INTO temp_gender
    SELECT b.dataid AS id, b.name 
    FROM masters a 
    LEFT JOIN mastersdata b ON a.masterid = b.masterid
    WHERE a.category = 9998 AND a.mastername = 'Gender';

    INSERT INTO temp_size
    SELECT b.dataid AS id, b.name 
    FROM masters a 
    LEFT JOIN mastersdata b ON a.masterid = b.masterid
    WHERE a.category = 9998 AND a.mastername = 'Size';

    INSERT INTO temp_color
    SELECT b.dataid AS id, b.name 
    FROM masters a 
    LEFT JOIN mastersdata b ON a.masterid = b.masterid
    WHERE a.category = 9998 AND a.mastername = 'Color';

    INSERT INTO temp_gst
    SELECT id, name FROM gst WHERE status = 1;


    SELECT 
        JSON_OBJECT(
            'category', (SELECT JSON_ARRAYAGG(JSON_OBJECT('id', id, 'name', name)) FROM temp_category),
            'school', (SELECT JSON_ARRAYAGG(JSON_OBJECT('id', id, 'name', name)) FROM temp_school),
            'gender', (SELECT JSON_ARRAYAGG(JSON_OBJECT('id', id, 'name', name)) FROM temp_gender),
            'size', (SELECT JSON_ARRAYAGG(JSON_OBJECT('id', id, 'name', name)) FROM temp_size),
            'color', (SELECT JSON_ARRAYAGG(JSON_OBJECT('id', id, 'name', name)) FROM temp_color),
            'gst', (SELECT JSON_ARRAYAGG(JSON_OBJECT('id', id, 'name', name)) FROM temp_gst)
        ) AS result;


    DROP TEMPORARY TABLE IF EXISTS temp_category;
    DROP TEMPORARY TABLE IF EXISTS temp_school;
    DROP TEMPORARY TABLE IF EXISTS temp_gender;
    DROP TEMPORARY TABLE IF EXISTS temp_size;
    DROP TEMPORARY TABLE IF EXISTS temp_color;
    DROP TEMPORARY TABLE IF EXISTS temp_gst;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `OLD_SP_InsertAddress` (IN `p_userid` BIGINT, IN `p_name` VARCHAR(100), IN `p_Address1` VARCHAR(500), IN `p_Address2` VARCHAR(500), IN `p_Address3` VARCHAR(500), IN `p_Address4` VARCHAR(500), IN `p_Address5` VARCHAR(500), IN `p_Address6` VARCHAR(500), IN `p_Address7` VARCHAR(500), IN `p_Address8` VARCHAR(500), IN `p_Landmark` VARCHAR(500), IN `p_city` VARCHAR(100), IN `p_state` VARCHAR(100), IN `p_country` VARCHAR(100), IN `p_pincode` VARCHAR(6), IN `p_email` VARCHAR(50), IN `p_mobileno` VARCHAR(10), IN `p_alternatemobileno` VARCHAR(10), IN `p_isprimary` BIT, IN `p_iswork` BIT, IN `p_status` BIT, IN `p_createdby` BIGINT, IN `p_createdon` DATETIME, OUT `p_result_status` VARCHAR(10), OUT `p_result_message` VARCHAR(100))  BEGIN
    DECLARE result_count INT;

    
    INSERT INTO address (
        userid, name, Address1, Address2, Address3, Address4, Address5,
        Address6, Address7, Address8, Landmark, city, state, country, pincode,
        email, mobileno, alternatemobileno, isprimary, iswork, status,
        createdby, createdon, lastmodifiedby, lastmodifiedate
    )
    VALUES (
        p_userid, p_name, p_Address1, p_Address2, p_Address3, p_Address4,
        p_Address5, p_Address6, p_Address7, p_Address8, p_Landmark, p_city,
        p_state, p_country, p_pincode, p_email, p_mobileno,
        p_alternatemobileno, p_isprimary, p_iswork, p_status,
        p_createdby, p_createdon, p_createdby, p_createdon
    );

    
    SELECT ROW_COUNT() INTO result_count;

    IF result_count > 0 THEN
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Address inserted';
    ELSE
        SET p_result_status = 'ERROR';
        SET p_result_message = 'Address not inserted';
    END IF;

    
    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `OLD_SP_UpdateAddress` (IN `p_addressid` BIGINT, IN `p_userid` BIGINT, IN `p_name` VARCHAR(100), IN `p_Address1` VARCHAR(500), IN `p_Address2` VARCHAR(500), IN `p_Address3` VARCHAR(500), IN `p_Address4` VARCHAR(500), IN `p_Address5` VARCHAR(500), IN `p_Address6` VARCHAR(500), IN `p_Address7` VARCHAR(500), IN `p_Address8` VARCHAR(500), IN `p_Landmark` VARCHAR(500), IN `p_city` VARCHAR(100), IN `p_state` VARCHAR(100), IN `p_country` VARCHAR(100), IN `p_pincode` VARCHAR(6), IN `p_email` VARCHAR(50), IN `p_mobileno` VARCHAR(10), IN `p_alternatemobileno` VARCHAR(10), IN `p_isprimary` BIT, IN `p_iswork` BIT, IN `p_status` BIT, IN `p_lastmodifiedby` BIGINT, IN `p_lastmodifiedate` DATETIME, OUT `p_result_status` VARCHAR(10), OUT `p_result_message` VARCHAR(100))  BEGIN
    DECLARE address_exists INT;

    
    SELECT COUNT(*) INTO address_exists FROM address WHERE addressid = p_addressid;

    IF address_exists = 0 THEN
        SET p_result_status = 'ERROR';
        SET p_result_message = 'Address not found';
        SELECT p_result_status AS status, p_result_message AS message;
    ELSE
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Address updated';
        SELECT p_result_status AS status, p_result_message AS message;

        UPDATE address
        SET
            userid = p_userid,
            name = p_name,
            Address1 = p_Address1,
            Address2 = p_Address2,
            Address3 = p_Address3,
            Address4 = p_Address4,
            Address5 = p_Address5,
            Address6 = p_Address6,
            Address7 = p_Address7,
            Address8 = p_Address8,
            Landmark = p_Landmark,
            city = p_city,
            state = p_state,
            country = p_country,
            pincode = p_pincode,
            email = p_email,
            mobileno = p_mobileno,
            alternatemobileno = p_alternatemobileno,
            isprimary = p_isprimary,
            iswork = p_iswork,
            status = p_status,
            lastmodifiedby = p_lastmodifiedby
        WHERE addressid = p_addressid;
    END IF;

END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `OLD_SP_VerifyOTP` (IN `p_mobileno` VARCHAR(10), IN `p_otpcode` VARCHAR(6), OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    
    DECLARE v_validity DATETIME;
     
    DECLARE p_transtime DATETIME;
    
    
    
    SET p_transtime = CONVERT_TZ(NOW(), '+00:00', '+05:30');

    
    SELECT validity INTO v_validity
    FROM otptable
    WHERE mobileno = p_mobileno AND otpcode = p_otpcode AND STATUS = 1
    ORDER BY id DESC
    LIMIT 1;

    
    IF v_validity IS NOT NULL AND v_validity > p_transtime THEN
        
        UPDATE otptable
        SET STATUS = 0
        WHERE mobileno = p_mobileno AND otpcode = p_otpcode;
		  
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'OTP verification successful';
    ELSE
        
        SET p_result_status = 'ERROR';
        SET p_result_message = 'Invalid OTP or OTP already used or expired';
    END IF;
    SELECT p_result_status AS status, p_result_message AS message ,v_validity AS validity;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SearchProductMiniDetailsOverall` (IN `p_subdataid` BIGINT, IN `p_submasterid` BIGINT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE result_count INT; 

    
    SELECT COUNT(*) INTO result_count
    FROM
        product a 
    LEFT JOIN
        productschoolmap b ON a.productid = b.productid
    LEFT JOIN
        productimage c ON a.productid = c.productid
    LEFT JOIN
        producttext d ON d.productid = a.productid
    WHERE
        d.subdataid IN (p_subdataid) AND d.submasterid IN (p_submasterid)
    GROUP BY
        a.productid;


 IF result_count > 0 THEN
        
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Data retrieved successfully';
        SELECT p_result_status AS status, p_result_message AS message;
    
    SELECT
        a.name,
        a.price,
        GROUP_CONCAT(TO_BASE64(c.image) SEPARATOR ', ') AS images
    FROM
        product a
    LEFT JOIN
        productschoolmap b ON a.productid = b.productid
    LEFT JOIN
        productimage c ON a.productid = c.productid 
    LEFT JOIN
        producttext d ON d.productid = a.productid 
    WHERE
         d.subdataid IN (p_subdataid) AND d.submasterid IN (p_submasterid)
    GROUP BY
        a.productid
    ORDER BY
        a.lastmodifiedate DESC;
    ELSE
        
        SET p_result_status = 'ERROR';
        SET p_result_message = 'No data found';
        SELECT p_result_status AS status, p_result_message AS message;
    END IF;

    
   
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_AddProduct` (IN `p_barcode` VARCHAR(100), IN `p_masterid` BIGINT, IN `p_submasterid` JSON, IN `p_subdataid` JSON, IN `p_name` VARCHAR(100), IN `p_description` VARCHAR(500), IN `p_price` DECIMAL(10,2), IN `p_gst` DECIMAL(10,2), IN `p_discount` DECIMAL(10,2), IN `p_productstatus` VARCHAR(100), IN `p_ispublic` BIT(1), IN `p_isuniform` BIT(1), IN `p_createdon` DATETIME, IN `p_createdby` BIGINT, IN `p_schoolid` JSON, IN `p_imageseq` JSON, IN `p_image` JSON, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE product_exists INT;
    DECLARE p_productid BIGINT;
    DECLARE idx INT DEFAULT 0;
    DECLARE code VARCHAR(50);
    DECLARE code1 VARCHAR(50);
    DECLARE code2 VARCHAR(50);
    DECLARE codeimage LONGTEXT; 

    
    SELECT COUNT(*) INTO product_exists
    FROM product
    WHERE barcode COLLATE utf8mb4_unicode_ci = p_barcode COLLATE utf8mb4_unicode_ci;

    IF product_exists > 0 THEN
        
        SET p_result_status = 'ERROR';
        SET p_result_message = 'Product already exists';
    ELSE
        
        INSERT INTO product (
            barcode, masterid, name, description, price, gst, discount,
            productstatus, ispublic, isuniform, createdon, createdby
        )
        VALUES (
            p_barcode, p_masterid, p_name, p_description, p_price,
            p_gst, p_discount, p_productstatus, p_ispublic, p_isuniform, p_createdon, p_createdby
        );

        SET p_productid = LAST_INSERT_ID();

        
        WHILE idx < JSON_LENGTH(p_schoolid) DO
            SET code = JSON_UNQUOTE(JSON_EXTRACT(p_schoolid, CONCAT('$[', idx, ']')));

            
            INSERT INTO productschoolmap (productid, schoolid)
            VALUES (p_productid, code);

            SET idx = idx + 1; 
        END WHILE;

        
        SET idx = 0;

        
        WHILE idx < JSON_LENGTH(p_imageseq) DO
            SET code = JSON_UNQUOTE(JSON_EXTRACT(p_imageseq, CONCAT('$[', idx, ']')));

            
            INSERT INTO productimage (productid, imageseq, image)
            VALUES (p_productid, code, NULL); 

            
            IF JSON_LENGTH(p_image) IS NOT NULL AND JSON_LENGTH(p_image) > 0 THEN
                SET codeimage = JSON_UNQUOTE(JSON_EXTRACT(p_image, CONCAT('$[', idx, ']')));

                
                UPDATE productimage
                SET image = FROM_BASE64(codeimage)
                WHERE productid = p_productid AND imageseq = code;

            END IF;

            SET idx = idx + 1; 
        END WHILE;

        
        SET idx = 0;

        
        WHILE idx < JSON_LENGTH(p_submasterid) AND idx < JSON_LENGTH(p_subdataid) DO
            SET code1 = JSON_UNQUOTE(JSON_EXTRACT(p_submasterid, CONCAT('$[', idx, ']')));
            SET code2 = JSON_UNQUOTE(JSON_EXTRACT(p_subdataid, CONCAT('$[', idx, ']')));

            
            INSERT INTO producttext (productid, submasterid, subdataid)
            VALUES (p_productid, code1, code2);

            SET idx = idx + 1; 
        END WHILE;

        
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Product added successfully';

    END IF;

    COMMIT;
            	
    		SELECT p_result_status AS status, p_result_message AS message ;
    		SELECT p_schoolid,p_imageseq,p_image;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_AddStaff` (IN `p_username` VARCHAR(50), IN `p_password` VARCHAR(150), IN `p_name` VARCHAR(100), IN `p_email` VARCHAR(50), IN `p_mobileno` VARCHAR(10), IN `p_roleid` INT, IN `p_Address1` VARCHAR(500), IN `p_Address2` VARCHAR(500), IN `p_Address3` VARCHAR(500), IN `p_Address4` VARCHAR(500), IN `p_Address5` VARCHAR(500), IN `p_Address6` VARCHAR(500), IN `p_Address7` VARCHAR(500), IN `p_Address8` VARCHAR(500), IN `p_Landmark` VARCHAR(500), IN `p_city` VARCHAR(100), IN `p_state` VARCHAR(100), IN `p_country` VARCHAR(100), IN `p_pincode` VARCHAR(6), IN `p_alternatemobileno` VARCHAR(10), IN `p_isprimary` BIT, IN `p_iswork` BIT, IN `p_status` BIT, IN `p_createdby` BIGINT, IN `p_createdon` DATETIME, IN `p_schoolcodes` JSON, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE v_username_count INT;
    DECLARE v_mobileno_count INT;
    DECLARE v_email_count INT;
   	DECLARE v_all_schools_valid BOOLEAN DEFAULT TRUE;
    DECLARE v_user_id BIGINT;
     DECLARE school_id BIGINT;
    DECLARE idx INT DEFAULT 0;
    DECLARE code VARCHAR(50);
    DECLARE v_result_status VARCHAR(10);
    DECLARE v_result_message VARCHAR(100);
    DECLARE is_user_exists BOOLEAN;
    SET p_result_status = 'FAILURE';
    SET p_result_message = 'Error While Add Staff Details';
    
    
    SELECT COUNT(*) INTO v_username_count FROM users WHERE username = p_username;
    SELECT COUNT(*) INTO v_mobileno_count FROM users WHERE mobileno = p_mobileno;
    SELECT COUNT(*) INTO v_email_count FROM users WHERE email = p_email;
    WHILE idx < JSON_LENGTH(p_schoolcodes) DO
    SET code = JSON_UNQUOTE(JSON_EXTRACT(p_schoolcodes, CONCAT('$[', idx, ']')));

    
    SELECT schoolid INTO school_id FROM school WHERE schoolcode = code;

    IF school_id IS NULL THEN
        
        -- SET v_all_schools_valid = FALSE;
      --  SET p_result_status = 'FAILURE';
       -- SET p_result_message = 'School Code Not Found';
        
  -- SELECT p_result_status AS status, p_result_message AS message;
        SET idx = JSON_LENGTH(p_schoolcodes); 
    END IF;

    SET idx = idx + 1;
END WHILE;


    
    IF v_username_count > 0 THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'Username already exists';
        
   SELECT p_result_status AS status, p_result_message AS message;
    ELSEIF v_mobileno_count > 0 THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'Mobile number already exists';
        
   SELECT p_result_status AS status, p_result_message AS message;
    ELSEIF v_email_count > 0 THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'Email already exists';
        
   SELECT p_result_status AS status, p_result_message AS message;
    ELSEIF LENGTH(p_mobileno) <> 10 THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'Mobile number must be a 10-digit number';
        
   SELECT p_result_status AS status, p_result_message AS message;
   ELSEIF LENGTH(p_pincode) <> 6 THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'Pin code must be a 6-digit number';
        
   SELECT p_result_status AS status, p_result_message AS message;
   ELSEIF LENGTH(p_email) > 0 AND NOT REGEXP_LIKE(p_email, '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+.[A-Z|a-z]{2,}$') THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'Invalid email format';  
        
   SELECT p_result_status AS status, p_result_message AS message;
	ELSEIF NOT v_all_schools_valid THEN
    		SET p_result_status = 'FAILURE';
    		SET p_result_message = 'School Code Not Found';  
   SELECT p_result_status AS status, p_result_message AS message;
   
        ELSEIF NOT EXISTS (SELECT 1 FROM roles WHERE rolesid = p_roleid) THEN
        		SET p_result_status = 'FAILURE';
            SET p_result_message = 'Role ID does not exist';
            
   SELECT p_result_status AS status, p_result_message AS message;
	ELSE        
        INSERT INTO users (username, password, name,  email, mobileno,isstaff,createdby)
        VALUES (p_username, p_password, p_name, p_email, p_mobileno,1,p_createdby);        

        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Staff created successfully';
        
   SELECT p_result_status AS status, p_result_message AS message;
        
        SELECT userid INTO v_user_id FROM users WHERE email = p_email;
        
                
        WHILE idx < JSON_LENGTH(p_schoolcodes) DO
            
            SET code = JSON_UNQUOTE(JSON_EXTRACT(p_schoolcodes, CONCAT('$[', idx, ']')));

            
            SELECT schoolid INTO school_id FROM school WHERE schoolcode = code;

            IF school_id IS NOT NULL THEN
                
                IF NOT EXISTS (SELECT 1 FROM usersschoolmap WHERE userid = v_user_id AND schoolid = school_id) THEN
                    
                    INSERT INTO usersschoolmap (userid, schoolid) VALUES (v_user_id, school_id);
                END IF;
            END IF;

            SET idx = idx + 1;
        END WHILE;
        
    CALL SP_InsertAddress(
        v_user_id,
        p_name,
        p_Address1,
        p_Address2,
        p_Address3,
        p_Address4,
        p_Address5,
        p_Address6,
        p_Address7,
        p_Address8,
        p_Landmark,
        p_city,
        p_state,
        p_country,
        p_pincode,
        p_email,
        p_mobileno,
        p_alternatemobileno,
        1,
        0,
        1,
        v_user_id,
        p_createdon,
        @v_result_status,
        @v_result_message
    );
    
    
   
        
    CALL SP_AssignRoleToUser(v_user_id,p_roleid,@v_result_status,@v_result_message);
    
    
            
   
   
   
   
  
  
  
   
    
    END IF;	   
	 
   SELECT p_result_status AS status, p_result_message AS message;  
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_Addtocart` (IN `p_userid` BIGINT, IN `p_productid` BIGINT, OUT `p_result_status` VARCHAR(10), OUT `p_result_message` VARCHAR(100))  BEGIN
    DECLARE result_count INT;

    
    SELECT COUNT(*) INTO result_count FROM addtocarttable WHERE userid = p_userid AND productid = p_productid AND STATUS = 'incart' ;

    
    IF result_count > 0 THEN
        SET p_result_status = 'ERROR';
        SET p_result_message = 'Record with the same userid and productid already exists';
    ELSE
        
        INSERT INTO addtocarttable (userid, productid) VALUES (p_userid, p_productid);

        
        SELECT ROW_COUNT() INTO result_count;

        
        IF result_count > 0 THEN
            SET p_result_status = 'SUCCESS';
            SET p_result_message = 'Record inserted into addtocarttable';
        ELSE
            SET p_result_status = 'ERROR';
            SET p_result_message = 'Record not inserted into addtocarttable';
        END IF;
    END IF;

    
    SELECT result_count AS affected_rows, p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_Admin_DB_GetOrderDetailsByStatusAndIsUniform` (IN `p_status` VARCHAR(50), IN `p_pageno` INT, IN `p_index` INT, IN `p_schoolid` BIGINT(19), OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE start_index INT DEFAULT 0;
    -- Check if the school is mapped
    DECLARE school_mapped INT;
    SET start_index := (p_pageno - 1) * p_index;

    
    SELECT COUNT(*) INTO school_mapped FROM productschoolmap WHERE schoolid = p_schoolid;

    IF school_mapped = 0 THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'School is not mapped';
        SELECT p_result_status AS status, p_result_message AS message;
    ELSE
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Order details retrieved successfully';
        SELECT p_result_status AS status, p_result_message AS message;

        SELECT 
            a.lastmodifiedat,
            a.id AS TransID,
            a.status,
            a.ordernumber,
            JSON_OBJECT("userid", MAX(a.userid)) AS User_details,
            JSON_OBJECT(
                "addressid", IFNULL(MAX(e.addressid), ""),
                "address_name", IFNULL(MAX(e.name), ""),
                "addressline1", IFNULL(MAX(e.address1), ""),
                "addressline2", IFNULL(MAX(e.address2), ""),
                "city", IFNULL(MAX(e.city), ""),
                "pincode", IFNULL(MAX(e.pincode), "")
            ) AS address_details,
            JSON_ARRAYAGG(
                JSON_OBJECT(
                    "productid", b.productid,
                    "name", b.name,
                    "description", b.description,
                    "price", b.price
                )
            ) AS products
        FROM
            transactions a
            LEFT JOIN product b ON a.productid = b.productid
            LEFT JOIN address e ON e.addressid = a.addressid
        WHERE
            a.status = p_status
            AND EXISTS (SELECT 1 FROM productschoolmap WHERE productid = a.productid AND schoolid = p_schoolid)
        GROUP BY
            a.ordernumber, a.lastmodifiedat, a.id
        ORDER BY
            MAX(a.lastmodifiedat) DESC
        LIMIT 
            start_index, p_index;
    END IF;

    
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_Admin_DB_GetOverallOrderLength` (OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    -- Initialize variables
    DECLARE packed_count INT;
    DECLARE ordered_count INT;
    DECLARE shipped_count INT;
    DECLARE billed_count INT;
    DECLARE uniform_count INT;
    DECLARE normal_count INT;

    -- Retrieve counts
    SELECT 
        COUNT(CASE WHEN status = 'Packed' THEN 1 END) AS packed_count,
        COUNT(CASE WHEN status = 'Ordered' THEN 1 END) AS ordered_count,
        COUNT(CASE WHEN status = 'Shipped' THEN 1 END) AS shipped_count,
        COUNT(CASE WHEN status = 'Billed' THEN 1 END) AS billed_count,
        (SELECT COUNT(*) FROM transactions t JOIN productschoolmap p ON t.productid = p.productid WHERE p.schoolid IS NOT NULL AND p.schoolid != '') AS uniform_count,
        (SELECT COUNT(*) FROM transactions t LEFT JOIN productschoolmap p ON t.productid = p.productid WHERE p.productid IS NULL OR (p.schoolid IS NULL OR p.schoolid = '')) AS normal_count
    INTO
        packed_count,
        ordered_count,
        shipped_count,
        billed_count,
        uniform_count,
        normal_count
    FROM transactions;

    -- Set result status and message
    SET p_result_status = 'SUCCESS';
    SET p_result_message = 'Overall order length retrieved successfully';
 SELECT p_result_status AS status,
        p_result_message AS message;
    -- Return counts
    SELECT 
        packed_count,
        ordered_count,
        shipped_count,
        billed_count,
        uniform_count,
        normal_count;              
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_AssignRoleToUser` (IN `p_userid` BIGINT, IN `p_rolesid` BIGINT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    
    SET p_result_status = 'FAILURE';
    SET p_result_message = 'Error assigning role to user';

    
    IF NOT EXISTS (SELECT 1 FROM users WHERE userid = p_userid) THEN
        SET p_result_message = 'User ID does not exist';
    ELSE
        
        IF NOT EXISTS (SELECT 1 FROM roles WHERE rolesid = p_rolesid) THEN
            SET p_result_message = 'Role ID does not exist';
        ELSE
            
            INSERT INTO userrolemap (userid, roleid)
            VALUES (p_userid, p_rolesid);

            
            SET p_result_status = 'SUCCESS';
            SET p_result_message = 'Role assigned to user successfully';
        END IF;
    END IF;

    
    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_CancelOrder` (IN `p_transtableid` INT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    
    SET p_result_status = 'FAILURE';
    SET p_result_message = 'transactions id not exists';

    
    IF EXISTS (
        SELECT 1
        FROM `transactions`
        WHERE id = p_transtableid
    ) THEN
        
        UPDATE `transactions`
        SET status = 'cancelinitiated'
        WHERE id = p_transtableid;

        
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Order canceled successfully';
    ELSE
        
        SET p_result_message = 'transactions id does not exist';
    END IF;

    
    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_CheckAuth` (IN `p_UserID` INT, IN `p_ModuleID` INT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    
    SET p_result_status = 'FAILURE';
    SET p_result_message = 'Error retrieving role details';

    
    IF EXISTS (
        SELECT 1
        FROM usermodulemap umm
        INNER JOIN module m ON umm.moduleid = m.moduleid
        WHERE umm.userid = p_UserID AND m.moduleid = p_ModuleID
    ) THEN
        
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'User has access to the module.';
    ELSE
        
        SET p_result_message = CONCAT('Not Authorized. User does not have permission to access module with ID ', p_ModuleID);
    END IF;

    
    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_CheckUniqueSchoolcode` (IN `p_schoolcode` VARCHAR(255), OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE code_count INT;

    
    SELECT COUNT(*) INTO code_count
    FROM school
    WHERE schoolcode = p_schoolcode;

    IF code_count = 0 THEN
        
        SET p_result_status = 'ERROR';
        SET p_result_message = 'School code does not exist';
    ELSE
        
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'School code present';
    END IF;
     SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_CreateRole` (IN `p_name` VARCHAR(20), IN `p_role` VARCHAR(50), IN `p_defaultmodule` BIGINT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    SET p_result_status = 'FAILURE';
    SET p_result_message = 'Error creating role';

    IF (SELECT COUNT(*) FROM module WHERE moduleid = p_defaultmodule) = 0 THEN
        SET p_result_message = 'Default module does not exist';
    ELSE
        -- Check if the role with the given name already exists
        IF (SELECT COUNT(*) FROM roles WHERE name = p_name) > 0 THEN
            SET p_result_message = 'Role with the same name already exists';
        ELSE
            -- Construct the dynamic query
            SET @sql = CONCAT('INSERT INTO roles (name, role, defaultmodule) VALUES (\'', p_name, '\', b\'', p_role, '\', ', p_defaultmodule, ')');

            -- Prepare and execute the dynamic query
            PREPARE stmt FROM @sql;
            EXECUTE stmt;
            DEALLOCATE PREPARE stmt;

            SET p_result_status = 'SUCCESS';
            SET p_result_message = 'Role created successfully';
        END IF;
    END IF;

    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_DB_AdminTransactionsCount` (IN `p_startdate` DATETIME, IN `p_enddate` DATETIME, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    -- Initialize result status and message
    SET p_result_status = 'SUCCESS';
    SET p_result_message = 'Transaction counts retrieved successfully';
        
    SELECT p_result_status AS status, p_result_message AS message;

    -- Retrieve transaction counts
    SELECT
        COALESCE(SUM(CASE WHEN t.status = 'initiated' THEN 1 ELSE 0 END), 0) AS initiated_count,
        COALESCE(SUM(CASE WHEN t.status = 'ordered' THEN 1 ELSE 0 END), 0) AS ordered_count,
        COALESCE(SUM(CASE WHEN t.status = 'shipped' THEN 1 ELSE 0 END), 0) AS shipped_count,
        COALESCE(SUM(CASE WHEN t.status = 'outfordelivery' THEN 1 ELSE 0 END), 0) AS outfordelivery_count,
        COALESCE(SUM(CASE WHEN t.status = 'delivered' THEN 1 ELSE 0 END), 0) AS delivered_count,
        COALESCE(SUM(CASE WHEN t.status = 'deliverfail' THEN 1 ELSE 0 END), 0) AS deliverfail_count,
        COALESCE(SUM(CASE WHEN t.status = 'cancelinitiated' THEN 1 ELSE 0 END), 0) AS cancelinitiated_count,
        COALESCE(SUM(CASE WHEN t.status = 'returninitiated' THEN 1 ELSE 0 END), 0) AS returninitiated_count,
        COALESCE(SUM(CASE WHEN t.status = 'outforreturn' THEN 1 ELSE 0 END), 0) AS outforreturn_count,
        COALESCE(SUM(CASE WHEN t.status = 'returnfail' THEN 1 ELSE 0 END), 0) AS returnfail_count,
        COALESCE(SUM(CASE WHEN t.status = 'refundinitiated' THEN 1 ELSE 0 END), 0) AS refundinitiated_count,
        COALESCE(SUM(CASE WHEN t.status = 'refundfail' THEN 1 ELSE 0 END), 0) AS refundfail_count,
        COALESCE(SUM(CASE WHEN t.status = 'refunddone' THEN 1 ELSE 0 END), 0) AS refunddone_count,
        COALESCE(SUM(CASE WHEN t.status = 'paymentfailed' THEN 1 ELSE 0 END), 0) AS paymentfailed_count,
        COALESCE(SUM(CASE WHEN t.status = 'packed' THEN 1 ELSE 0 END), 0) AS packed_count,
         COALESCE(SUM(CASE WHEN t.status = 'returned' THEN 1 ELSE 0 END), 0) AS returned_count,
        COALESCE((SUM(CASE WHEN t.status = 'initiated' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS initiated_percentage,
        COALESCE((SUM(CASE WHEN t.status = 'ordered' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS ordered_percentage,
        COALESCE((SUM(CASE WHEN t.status = 'shipped' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS shipped_percentage,
        COALESCE((SUM(CASE WHEN t.status = 'outfordelivery' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS outfordelivery_percentage,
        COALESCE((SUM(CASE WHEN t.status = 'delivered' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS delivered_percentage,
        COALESCE((SUM(CASE WHEN t.status = 'deliverfail' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS deliverfail_percentage,
        COALESCE((SUM(CASE WHEN t.status = 'cancelinitiated' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS cancelinitiated_percentage,
        COALESCE((SUM(CASE WHEN t.status = 'returninitiated' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS returninitiated_percentage,
        COALESCE((SUM(CASE WHEN t.status = 'outforreturn' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS outforreturn_percentage,
        COALESCE((SUM(CASE WHEN t.status = 'returnfail' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS returnfail_percentage,
        COALESCE((SUM(CASE WHEN t.status = 'refundinitiated' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS refundinitiated_percentage,
        COALESCE((SUM(CASE WHEN t.status = 'refundfail' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS refundfail_percentage,
        COALESCE((SUM(CASE WHEN t.status = 'refunddone' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS refunddone_percentage,
        COALESCE((SUM(CASE WHEN t.status = 'paymentfailed' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS paymentfailed_percentage,
        COALESCE((SUM(CASE WHEN t.status = 'packed' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS packed_percentage,
         COALESCE((SUM(CASE WHEN t.status = 'returned' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS returned_percentage
    FROM transactions t
    JOIN product p ON t.productid = p.productid
    WHERE t.createdon BETWEEN p_startdate AND p_enddate;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_DB_AllGetOrderDetails` (IN `p_index` INT, IN `p_pageno` INT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE start_index INT;
    DECLARE offset_val INT;
    
    SET p_result_message = 'Transaction ID does not exist';

    IF EXISTS (
        SELECT 1
        FROM `transactions`
    ) THEN    
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Order details retrieved successfully';   
		  SELECT p_result_status AS status, p_result_message AS message; 

        -- Calculate start index and offset
        SET start_index = (p_pageno - 1) * p_index;
        SET offset_val = start_index + p_index;

              --  JSON_OBJECT("image", IFNULL(TO_BASE64(c.image), ""), "imageseq", IFNULL(c.imageseq, "")) AS image_details,
        -- Prepare and execute dynamic SQL
        SET @sql = CONCAT(
            'SELECT a.lastmodifiedat,a.id AS TransID ,a.status,
    a.ordernumber,
    JSON_OBJECT("userid", MAX(a.userid)) AS User_details,
    JSON_OBJECT(
    		"addressid",IFNULL(MAX(e.addressid), ""),
        "address_name", IFNULL(MAX(e.name), ""),
        "addressline1", IFNULL(MAX(e.address1), ""),
        "addressline2", IFNULL(MAX(e.address2), ""),
        "city", IFNULL(MAX(e.city), ""),
        "pincode", IFNULL(MAX(e.pincode), "")
    ) AS address_details,
    JSON_ARRAYAGG(
        JSON_OBJECT(
            "productid", b.productid,
            "name", b.name,
            "description", b.description,
            "price", b.price
        )
    ) AS products
FROM
    transactions a
    LEFT JOIN product b ON a.productid = b.productid
    LEFT JOIN address e ON e.addressid = a.addressid
GROUP BY
    a.ordernumber,a.lastmodifiedat,a.id
ORDER BY
    MAX(a.lastmodifiedat) DESC
LIMIT ', start_index, ', ', offset_val
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
        
    ELSE
        SET p_result_message = 'User has no orders';
        SET p_result_status = 'SUCCESS';
        SELECT p_result_status AS status, p_result_message AS message;
        SELECT NULL AS empty_result WHERE FALSE;
    END IF;

END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_DB_AllGetOrderDetailsByStatus` (IN `p_status` VARCHAR(50), IN `p_pageno` INT, IN `p_index` INT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE start_index INT;
    DECLARE offset_val INT;

    SET p_result_message = 'Transaction ID does not exist';

    IF EXISTS (
        SELECT 1
        FROM `transactions`
        WHERE status = p_status
    ) THEN
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Order details retrieved successfully';
SELECT p_result_status AS status, p_result_message AS message;
        -- Calculate start index and offset
        SET start_index = (p_pageno - 1) * p_index;
        SET offset_val = p_index;

        -- Prepare and execute dynamic SQL
        SET @sql = CONCAT(
            'SELECT a.lastmodifiedat,a.id AS TransID ,a.status,
    a.ordernumber,
    JSON_OBJECT("userid", MAX(a.userid)) AS User_details,
    JSON_OBJECT(
    		"addressid",IFNULL(MAX(e.addressid), ""),
        "address_name", IFNULL(MAX(e.name), ""),
        "addressline1", IFNULL(MAX(e.address1), ""),
        "addressline2", IFNULL(MAX(e.address2), ""),
        "city", IFNULL(MAX(e.city), ""),
        "pincode", IFNULL(MAX(e.pincode), "")
    ) AS address_details,
    JSON_ARRAYAGG(
        JSON_OBJECT(
            "productid", b.productid,
            "name", b.name,
            "description", b.description,
            "price", b.price
        )
    ) AS products
FROM
    transactions a
    LEFT JOIN product b ON a.productid = b.productid
    LEFT JOIN address e ON e.addressid = a.addressid
            WHERE
                a.status = ', QUOTE(p_status), '
            GROUP BY
                a.ordernumber,a.lastmodifiedat,a.id
            ORDER BY
                MAX(a.lastmodifiedat) DESC
            LIMIT ', start_index, ', ', offset_val
        );

        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;

    ELSE
         SET p_result_message = 'No Data Found';
        SET p_result_status = 'SUCCESS';
        SELECT p_result_status AS status, p_result_message AS message;
        SELECT NULL AS empty_result WHERE FALSE;
    END IF;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_DB_GetOrderDetailsByOrdernumber` (IN `p_userid` INT, IN `p_ordernumber` VARCHAR(50), OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    
    SET p_result_status = 'FAILURE';
    SET p_result_message = 'Transaction ID does not exist';
    IF EXISTS (
        SELECT 1
        FROM `transactions`
        WHERE userid = p_userid
    ) THEN    
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Order details retrieved successfully';    
        SELECT p_result_status AS status, p_result_message AS message;        
        SET @sql = CONCAT(
            'SELECT a.lastmodifiedat,a.id AS TransID ,a.status,
                a.ordernumber,
                JSON_OBJECT("userid", a.userid) AS User_details,
                JSON_OBJECT(
                		"addressid",IFNULL(MAX(e.addressid), ""),
                    "address_name", IFNULL(MAX(e.name), ""),
                    "addressline1", IFNULL(MAX(e.address1), ""),
                    "addressline2", IFNULL(MAX(e.address2), ""),
                    "city", IFNULL(MAX(e.city), ""),
                    "pincode", IFNULL(MAX(e.pincode), "")
                ) AS address_details,
                JSON_ARRAYAGG(
                    JSON_OBJECT(
                        "productid", b.productid,
                        "name", b.name,
                        "description", b.description,
                        "price", b.price
                    )
                ) AS products
            FROM
                `transactions` a
                LEFT JOIN product b ON a.productid = b.productid
                LEFT JOIN address e ON e.addressid = a.addressid
            WHERE
                a.userid = ', p_userid, '
                AND a.ordernumber = "', p_ordernumber, '"
            GROUP BY
                a.ordernumber,a.lastmodifiedat,a.id ,
            ORDER BY
                MAX(a.lastmodifiedat) DESC'
        );         
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;        
    ELSE
        
       SET p_result_message = 'User has no orders';
        SET p_result_status = 'SUCCESS';
        SELECT p_result_status AS status, p_result_message AS message;
        SELECT NULL AS empty_result WHERE FALSE;
    END IF;

    
    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_DB_GetRevenueTrend` (IN `p_startdate` DATE, IN `p_enddate` DATE, IN `p_status` VARCHAR(15), IN `p_chart_type` VARCHAR(15), OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    -- Initialize output parameters
    SET p_result_status = 'SUCCESS';
    SET p_result_message = 'Revenue trend retrieved successfully';

    -- Return status and message
    SELECT p_result_status AS status, p_result_message AS message;

    -- Set max recursion depth
    SET @@cte_max_recursion_depth = 20000; -- or any other larger value you need

    -- Retrieve revenue trend data based on chart type
    IF p_chart_type = 'day' THEN
        WITH RECURSIVE date_range AS (
            SELECT p_startdate AS date_value
            UNION ALL
            SELECT DATE_ADD(date_value, INTERVAL 1 DAY)
            FROM date_range
            WHERE date_value < p_enddate
        )
        SELECT 
            dr.date_value AS x_data,
            COALESCE(SUM(p.price), 0.00) AS y_data
        FROM date_range dr
        LEFT JOIN transactions t ON DATE(t.createdon) = dr.date_value AND t.status = p_status
        LEFT JOIN product p ON t.productid = p.productid
        GROUP BY dr.date_value
        ORDER BY dr.date_value;

    ELSEIF p_chart_type = 'month' THEN
        WITH RECURSIVE date_range AS (
            SELECT DATE_FORMAT(p_startdate, '%Y-%m-01') AS date_value
            UNION ALL
            SELECT DATE_FORMAT(DATE_ADD(date_value, INTERVAL 1 MONTH), '%Y-%m-01')
            FROM date_range
            WHERE date_value < DATE_FORMAT(p_enddate, '%Y-%m-01')
        )
        SELECT 
            DATE_FORMAT(dr.date_value, '%Y-%m') AS x_data,
            COALESCE(SUM(p.price), 0.00) AS y_data
        FROM date_range dr
        LEFT JOIN transactions t ON DATE_FORMAT(t.createdon, '%Y-%m') = DATE_FORMAT(dr.date_value, '%Y-%m') AND t.status = p_status
        LEFT JOIN product p ON t.productid = p.productid
        GROUP BY DATE_FORMAT(dr.date_value, '%Y-%m')
        ORDER BY DATE_FORMAT(dr.date_value, '%Y-%m');

    ELSEIF p_chart_type = 'year' THEN
        WITH RECURSIVE date_range AS (
            SELECT DATE_FORMAT(p_startdate, '%Y-01-01') AS date_value
            UNION ALL
            SELECT DATE_FORMAT(DATE_ADD(date_value, INTERVAL 1 YEAR), '%Y-01-01')
            FROM date_range
            WHERE date_value < DATE_FORMAT(p_enddate, '%Y-01-01')
        )
        SELECT 
            DATE_FORMAT(dr.date_value, '%Y') AS x_data,
            COALESCE(SUM(p.price), 0.00) AS y_data
        FROM date_range dr
        LEFT JOIN transactions t ON DATE_FORMAT(t.createdon, '%Y') = DATE_FORMAT(dr.date_value, '%Y') AND t.status = p_status
        LEFT JOIN product p ON t.productid = p.productid
        GROUP BY DATE_FORMAT(dr.date_value, '%Y')
        ORDER BY DATE_FORMAT(dr.date_value, '%Y');

    END IF;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_DB_GetRevenueTrendByDayCount` (IN `p_DayCount` VARCHAR(15), IN `p_status` VARCHAR(15), OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE p_startdate DATE;
    DECLARE p_enddate DATE;
    SET @@cte_max_recursion_depth = 20000;

    -- Determine the start and end dates based on the provided day count
    CASE p_DayCount
        WHEN '7' THEN
            SET p_startdate = DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY);
        WHEN '30' THEN
            SET p_startdate = DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY);
        WHEN '60' THEN
            SET p_startdate = DATE_SUB(CURRENT_DATE(), INTERVAL 60 DAY);
        WHEN '180' THEN
            SET p_startdate = DATE_SUB(CURRENT_DATE(), INTERVAL 180 DAY);
        WHEN '365' THEN
            SET p_startdate = DATE_SUB(CURRENT_DATE(), INTERVAL 365 DAY);
        ELSE -- For 'custom'
            SET p_startdate = DATE_SUB(CURRENT_DATE(), INTERVAL p_DayCount DAY); -- Default to 1 day
    END CASE;

    SET p_enddate = CURRENT_DATE(); -- End date is today

    -- Initialize output parameters
    SET p_result_status = 'SUCCESS';
    SET p_result_message = 'Revenue trend retrieved successfully';

    -- Return status and message
    SELECT p_result_status AS status, p_result_message AS message;

    -- Retrieve revenue trend data
    WITH RECURSIVE date_range AS (
        SELECT p_startdate AS date_value
        UNION ALL
        SELECT DATE_ADD(date_value, INTERVAL 1 DAY)
        FROM date_range
        WHERE date_value < p_enddate
    )
    SELECT 
        dr.date_value AS x_data,
        COALESCE(SUM(p.price), 0.00) AS y_data
    FROM date_range dr
    LEFT JOIN transactions t ON DATE(t.createdon) = dr.date_value AND t.status = p_status
    LEFT JOIN product p ON t.productid = p.productid
    GROUP BY dr.date_value
    ORDER BY dr.date_value;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_DB_GetTopSellingProducts` (IN `p_startdate` DATETIME, IN `p_enddate` DATETIME, IN `p_limit` INT, IN `p_status` VARCHAR(15), OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    SET p_result_status = 'SUCCESS';
    SET p_result_message = 'Top selling products retrieved successfully';
    SELECT p_result_status AS status, p_result_message AS message;
    SELECT 
        p.name AS x_data,
        COUNT(*) AS y_data
    FROM transactions t
    JOIN product p ON t.productid = p.productid
    WHERE t.createdon BETWEEN p_startdate AND p_enddate
    AND t.status = p_status
    GROUP BY p.name
    ORDER BY y_data DESC
    LIMIT p_limit;

END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_DB_GetTopSellingProductsBycharttype` (IN `p_DayCount` VARCHAR(15), IN `p_limit` INT, IN `p_status` VARCHAR(15), IN `p_chart_type` VARCHAR(10), OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE p_startdate DATE;
    DECLARE p_enddate DATE;

    -- Determine the start and end dates based on the provided day count
    CASE p_DayCount
        WHEN '7' THEN
            SET p_startdate = DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY);
        WHEN '30' THEN
            SET p_startdate = DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY);
        WHEN '60' THEN
            SET p_startdate = DATE_SUB(CURRENT_DATE(), INTERVAL 60 DAY);
        WHEN '180' THEN
            SET p_startdate = DATE_SUB(CURRENT_DATE(), INTERVAL 180 DAY);
        WHEN '365' THEN
            SET p_startdate = DATE_SUB(CURRENT_DATE(), INTERVAL 365 DAY);
        ELSE -- For 'custom' or any other value
            SET p_startdate = DATE_SUB(CURRENT_DATE(), INTERVAL p_DayCount DAY);
    END CASE;

    SET p_enddate = CURRENT_DATE(); -- End date is today

    -- Initialize output parameters
    SET p_result_status = 'SUCCESS';
    SET p_result_message = 'Top selling products retrieved successfully';

    -- Return status and message
    SELECT p_result_status AS status, p_result_message AS message;

    -- Debug statements
    -- SELECT p_startdate, p_enddate, p_limit, p_status, p_chart_type;

    -- Retrieve top selling products data based on chart type
    IF p_chart_type = 'day' THEN
        SELECT 
            DAY(t.createdon) AS x_data,
            p.name,
            COUNT(*) AS y_data
        FROM transactions t
        JOIN product p ON t.productid = p.productid
        WHERE t.createdon BETWEEN p_startdate AND p_enddate
          AND t.status = p_status
        GROUP BY x_data, p.name
        ORDER BY y_data DESC
        LIMIT p_limit;

    ELSEIF p_chart_type = 'month' THEN
        SELECT 
            MONTHNAME(t.createdon) AS x_data,
            p.name,
            COUNT(*) AS y_data
        FROM transactions t
        JOIN product p ON t.productid = p.productid
        WHERE t.createdon BETWEEN p_startdate AND p_enddate
          AND t.status = p_status
        GROUP BY x_data, p.name
        ORDER BY y_data DESC
        LIMIT p_limit;

    ELSEIF p_chart_type = 'year' THEN
        SELECT 
            YEAR(t.createdon) AS x_data,
            p.name,
            COUNT(*) AS y_data
        FROM transactions t
        JOIN product p ON t.productid = p.productid
        WHERE t.createdon BETWEEN p_startdate AND p_enddate
          AND t.status = p_status
        GROUP BY x_data, p.name
        ORDER BY y_data DESC
        LIMIT p_limit;

    END IF;

END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_DB_GetTopSellingProductsByDayCount` (IN `p_DayCount` VARCHAR(15), IN `p_limit` INT, IN `p_status` VARCHAR(15), OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE p_startdate DATE;
    DECLARE p_enddate DATE;

    -- Determine the start and end dates based on the provided day count
    CASE p_DayCount
        WHEN '7' THEN
            SET p_startdate = DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY);
        WHEN '30' THEN
            SET p_startdate = DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY);
        WHEN '60' THEN
            SET p_startdate = DATE_SUB(CURRENT_DATE(), INTERVAL 60 DAY);
        WHEN '180' THEN
            SET p_startdate = DATE_SUB(CURRENT_DATE(), INTERVAL 180 DAY);
        WHEN '365' THEN
            SET p_startdate = DATE_SUB(CURRENT_DATE(), INTERVAL 365 DAY);
        ELSE -- For 'custom' or any other value
            SET p_startdate = DATE_SUB(CURRENT_DATE(), INTERVAL p_DayCount DAY);
    END CASE;

    SET p_enddate = CURRENT_DATE(); -- End date is today

    -- Initialize output parameters
    SET p_result_status = 'SUCCESS';
    SET p_result_message = 'Top selling products retrieved successfully';

    -- Return status and message
    SELECT p_result_status AS status, p_result_message AS message;

    -- Retrieve top selling products data
    WITH RECURSIVE date_range AS (
        SELECT p_startdate AS date_value
        UNION ALL
        SELECT DATE_ADD(date_value, INTERVAL 1 DAY)
        FROM date_range
        WHERE date_value < p_enddate
    )
    SELECT 
        p.name AS x_data,
        COUNT(*) AS y_data
    FROM date_range dr
    JOIN transactions t ON DATE(t.createdon) = dr.date_value
    JOIN product p ON t.productid = p.productid
    WHERE t.status = p_status
    GROUP BY p.name
    ORDER BY y_data DESC
    LIMIT p_limit;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_DB_GetTopSellingProducts_By_ChartType` (IN `p_startdate` DATE, IN `p_enddate` DATE, IN `p_limit` INT, IN `p_status` VARCHAR(15), IN `p_chart_type` VARCHAR(10), OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    -- Initialize output parameters
    SET p_result_status = 'SUCCESS';
    SET p_result_message = 'Top selling products retrieved successfully';

    -- Return status and message
    SELECT p_result_status AS status, p_result_message AS message;

    -- Debug statements
    -- SELECT p_startdate, p_enddate, p_limit, p_status, p_chart_type;

    -- Retrieve top selling products data based on chart type
    IF p_chart_type = 'day' THEN
        SELECT 
            DAY(t.createdon) AS x_data,
            p.name,
            COUNT(*) AS y_data
        FROM transactions t
        JOIN product p ON t.productid = p.productid
        WHERE t.createdon BETWEEN p_startdate AND p_enddate
          AND t.status = p_status
        GROUP BY x_data, p.name
        ORDER BY y_data DESC
        LIMIT p_limit;

    ELSEIF p_chart_type = 'month' THEN
        SELECT 
            MONTHNAME(t.createdon) AS x_data,
            p.name,
            COUNT(*) AS y_data
        FROM transactions t
        JOIN product p ON t.productid = p.productid
        WHERE t.createdon BETWEEN p_startdate AND p_enddate
          AND t.status = p_status
        GROUP BY x_data, p.name
        ORDER BY y_data DESC
        LIMIT p_limit;

    ELSEIF p_chart_type = 'year' THEN
        SELECT 
            YEAR(t.createdon) AS x_data,
            p.name,
            COUNT(*) AS y_data
        FROM transactions t
        JOIN product p ON t.productid = p.productid
        WHERE t.createdon BETWEEN p_startdate AND p_enddate
          AND t.status = p_status
        GROUP BY x_data, p.name
        ORDER BY y_data DESC
        LIMIT p_limit;

    END IF;

END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_DB_GetTransactionStatusDistribution` (IN `p_startdate` DATETIME, IN `p_enddate` DATETIME, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN		
    SET p_result_status = 'SUCCESS';
    SET p_result_message = 'Transaction status distribution retrieved successfully';
    SELECT p_result_status AS status, p_result_message AS message;
    SELECT 
        status AS x_data,
        COUNT(*) AS y_data
    FROM transactions
    WHERE createdon BETWEEN p_startdate AND p_enddate
   -- AND status = p_status
    GROUP BY status;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_DB_SchoolTransactionsCount` (IN `p_schoolid` VARCHAR(250), IN `p_startdate` DATETIME, IN `p_enddate` DATETIME, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    -- Initialize result status and message
    SET p_result_status = 'SUCCESS';
    SET p_result_message = 'Transaction counts retrieved successfully';
 -- Select the result status and message
    SELECT p_result_status AS status, p_result_message AS message;
    -- Retrieve transaction counts
    SELECT
        COALESCE(SUM(CASE WHEN t.status = 'initiated' THEN 1 ELSE 0 END), 0) AS initiated_count,
        COALESCE(SUM(CASE WHEN t.status = 'ordered' THEN 1 ELSE 0 END), 0) AS ordered_count,
        COALESCE(SUM(CASE WHEN t.status = 'shipped' THEN 1 ELSE 0 END), 0) AS shipped_count,
        COALESCE(SUM(CASE WHEN t.status = 'outfordelivery' THEN 1 ELSE 0 END), 0) AS outfordelivery_count,
        COALESCE(SUM(CASE WHEN t.status = 'delivered' THEN 1 ELSE 0 END), 0) AS delivered_count,
        COALESCE(SUM(CASE WHEN t.status = 'deliverfail' THEN 1 ELSE 0 END), 0) AS deliverfail_count,
        COALESCE(SUM(CASE WHEN t.status = 'cancelinitiated' THEN 1 ELSE 0 END), 0) AS cancelinitiated_count,
        COALESCE(SUM(CASE WHEN t.status = 'returninitiated' THEN 1 ELSE 0 END), 0) AS returninitiated_count,
        COALESCE(SUM(CASE WHEN t.status = 'outforreturn' THEN 1 ELSE 0 END), 0) AS outforreturn_count,
        COALESCE(SUM(CASE WHEN t.status = 'returnfail' THEN 1 ELSE 0 END), 0) AS returnfail_count,
        COALESCE(SUM(CASE WHEN t.status = 'refundinitiated' THEN 1 ELSE 0 END), 0) AS refundinitiated_count,
        COALESCE(SUM(CASE WHEN t.status = 'refundfail' THEN 1 ELSE 0 END), 0) AS refundfail_count,
        COALESCE(SUM(CASE WHEN t.status = 'refunddone' THEN 1 ELSE 0 END), 0) AS refunddone_count,
        COALESCE(SUM(CASE WHEN t.status = 'paymentfailed' THEN 1 ELSE 0 END), 0) AS paymentfailed_count,
        COALESCE(SUM(CASE WHEN t.status = 'packed' THEN 1 ELSE 0 END), 0) AS packed_count,
        COALESCE((SUM(CASE WHEN t.status = 'initiated' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS initiated_percentage,
        COALESCE((SUM(CASE WHEN t.status = 'ordered' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS ordered_percentage,
        COALESCE((SUM(CASE WHEN t.status = 'shipped' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS shipped_percentage,
        COALESCE((SUM(CASE WHEN t.status = 'outfordelivery' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS outfordelivery_percentage,
        COALESCE((SUM(CASE WHEN t.status = 'delivered' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS delivered_percentage,
        COALESCE((SUM(CASE WHEN t.status = 'deliverfail' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS deliverfail_percentage,
        COALESCE((SUM(CASE WHEN t.status = 'cancelinitiated' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS cancelinitiated_percentage,
        COALESCE((SUM(CASE WHEN t.status = 'returninitiated' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS returninitiated_percentage,
        COALESCE((SUM(CASE WHEN t.status = 'outforreturn' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS outforreturn_percentage,
        COALESCE((SUM(CASE WHEN t.status = 'returnfail' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS returnfail_percentage,
        COALESCE((SUM(CASE WHEN t.status = 'refundinitiated' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS refundinitiated_percentage,
        COALESCE((SUM(CASE WHEN t.status = 'refundfail' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS refundfail_percentage,
        COALESCE((SUM(CASE WHEN t.status = 'refunddone' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS refunddone_percentage,
        COALESCE((SUM(CASE WHEN t.status = 'paymentfailed' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS paymentfailed_percentage,
        COALESCE((SUM(CASE WHEN t.status = 'packed' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS packed_percentage,
        -- Total Uniform Ordered
        COALESCE(SUM(CASE WHEN t.status = 'ordered' THEN 1 ELSE 0 END), 0) AS total_uniform_ordered,
        -- Total Uniform Delivered
        COALESCE(SUM(CASE WHEN t.status = 'delivered' THEN 1 ELSE 0 END), 0) AS total_uniform_delivered,
        -- Uniform Ordered Today
        COALESCE(SUM(CASE WHEN t.status = 'ordered' AND DATE(t.createdon) = CURDATE() THEN 1 ELSE 0 END), 0) AS uniform_ordered_today,
        -- Uniform Delivered Today
        COALESCE(SUM(CASE WHEN t.status = 'delivered' AND DATE(t.createdon) = CURDATE() THEN 1 ELSE 0 END), 0) AS uniform_delivered_today,
        -- Total Uniform Ordered Percentage
        COALESCE((SUM(CASE WHEN t.status = 'ordered' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS total_uniform_ordered_percentage,
        -- Total Uniform Delivered Percentage
        COALESCE((SUM(CASE WHEN t.status = 'delivered' THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS total_uniform_delivered_percentage,
        -- Uniform Ordered Today Percentage
        COALESCE((SUM(CASE WHEN t.status = 'ordered' AND DATE(t.createdon) = CURDATE() THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS uniform_ordered_today_percentage,
        -- Uniform Delivered Today Percentage
        COALESCE((SUM(CASE WHEN t.status = 'delivered' AND DATE(t.createdon) = CURDATE() THEN 1 ELSE 0 END) * 100) / COUNT(*), 0) AS uniform_delivered_today_percentage
    FROM transactions t
    JOIN product p ON t.productid = p.productid
    JOIN productschoolmap ps ON p.productid = ps.productid
    WHERE
        ps.schoolid = p_schoolid COLLATE utf8mb4_unicode_ci
        AND t.createdon BETWEEN p_startdate AND p_enddate;

END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_DeleteAddress` (IN `p_addressid` BIGINT, IN `p_userid` BIGINT, OUT `p_result_status` VARCHAR(10), OUT `p_result_message` VARCHAR(100))  BEGIN
    DECLARE address_exists INT;

    
    SELECT COUNT(*) INTO address_exists FROM address WHERE addressid = p_addressid AND userid = p_userid;

    IF address_exists = 0 THEN
        SET p_result_status = 'ERROR';
        SET p_result_message = 'Address not found for the given user';
        SELECT p_result_status AS status, p_result_message AS message;
    ELSE
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Address deleted';
        SELECT p_result_status AS status, p_result_message AS message;        
        DELETE FROM address WHERE addressid = p_addressid AND userid = p_userid;
    END IF;

END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_DeleteModule` (IN `p_moduleid` BIGINT, OUT `p_status` VARCHAR(255), OUT `p_message` VARCHAR(255))  BEGIN
    
    DELETE FROM module WHERE moduleid = p_moduleid;

    IF ROW_COUNT() > 0 THEN
        SET p_status = 'SUCCESS';
        SET p_message = 'Module deleted successfully.';
    ELSE
        SET p_status = 'FAILURE';
        SET p_message = 'Module not found.';
    END IF;
    SELECT p_status AS status, p_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_DeleteProduct` (IN `p_productid` BIGINT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE product_exists INT DEFAULT 0;

    -- Check if the product exists
    SELECT COUNT(*) INTO product_exists
    FROM product
    WHERE productid = p_productid;

    -- If the product exists, delete related records
    IF product_exists > 0 THEN
        DELETE FROM product WHERE productid = p_productid;
        DELETE FROM productimage WHERE productid = p_productid;
        DELETE FROM producttext WHERE productid = p_productid;

        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Record deleted successfully';
    ELSE
        -- Product does not exist
        SET p_result_status = 'ERROR';
        SET p_result_message = 'Product does not exist';
    END IF;

    -- Return the result status and message
    SELECT p_result_status AS status, p_result_message AS message;

END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_DeleteRole` (IN `p_rolesid` BIGINT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    
    SET p_result_status = 'FAILURE';
    SET p_result_message = 'Error deleting role';

    
    DELETE FROM roles WHERE rolesid = p_rolesid;
    
    IF ROW_COUNT() > 0 THEN
        
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Role deleted successfully';
    ELSE
        
        SET p_result_message = 'Role ID does not exist';
    END IF;

    
    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_DeleteSchool` (IN `p_schoolid` BIGINT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE v_count INT;

    
    SELECT COUNT(*) INTO v_count FROM school WHERE schoolid = p_schoolid;

    IF v_count > 0 THEN
        
        DELETE FROM school WHERE schoolid = p_schoolid;

        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Record deleted successfully';
    ELSE
        
        SET p_result_status = 'ERROR';
        SET p_result_message = 'School does not exist';
    END IF;
     SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_DeleteStaff` (IN `p_userid` INT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE is_user_exists BOOLEAN;

    
    SELECT COUNT(*) > 0 INTO is_user_exists
    FROM users
    WHERE userid = p_userid;

    
    IF is_user_exists THEN
        DELETE FROM address WHERE userid = p_userid;
        DELETE FROM usersschoolmap WHERE userid = p_userid;
        
        DELETE FROM userrolemap WHERE userid = p_userid;
        
        
        DELETE FROM users WHERE userid = p_userid;

        
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Staff deleted successfully';
    ELSE
        
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'Staff not found';
    END IF;
    
    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_execReport` (IN `p_report_name` VARCHAR(255), IN `p_fromdate` DATE, IN `p_todate` DATE, IN `p_export` BOOLEAN, IN `p_include_filter` BOOLEAN, IN `p_page` INT, IN `p_limit` INT, IN `p_filter_data` JSON, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` TEXT)  BEGIN
DECLARE report_id INT;
    DECLARE v_query TEXT;
    DECLARE offset INT;
    DECLARE filter_clause TEXT DEFAULT '';
    DECLARE sql_query TEXT;
    DECLARE bkname_var VARCHAR(255);
    DECLARE i INT DEFAULT 0;
    DECLARE total INT DEFAULT 0;
    DECLARE dpname_var VARCHAR(255);
    DECLARE value_var VARCHAR(255);
    DECLARE use_fromdate BOOLEAN DEFAULT FALSE;
    DECLARE use_todate BOOLEAN DEFAULT FALSE;
    DECLARE idx INT DEFAULT 0;

    -- Get the report query and report id
    SELECT reportid, report_query INTO report_id, v_query FROM report WHERE report_name = p_report_name;

    IF report_id IS NOT NULL THEN
        IF v_query IS NOT NULL THEN
            -- If include_filter is true, build the filter clause
            IF p_include_filter THEN
                SET total = JSON_LENGTH(p_filter_data);
                SET filter_clause =' WHERE 1=1';

                -- Loop through each element in the JSON array
                WHILE idx < total DO
                    -- Extract the dpname and value fields from the JSON array element
                    SET dpname_var = JSON_UNQUOTE(JSON_EXTRACT(p_filter_data, CONCAT('$[', idx, '].dpname')));
                    SET value_var = JSON_UNQUOTE(JSON_EXTRACT(p_filter_data, CONCAT('$[', idx, '].value')));

                    -- Fetch bkname from reportfilter table based on dpname
                    SELECT bkname INTO bkname_var FROM reportfilter WHERE dpname = dpname_var AND reportid = report_id LIMIT 1;

                    -- If bkname is found, use it; otherwise, use dpname as fallback
                    IF bkname_var IS NOT NULL THEN
                        SET filter_clause = CONCAT(filter_clause, ' AND ', bkname_var, '="', value_var, '"');
                    ELSE
                        SET filter_clause = CONCAT(filter_clause, ' AND ', dpname_var, '="', value_var, '"');
                    END IF;

                    SET idx = idx + 1;
                END WHILE;

                -- Determine whether to use fromdate and todate from the reportfilter table
                SELECT fromdate, todate INTO use_fromdate, use_todate FROM report WHERE report_name = p_report_name;

                -- Add date filters if specified in the reportfilter table
                IF use_fromdate AND use_todate THEN
                    SET filter_clause = CONCAT(filter_clause, ' AND created_at BETWEEN "', p_fromdate, '" AND "', p_todate, '"');
                END IF;

                -- Set result status and message
                SET p_result_status = 'SUCCESS';
                SET p_result_message = 'Report executed successfully';
                 -- Return the result status and message
    SELECT p_result_status AS status, p_result_message AS message;

                -- Construct the final SQL query
                SET sql_query = CONCAT(v_query, filter_clause);
                SET @sql = sql_query;

                -- Debug: Print variables to check values
                -- SELECT v_query AS debug_v_query, filter_clause AS debug_filter_clause, sql_query AS debug_sql_query;
                
                -- Execute the report query
                IF p_export THEN
                --	SELECT v_query AS debug_v_query, filter_clause AS debug_filter_clause, sql_query AS debug_sql_query;
                    -- Execute the report query without pagination
                    PREPARE stmt FROM @sql;
                    EXECUTE stmt;
                    DEALLOCATE PREPARE stmt;
                ELSE
                    -- Add pagination
                    SET offset = p_page * p_limit;
                    SET @sql = CONCAT(@sql, ' LIMIT ', offset, ', ', p_limit);

                    -- Execute the report query with pagination
                    BEGIN
                        DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
                        BEGIN
                            GET DIAGNOSTICS CONDITION 1 @sql_state = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
                            SET p_result_status = 'FAILURE';
                            SET p_result_message = CONCAT('Error: ', @errno, ', SQL State: ', @sql_state, ', Message: ', @text, ', SQL Query: ', @sql);
                        END;

                        PREPARE stmt FROM @sql;
                        EXECUTE stmt;
                        DEALLOCATE PREPARE stmt;
                    END;
                END IF;
            ELSE
                -- Execute the report query without filters
               -- SET sql_query = v_query;
               -- IF use_fromdate AND use_todate THEN
               --     SET sql_query = CONCAT(sql_query, ' WHERE created_at BETWEEN "', p_fromdate, '" AND "', p_todate, '"');
               -- END IF;
               -- Set result status and message
                SET p_result_status = 'SUCCESS';
                SET p_result_message = 'Report executed successfully';
                
               
                 -- Return the result status and message
    SELECT p_result_status AS status, p_result_message AS message;
    -- SELECT v_query;
     SET @sql = v_query;

                    -- Execute the report query without pagination
                    PREPARE stmt FROM @sql;
                    EXECUTE stmt;
                    DEALLOCATE PREPARE stmt;
                
            END IF;
        ELSE
            -- Report query not found
            SET p_result_status = 'FAILURE';
            SET p_result_message = 'Report query not found';
             -- Return the result status and message
    SELECT p_result_status AS status, p_result_message AS message;
        END IF;
    ELSE
        -- Report not found
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'Report not found';
         -- Return the result status and message
    SELECT p_result_status AS status, p_result_message AS message;
    END IF;

END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_GenerateOrUpdateOTP` (IN `p_mobileno` VARCHAR(10), IN `p_otpcode` VARCHAR(6), OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    
    DECLARE v_record_count INT;
    DECLARE v_user_id INT; 
   DECLARE p_transtime DATETIME; 
      DECLARE p_validity DATETIME; 
    
    SET p_transtime = CONVERT_TZ(NOW(), '+00:00', '+05:30');
    SET p_validity = CONVERT_TZ(DATE_ADD(NOW(), INTERVAL 10 MINUTE), '+00:00', '+05:30');

    
    SELECT userid INTO v_user_id FROM users WHERE mobileno = p_mobileno;

    
    SELECT COUNT(*) INTO v_record_count FROM otptable WHERE mobileno = p_mobileno;

    
    IF v_record_count > 0 THEN
        UPDATE otptable
        SET
            otpcode = p_otpcode,
            validity = p_validity,            
            transtime = p_transtime,
            userid = v_user_id,
            status = 1
        WHERE
            mobileno = p_mobileno
        ORDER BY
            id DESC
        LIMIT 1;

        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'OTP record updated successfully';
    ELSE
        
        INSERT INTO otptable (mobileno, otpcode, validity, transtime, userid)
        VALUES (p_mobileno, p_otpcode, p_validity, p_transtime, v_user_id);

        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'OTP record created successfully';
    END IF;
    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_getAddressById` (IN `p_AddressById` BIGINT, OUT `p_result_status` VARCHAR(10), OUT `p_result_message` VARCHAR(100))  BEGIN
    
    DECLARE address_exists INT;

    SELECT COUNT(*) INTO address_exists FROM address WHERE addressid = p_AddressById;

    IF address_exists = 0 THEN
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'No data found';
        SELECT p_result_status AS status, p_result_message AS message;
        SELECT NULL AS empty_result WHERE FALSE;
    ELSE
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Address retrieved';
        SELECT p_result_status AS status, p_result_message AS message;

        SELECT addressid, name, Address1, Address2, Address3, Address4, Address5,
            Address6, Address7, Address8, Landmark, city, state, country, pincode,
            email, mobileno FROM address WHERE addressid = p_AddressById;
    END IF;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_getaddressdetail` (IN `p_userid` BIGINT, OUT `p_result_status` VARCHAR(10), OUT `p_result_message` VARCHAR(100))  BEGIN
    
    DECLARE address_exists INT;

    SELECT COUNT(*) INTO address_exists FROM address WHERE userid = p_userid;

    IF address_exists = 0 THEN
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'No data found';
        SELECT p_result_status AS status, p_result_message AS message;
        SELECT NULL AS empty_result WHERE FALSE;
    ELSE
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Address retrieved';
        SELECT p_result_status AS status, p_result_message AS message;

        
        SELECT addressid, name, locationdetails, fulladdress, Landmark, city, state, country, pincode,
            email, mobileno FROM address WHERE userid = p_userid;
    END IF;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_getaddress_withPGN` (IN `p_userid` INT, IN `pageno` INT, IN `count` INT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE start_row INT;
    DECLARE total_rows INT;
    DECLARE total_pages INT;
    
    SET SESSION group_concat_max_len = 100000000;

    
    SET start_row = (pageno - 1) * count;

    
    SELECT COUNT(*) INTO total_rows FROM address WHERE userid = p_userid;
    SET total_pages = CEIL(total_rows / count);

    IF total_rows = 0 THEN
        SET p_result_message = 'No Address found';
        SET p_result_status = 'SUCCESS';
        SELECT p_result_status AS status, p_result_message AS message, total_rows AS totalcount;        
        SELECT NULL AS empty_result WHERE FALSE;
    ELSEIF pageno < 1 OR pageno > total_pages THEN
        
        SET p_result_status = 'ERROR';
        SET p_result_message = 'No Address found on this page';
        SELECT p_result_status AS status, p_result_message AS message, total_rows AS totalcount;
    ELSE
        
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Address information retrieved successfully';
        SELECT p_result_status AS status, p_result_message AS message, total_rows AS totalcount;

        
        SELECT addressid, name, Address1, Address2, Address3, Address4, Address5,
            Address6, Address7, Address8, Landmark, city, state, country, pincode,
            email, mobileno 
        FROM address 
        WHERE userid = p_userid
        GROUP BY addressid  
        LIMIT start_row, count;
    END IF;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_getaddtocart` (IN `p_userid` BIGINT, IN `pageno` INT, IN `count` INT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE start_row INT;
    DECLARE total_rows INT;
    DECLARE total_pages INT;
    
    SET start_row = (pageno - 1) * count;
    
    SELECT COUNT(*) INTO total_rows FROM addtocarttable WHERE userid = p_userid AND STATUS = 'incart';
    SET total_pages = CEIL(total_rows / count);

    IF total_rows = 0 THEN
        
       SET p_result_status = 'SUCCESS';
        SET p_result_message = 'No data found';
        SELECT p_result_status AS status, p_result_message AS message;
        SELECT NULL AS empty_result WHERE FALSE;
    ELSEIF pageno < 1 OR pageno > total_pages THEN
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'No Data found on this page';
        SELECT p_result_status AS status, p_result_message AS message, total_rows AS totalcount;
        SELECT NULL AS empty_result WHERE FALSE;
    ELSE
        
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Data retrieved successfully';
        SELECT p_result_status AS status, p_result_message AS message, total_rows AS totalcount;
        
       SELECT
    addtocarttable.atcartid,
    addtocarttable.productid,
    product.name,
    product.description,
    product.price,
    JSON_ARRAYAGG(pt.submasterid) AS submasterids,
    JSON_ARRAYAGG(pt.subdataid) AS subdataids,
    addtocarttable.status,
    (
        SELECT JSON_ARRAYAGG(
            JSON_OBJECT(
                'image', TO_BASE64(productimage.image),
                'imageseq', productimage.imageseq
            )
        )
        FROM productimage
        WHERE productimage.productid = addtocarttable.productid
    ) AS images,
    (
        SELECT COUNT(*)
        FROM addtocarttable AS ac
        WHERE
            ac.productid = addtocarttable.productid
            AND ac.status = 'incart'
    ) AS addtocart_quantity,
    (
        SELECT COUNT(*)
        FROM product AS p
        WHERE
            p.name = product.name
            AND p.description = product.description
    ) AS total_quantity,
    (
        SELECT COUNT(*)
        FROM product AS p
        WHERE
            p.name = product.name
            AND p.description = product.description
            AND p.productid NOT IN (SELECT productid FROM addtocarttable WHERE userid = p_userid AND status = 'incart')
    ) AS available_quantity
FROM
    addtocarttable
    LEFT JOIN product ON product.productid = addtocarttable.productid
    LEFT JOIN producttext pt ON pt.productid = addtocarttable.productid
WHERE
    addtocarttable.userid = p_userid AND addtocarttable.status IN ('incart', 'unchecked', 'saveforlater')
GROUP BY        
    addtocarttable.userid,
    addtocarttable.atcartid,
    addtocarttable.productid,
    product.name,
    product.description,
    product.price,
    addtocarttable.status
LIMIT start_row, count;

SELECT
   -- same_product_ids,
    added_to_cart_ids,
    COALESCE(addtocart_quantity, 0) AS addtocart_quantity,
    COALESCE(total_quantity, 0) AS total_quantity,
    COALESCE(total_quantity - COALESCE(addtocart_quantity, 0), 0) AS available_quantity
FROM (
    SELECT
      --  GROUP_CONCAT(product.productid) AS same_product_ids,
        GROUP_CONCAT(addtocart.productid) AS added_to_cart_ids,
        COUNT(addtocart.productid) AS addtocart_quantity,
        COUNT(product.productid) AS total_quantity
    FROM
        product
    LEFT JOIN (
        SELECT productid
        FROM addtocarttable
        WHERE userid = p_userid
        AND status = 'incart'
    ) AS addtocart ON product.productid = addtocart.productid
    GROUP BY
        product.name,
        product.description
    HAVING
        added_to_cart_ids IS NOT NULL
) AS subquery;

     

    END IF;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_GetAllReportNames` (OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(100))  BEGIN
    -- Declare variables
    DECLARE v_row_count INT;

    -- Get row count
    SELECT COUNT(*) INTO v_row_count FROM report;

    IF v_row_count > 0 THEN
        -- Set result status and message
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Report names retrieved successfully.';
SELECT p_result_status AS status, p_result_message AS message;
        -- Get report data
        SELECT reportid, report_name, fromdate, todate, report_export,include_filter FROM report;
    ELSE
        -- Set result status and message for failure
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'No report names found.';
        SELECT p_result_status AS status, p_result_message AS message;
    END IF;

END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_getbriefproductdetails` (IN `p_productid` BIGINT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE product_exists INT;

    
    SELECT COUNT(*) INTO product_exists
    FROM product
    WHERE productid = p_productid;

    IF product_exists = 0 THEN
        
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Product does not exist';
        SELECT p_result_status AS status, p_result_message AS message;
        SELECT NULL AS result LIMIT 0;
    ELSE
        
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Product information retrieved successfully';
        SELECT p_result_status AS status, p_result_message AS message;
        
SELECT
    p.productid,
    p.barcode,
    p.masterid,
    p.name,
    p.description,
    p.price,
    p.gst,
    p.discount,
    (
        SELECT COUNT(*)
        FROM product
        WHERE
            name = p.name
            AND description = p.description
            AND productid != p.productid
    ) AS quantity,
    JSON_ARRAYAGG(JSON_OBJECT('image', TO_BASE64(pi.image), 'imageseq', pi.imageseq)) AS images,
    p.productstatus,
    p.ispublic,
    p.isuniform,
    (
        SELECT JSON_ARRAYAGG(
            JSON_OBJECT(
                'similar_product_id', p_similar.productid,
                'similar_subdata_ids', (
                    SELECT JSON_ARRAYAGG(pt_sub.subdataid)
                    FROM producttext pt_sub
                    WHERE pt_sub.productid = p_similar.productid
                ),
                'similar_submaster_ids', (
                    SELECT JSON_ARRAYAGG(pt_sub.submasterid)
                    FROM producttext pt_sub
                    WHERE pt_sub.productid = p_similar.productid
                )
            )
        )
        FROM product p_similar
        WHERE p_similar.name = p.name
        AND p_similar.description <> p.description
    ) AS similar_details
FROM
    product p
LEFT JOIN productimage pi ON pi.productid = p.productid
WHERE
    p.productid = p_productid
GROUP BY
    p.productid;

    END IF;

    COMMIT;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_GetCancelOrderDetails` (IN `p_userid` INT, IN `p_limit` INT, IN `p_page` INT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255), OUT `p_total_pages` INT)  BEGIN
	
     DECLARE start_row INT;
    DECLARE total_rows INT;
    DECLARE total_pages INT;
    SET p_result_status = 'SUCCESS';
    SET p_result_message = 'No cancel orders found';
    SET p_total_pages = 0;
    
    
    SET SESSION group_concat_max_len = 100000000;

    
    SET start_row = (p_page - 1) * p_limit;
    
        SELECT COUNT(*)INTO total_rows
        FROM transactions a
        LEFT JOIN product b ON a.productid = b.productid
        WHERE a.userid = p_userid AND a.status = 'cancelinitiated';

    
    IF (
        SELECT COUNT(*)
        FROM transactions a
        LEFT JOIN product b ON a.productid = b.productid
        LEFT JOIN productimage c ON c.productid = b.productid AND c.imageseq = 1
        LEFT JOIN address e ON e.addressid = a.id
        WHERE a.userid = p_userid AND a.status = 'cancelinitiated'
    ) > 0 THEN
        
        SELECT CEIL(COUNT(*) / p_limit) INTO p_total_pages
        FROM transactions a
        LEFT JOIN product b ON a.productid = b.productid
        WHERE a.userid = p_userid AND a.status = 'cancelinitiated';

        
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Cancel order details retrieved successfully';
           
    SELECT p_result_status AS status, p_result_message AS message, p_total_pages AS total_pages;

        

SELECT
    a.id,
    a.createdon AS ordercancelleddate,
    a.status,
    e.name AS addressname,
    JSON_OBJECT(
        'addressline1', e.address1,
        'addressline2', e.address2,
        'city', e.city,
        'pincode', e.pincode
    ) AS address,
    a.id AS orderid,
    a.productid,
    b.name AS product_name,
    b.description AS product_description,
    b.price AS product_price,
    JSON_OBJECT(
        'image', IFNULL(c.image, '')
    ) AS image
FROM transactions a
LEFT JOIN address e ON e.addressid = a.id
LEFT JOIN product b ON a.productid = b.productid
LEFT JOIN productimage c ON c.productid = b.productid AND c.imageseq = 1
WHERE a.userid = p_userid AND a.status = 'cancelinitiated'
ORDER BY a.createdon DESC
LIMIT start_row, p_limit;
    ELSE
        
        SET p_result_message = 'User has no canceled orders';
        SELECT p_result_status AS status, p_result_message AS message;
        SELECT NULL AS empty_result WHERE FALSE;
    END IF;

    
    SELECT p_result_status AS status, p_result_message AS message, p_total_pages AS total_pages;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_getdefaultdetail` (IN `p_userid` BIGINT, OUT `p_result_status` VARCHAR(10), OUT `p_result_message` VARCHAR(100))  BEGIN
    
    DECLARE address_exists INT;

    SELECT COUNT(*) INTO address_exists FROM address WHERE isprimary > 0 and userid = p_userid;

    IF address_exists = 0 THEN
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Address not found';
        SELECT p_result_status AS status, p_result_message AS message;
    ELSE
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Address retrieved';
        SELECT p_result_status AS status, p_result_message AS message;

        
        SELECT addressid, name, Address1, Address2, Address3, Address4, Address5,
            Address6, Address7, Address8, Landmark, city, state, country, pincode,
            email, mobileno FROM address
        WHERE isprimary > 0 and userid = p_userid;
    END IF;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_GetGradeBySchoolId` ()  BEGIN

END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_getminmaxprice` (OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    
   DECLARE p_min_price DECIMAL(10,2);
DECLARE p_max_price DECIMAL(10,2);

SET p_min_price = 0.00;
SET p_max_price = 0.00;

    SET p_result_status = 'ERROR';
    SET p_result_message = '';

   
    SELECT
        CASE WHEN MIN(price) IS NOT NULL THEN MIN(price) ELSE 0.00 END,
        CASE WHEN MAX(price) IS NOT NULL THEN MAX(price) ELSE 0.00 END
    INTO p_min_price, p_max_price
    FROM product;

    
    IF p_min_price <> 0.00 OR p_max_price <> 0.00 THEN
        
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Minimum and maximum prices retrieved successfully';
    ELSE
        
        SET p_result_message = 'No products found in the product table';
    END IF;
    
    SELECT p_result_status AS status, p_result_message AS message;
    SELECT p_min_price, p_max_price;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_GetModuleByID` (IN `p_moduleid` BIGINT, OUT `p_status` VARCHAR(255), OUT `p_message` VARCHAR(255))  BEGIN  
   DECLARE count INT;

    SELECT COUNT(*) INTO count FROM module WHERE moduleid = p_moduleid;
    IF count > 0 THEN    
        SET p_status = 'SUCCESS';
        SET p_message = 'Module details retrieved successfully.';
        SELECT p_status AS status, p_message AS message;
        SELECT moduleid,name FROM module WHERE moduleid = p_moduleid;
    ELSE
        SET p_status = 'FAILURE';
        SET p_message = 'Module not found.';
        SELECT p_status AS status, p_message AS message;
    END IF;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_GetModuleDetails` (OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    
    SET p_result_status = 'FAILURE';
    SET p_result_message = 'Error retrieving module details';

    
    IF EXISTS (SELECT 1 FROM module) THEN
    
        
        SET p_result_status = 'SUCCESS';        
        
        SET p_result_message = 'module data found';
        
    SELECT p_result_status AS status, p_result_message AS message;
        
          SELECT moduleid, name FROM module;
    ELSE
        
        SET p_result_message = 'No module data found';
    END IF;
            
    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_GetOrderDetails` (IN `p_userid` INT, IN `p_limit` INT, IN `p_page` INT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    
    SET p_result_status = 'FAILURE';
    SET p_result_message = 'transaction id not exists';

    
    SET @start_index := (p_page - 1) * p_limit;

    
    IF EXISTS (
        SELECT 1
        FROM `transactions`
        WHERE userid = p_userid
    ) THEN
    
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Order details retrieved successfully';
    
    SELECT p_result_status AS status, p_result_message AS message;
        
        SET @sql = CONCAT(
            'SELECT
    a.id,
    a.transid,
    a.ordernumber,
    a.status,
    a.createdon,
    b.name,
    b.description,
    b.price,
    JSON_OBJECT("image", IFNULL(TO_BASE64(c.image), ""), "imageseq", IFNULL(c.imageseq, "")) AS image_details,
    JSON_OBJECT(
    		"addressid",IFNULL(MAX(e.addressid), ""),
        "address_name", IFNULL(MAX(e.name), ""),
        "addressline1", IFNULL(MAX(e.address1), ""),
        "addressline2", IFNULL(MAX(e.address2), ""),
        "city", IFNULL(MAX(e.city), ""),
        "pincode", IFNULL(MAX(e.pincode), "")
    ) AS address_details
FROM
    `transactions` a
    LEFT JOIN product b ON a.productid = b.productid
    LEFT JOIN productimage c ON c.productid = b.productid AND c.imageseq = 1
    LEFT JOIN address e ON e.addressid = a.addressid
WHERE
    a.userid = ', p_userid, '
    AND a.status IN ("ordered", "shipped", "outfordelivery", "delivered", "deliverfail")
GROUP BY
    a.id,
    a.transid,
    a.ordernumber,
    a.status,
    a.createdon,
    b.name,
    b.description,
    b.price,
    c.image
ORDER BY
    MAX(a.lastmodifiedat) DESC
            LIMIT ', @start_index, ',', p_limit
        );

        
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;

        
    ELSE
        
        SET p_result_message = 'User has no orders';
    END IF;

    
    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_getordersummary` (IN `p_userid` INT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    
    SET p_result_status = 'FAILURE';
    SET p_result_message = 'No Data Found';

    
    SELECT COUNT(DISTINCT addtocarttable.productid) INTO @product_count
    FROM addtocarttable
    WHERE userid = p_userid AND status = 'incart';

    
    IF @product_count > 0 THEN
        
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Order summary retrieved successfully';
         
        SELECT p_result_status AS status, p_result_message AS message;
        
        SELECT
            COUNT(DISTINCT addtocarttable.productid) AS 'Count',
            COALESCE(SUM(product.price), 0) AS 'Total',
            JSON_ARRAYAGG(
                JSON_OBJECT(
                    'productid', product.productid,
                    'price', product.price,
                    'images', (
                        SELECT JSON_ARRAYAGG(
                            JSON_OBJECT(
                                'imageseq', productimage.imageseq,
                                'image', productimage.image
                            )
                        )
                        FROM productimage
                        WHERE productimage.productid = product.productid
                    ),
                    'name', product.name
                )
            ) AS 'product'
        FROM addtocarttable
        JOIN product ON addtocarttable.productid = product.productid
        WHERE addtocarttable.userid = p_userid AND addtocarttable.status = 'incart'
        GROUP BY addtocarttable.userid;
    ELSE
        SET p_result_status = 'SUCCESS';
        SELECT p_result_status AS status, p_result_message AS message;
        SELECT NULL AS result LIMIT 0;
    END IF;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_GetProductAll` (OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE product_exists INT;
    
    
    SELECT COUNT(*) INTO product_exists
    FROM product;
    
    IF product_exists IS NULL OR product_exists = 0 THEN


        
        SET p_result_status = 'ERROR';
        SET p_result_message = 'Product does not exist';
        SELECT p_result_status AS status, p_result_message AS message;
    ELSE

        
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Product information retrieved successfully';
        SELECT p_result_status AS status, p_result_message AS message;
        
        SELECT
            p.productid,
            p.barcode,
            p.masterid,
            producttext.subdataid,
            productschoolmap.schoolid,
            p.name,
            p.description,
            p.price,
            p.gst,
            p.discount,
            GROUP_CONCAT(DISTINCT(productimage.imageseq) SEPARATOR '; ') AS imageseq,
            p.productstatus,
            p.ispublic,
            p.isuniform,
            p.createdon,
            p.lastmodifiedate,
            p.lastmodifiedby,
            p.createdby
        FROM
            product p
        LEFT JOIN producttext ON (producttext.productid = p.productid)
        LEFT JOIN productschoolmap ON (productschoolmap.productid = p.productid)
        LEFT JOIN productimage ON (productimage.productid = p.productid)
        GROUP BY productimage.productid,producttext.subdataid,
            productschoolmap.schoolid;
        

    END IF;
    

    COMMIT;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_GetProductAll_withPGN` (IN `pageno` INT, IN `count` INT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE start_row INT;
    DECLARE total_rows INT;
    DECLARE total_pages INT;

    
    SET start_row = (pageno - 1) * count;

    
    SELECT COUNT(*) INTO total_rows FROM product;
    SET total_pages = CEIL(total_rows / count);

    IF total_rows = 0 THEN
        
        SET p_result_status = 'ERROR';
        SET p_result_message = 'No products found';
        SELECT p_result_status AS status, p_result_message AS message, total_rows AS totalcount;
    ELSEIF pageno < 1 OR pageno > total_pages THEN
        
        SET p_result_status = 'ERROR';
        SET p_result_message = 'No products found on this page';
        SELECT p_result_status AS status, p_result_message AS message, total_rows AS totalcount;
    ELSE
        
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Product information retrieved successfully';
        SELECT p_result_status AS status, p_result_message AS message, total_rows AS totalcount;

        
        SELECT
            p.productid,
            p.barcode,
            p.masterid,
            producttext.subdataid,
            productschoolmap.schoolid,
            p.name,
            p.description,
            p.price,
            p.gst,
            p.discount,
            JSON_ARRAYAGG(JSON_OBJECT('image', TO_BASE64(image),'imageseq', imageseq)) AS images,
            p.productstatus,
            p.ispublic,
            p.isuniform,
            p.createdon,
            p.lastmodifiedate,
            p.lastmodifiedby,
            p.createdby
        FROM
            product p
        LEFT JOIN producttext ON (producttext.productid = p.productid)
        LEFT JOIN productschoolmap ON (productschoolmap.productid = p.productid)
        LEFT JOIN productimage ON (productimage.productid = p.productid)
        GROUP BY
    p.productid
        LIMIT start_row, count;
    END IF;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_GetProductByProductid` (IN `p_productid` BIGINT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE product_exists INT;

    
    SELECT COUNT(*) INTO product_exists
    FROM product
    WHERE productid = p_productid;

    IF product_exists = 0 THEN
        
        SET p_result_status = 'ERROR';
        SET p_result_message = 'Product does not exist';
        SELECT p_result_status AS status, p_result_message AS message;
    ELSE
        
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Product information retrieved successfully';
        SELECT p_result_status AS status, p_result_message AS message;

        SELECT
            p.productid,
            p.barcode,
            p.masterid,
             producttext.submasterid,
            producttext.subdataid,
            productschoolmap.schoolid,
            p.name,
            p.description,
            p.price,
            p.gst,
            p.discount,            
            JSON_ARRAYAGG(JSON_OBJECT('image', TO_BASE64(image),'imageseq', imageseq)) AS images,
            p.productstatus,
            p.ispublic,
            p.isuniform,
            p.createdon,
            p.lastmodifiedate,
            p.lastmodifiedby,
            p.createdby
        FROM
            product p
        LEFT JOIN producttext ON (producttext.productid = p.productid)
        LEFT JOIN productschoolmap ON (productschoolmap.productid = p.productid)
        LEFT JOIN productimage ON (productimage.productid = p.productid)
        WHERE p.productid = p_productid
        GROUP BY p.productid,producttext.subdataid,productschoolmap.schoolid;

    END IF;

    

    COMMIT;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_Getproductminidetails` (IN `p_masterid` BIGINT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE result_count INT;

    
    SELECT COUNT(*) INTO result_count
    FROM product
    WHERE masterid = p_masterid;

    IF result_count > 0 THEN
SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Data retrieved successfully';
SELECT p_result_status AS status, p_result_message AS message;
        
        SELECT
            product.productid,
            product.name,
            product.price,
            JSON_ARRAYAGG(JSON_OBJECT('image', TO_BASE64(image),'imageseq', imageseq)) AS images
        FROM product
        LEFT JOIN productimage ON productimage.productid = product.productid
        WHERE product.masterid = p_masterid
        GROUP BY product.productid
        ORDER BY product.lastmodifiedate DESC;

        
    ELSE
        
        SET p_result_status = 'ERROR';
        SET p_result_message = 'No data found';
SELECT p_result_status AS status, p_result_message AS message;
    END IF;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_GetProductwithimage` (OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE result_count INT;

    
    SELECT COUNT(*) INTO result_count
    FROM masters
    WHERE category = 0;

    IF result_count > 0 THEN
  SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Data retrieved successfully';
SELECT p_result_status AS status, p_result_message AS message;
        
        SELECT masterid, mastername, TO_BASE64(image) AS image
        FROM masters
        WHERE category = 0
        ORDER BY masterid ASC;

    ELSE
        
        SET p_result_status = 'ERROR';
        SET p_result_message = 'No data found';
        SELECT p_result_status AS status, p_result_message AS message;
    END IF;
        
    
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_GetRoleDetails` (OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    
    SET p_result_status = 'FAILURE';
    SET p_result_message = 'Error retrieving role details';

    
    IF EXISTS (SELECT 1 FROM roles) THEN
    
        
        SET p_result_status = 'SUCCESS';
         
        SET p_result_message = 'User role data found';
         
    SELECT p_result_status AS status, p_result_message AS message;
		  SELECT rolesid,name,bin(ROLE) AS role,defaultmodule AS default_module_id
    --  SELECT rolesid,name, LPAD(BIN(ROLE), (SELECT COUNT(*) FROM module), '0') AS role,defaultmodule AS default_module_id
FROM roles;



    ELSE
        
        SET p_result_message = 'No role data found';    
    SELECT p_result_status AS status, p_result_message AS message;
    END IF;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_GetRoleDetailsByID` (IN `p_roleID` INT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    
    SET p_result_status = 'FAILURE';
    SET p_result_message = 'Error retrieving role details';

    
    IF EXISTS (SELECT 1 FROM roles WHERE rolesid = p_roleID) THEN
        
        SET p_result_status = 'SUCCESS';
        
        SET p_result_message = 'User role data found';
        
    SELECT p_result_status AS status, p_result_message AS message;
        
	--	SELECT rolesid,name ,bin(role) AS ROLE,defaultmodule AS default_module_id FROM roles WHERE rolesid = p_roleID;
	SELECT 
	bin(ROLE) AS role,
    -- (SELECT LPAD(BIN(role), (SELECT COUNT(*) FROM module), '0') FROM roles WHERE rolesid =p_roleID) AS role,
    rolesid,
    name,
    defaultmodule AS default_module_id
FROM 
    roles
    WHERE rolesid =p_roleID;
    ELSE
        
        SET p_result_message = 'No role data found';
    END IF;

    
    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_getschoolByschoolid` (IN `p_schoolid` INT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE result_count INT;

    
    SELECT COUNT(*) INTO result_count
    FROM school
    WHERE school.schoolid = p_schoolid AND status != 0;

    IF result_count > 0 THEN   
        
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Data retrieved successfully';
        
    SELECT p_result_status AS status, p_result_message AS message;
	      SELECT schoolid, schoolcode, NAME, address,email, mobileno
    FROM school
    WHERE schoolid = p_schoolid AND status != 0;
    ELSE
        
        SET p_result_status = 'ERROR';
        SET p_result_message = 'No data found for the specified schoolid';
        
        
        SELECT p_result_status AS status, p_result_message AS message;
    END IF;    
    
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_getschoolcode` (OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE result_count INT;

    
    SELECT COUNT(*) INTO result_count
    FROM school
    WHERE status != 0;
  
    IF result_count > 0 THEN   
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Data retrieved successfully';
        
    SELECT p_result_status AS status, p_result_message AS message;
	      SELECT schoolid, schoolcode, name, address, mobileno,email
    FROM school
    WHERE status != 0;
    ELSE
        
        SET p_result_status = 'ERROR';
        SET p_result_message = 'No data found';
        
        
        SELECT p_result_status AS status, p_result_message AS message;
    END IF;    
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_getschoolcode_withPGN` (IN `pageno` INT, IN `count` INT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE start_row INT;
    DECLARE total_rows INT;
    DECLARE total_pages INT;

    
    SET start_row = (pageno - 1) * count;

    
    SELECT COUNT(*) INTO total_rows FROM school WHERE status != 0;
    SET total_pages = CEIL(total_rows / count);

    IF total_rows = 0 THEN
        
        SET p_result_status = 'ERROR';
        SET p_result_message = 'No School found';
        SELECT p_result_status AS status, p_result_message AS message, total_rows AS totalcount;
    ELSEIF pageno < 1 OR pageno > total_pages THEN
        
        SET p_result_status = 'ERROR';
        SET p_result_message = 'No School found on this page';
        SELECT p_result_status AS status, p_result_message AS message, total_rows AS totalcount;
    ELSE
        
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'School information retrieved successfully';
        SELECT p_result_status AS status, p_result_message AS message, total_rows AS totalcount;

        
        SELECT schoolid, schoolcode, NAME, address, mobileno
        FROM school
        WHERE status != 0
        GROUP BY schoolid
        LIMIT start_row, count;
    END IF;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_GetStateNames` (OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE result_count INT;

    
    SELECT COUNT(*) INTO result_count
    FROM states_names;
  
    IF result_count > 0 THEN   
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Data retrieved successfully';
        
    SELECT p_result_status AS status, p_result_message AS message;
	      SELECT * FROM states_names;
    ELSE
        
        SET p_result_status = 'ERROR';
        SET p_result_message = 'No data found';
        SELECT p_result_status AS status, p_result_message AS message;
    END IF;    
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_GetTopSellingProducts` (IN `p_startdate` DATETIME, IN `p_enddate` DATETIME, IN `p_limit` INT, IN `p_status` VARCHAR(15), OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
 		SET p_result_status = 'SUCCESS';
      SET p_result_message = 'Top selling products retrieved successfully';
     SELECT p_result_status AS status, p_result_message AS message;
    SELECT 
        p.product_name AS x_data,
        COUNT(*) AS y_data
    FROM transactions t
    JOIN product p ON t.productid = p.productid
    WHERE t.createdon BETWEEN p_startdate AND p_enddate
    AND t.status = p_status
    GROUP BY p.productid
    ORDER BY y_data DESC
    LIMIT p_limit;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_GetTrackPackageStatus` (IN `p_transtableid` INT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    
    SET p_result_status = 'FAILURE';
    SET p_result_message = 'Error retrieving package status';

    
    IF EXISTS (
        SELECT 1
        FROM `transactions`
        WHERE id = p_transtableid
    ) THEN
    SET p_result_status = 'SUCCESS';
        
        SET p_result_message = 'Package status retrieved successfully';
         
    SELECT p_result_status AS status, p_result_message AS message;
        
       SELECT t.id AS TransactionID, t.STATUS AS "Transaction Status", t.ordernumber AS "Order Number", t.createdon AS "Transaction Date"
FROM `transactions` t
INNER JOIN (
    SELECT ordernumber, MAX(createdon) AS max_createdon
    FROM `transactions`
    GROUP BY ordernumber
) latest ON t.ordernumber = latest.ordernumber AND t.createdon = latest.max_createdon
WHERE id = p_transtableid;
        
    ELSE
        
        SET p_result_message = 'transactions id does not exist';
    END IF;

    
    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_GetUserDetailsbyID` (IN `p_userid` BIGINT, OUT `p_status` VARCHAR(255), OUT `p_message` VARCHAR(255))  BEGIN
    
    SET p_status = 'ERROR';
    SET p_message = 'Error executing stored procedure';

    
    SELECT 1 INTO @user_exists FROM users WHERE userid = p_userid LIMIT 1;

    IF @user_exists IS NULL THEN
        SET p_status = 'FAILURE';
        SET p_message = 'User not found';        
    
    SELECT p_status AS status, p_message AS message;
    ELSE
        
        SET p_status = 'SUCCESS';
        SET p_message = 'User details retrieved successfully';
          
    SELECT p_status AS status, p_message AS message;

        
        
   SELECT
    u.userid,
    u.username,
    u.name,
    u.email,
    u.mobileno,
    r.rolesid AS roleid,
    r.name AS role_name,
    BIN(r.role) AS role,
    r.defaultmodule AS default_module_id,
    u.isstaff,
    u.status,
    (
        SELECT JSON_ARRAYAGG(
            JSON_OBJECT(
                'addressid', a.addressid,
                'name', a.name,
                'fulladdress',fulladdress,
                'locationdetails',locationdetails,
                'Landmark', a.Landmark,
                'city', a.city,
                'state', a.state,
                'country', a.country,
                'pincode', a.pincode,
                'email', a.email,
                'mobileno', a.mobileno,
                'alternatemobileno', a.alternatemobileno,
                'isprimary', a.isprimary,
                'iswork', a.iswork,
                'status', a.status
            )
        )
        FROM address a
        WHERE u.userid = a.userid
    ) AS addresses,
    GROUP_CONCAT(DISTINCT m.name) AS module_names,
    GROUP_CONCAT(DISTINCT m.moduleid) AS module_ids
FROM
    users u
LEFT JOIN userrolemap urm ON u.userid = urm.userid
LEFT JOIN roles r ON urm.roleid = r.rolesid
LEFT JOIN usermodulemap umm ON u.userid = umm.userid
LEFT JOIN module m ON umm.moduleid = m.moduleid
WHERE
    u.userid = p_userid
GROUP BY
    u.userid,
    u.username,
    u.name,
    u.email,
    u.mobileno,
    r.rolesid,
    r.name,
    u.isstaff,
    u.status;


    END IF;

END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_GetUserRoleDetailsByUserID` (IN `p_userid` BIGINT(19), OUT `sp_status` VARCHAR(50), OUT `sp_result` VARCHAR(255))  BEGIN
    DECLARE row_count INT;

    -- Initialize OUT parameters
    SET sp_status = 'SUCCESS';
    SET sp_result = 'User role details retrieved successfully';
    SELECT sp_status AS status, sp_result AS message;

    -- Check if the user role details exist
    SELECT COUNT(*) INTO row_count FROM userrolemap WHERE userid = p_userid;
    
    IF row_count > 0 THEN
        -- Fetch user role details
       SELECT
    u.userid AS UserID,
    r.rolesid,
    r.name AS role_name,
    BIN(r.role) AS role,
    r.status AS role_status,
    r.defaultmodule AS default_module_id,
    COALESCE(usm.schoolid, '') AS schoolid
FROM
    users u
JOIN
    userrolemap urm ON u.userid = urm.userid
JOIN
    roles r ON urm.roleid = r.rolesid
LEFT JOIN
    usersschoolmap usm ON u.userid = usm.userid
WHERE
    u.userid = p_userid;

        -- Set success status and message
        SET sp_status = 'SUCCESS';
        SET sp_result = 'User role details retrieved successfully';
    ELSE
        -- Set a message for no user role details found
        SET sp_result = 'No user role details found for the specified user ID';
    END IF;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_initproductapi` (OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE result_count INT;
    SELECT COUNT(*) INTO result_count FROM mastersdata c;
    
    IF result_count > 0 THEN
       SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Data retrieved successfully';
        
    SELECT p_result_status AS status, p_result_message AS message;
    ELSE
        SET p_result_status = 'ERROR';
        SET p_result_message = 'No data found';
        
        
        SELECT p_result_status AS status, p_result_message AS message;
    END IF;

    
    SELECT 
        b1.mastername AS 'Category Name',
        b.mastername AS 'Sub Category',
        c.name AS 'Type',
        b.category AS 'Master Code',
        c.masterid AS 'Category Code',
        c.dataid AS 'Data Code' 
    FROM 
        mastersdata c
    LEFT JOIN 
        masters b ON b.masterid = c.masterid
    LEFT JOIN 
        masters b1 ON b1.masterid = b.category 
    GROUP BY 
        c.dataid;

    
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_InsertAddress` (IN `p_userid` BIGINT, IN `p_name` VARCHAR(100), IN `p_fullAddress` TEXT, IN `p_locationDetails` TEXT, IN `p_city` VARCHAR(100), IN `p_state` VARCHAR(100), IN `p_country` VARCHAR(100), IN `p_pincode` VARCHAR(6), IN `p_email` VARCHAR(50), IN `p_mobileno` VARCHAR(10), IN `p_alternatemobileno` VARCHAR(10), IN `p_isprimary` BIT, IN `p_iswork` BIT, IN `p_status` BIT, IN `p_createdby` BIGINT, IN `p_createdon` DATETIME, OUT `p_result_status` VARCHAR(10), OUT `p_result_message` VARCHAR(100))  BEGIN
    DECLARE result_count INT;

    -- Insert into address table including fullAddress and locationDetails
    INSERT INTO address (
        userid, name, fullAddress, locationDetails, city, state, country, 
        pincode, email, mobileno, alternatemobileno, isprimary, iswork, status, 
        createdby, createdon, lastmodifiedby, lastmodifiedate
    )
    VALUES (
        p_userid, p_name, p_fullAddress, p_locationDetails, p_city, p_state, 
        p_country, p_pincode, p_email, p_mobileno, p_alternatemobileno, p_isprimary, 
        p_iswork, p_status, p_createdby, p_createdon, p_createdby, p_createdon
    );

    -- Check if the address was inserted
    SELECT ROW_COUNT() INTO result_count;

    IF result_count > 0 THEN
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Address inserted';
    ELSE
        SET p_result_status = 'ERROR';
        SET p_result_message = 'Address not inserted';
    END IF;

    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_InsertModule` (IN `p_name` VARCHAR(100), IN `p_created_by` INT, OUT `p_status` VARCHAR(255), OUT `p_message` VARCHAR(255))  BEGIN
    DECLARE duplicate_count INT;

    -- Check if the module name already exists
    SELECT COUNT(*) INTO duplicate_count FROM module WHERE name = p_name;

    IF duplicate_count > 0 THEN
        SET p_status = 'FAILURE';
        SET p_message = 'Module with the same name already exists.';
    ELSE
        -- Insert the new module
        INSERT INTO module (name, createdby) VALUES (p_name, p_created_by);
        
        SET p_status = 'SUCCESS';
        SET p_message = 'Module inserted successfully.';
    END IF;

    -- Return the status and message
    SELECT p_status AS status, p_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_InsertSchool` (IN `p_schoolcode` VARCHAR(200), IN `p_name` VARCHAR(200), IN `p_address` VARCHAR(500), IN `p_email` VARCHAR(50), IN `p_mobileno` VARCHAR(10), IN `p_createdby` BIGINT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE v_count INT;

    
    SELECT COUNT(*) INTO v_count FROM school WHERE schoolcode = p_schoolcode;

    IF v_count > 0 THEN
        
        SET p_result_status = 'ERROR';
        SET p_result_message = 'School code already exists';
    ELSE
        
        INSERT INTO school (
            schoolcode,
            name,
            address,
            email,
            mobileno,
            createdAt,
            createdby
        ) VALUES (
            p_schoolcode,
            p_name,
            p_address,
            p_email,
            p_mobileno,
            CURRENT_TIMESTAMP,
            p_createdby
        );

        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Record inserted successfully';
    END IF;
    
     SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_insertsmsotplog` (IN `p_mobileno` VARCHAR(10), IN `p_email` VARCHAR(50), IN `p_otpcode` VARCHAR(6), IN `p_senttime` DATETIME, IN `p_status` BIT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    
    IF NOT regexp_like(p_mobileno, '^[0-9]{10}$') THEN
        SET p_result_status = 'ERROR';
        SET p_result_message = 'Invalid mobile number format';
    ELSE
        
        IF EXISTS (SELECT 1 FROM otpsmslog WHERE mobileno = p_mobileno AND otpcode = p_otpcode) THEN
            
            UPDATE otpsmslog
            SET senttime = p_senttime,
                status = p_status
            WHERE mobileno = p_mobileno AND otpcode = p_otpcode;

            SET p_result_status = 'SUCCESS';
            SET p_result_message = 'Record updated successfully';
        ELSE
            
            INSERT INTO otpsmslog (mobileno, email, otpcode, senttime, status)
            VALUES (p_mobileno, p_email,  p_otpcode, p_senttime, p_status);

            SET p_result_status = 'SUCCESS';
            SET p_result_message = 'Record inserted successfully';
        END IF;
    END IF;
    
    SELECT p_result_status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_InsertTransaction` (IN `p_userid` INT, IN `p_productid` INT, IN `p_addressid` INT, IN `p_status` VARCHAR(50), OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE v_today DATE;
    DECLARE v_counter INT;
    DECLARE v_order_number VARCHAR(20);
    DECLARE v_trans_id VARCHAR(20);

    SET p_result_status = 'FAILURE';
    SET p_result_message = 'Error inserting transaction';

    SET v_today = CURDATE();

    IF NOT EXISTS (SELECT 1 FROM users WHERE userid = p_userid) THEN
        SET p_result_message = 'User ID does not exist';
    
    ELSEIF NOT EXISTS (SELECT 1 FROM product WHERE productid = p_productid) THEN
        SET p_result_message = 'Product ID does not exist';
    
    ELSE
        IF NOT EXISTS (
            SELECT 1
            FROM transactions
            WHERE userid = p_userid AND productid = p_productid
        ) THEN
            -- Increment daily counter
            INSERT INTO daily_reset_counter (counter_date, counter_value)
            VALUES (v_today, 1)
            ON DUPLICATE KEY UPDATE counter_value = counter_value + 1;

            SELECT counter_value INTO v_counter
            FROM daily_reset_counter
            WHERE counter_date = v_today;

            -- Create ordernumber and transid
            SET v_order_number = CONCAT('2CQR-',DATE_FORMAT(v_today, '%Y%m%d'), '-', LPAD(v_counter, 4, '0'));
            SET v_trans_id = CONCAT('Trans-',DATE_FORMAT(v_today, '%Y%m%d'), '-', LPAD(v_counter, 4, '0'));

            -- Insert into transactions
            INSERT INTO transactions (userid, productid, addressid, status, ordernumber, transid)
            VALUES (p_userid, p_productid, p_addressid, p_status, v_order_number, v_trans_id);

            -- Log the transaction
            INSERT INTO transactionlog (transtableid, status, createdby)
            VALUES (LAST_INSERT_ID(), p_status, p_userid);

            SET p_result_status = 'SUCCESS';
            SET p_result_message = 'Transaction inserted successfully';
        ELSE
            SET p_result_message = 'Duplicate transaction entry';
        END IF;
    END IF;

    -- Return result
    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_InsertTransactionBulk` (IN `p_userid` INT, IN `p_addressid` INT, IN `p_status` VARCHAR(50), OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE current_productid INT;
    DECLARE idx INT DEFAULT 0;
    DECLARE p_productid JSON;
    DECLARE max_order_number INT;
    DECLARE trans_counter INT;
    DECLARE order_counter INT;

    -- Fetch p_productid JSON array from addtocarttable
    SELECT JSON_ARRAYAGG(productid)
    INTO p_productid
    FROM addtocarttable
    WHERE userid = p_userid AND status = 'incart';

    SET p_result_status = 'FAILURE';
    SET p_result_message = 'No Products in Cart';

    IF NOT EXISTS (SELECT 1 FROM users WHERE userid = p_userid) THEN
        SET p_result_message = 'User ID does not exist';
    ELSE
        -- Generate the transid
        SET @date_string = DATE_FORMAT(NOW(), '%Y%m%d');
        SELECT COALESCE(MAX(counter_value), 0) + 1 INTO trans_counter
        FROM daily_reset_counter
        WHERE counter_date = CURDATE();
        
        -- Update or insert the counter
        INSERT INTO daily_reset_counter (counter_date, counter_value)
        VALUES (CURDATE(), trans_counter)
        ON DUPLICATE KEY UPDATE counter_value = trans_counter;
        
        SET @trans_id = CONCAT('Trans-', @date_string, '-', LPAD(trans_counter, 4, '0'));

        -- Initialize the order counter
        SET order_counter = 1;

        WHILE idx < JSON_LENGTH(p_productid) DO
            SET current_productid = JSON_UNQUOTE(JSON_EXTRACT(p_productid, CONCAT('$[', idx, ']')));

            -- Check if the product status is 'incart' and available
            IF EXISTS (SELECT 1 FROM addtocarttable WHERE productid = current_productid AND userid = p_userid AND status = 'incart') THEN
                -- Check if the product exists
                IF EXISTS (SELECT 1 FROM product WHERE productid = current_productid) THEN
                    -- Generate the ordernumber
                    SET @order_number = CONCAT('2CQR-', @date_string, '-', LPAD(order_counter, 4, '0'));
                    SET order_counter = order_counter + 1;

                    -- Insert the transaction
                    INSERT INTO transactions (userid, productid, addressid, status, ordernumber, transid)
                    VALUES (p_userid, current_productid, p_addressid, p_status, @order_number, @trans_id);

                    -- Insert a corresponding log entry
                    INSERT INTO transactionlog (transtableid, status, createdby)
                    VALUES (@trans_id, p_status, p_userid);

                    -- Change the status of the product in addtocarttable to 'Ordered'
                    UPDATE addtocarttable
                    SET status = 'Ordered'
                    WHERE productid = current_productid AND userid = p_userid;

                    SET p_result_status = 'SUCCESS';
                    SET p_result_message = 'Transaction(s) inserted successfully';
                ELSE
                    SET p_result_message = CONCAT('Product ID ', current_productid, ' does not exist');
                END IF;
            ELSE
                -- Change the status of the product in addtocarttable to 'expired' if not available
                UPDATE addtocarttable
                SET status = 'expired'
                WHERE productid = current_productid AND userid = p_userid;

                SET p_result_message = CONCAT('Product ID ', current_productid, ' is not available in cart');
            END IF;

            SET idx = idx + 1;
        END WHILE;
    END IF;

    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_quantity` (IN `p_userid` BIGINT, IN `p_productid` BIGINT, IN `p_quantity` INT, OUT `p_result_status` VARCHAR(10), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE p_name VARCHAR(255);
    DECLARE p_description TEXT;
    DECLARE p_count INT;
    DECLARE p_added_quantity INT;
    DECLARE p_removed_quantity INT;

    -- Step 1: Get name and description of the product
    SELECT name, description INTO p_name, p_description 
    FROM product 
    WHERE productid = p_productid;

    -- Step 2: Get current count of 'incart' items for the specified product and user
    SELECT COALESCE(COUNT(*), 0) INTO p_count
    FROM addtocarttable a
    JOIN product p ON a.productid = p.productid
    WHERE a.userid = p_userid 
      AND p.name COLLATE utf8mb4_unicode_ci = p_name COLLATE utf8mb4_unicode_ci
      AND p.description COLLATE utf8mb4_unicode_ci = p_description COLLATE utf8mb4_unicode_ci
      AND a.status = 'incart';

    -- Step 3: Calculate the action based on p_count and p_quantity
    IF p_quantity > p_count THEN
        -- Calculate how many more items to add
        SET p_added_quantity = p_quantity - p_count;

        -- Insert the required quantity of products into the cart
        INSERT INTO addtocarttable (userid, productid, status)
        SELECT p_userid, productid, 'incart'
        FROM (
            SELECT productid
            FROM product
            WHERE name COLLATE utf8mb4_unicode_ci = p_name COLLATE utf8mb4_unicode_ci
              AND description COLLATE utf8mb4_unicode_ci = p_description COLLATE utf8mb4_unicode_ci
              AND productid NOT IN (
                  SELECT productid FROM addtocarttable WHERE userid = p_userid AND status = 'incart'
              )
            ORDER BY productid DESC
            LIMIT p_added_quantity
        ) AS subquery;

        SET p_result_status = 'SUCCESS';
        SET p_result_message = CONCAT(p_added_quantity, ' record(s) inserted');
    ELSEIF p_quantity < p_count THEN
        -- Calculate how many items to remove
        SET p_removed_quantity = p_count - p_quantity;

        -- Remove the excess quantity of products from the cart
        UPDATE addtocarttable a
        JOIN (
            SELECT a.productid
            FROM addtocarttable a
            JOIN product p ON a.productid = p.productid
            WHERE a.userid = p_userid 
              AND p.name COLLATE utf8mb4_unicode_ci = p_name COLLATE utf8mb4_unicode_ci
              AND p.description COLLATE utf8mb4_unicode_ci = p_description COLLATE utf8mb4_unicode_ci
              AND a.status = 'incart'
            ORDER BY a.productid ASC
            LIMIT p_removed_quantity
        ) AS subquery ON a.productid = subquery.productid
        SET a.status = 'delete';

        SET p_result_status = 'SUCCESS';
        SET p_result_message = CONCAT(p_removed_quantity, ' record(s) removed');
    ELSE
        -- No action required if p_quantity equals p_count
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'No action taken';
    END IF;

    -- Step 4: Return status and message
    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_quantityadd` (IN `p_userid` BIGINT, IN `p_productid` BIGINT, OUT `p_result_status` VARCHAR(10), OUT `p_result_message` VARCHAR(255))  BEGIN
   
DECLARE next_available_productid BIGINT;
DECLARE done BOOLEAN DEFAULT FALSE;


DECLARE cur_available_productid CURSOR FOR
    SELECT productid
    FROM product
    WHERE name = (SELECT name FROM product WHERE productid = p_productid)
        AND description = (SELECT description FROM product WHERE productid = p_productid)
        AND productid != p_productid;


DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;


OPEN cur_available_productid;


read_loop: LOOP
    FETCH cur_available_productid INTO next_available_productid;

    IF done THEN
        LEAVE read_loop;
    END IF;

    
    SELECT next_available_productid AS debug_next_available_productid;

    
    IF NOT EXISTS (
        SELECT 1
        FROM addtocarttable
        WHERE productid = next_available_productid AND STATUS = 'incart' 
    ) THEN        
            
            INSERT INTO addtocarttable (userid, productid, status)
            VALUES (p_userid, next_available_productid, 'incart');

            SET p_result_status = 'SUCCESS';
            SET p_result_message = 'Record inserted';

            
            

            LEAVE read_loop; 
    END IF;
END LOOP;


CLOSE cur_available_productid;


IF done AND p_result_status IS NULL THEN
    SET p_result_status = 'ERROR';
    SET p_result_message = 'No More Same Product Available - OUT OF STOCK';
END IF;


SELECT p_result_status AS status, p_result_message AS message;

END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_quantityremove` (IN `p_userid` BIGINT, IN `p_productid` BIGINT, OUT `p_result_status` VARCHAR(10), OUT `p_result_message` VARCHAR(100))  BEGIN
    DECLARE next_available_productid BIGINT;

    
    SELECT productid INTO next_available_productid
    FROM addtocarttable
    WHERE userid = p_userid
        AND productid IN (
            SELECT productid
            FROM product
            WHERE name = (SELECT name FROM product WHERE productid = p_productid)
                AND description = (SELECT description FROM product WHERE productid = p_productid)
                
        )
        AND status = 'incart'
    LIMIT 1;  

    
    IF next_available_productid IS NOT NULL THEN
        
        UPDATE addtocarttable
        SET status = 'delete'
        WHERE userid = p_userid
            AND productid = next_available_productid;

        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Record status updated';
    ELSE
        SET p_result_status = 'ERROR';
        SET p_result_message = 'No matching record found for deletion';
    END IF;

    
    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_Register` (IN `p_username` VARCHAR(50), IN `p_password` VARCHAR(150), IN `p_name` VARCHAR(100), IN `p_email` VARCHAR(50), IN `p_mobileno` VARCHAR(10), IN `p_schoolcodes` JSON, IN `p_fullAddress` TEXT, IN `p_locationDetails` TEXT, IN `p_landmark` VARCHAR(255), IN `p_city` VARCHAR(100), IN `p_state` VARCHAR(100), IN `p_country` VARCHAR(100), IN `p_pincode` VARCHAR(6), IN `p_alternatemobileno` VARCHAR(10), IN `p_isprimary` BIT, IN `p_iswork` BIT, IN `p_status` BIT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE v_username_count INT;
    DECLARE v_mobileno_count INT;
    DECLARE v_email_count INT;
    DECLARE v_all_schools_valid BOOLEAN DEFAULT TRUE;
    DECLARE v_user_id BIGINT;
    DECLARE idx INT DEFAULT 0;
    DECLARE total INT;
    DECLARE code VARCHAR(255);
    DECLARE school_id INT;
    DECLARE idxinsert INT DEFAULT 0;
    DECLARE p_roleid BIGINT;

    -- Retrieve the role ID from the roles table
    SELECT rolesid INTO p_roleid
    FROM roles
    WHERE name = 'online';

    -- Check for existing username, mobile number, and email
    SELECT COUNT(*) INTO v_username_count FROM users WHERE username = p_username;
    SELECT COUNT(*) INTO v_mobileno_count FROM users WHERE mobileno = p_mobileno;
    SELECT COUNT(*) INTO v_email_count FROM users WHERE email = p_email;

    -- Get the length of the JSON array
    SET total = JSON_LENGTH(p_schoolcodes);

    -- Loop through each school code in the JSON array
    WHILE idx < total DO
        -- Extract the school code from the JSON array
        SET code = JSON_UNQUOTE(JSON_EXTRACT(p_schoolcodes, CONCAT('$[', idx, ']')));

        -- Check if the school code exists in the school table
        SELECT schoolid INTO school_id FROM school WHERE schoolcode = code;

        -- If the school code is not found, set the result status and message, and exit the loop
        IF school_id IS NULL THEN
            SET v_all_schools_valid = FALSE;
            SET idx = total; -- Exit the loop
        END IF;

        -- Increment the index to move to the next school code
        SET idx = idx + 1;
    END WHILE;

    -- Validate inputs and set result status and message accordingly
    IF v_username_count > 0 THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'Username already exists';
    ELSEIF v_mobileno_count > 0 THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'Mobile number already exists';
    ELSEIF v_email_count > 0 THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'Email already exists';
    ELSEIF LENGTH(p_mobileno) <> 10 THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'Mobile number must be a 10-digit number';
    ELSEIF LENGTH(p_pincode) <> 6 THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'Pin code must be a 6-digit number';
    ELSEIF LENGTH(p_email) > 0 AND NOT REGEXP_LIKE(p_email, '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z|a-z]{2,}$') THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'Invalid email format';
    ELSEIF NOT v_all_schools_valid THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'One or more school codes not found';
    ELSE
    		 -- Update the 'deleted_at' column with the current timestamp
    UPDATE temp_register
    SET deleted_at = CURRENT_TIMESTAMP
    WHERE mobileno = p_mobileno AND deleted_at IS NULL;
        -- Insert the data as JSON into temp_register
        INSERT INTO temp_register (mobileno, json_data)
        VALUES (p_mobileno, 
                JSON_OBJECT(
                    'username', p_username,
                    'password', p_password,
                    'name', p_name,
                    'email', p_email,
                    'schoolcodes', p_schoolcodes,
                    'fullAddress', p_fullAddress,
                    'locationDetails', p_locationDetails,
                    'landmark', p_landmark,
                    'city', p_city,
                    'state', p_state,
                    'country', p_country,
                    'pincode', p_pincode,
                    'alternatemobileno', p_alternatemobileno,
                    'isprimary', p_isprimary,
                    'iswork', p_iswork,
                    'status', p_status,
                    'roleid', p_roleid  -- Added p_roleid here
                ));

        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Data temporarily registered, pending OTP verification';
       
    END IF;

    -- Output the result status and message
    SELECT p_result_status AS status, p_result_message AS message;

END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_RemoveRoleFromUser` (IN `p_userid` BIGINT, IN `p_rolesid` BIGINT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    
    SET p_result_status = 'FAILURE';
    SET p_result_message = 'Error removing role from user';

    
    IF NOT EXISTS (SELECT 1 FROM users WHERE userid = p_userid) THEN
        SET p_result_message = 'User ID does not exist';
    ELSE
        
        IF NOT EXISTS (SELECT 1 FROM roles WHERE rolesid = p_rolesid) THEN
            SET p_result_message = 'Role ID does not exist';
        ELSE
            
            DELETE FROM userrolemap WHERE userid = p_userid AND roleid = p_rolesid;

            
            SET p_result_status = 'SUCCESS';
            SET p_result_message = 'Role removed from user successfully';
        END IF;
    END IF;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_reportDataGetByName` (IN `p_report_name` VARCHAR(255), OUT `p_result_status` VARCHAR(50), OUT `p_result_message` JSON)  BEGIN
    -- Declare variables
    DECLARE v_report_id INT;
    DECLARE v_report_query TEXT;
    DECLARE v_dpname VARCHAR(50);
    DECLARE v_filter_query TEXT;
    DECLARE done INT DEFAULT 0;
    DECLARE v_query TEXT;
    DECLARE v_export_flag BOOLEAN;
    DECLARE v_include_filter BOOLEAN;
    DECLARE v_fromdate BOOLEAN;
    DECLARE v_todate BOOLEAN;
    DECLARE resultdata JSON;

    -- Error handling variables
    DECLARE error_occurred BOOLEAN DEFAULT FALSE;
    DECLARE error_message TEXT;

    -- Error handler for SQL exceptions
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
    BEGIN
        SET error_occurred = TRUE;
        GET DIAGNOSTICS CONDITION 1 error_message = MESSAGE_TEXT;
    END;

    -- Fetch data from the report table
    SELECT reportid, fromdate, todate, report_export , include_filter
    INTO v_report_id, v_fromdate, v_todate, v_export_flag,v_include_filter
    FROM report 
    WHERE report_name = p_report_name;

    -- Check if an error occurred during the previous query
    IF error_occurred THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = JSON_OBJECT('error', error_message);
        SELECT p_result_status AS status, p_result_message AS message;
    END IF;

    -- Check if the report exists
    IF v_report_id IS NULL THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = JSON_OBJECT('error', 'Report not found');
        SELECT p_result_status AS status, p_result_message AS message;
    ELSE
        -- Fetch the report query
        SELECT report_query INTO v_report_query 
        FROM report 
        WHERE reportid = v_report_id;

        -- Check if an error occurred during the previous query
        IF error_occurred THEN
            SET p_result_status = 'FAILURE';
            SET p_result_message = JSON_OBJECT('error', error_message);
            SELECT p_result_status AS status, p_result_message AS message;
        END IF;

        -- Check if the report query is fetched
        IF v_report_query IS NULL THEN
            SET p_result_status = 'FAILURE';
            SET p_result_message = JSON_OBJECT('error', 'Report query not found');
            SELECT p_result_status AS status, p_result_message AS message;
        ELSE
            -- Set the final result status and message
            SET p_result_status = 'SUCCESS';
            SET p_result_message = JSON_OBJECT('Success', 'Report query found');
            SELECT p_result_status AS status, p_result_message AS message;

            -- Fetch the result of the executed query
            SET resultdata = JSON_OBJECT('report_id', v_report_id, 'report_name', p_report_name, 'fromdate', v_fromdate, 'todate', v_todate, 'export_flag', v_export_flag,'include_filter',v_include_filter);
            SELECT resultdata;

            -- Create a temporary table to store filter queries
            CREATE TEMPORARY TABLE IF NOT EXISTS temp_filter_queries (
                dpname VARCHAR(50),
                query_str TEXT,
                report_id INT
            );

            -- Insert filter queries into the temporary table
            INSERT INTO temp_filter_queries (dpname, query_str, report_id)
            SELECT dpname, query_str, reportid
            FROM reportfilter 
            WHERE reportid = v_report_id;

            -- Fetch and execute each filter query and build the filter clause
            WHILE (SELECT COUNT(*) FROM temp_filter_queries WHERE report_id = v_report_id) > 0 DO
                -- Fetch the next filter query
                SELECT dpname, query_str 
                INTO v_dpname, v_filter_query 
                FROM temp_filter_queries 
                WHERE report_id = v_report_id 
                LIMIT 1;
                
                -- Display JSON object with dpname and value_str
                SELECT JSON_OBJECT('dpname', v_dpname, 'static_value', value_str, 'control_type', control_type) AS json_value_result
                FROM reportfilter
                WHERE dpname = v_dpname AND reportid = v_report_id;

                -- Execute the filter query and store the result
                SET @filter_query = v_filter_query;
                PREPARE stmt_filter FROM @filter_query;
                EXECUTE stmt_filter;
                DEALLOCATE PREPARE stmt_filter;
                -- Delete the fetched row
                DELETE FROM temp_filter_queries WHERE dpname = v_dpname;
            END WHILE;

            -- Drop the temporary table
            DROP TEMPORARY TABLE IF EXISTS temp_filter_queries;
        END IF;
    END IF;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_ReturnOrder` (IN `p_transtableid` INT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    
    SET p_result_status = 'FAILURE';
    SET p_result_message = 'transactions id not exists';

    
    IF EXISTS (
        SELECT 1
        FROM `transactions`
        WHERE id = p_transtableid
    ) THEN
        
        UPDATE `transactions`
        SET status = 'returninitiated'
        WHERE id = p_transtableid;

        
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Return initiated successfully';
    ELSE
        
        SET p_result_message = 'transactions id does not exist';
    END IF;

    
    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_SaveReportSetting` (IN `p_report_name` VARCHAR(255), IN `p_fromdate` BOOLEAN, IN `p_todate` BOOLEAN, IN `p_export` BOOLEAN, IN `p_include_filter` BOOLEAN, IN `p_query` TEXT, IN `p_last_modified_by` INT, IN `p_filter_data` JSON, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE v_report_count INT;
    DECLARE report_id INT;
    DECLARE idx INT DEFAULT 0;
    DECLARE total INT;
    DECLARE dpname VARCHAR(50);
    DECLARE bkname VARCHAR(50);
    DECLARE query_value VARCHAR(100);
    DECLARE query_str TEXT;
     DECLARE control_type_str TEXT;

    -- Check if the report name already exists
    SELECT COUNT(*) INTO v_report_count FROM report WHERE report_name = p_report_name;

    IF v_report_count > 0 THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'Report name already exists';
        SELECT p_result_status AS status, p_result_message AS message;
    ELSE
        -- Insert a new record into the report table
        INSERT INTO report (report_name, fromdate, todate, report_export, report_query,include_filter, created_by, modified_by, status)
        VALUES (p_report_name, p_fromdate, p_todate, p_export, p_query,p_include_filter, p_last_modified_by, p_last_modified_by, 'active');

        SET report_id = LAST_INSERT_ID();

        IF report_id > 0 THEN
            SET p_result_status = 'SUCCESS';
            SET p_result_message = 'Report added successfully';
            SELECT p_result_status AS status, p_result_message AS message;

            -- Get the length of the JSON array
            SET total = JSON_LENGTH(p_filter_data);

            -- Loop through each element in the JSON array
            WHILE idx < total DO
                -- Extract the dpname, bkname, and value fields from the JSON array element
                SET dpname = JSON_UNQUOTE(JSON_EXTRACT(p_filter_data, CONCAT('$[', idx, '].dpname')));
                SET bkname = JSON_UNQUOTE(JSON_EXTRACT(p_filter_data, CONCAT('$[', idx, '].bkname')));
                SET query_value = JSON_UNQUOTE(JSON_EXTRACT(p_filter_data, CONCAT('$[', idx, '].value')));
                SET query_str = JSON_UNQUOTE(JSON_EXTRACT(p_filter_data, CONCAT('$[', idx, '].query')));
                SET control_type_str = JSON_UNQUOTE(JSON_EXTRACT(p_filter_data, CONCAT('$[', idx, '].control_type')));

                -- Insert filter values into the reportfilter table
                INSERT INTO reportfilter (reportid, dpname, bkname, value_str,query_str,control_type, created_by, modified_by, status)
                VALUES (report_id, dpname, bkname, query_value,query_str,control_type_str, p_last_modified_by, p_last_modified_by, 'active');

                SET idx = idx + 1;
            END WHILE;

        ELSE
            SET p_result_status = 'FAILURE';
            SET p_result_message = 'Failed to add report record';
        END IF;
    END IF;

    -- Return the result status and message
    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_School_DB_GetOrderDetailsByStatus` (IN `p_school_id` BIGINT(19), IN `p_status` VARCHAR(50), IN `p_page_no` INT, IN `p_index` INT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE start_index INT DEFAULT 0;
    SET start_index := (p_page_no - 1) * p_index;

    SET p_result_status = 'SUCCESS';
    SET p_result_message = 'Order details retrieved successfully';
    SELECT p_result_status AS status, p_result_message AS message;

    SELECT 
        a.lastmodifiedat,
        a.id AS TransID,
        a.status,
        a.ordernumber,
        JSON_OBJECT("userid", MAX(a.userid)) AS User_details,
        JSON_OBJECT(
            "addressid", IFNULL(MAX(e.addressid), ""),
            "address_name", IFNULL(MAX(e.name), ""),
            "addressline1", IFNULL(MAX(e.address1), ""),
            "addressline2", IFNULL(MAX(e.address2), ""),
            "city", IFNULL(MAX(e.city), ""),
            "pincode", IFNULL(MAX(e.pincode), "")
        ) AS address_details,
        JSON_ARRAYAGG(
            JSON_OBJECT(
                "productid", b.productid,
                "name", b.name,
                "description", b.description,
                "price", b.price
            )
        ) AS products
    FROM
        transactions a
        LEFT JOIN product b ON a.productid = b.productid
        LEFT JOIN address e ON e.addressid = a.addressid
        JOIN productschoolmap p ON a.productid = p.productid
    WHERE
        a.status = p_status
        AND p.schoolid = p_school_id
    GROUP BY
        a.ordernumber, a.lastmodifiedat, a.id
    ORDER BY
        MAX(a.lastmodifiedat) DESC
    LIMIT
        start_index, p_index;

    
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_School_DB_GetOrderDetailsByStatusByDatewise` (IN `p_startdate` DATETIME, IN `p_enddate` DATETIME, IN `p_school_id` BIGINT(19), IN `p_status` VARCHAR(50), IN `p_page_no` INT, IN `p_index` INT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE start_index INT DEFAULT 0;
    SET start_index := (p_page_no - 1) * p_index;

    SET p_result_status = 'SUCCESS';
    SET p_result_message = 'Order details retrieved successfully';
    SELECT p_result_status AS status, p_result_message AS message;

    SELECT 
        a.lastmodifiedat,
        a.id AS TransID,
        a.status,
        a.ordernumber,
        JSON_OBJECT("userid", MAX(a.userid)) AS User_details,
        JSON_OBJECT(
            "addressid", IFNULL(MAX(e.addressid), ""),
            "address_name", IFNULL(MAX(e.name), ""),
            "addressline1", IFNULL(MAX(e.address1), ""),
            "addressline2", IFNULL(MAX(e.address2), ""),
            "city", IFNULL(MAX(e.city), ""),
            "pincode", IFNULL(MAX(e.pincode), "")
        ) AS address_details,
        JSON_ARRAYAGG(
            JSON_OBJECT(
                "productid", b.productid,
                "name", b.name,
                "description", b.description,
                "price", b.price
            )
        ) AS products
    FROM
        transactions a
        LEFT JOIN product b ON a.productid = b.productid
        LEFT JOIN address e ON e.addressid = a.addressid
        JOIN productschoolmap p ON a.productid = p.productid
    WHERE
        a.status = p_status
        AND p.schoolid = p_school_id
        AND a.lastmodifiedat BETWEEN p_startdate AND p_enddate
    GROUP BY
        a.ordernumber, a.lastmodifiedat, a.id
    ORDER BY
        MAX(a.lastmodifiedat) DESC
    LIMIT
        start_index, p_index;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_School_DB_GetRevenueTrend` (IN `p_startdate` DATE, IN `p_enddate` DATE, IN `p_schoolid` INT, IN `p_status` VARCHAR(15), IN `p_chart_type` VARCHAR(15), OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    -- Initialize output parameters
    SET p_result_status = 'SUCCESS';
    SET p_result_message = 'Revenue trend retrieved successfully';

    -- Return status and message
    SELECT p_result_status AS status, p_result_message AS message;

    -- Set max recursion depth
    SET @@cte_max_recursion_depth = 20000; -- or any other larger value you need

    -- Retrieve revenue trend data based on chart type
    IF p_chart_type = 'day' THEN
        WITH RECURSIVE date_range AS (
            SELECT p_startdate AS date_value
            UNION ALL
            SELECT DATE_ADD(date_value, INTERVAL 1 DAY)
            FROM date_range
            WHERE date_value < p_enddate
        )
        SELECT 
            dr.date_value AS x_data,
            COALESCE(SUM(p.price), 0.00) AS y_data
        FROM date_range dr
        LEFT JOIN transactions t ON DATE(t.createdon) = dr.date_value AND t.status = p_status
        LEFT JOIN product p ON t.productid = p.productid
        JOIN productschoolmap ps ON p.productid = ps.productid
        WHERE ps.schoolid = p_schoolid
        GROUP BY dr.date_value
        ORDER BY dr.date_value;

    ELSEIF p_chart_type = 'month' THEN
        WITH RECURSIVE date_range AS (
            SELECT DATE_FORMAT(p_startdate, '%Y-%m-01') AS date_value
            UNION ALL
            SELECT DATE_FORMAT(DATE_ADD(date_value, INTERVAL 1 MONTH), '%Y-%m-01')
            FROM date_range
            WHERE date_value < DATE_FORMAT(p_enddate, '%Y-%m-01')
        )
        SELECT 
            DATE_FORMAT(dr.date_value, '%Y-%m') AS x_data,
            COALESCE(SUM(p.price), 0.00) AS y_data
        FROM date_range dr
        LEFT JOIN transactions t ON DATE_FORMAT(t.createdon, '%Y-%m') = DATE_FORMAT(dr.date_value, '%Y-%m') AND t.status = p_status
        LEFT JOIN product p ON t.productid = p.productid
        JOIN productschoolmap ps ON p.productid = ps.productid
        WHERE ps.schoolid = p_schoolid
        GROUP BY DATE_FORMAT(dr.date_value, '%Y-%m')
        ORDER BY DATE_FORMAT(dr.date_value, '%Y-%m');

    ELSEIF p_chart_type = 'year' THEN
        WITH RECURSIVE date_range AS (
            SELECT DATE_FORMAT(p_startdate, '%Y-01-01') AS date_value
            UNION ALL
            SELECT DATE_FORMAT(DATE_ADD(date_value, INTERVAL 1 YEAR), '%Y-01-01')
            FROM date_range
            WHERE date_value < DATE_FORMAT(p_enddate, '%Y-01-01')
        )
        SELECT 
            DATE_FORMAT(dr.date_value, '%Y') AS x_data,
            COALESCE(SUM(p.price), 0.00) AS y_data
        FROM date_range dr
        LEFT JOIN transactions t ON DATE_FORMAT(t.createdon, '%Y') = DATE_FORMAT(dr.date_value, '%Y') AND t.status = p_status
        LEFT JOIN product p ON t.productid = p.productid
        JOIN productschoolmap ps ON p.productid = ps.productid
        WHERE ps.schoolid = p_schoolid
        GROUP BY DATE_FORMAT(dr.date_value, '%Y')
        ORDER BY DATE_FORMAT(dr.date_value, '%Y');

    END IF;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_School_DB_GetTopSellingProducts` (IN `p_startdate` DATETIME, IN `p_enddate` DATETIME, IN `p_limit` INT, IN `p_status` VARCHAR(15), IN `p_schoolid` INT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    -- Initialize output parameters
    SET p_result_status = 'SUCCESS';
    SET p_result_message = 'Top selling products retrieved successfully';
    
    -- Return status and message
    SELECT p_result_status AS status, p_result_message AS message;
    
    -- Debug statements
    -- SELECT p_startdate, p_enddate, p_limit, p_status, p_schoolid;
    
    -- Retrieve top selling products
    SELECT 
        p.name AS x_data,
        COUNT(*) AS y_data
    FROM transactions t
    JOIN product p ON t.productid = p.productid
    JOIN productschoolmap ps ON p.productid = ps.productid
    WHERE t.createdon BETWEEN p_startdate AND p_enddate
      AND t.status = p_status
      AND ps.schoolid = p_schoolid -- Filter by schoolid
    GROUP BY p.name
    ORDER BY y_data DESC
    LIMIT p_limit;

END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_School_DB_GetTopSellingProductsBycharttype` (IN `p_startdate` DATE, IN `p_enddate` DATE, IN `p_schoolid` INT, IN `p_limit` INT, IN `p_status` VARCHAR(15), IN `p_chart_type` VARCHAR(15), OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    -- Initialize output parameters
    SET p_result_status = 'SUCCESS';
    SET p_result_message = 'Top selling products retrieved successfully';

    -- Return status and message
    SELECT p_result_status AS status, p_result_message AS message;

    -- Retrieve top selling products data based on chart type
    IF p_chart_type = 'day' THEN
        SELECT 
            DATE(t.createdon) AS x_data,
            p.name,
            COUNT(*) AS y_data
        FROM transactions t
        JOIN product p ON t.productid = p.productid
        JOIN productschoolmap ps ON p.productid = ps.productid
        WHERE 
            t.createdon BETWEEN p_startdate AND p_enddate
            AND t.status = p_status
            AND ps.schoolid = p_schoolid
        GROUP BY DATE(t.createdon), p.name
        ORDER BY y_data DESC
        LIMIT p_limit;

    ELSEIF p_chart_type = 'month' THEN
        SELECT 
            DATE_FORMAT(t.createdon, '%Y-%m') AS x_data,
            p.name,
            COUNT(*) AS y_data
        FROM transactions t
        JOIN product p ON t.productid = p.productid
        JOIN productschoolmap ps ON p.productid = ps.productid
        WHERE 
            t.createdon BETWEEN p_startdate AND p_enddate
            AND t.status = p_status
            AND ps.schoolid = p_schoolid
        GROUP BY DATE_FORMAT(t.createdon, '%Y-%m'), p.name
        ORDER BY y_data DESC
        LIMIT p_limit;

    ELSEIF p_chart_type = 'year' THEN
        SELECT 
            DATE_FORMAT(t.createdon, '%Y') AS x_data,
            p.name,
            COUNT(*) AS y_data
        FROM transactions t
        JOIN product p ON t.productid = p.productid
        JOIN productschoolmap ps ON p.productid = ps.productid
        WHERE 
            t.createdon BETWEEN p_startdate AND p_enddate
            AND t.status = p_status
            AND ps.schoolid = p_schoolid
        GROUP BY DATE_FORMAT(t.createdon, '%Y'), p.name
        ORDER BY y_data DESC
        LIMIT p_limit;

    END IF;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_SearchProduct` (IN `search_input` VARCHAR(500), OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE result_count INT;

    -- Add indexes on columns used in the search
   -- ALTER TABLE product ADD INDEX idx_name_description (NAME, DESCRIPTION);

    -- Check if the search_input is empty
    IF search_input = '' THEN
        SET result_count = 0;
    ELSE
        -- Use a subquery to perform the search and count results
        SELECT COUNT(*) INTO result_count
        FROM (
            SELECT productid
            FROM product
            WHERE CONCAT(NAME, '-', DESCRIPTION) LIKE CONCAT('%', search_input, '%') COLLATE utf8mb4_unicode_ci
        ) AS temp_result;
    END IF;

    IF result_count > 0 THEN
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Data retrieved successfully';

        SELECT p_result_status AS status, p_result_message AS message;

        -- Use a subquery to select the search results
        SELECT CONCAT(p_name.name, '-', p_desc.description) AS searchterms,
               p.productid,
               p.masterid,
               JSON_ARRAYAGG(pt.submasterid) AS submasterids,
               JSON_ARRAYAGG(pt.subdataid) AS subdataids
        FROM product p
        LEFT JOIN producttext pt ON p.productid = pt.productid
        LEFT JOIN
          (SELECT productid, NAME FROM product) AS p_name ON p.productid = p_name.productid
        LEFT JOIN
          (SELECT productid, DESCRIPTION FROM product) AS p_desc ON p.productid = p_desc.productid
        WHERE CONCAT(p_name.name, '-', p_desc.description) LIKE CONCAT('%', search_input, '%') COLLATE utf8mb4_unicode_ci
        GROUP BY p.productid
        ORDER BY p.productid ASC
        LIMIT 10;
    ELSE
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'No data found';

        SELECT p_result_status AS status, p_result_message AS message;

        SELECT NULL AS empty_result
        WHERE FALSE;
    END IF;

END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_SearchProductMinidetailsFilters` (IN `p_subdataid` BIGINT, IN `p_submasterid` BIGINT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE result_count INT; 

    
    SELECT COUNT(*) INTO result_count
    FROM
        product a 
    LEFT JOIN
        productschoolmap b ON a.productid = b.productid
    LEFT JOIN
        productimage c ON a.productid = c.productid
    LEFT JOIN
        producttext d ON d.productid = a.productid
    WHERE
        d.subdataid IN (p_subdataid) AND d.submasterid IN (p_submasterid)
    GROUP BY
        a.productid;


 IF result_count > 0 THEN
        
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Data retrieved successfully';
        SELECT p_result_status AS status, p_result_message AS message;
    
    SELECT
        a.name,
        a.price,
        GROUP_CONCAT(TO_BASE64(c.image) SEPARATOR ', ') AS images
    FROM
        product a
    LEFT JOIN
        productschoolmap b ON a.productid = b.productid
    LEFT JOIN
        productimage c ON a.productid = c.productid 
    LEFT JOIN
        producttext d ON d.productid = a.productid 
    WHERE
         d.subdataid IN (p_subdataid) AND d.submasterid IN (p_submasterid)
    GROUP BY
        a.productid
    ORDER BY
        a.lastmodifiedate DESC;
    ELSE
        
        SET p_result_status = 'ERROR';
        SET p_result_message = 'No data found';
        SELECT p_result_status AS status, p_result_message AS message;
    END IF;

    
   
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_SearchProductMinidetailsSchool` (IN `p_userid` BIGINT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE result_count INT; 

    
    SELECT COUNT(*) INTO result_count
    FROM
        product a 
    LEFT JOIN
        productschoolmap b ON a.productid = b.productid
    LEFT JOIN
        productimage c ON a.productid = c.productid 
    WHERE
        b.schoolid IN (SELECT schoolid FROM `usersschoolmap` WHERE userid = p_userid)
    GROUP BY
        a.productid;


    
    IF result_count > 0 THEN
        
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Data retrieved successfully';
        SELECT p_result_status AS status, p_result_message AS message;

    
    SELECT
        a.name,
        a.price,
        GROUP_CONCAT(TO_BASE64(c.image) SEPARATOR ', ') AS images
    FROM
        product a
    LEFT JOIN
        productschoolmap b ON a.productid = b.productid
    LEFT JOIN
        productimage c ON a.productid = c.productid 
    WHERE
        b.schoolid IN (SELECT schoolid FROM `usersschoolmap` WHERE userid = p_userid)
    GROUP BY
        a.productid
    ORDER BY
        a.lastmodifiedate DESC;


    ELSE
        
        SET p_result_status = 'ERROR';
        SET p_result_message = 'No data found';
        SELECT p_result_status AS status, p_result_message AS message;
    END IF;

    
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_searchproductother` (IN `p_masterid` JSON, IN `p_subdataid` JSON, IN `p_limit` BIGINT, IN `p_pageno` BIGINT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
  
    DECLARE offset_value INT;
    DECLARE masterid_values VARCHAR(255); 
    DECLARE subdataid_values VARCHAR(255); 

    
    SET SESSION group_concat_max_len = 10000000; 

    
    SET offset_value = (p_pageno - 1) * p_limit;

    
  
  
  
  
  
  
  
  
  

   
        
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Data retrieved successfully';
        SELECT p_result_status AS status, p_result_message AS message;
        
        
        SELECT GROUP_CONCAT(value) INTO masterid_values
        FROM JSON_TABLE(p_masterid, '$[*]' COLUMNS (value INT PATH '$')) AS m;

        
        SELECT GROUP_CONCAT(value) INTO subdataid_values
        FROM JSON_TABLE(p_subdataid, '$[*]' COLUMNS (value INT PATH '$')) AS s;

       SET @sql = CONCAT(
    'SELECT
        a.productid,
        a.name,
        a.description,
        a.price,
        JSON_ARRAYAGG(
            JSON_OBJECT(
                ''image'', TO_BASE64(c.image),
                ''imageseq'', c.imageseq
            )
        ) AS images
    FROM
        product a
    LEFT JOIN
        productimage c ON a.productid = c.productid 
    LEFT JOIN
        producttext d ON d.productid = a.productid
    WHERE 1=1',
    CASE
        WHEN masterid_values IS NOT NULL AND subdataid_values IS NOT NULL THEN
            CONCAT(
                ' AND a.masterid IN (', masterid_values, ')
                AND d.subdataid IN (', subdataid_values, ')'
            )
        WHEN masterid_values IS NOT NULL THEN
            CONCAT(
                ' AND a.masterid IN (', masterid_values, ')'
            )
        WHEN subdataid_values IS NOT NULL THEN
            CONCAT(
                ' AND d.subdataid IN (', subdataid_values, ')'
            )
        ELSE
            ''
    END,
    ' AND a.isuniform = 0',
    ' GROUP BY
        a.productid, a.name, a.price
    ORDER BY
        a.lastmodifiedate DESC
    LIMIT ', p_limit,
    ' OFFSET ', offset_value, ';'
);




        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
  
        
  
  
  
  
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_searchproductschool` (IN `p_userid` BIGINT, IN `p_masterid` JSON, IN `p_subdataid` JSON, IN `p_limit` BIGINT, IN `p_pageno` BIGINT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE result_count INT; 
    DECLARE offset_value INT;
    DECLARE masterid_values VARCHAR(255); 
    DECLARE subdataid_values VARCHAR(255); 

    
    SET SESSION group_concat_max_len = 10000000; 

    
    SET offset_value = (p_pageno - 1) * p_limit;

    
   
  
  
   
   
  
   
  
  
  
  

  
        
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Data retrieved successfully';
        SELECT p_result_status AS status, p_result_message AS message;
        
        
        SELECT GROUP_CONCAT(value) INTO masterid_values
        FROM JSON_TABLE(p_masterid, '$[*]' COLUMNS (value INT PATH '$')) AS m;

        
        SELECT GROUP_CONCAT(value) INTO subdataid_values
        FROM JSON_TABLE(p_subdataid, '$[*]' COLUMNS (value INT PATH '$')) AS s;

        
        SET @sql = CONCAT(
            'SELECT
                a.productid,
                a.name,
                a.description,
                a.price,
                JSON_ARRAYAGG(
                    JSON_OBJECT(
                        ''image'', TO_BASE64(c.image),
                        ''imageseq'', c.imageseq
                    )
                ) AS images
            FROM
                product a
            LEFT JOIN
                productschoolmap b ON a.productid = b.productid
            LEFT JOIN
                productimage c ON a.productid = c.productid 
            LEFT JOIN
                producttext d ON d.productid = a.productid
            WHERE 1=1',
            CASE
                WHEN masterid_values IS NOT NULL AND subdataid_values IS NOT NULL THEN
                    CONCAT(
                        ' AND a.masterid IN (', masterid_values, ')
                        AND d.subdataid IN (', subdataid_values, ')'
                    )
                WHEN masterid_values IS NOT NULL THEN
                    CONCAT(
                        ' AND a.masterid IN (', masterid_values, ')'
                    )
                WHEN subdataid_values IS NOT NULL THEN
                    CONCAT(
                        ' AND d.subdataid IN (', subdataid_values, ')'
                    )
                ELSE
                    ''
            END,
            ' AND b.schoolid IN (SELECT schoolid FROM `usersschoolmap` WHERE userid = ', p_userid,')',
            ' GROUP BY
                a.productid, a.name, a.price
            ORDER BY
                a.lastmodifiedate DESC
            LIMIT ', p_limit,
            ' OFFSET ', offset_value, ';'
        );

        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
  
        
   
   
   
  
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_SignUpUserWithSchoolandAddress` (IN `p_username` VARCHAR(50), IN `p_password` VARCHAR(150), IN `p_name` VARCHAR(100), IN `p_email` VARCHAR(50), IN `p_mobileno` VARCHAR(10), IN `p_schoolcodes` JSON, IN `p_Address1` VARCHAR(500), IN `p_Address2` VARCHAR(500), IN `p_Address3` VARCHAR(500), IN `p_Address4` VARCHAR(500), IN `p_Address5` VARCHAR(500), IN `p_Address6` VARCHAR(500), IN `p_Address7` VARCHAR(500), IN `p_Address8` VARCHAR(500), IN `p_Landmark` VARCHAR(500), IN `p_city` VARCHAR(100), IN `p_state` VARCHAR(100), IN `p_country` VARCHAR(100), IN `p_pincode` VARCHAR(6), IN `p_alternatemobileno` VARCHAR(10), IN `p_isprimary` BIT, IN `p_iswork` BIT, IN `p_status` BIT, IN `p_createdby` BIGINT, IN `p_createdon` DATETIME, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE v_username_count INT;
    DECLARE v_mobileno_count INT;
    DECLARE v_email_count INT;
    DECLARE v_all_schools_valid BOOLEAN DEFAULT TRUE;
    DECLARE v_user_id BIGINT;
    DECLARE idx INT DEFAULT 0;
    DECLARE total INT;
    DECLARE code VARCHAR(255);
    DECLARE school_id INT;
    DECLARE idxinsert INT DEFAULT 0;
    DECLARE p_roleid BIGINT;

    -- Retrieve the role ID from the roles table
    SELECT rolesid INTO p_roleid
    FROM roles
    WHERE name = 'online';

    -- Check for existing username, mobile number, and email
    SELECT COUNT(*) INTO v_username_count FROM users WHERE username = p_username;
    SELECT COUNT(*) INTO v_mobileno_count FROM users WHERE mobileno = p_mobileno;
    SELECT COUNT(*) INTO v_email_count FROM users WHERE email = p_email;

    -- Get the length of the JSON array    SET total = JSON_LENGTH(p_schoolcodes);

    -- Loop through each school code in the JSON array
    WHILE idx < total DO
        -- Extract the school code from the JSON array
        SET code = JSON_UNQUOTE(JSON_EXTRACT(p_schoolcodes, CONCAT('$[', idx, ']')));

        -- Check if the school code exists in the school table
        SELECT schoolid INTO school_id FROM school WHERE schoolcode = code;

        -- If the school code is not found, set the result status and message, and exit the loop
        IF school_id IS NULL THEN
            SET v_all_schools_valid = FALSE;
            SET idx = total; -- Exit the loop
        END IF;

        -- Increment the index to move to the next school code
        SET idx = idx + 1;
    END WHILE;

    -- Validate inputs and set result status and message accordingly
    IF v_username_count > 0 THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'Username already exists';
    ELSEIF v_mobileno_count > 0 THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'Mobile number already exists';
    ELSEIF v_email_count > 0 THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'Email already exists';
    ELSEIF LENGTH(p_mobileno) <> 10 THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'Mobile number must be a 10-digit number';
    ELSEIF LENGTH(p_pincode) <> 6 THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'Pin code must be a 6-digit number';
    ELSEIF LENGTH(p_email) > 0 AND NOT REGEXP_LIKE(p_email, '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}$') THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'Invalid email format';
    ELSEIF NOT v_all_schools_valid THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'One or more school codes not found';
    ELSE
    		SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Signup Successful';
        SELECT p_result_status AS status, p_result_message AS message;
        
        -- Insert new user into the users table
        INSERT INTO users (username, password, name, email, mobileno)
        VALUES (p_username, p_password, p_name, p_email, p_mobileno);

        -- Get the user ID of the newly created user
        SELECT userid INTO v_user_id FROM users WHERE email = p_email;

        -- Insert school mappings for the user
        WHILE idxinsert < JSON_LENGTH(p_schoolcodes) DO
            SET code = JSON_UNQUOTE(JSON_EXTRACT(p_schoolcodes, CONCAT('$[', idxinsert, ']')));

            SELECT schoolid INTO school_id FROM school WHERE schoolcode = code;

            IF school_id IS NOT NULL THEN
                IF NOT EXISTS (SELECT 1 FROM usersschoolmap WHERE userid = v_user_id AND schoolid = school_id) THEN
                    INSERT INTO usersschoolmap (userid, schoolid) VALUES (v_user_id, school_id);
                END IF;
            END IF;

            SET idxinsert = idxinsert + 1;
        END WHILE;

        -- Insert the address using the SP_InsertAddress procedure
        CALL SP_InsertAddress(
            v_user_id,
            p_name,
            p_Address1,
            p_Address2,
            p_Address3,
            p_Address4,
            p_Address5,
            p_Address6,
            p_Address7,
            p_Address8,
            p_Landmark,
            p_city,
            p_state,
            p_country,
            p_pincode,
            p_email,
            p_mobileno,
            p_alternatemobileno,
            p_isprimary,
            p_iswork,
            p_status,
            p_createdby,
            p_createdon,
            @v_result_status,
            @v_result_message
        );

        -- Check if the role ID exists and assign the role
        IF p_roleid IS NOT NULL THEN
            CALL SP_AssignRoleToUser(v_user_id, p_roleid, @v_result_status, @v_result_message);
            SET p_result_status = @v_result_status;
            SET p_result_message = @v_result_message;
        ELSE
            SET p_result_status = 'FAILURE';
            SET p_result_message = 'Role ID for "online" not found';
        END IF;
    END IF;

    -- Output the result status and message
    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_Staff_DB_GetOrderDetailsByStatus` (IN `p_userid` BIGINT(19), IN `p_status` VARCHAR(50), IN `p_pageno` INT, IN `p_index` INT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE is_staff BIT(1);
    DECLARE start_index INT DEFAULT 0;
   SET start_index := (p_pageno - 1) * p_index;
    
    -- Check if the user is a staff member
    SELECT isstaff INTO is_staff FROM users WHERE userid = p_userid;

    IF is_staff = 1 THEN
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Order details retrieved successfully';
        SELECT p_result_status AS status, p_result_message AS message;

        SELECT 
            a.lastmodifiedat,
            a.id AS TransID,
            a.status,
            a.ordernumber,
            JSON_OBJECT("userid", MAX(a.userid)) AS User_details,
            JSON_OBJECT(
                "addressid", IFNULL(MAX(e.addressid), ""),
                "address_name", IFNULL(MAX(e.name), ""),
                "addressline1", IFNULL(MAX(e.address1), ""),
                "addressline2", IFNULL(MAX(e.address2), ""),
                "city", IFNULL(MAX(e.city), ""),
                "pincode", IFNULL(MAX(e.pincode), "")
            ) AS address_details,
            JSON_ARRAYAGG(
                JSON_OBJECT(
                    "productid", b.productid,
                    "name", b.name,
                    "description", b.description,
                    "price", b.price
                )
            ) AS products
        FROM
            transactions a
            LEFT JOIN product b ON a.productid = b.productid
            LEFT JOIN address e ON e.addressid = a.addressid
            JOIN usersschoolmap u ON a.userid = u.userid
        WHERE
            a.status = p_status
            AND u.schoolid IN (SELECT schoolid FROM usersschoolmap WHERE userid = p_userid)
        GROUP BY
            a.ordernumber, a.lastmodifiedat, a.id
        ORDER BY
            MAX(a.lastmodifiedat) DESC
        LIMIT
            start_index, p_index;

        SELECT p_result_status AS status, p_result_message AS message;
    ELSE
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'User is not authorized to access this data';
        SELECT p_result_status AS status, p_result_message AS message;
    END IF;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_Staff_DB_GetOrderDetailsByStatusAndDate` (IN `p_userid` BIGINT(19), IN `p_status` VARCHAR(50), IN `p_pageno` INT, IN `p_index` INT, IN `p_startdate` DATETIME, IN `p_enddate` DATETIME, IN `p_schoolid` BIGINT(19), OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE start_index INT DEFAULT 0;
        -- Check if the user exists
    DECLARE user_exists INT;
    SET start_index := (p_pageno - 1) * p_index;


    SELECT COUNT(*) INTO user_exists FROM usersschoolmap WHERE userid = p_userid AND schoolid = p_schoolid;

    IF user_exists = 0 THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'User is not associated with the specified school';
        SELECT p_result_status AS status, p_result_message AS message;       
    ELSE

    SET p_result_status = 'SUCCESS';
    SET p_result_message = 'Order details retrieved successfully';
    SELECT p_result_status AS status, p_result_message AS message;

    SELECT 
        a.lastmodifiedat,
        a.id AS TransID,
        a.status,
        a.ordernumber,
        JSON_OBJECT("userid", MAX(a.userid)) AS User_details,
        JSON_OBJECT(
            "addressid", IFNULL(MAX(e.addressid), ""),
            "address_name", IFNULL(MAX(e.name), ""),
            "addressline1", IFNULL(MAX(e.address1), ""),
            "addressline2", IFNULL(MAX(e.address2), ""),
            "city", IFNULL(MAX(e.city), ""),
            "pincode", IFNULL(MAX(e.pincode), "")
        ) AS address_details,
        JSON_ARRAYAGG(
            JSON_OBJECT(
                "productid", b.productid,
                "name", b.name,
                "description", b.description,
                "price", b.price
            )
        ) AS products
    FROM
        transactions a
        LEFT JOIN product b ON a.productid = b.productid
        LEFT JOIN address e ON e.addressid = a.addressid
        JOIN usersschoolmap u ON a.userid = u.userid
    WHERE
        a.status = p_status
        AND a.createdon BETWEEN p_startdate AND p_enddate
        AND u.schoolid = p_schoolid
    GROUP BY
        a.ordernumber, a.lastmodifiedat, a.id
    ORDER BY
        MAX(a.lastmodifiedat) DESC
    LIMIT 
        start_index, p_index;

    
    END IF;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_Staff_DB_GetOverallLength` (IN `p_userid` BIGINT(19), IN `p_schoolid` BIGINT(19), OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE user_exists INT;
    DECLARE total_packed INT;
        DECLARE total_ordered INT;
        DECLARE total_shipped INT;
        DECLARE total_online_store INT;
        DECLARE total_uniform_normal INT;

    -- Check if the user exists in the specified school
    SELECT COUNT(*) INTO user_exists
    FROM usersschoolmap
    WHERE userid = p_userid AND schoolid = p_schoolid;

    IF user_exists = 0 THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'User is not associated with the specified school';
    ELSE
        -- Initialize variables
        SET total_packed = 0;
        SET total_ordered = 0;
        SET total_shipped = 0;
        SET total_online_store = 0;
        SET total_uniform_normal = 0;

        -- Calculate overall lengths
        SELECT 
            SUM(CASE WHEN t.status = 'Packed' THEN 1 ELSE 0 END),
            SUM(CASE WHEN t.status = 'Ordered' THEN 1 ELSE 0 END),
            SUM(CASE WHEN t.status = 'Shipped' THEN 1 ELSE 0 END),
            SUM(CASE WHEN t.status = 'Online' OR t.status = 'Store' THEN 1 ELSE 0 END),
            SUM(CASE WHEN t.status = 'Uniform' OR t.status = 'Normal' THEN 1 ELSE 0 END)
        INTO
            total_packed,
            total_ordered,
            total_shipped,
            total_online_store,
            total_uniform_normal
        FROM transactions t
    JOIN usersschoolmap u ON t.userid = u.userid
    WHERE u.schoolid = p_schoolid;

        -- Set result status and message
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Overall lengths retrieved successfully';
    END IF;

    -- Return results
    SELECT 
        p_result_status AS status,
        p_result_message AS message,
        total_packed,
        total_ordered,
        total_shipped,
        total_online_store,
        total_uniform_normal;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_UpdateAddress` (IN `p_addressid` BIGINT, IN `p_userid` BIGINT, IN `p_name` VARCHAR(100), IN `p_fullAddress` TEXT, IN `p_locationDetails` TEXT, IN `p_Landmark` VARCHAR(500), IN `p_city` VARCHAR(100), IN `p_state` VARCHAR(100), IN `p_country` VARCHAR(100), IN `p_pincode` VARCHAR(6), IN `p_email` VARCHAR(50), IN `p_mobileno` VARCHAR(10), IN `p_alternatemobileno` VARCHAR(10), IN `p_isprimary` BIT, IN `p_iswork` BIT, IN `p_status` BIT, IN `p_lastmodifiedby` BIGINT, IN `p_lastmodifiedate` DATETIME, OUT `p_result_status` VARCHAR(10), OUT `p_result_message` VARCHAR(100))  BEGIN
    DECLARE address_exists INT;

    
    SELECT COUNT(*) INTO address_exists FROM address WHERE addressid = p_addressid;

    IF address_exists = 0 THEN
        SET p_result_status = 'ERROR';
        SET p_result_message = 'Address not found';
        SELECT p_result_status AS status, p_result_message AS message;
    ELSE
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Address updated';
        SELECT p_result_status AS status, p_result_message AS message;

        UPDATE address
        SET
            userid = p_userid,
            name = p_name,
            fullAddress = p_fullAddress ,
				locationDetails = p_locationDetails,
            Landmark = p_Landmark,
            city = p_city,
            state = p_state,
            country = p_country,
            pincode = p_pincode,
            email = p_email,
            mobileno = p_mobileno,
            alternatemobileno = p_alternatemobileno,
            isprimary = p_isprimary,
            iswork = p_iswork,
            status = p_status,
            lastmodifiedby = p_lastmodifiedby
        WHERE addressid = p_addressid;
    END IF;

END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_UpdateCart` (IN `p_atcartids` JSON, IN `p_status` VARCHAR(100), OUT `p_result_status` VARCHAR(10), OUT `p_result_message` VARCHAR(100))  BEGIN
DECLARE atcart_exists INT;

    
    SELECT COUNT(*) INTO atcart_exists
    FROM addtocarttable
    WHERE atcartid IN (
        SELECT atcartid
        FROM JSON_TABLE(p_atcartids, '$[*]' COLUMNS (atcartid INT PATH '$')) AS atcartids
    );

    IF atcart_exists > 0 THEN
        
        UPDATE addtocarttable 
        SET status = p_status 
        WHERE atcartid IN (
            SELECT atcartid
            FROM JSON_TABLE(p_atcartids, '$[*]' COLUMNS (atcartid INT PATH '$')) AS atcartids
        );

        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Records updated in addtocarttable';
    ELSE
        
        SET p_result_status = 'ERROR';
        SET p_result_message = 'No matching records found in addtocarttable';
    END IF;

    
    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_UpdateModule` (IN `p_moduleid` BIGINT, IN `p_name` VARCHAR(100), OUT `p_status` VARCHAR(255), OUT `p_message` VARCHAR(255))  BEGIN
    DECLARE duplicate_count INT;

    
    SELECT COUNT(*) INTO duplicate_count FROM module WHERE name = p_name AND moduleid <> p_moduleid;

    IF duplicate_count > 0 THEN
        SET p_status = 'FAILURE';
        SET p_message = 'Another module with the same name already exists.';
    ELSE
        
        UPDATE module SET name = p_name WHERE moduleid = p_moduleid;
        SET p_status = 'SUCCESS';
        SET p_message = 'Module updated successfully.';
    END IF;
    SELECT p_status AS status, p_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_UpdateProduct` (IN `p_productid` BIGINT, IN `p_barcode` VARCHAR(50), IN `p_masterid` BIGINT, IN `p_submasterid` JSON, IN `p_subdataid` JSON, IN `p_name` VARCHAR(100), IN `p_description` VARCHAR(500), IN `p_price` DECIMAL(10,0), IN `p_gst` DECIMAL(10,0), IN `p_discount` DECIMAL(10,0), IN `p_productstatus` VARCHAR(100), IN `p_ispublic` BIT(1), IN `p_isuniform` BIT(1), IN `p_lastmodifiedate` DATETIME, IN `p_lastmodifiedby` BIGINT, IN `p_schoolid` JSON, IN `p_imageseq` JSON, IN `p_image` JSON, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE product_exists INT;
    DECLARE idx INT DEFAULT 0;
    DECLARE code VARCHAR(50);
    DECLARE code1 VARCHAR(50);
    DECLARE code2 VARCHAR(50);
    DECLARE codeimage LONGTEXT;

    SET product_exists = NULL;

    
    SELECT COUNT(*) INTO product_exists
    FROM product
    WHERE productid = p_productid;

    
    

    IF product_exists IS NOT NULL AND product_exists > 0 THEN
        
        UPDATE product
        SET
            barcode = p_barcode,
            masterid = p_masterid,
            name = p_name,
            description = p_description,
            price = p_price,
            gst = p_gst,
            discount = p_discount,
            productstatus = p_productstatus,
            ispublic = p_ispublic,
            isuniform = p_isuniform,
            lastmodifiedate = p_lastmodifiedate,
            lastmodifiedby = p_lastmodifiedby
        WHERE productid = p_productid;

        
        

        
        DELETE FROM productschoolmap WHERE productid = p_productid;
        
            IF JSON_LENGTH(p_schoolid) IS NOT NULL AND JSON_LENGTH(p_schoolid) > 0 THEN

        
        WHILE idx < JSON_LENGTH(p_schoolid) DO
            SET code = JSON_UNQUOTE(JSON_EXTRACT(p_schoolid, CONCAT('$[', idx, ']')));
            
            

            
            INSERT INTO productschoolmap (productid, schoolid)
            VALUES (p_productid, code);

            
            

            SET idx = idx + 1;  
        END WHILE;
        END IF;

        
        SET idx = 0;

        
        DELETE FROM productimage WHERE productid = p_productid;

        
        WHILE idx < JSON_LENGTH(p_imageseq) DO
            SET code = JSON_UNQUOTE(JSON_EXTRACT(p_imageseq, CONCAT('$[', idx, ']')));
            
            

            
            INSERT INTO productimage (productid, imageseq, image)
            VALUES (p_productid, code, NULL); 

            
            

            
            IF JSON_LENGTH(p_image) IS NOT NULL AND JSON_LENGTH(p_image) > 0 THEN
                
                SET codeimage = JSON_UNQUOTE(JSON_EXTRACT(p_image, CONCAT('$[', idx, ']')));

                
                

                
                UPDATE productimage
                SET image = FROM_BASE64(codeimage)
                WHERE productid = p_productid AND imageseq = code;

                
                
            END IF;

            SET idx = idx + 1; 
        END WHILE;

        SET idx = 0;

         DELETE FROM producttext WHERE productid = p_productid;

        
                WHILE idx < JSON_LENGTH(p_submasterid) AND idx < JSON_LENGTH(p_subdataid) DO
            SET code1 = JSON_UNQUOTE(JSON_EXTRACT(p_submasterid, CONCAT('$[', idx, ']')));
            SET code2 = JSON_UNQUOTE(JSON_EXTRACT(p_subdataid, CONCAT('$[', idx, ']')));

            
            INSERT INTO producttext (productid, submasterid, subdataid)
            VALUES (p_productid, code1, code2);

            SET idx = idx + 1; 
        END WHILE;

        
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Product added successfully';


        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Record updated successfully';

        
        
    ELSE
        
        SET p_result_status = 'ERROR';
        SET p_result_message = 'Product does not exist';

        
        
    END IF;
     SELECT p_result_status AS status, p_result_message AS message;

    COMMIT;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_UpdateRole` (IN `p_rolesid` BIGINT, IN `p_name` VARCHAR(20), IN `p_role` VARCHAR(50), IN `p_defaultmodule` BIGINT, IN `p_lastmodifiedby` INT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    SET p_result_status = 'FAILURE';
    SET p_result_message = 'Error updating role';

    IF NOT EXISTS (SELECT 1 FROM roles WHERE rolesid = p_rolesid) THEN
        SET p_result_message = 'Role ID does not exist';
    
    ELSEIF NOT EXISTS (SELECT 1 FROM module WHERE moduleid = p_defaultmodule) THEN
        SET p_result_message = 'Default module does not exist';
    
    ELSE
        -- Construct the dynamic query
        SET @sql = CONCAT('UPDATE roles SET name = ''', p_name, ''', role = b''', p_role, ''', defaultmodule = ', p_defaultmodule, ', lastmodifiedby = ', p_lastmodifiedby, ' WHERE rolesid = ', p_rolesid);
        
        -- Prepare and execute the dynamic query
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;

        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Role updated successfully';
    END IF;

    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_UpdateSchool` (IN `p_schoolid` BIGINT, IN `p_schoolcode` VARCHAR(10), IN `p_name` VARCHAR(200), IN `p_address` VARCHAR(500), IN `p_email` VARCHAR(50), IN `p_mobileno` VARCHAR(10), IN `p_updatedby` BIGINT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE v_count INT;

    
    SELECT COUNT(*) INTO v_count FROM school WHERE schoolid = p_schoolid;

    IF v_count = 1 THEN
        
        UPDATE school
        SET 
            schoolcode = p_schoolcode,
            name = p_name,
            address = p_address,
            email=p_email,
            mobileno = p_mobileno,
            updatedAt = CURRENT_TIMESTAMP,
            updatedby = p_updatedby WHERE schoolid = p_schoolid;

        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Record updated successfully';
    ELSE
        
        SET p_result_status = 'ERROR';
        SET p_result_message = 'School with the given ID does not exist';
    END IF;
    
     SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_UpdateStaff` (IN `p_userid` INT, IN `p_addressid` INT, IN `p_username` VARCHAR(50), IN `p_name` VARCHAR(100), IN `p_email` VARCHAR(50), IN `p_mobileno` VARCHAR(10), IN `p_old_rolesid` INT, IN `p_new_rolesid` INT, IN `p_Address1` VARCHAR(500), IN `p_Address2` VARCHAR(500), IN `p_Address3` VARCHAR(500), IN `p_Address4` VARCHAR(500), IN `p_Address5` VARCHAR(500), IN `p_Address6` VARCHAR(500), IN `p_Address7` VARCHAR(500), IN `p_Address8` VARCHAR(500), IN `p_Landmark` VARCHAR(500), IN `p_city` VARCHAR(100), IN `p_state` VARCHAR(100), IN `p_country` VARCHAR(100), IN `p_pincode` VARCHAR(6), IN `p_alternatemobileno` VARCHAR(10), IN `p_isprimary` BIT, IN `p_iswork` BIT, IN `p_status` BIT, IN `p_updatedby` BIGINT, IN `p_updateon` DATETIME, IN `p_schoolcodes` JSON, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE v_username_count INT;
    DECLARE v_mobileno_count INT;
    DECLARE v_email_count INT;
    DECLARE school_id BIGINT;
    DECLARE idx INT DEFAULT 0;
    DECLARE code VARCHAR(50);
    DECLARE v_result_status VARCHAR(10);
    DECLARE v_result_message VARCHAR(100);
    DECLARE is_user_exists BOOLEAN;
    DECLARE is_user_address_exists INT;
    
    SET p_result_status = 'FAILURE';
    SET p_result_message = 'Error While Update Staff Details';


SELECT COUNT(*) INTO is_user_address_exists
FROM address
WHERE addressid = p_addressid;


SELECT COUNT(*) > 0 INTO is_user_exists
FROM users
WHERE userid = p_userid;


SELECT COUNT(*) INTO v_username_count FROM users WHERE username = p_username AND userid != p_userid;
SELECT COUNT(*) INTO v_mobileno_count FROM users WHERE mobileno = p_mobileno AND userid != p_userid;
SELECT COUNT(*) INTO v_email_count FROM users WHERE email = p_email AND userid != p_userid;


IF NOT EXISTS (SELECT 1 FROM users WHERE userid = p_userid) THEN
    SET p_result_status = 'FAILURE';
    SET p_result_message = 'User ID does not exist';
ELSEIF NOT EXISTS (SELECT 1 FROM userrolemap WHERE userid = p_userid AND roleid = p_old_rolesid) THEN
    SET p_result_status = 'FAILURE';
    SET p_result_message = 'Old Role ID does not exist for the user';
ELSEIF NOT EXISTS (SELECT 1 FROM roles WHERE rolesid = p_new_rolesid) THEN
    SET p_result_status = 'FAILURE';
    SET p_result_message = 'New Role ID does not exist';
ELSEIF v_username_count > 0 THEN
    SET p_result_status = 'FAILURE';
    SET p_result_message = 'Username already exists with other Users';
ELSEIF v_mobileno_count > 0 THEN
    SET p_result_status = 'FAILURE';
    SET p_result_message = 'Mobile number already exists with other Users';
ELSEIF v_email_count > 0 THEN
    SET p_result_status = 'FAILURE';
    SET p_result_message = 'Email already exists with other Users';
    ELSEIF LENGTH(p_mobileno) <> 10 THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'Mobile number must be a 10-digit number';
   ELSEIF LENGTH(p_pincode) <> 6 THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'Pin code must be a 6-digit number';
   ELSEIF LENGTH(p_email) > 0 AND NOT REGEXP_LIKE(p_email, '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+.[A-Z|a-z]{2,}$') THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'Invalid email format';    
--	ELSEIF is_user_address_exists = 0 THEN
--   		SET p_result_status = 'FAILURE';
--   	SET p_result_message = CONCAT('Staff Address Not Found ', CAST(p_addressid AS CHAR));
   ELSEIF p_userid IS NOT NULL AND is_user_exists THEN
        
        UPDATE users
        SET
            username = p_username,
           
            name = p_name,
            email = p_email,
            mobileno = p_mobileno,
            updatedby = p_updatedby
        WHERE userid = p_userid;
        
                UPDATE userrolemap
                SET roleid = p_new_rolesid
                WHERE userid = p_userid AND roleid = p_old_rolesid;
                
                   
			DELETE FROM usersschoolmap WHERE userid = p_userid;

			
			WHILE idx < JSON_LENGTH(p_schoolcodes) DO
   		 
   		 SET code = JSON_UNQUOTE(JSON_EXTRACT(p_schoolcodes, CONCAT('$[', idx, ']')));

   		 
  		  SELECT schoolid INTO school_id FROM school WHERE schoolcode = code;

   		 IF school_id IS NOT NULL THEN
        
        IF NOT EXISTS (SELECT 1 FROM usersschoolmap WHERE userid = p_userid AND schoolid = school_id) THEN
            
            INSERT INTO usersschoolmap (userid, schoolid) VALUES (p_userid, school_id);
        END IF;
   	 END IF;
   	 SET idx = idx + 1;
END WHILE;
   
   
        
      
      SET p_result_status = 'SUCCESS';
      SET p_result_message = 'Staff Details updated successfully';
      SELECT p_result_status AS status, p_result_message AS message;
        CALL SP_UpdateAddress(
        p_addressid,
        p_userid,
        p_name,
        p_Address1,
        p_Address2,
        p_Address3,
        p_Address4,
        p_Address5,
        p_Address6,
        p_Address7,
        p_Address8,
        p_Landmark,
        p_city,
        p_state,
        p_country,
        p_pincode,
        p_email,
        p_mobileno,
        p_alternatemobileno,
        p_isprimary,
        p_iswork,
        p_status,
        p_updatedby,
        p_updateon,
        @v_result_status,
        @v_result_message
    );   
 
        
       
           
      
      
      
      
   
   
   
   
    END IF;	  
     SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_UpdateTransaction` (IN `p_transtableid` INT, IN `p_addressid` INT, IN `p_status` VARCHAR(255), IN `p_lastmodifiedby` INT, OUT `p_result_status` VARCHAR(255), OUT `p_result_message` VARCHAR(255))  BEGIN
    
    SET p_result_status = 'FAILURE';
    SET p_result_message = 'transactions update failed';

    
    IF EXISTS (
        SELECT 1
        FROM transactions
        WHERE id = p_transtableid
    ) THEN
        
        UPDATE transactions
        SET status = p_status,addressid =p_addressid, lastmodifiedby = p_lastmodifiedby
        WHERE id = p_transtableid;

        
        INSERT INTO transactionlog (transtableid, status, createdby)
        VALUES (p_transtableid, p_status, p_lastmodifiedby);

        
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'transactions updated successfully';
    ELSE
        
        SET p_result_message = 'transactions id does not exist';
    END IF;

    
    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_UpdateTransactionStatus` (IN `p_ids` JSON, IN `p_status` VARCHAR(255), OUT `p_result_status` VARCHAR(255), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE current_id BIGINT(19);
    DECLARE idx INT DEFAULT 0;
    
    SET p_result_status = 'FAILURE';
    SET p_result_message = 'Error updating transaction status';
    
    WHILE idx < JSON_LENGTH(p_ids) DO
        SET current_id = CAST(JSON_UNQUOTE(JSON_EXTRACT(p_ids, CONCAT('$[', idx, ']'))) AS UNSIGNED);
        
        -- Check if the ID exists
        IF EXISTS (SELECT 1 FROM transactions WHERE id = current_id) THEN
            -- Update the status
            UPDATE transactions SET status = p_status WHERE id = current_id;
            SET p_result_status = 'SUCCESS';
            SET p_result_message = 'Transaction status updated successfully';
        ELSE
            SET p_result_message = CONCAT('Transaction with ID ', current_id, ' does not exist');
        END IF;
        
        SET idx = idx + 1;
    END WHILE;

    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_UpdateUserRole` (IN `p_userid` BIGINT, IN `p_old_rolesid` BIGINT, IN `p_new_rolesid` BIGINT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    
    SET p_result_status = 'FAILURE';
    SET p_result_message = 'Error updating user role';

    
    IF NOT EXISTS (SELECT 1 FROM users WHERE userid = p_userid) THEN
        SET p_result_message = 'User ID does not exist';
    ELSE
        
        IF NOT EXISTS (SELECT 1 FROM userrolemap WHERE userid = p_userid AND roleid = p_old_rolesid) THEN
            SET p_result_message = 'Old Role ID does not exist for the user';
        ELSE
            
            IF NOT EXISTS (SELECT 1 FROM roles WHERE rolesid = p_new_rolesid) THEN
                SET p_result_message = 'New Role ID does not exist';
            ELSE
            
                
                SET p_result_status = 'SUCCESS';
                SET p_result_message = 'User role updated successfully';
    
    SELECT p_result_status AS status, p_result_message AS message;
                
                UPDATE userrolemap
                SET roleid = p_new_rolesid
                WHERE userid = p_userid AND roleid = p_old_rolesid;

                
                SET p_result_status = 'SUCCESS';
                SET p_result_message = 'User role updated successfully';
            END IF;
        END IF;
    END IF;
    
    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `SP_VerifyOTP` (IN `p_mobileno` VARCHAR(10), IN `p_otpcode` VARCHAR(6), OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
   
    DECLARE v_user_id BIGINT;
    DECLARE v_validity DATETIME;
    DECLARE v_json_data JSON;
    DECLARE p_transtime DATETIME;
    DECLARE v_username VARCHAR(50);
    DECLARE v_password VARCHAR(150);
    DECLARE v_name VARCHAR(100);
    DECLARE v_email VARCHAR(50);
    DECLARE v_schoolcodes JSON;
    DECLARE v_fullAddress TEXT;
    DECLARE v_locationDetails TEXT;
    DECLARE v_landmark VARCHAR(255);
    DECLARE v_city VARCHAR(100);
    DECLARE v_state VARCHAR(100);
    DECLARE v_country VARCHAR(100);
    DECLARE v_pincode VARCHAR(6);
    DECLARE v_alternatemobileno VARCHAR(10);
    DECLARE v_isprimary BIT;
    DECLARE v_iswork BIT;
    DECLARE v_status BIT;
    DECLARE code VARCHAR(255);
    DECLARE school_id INT;
    DECLARE idxinsert INT DEFAULT 0;
    DECLARE p_roleid BIGINT;

    SET p_transtime = CONVERT_TZ(NOW(), '+00:00', '+05:30');

    -- Verify the OTP validity
    SELECT validity INTO v_validity
    FROM otptable
    WHERE mobileno = p_mobileno AND otpcode = p_otpcode AND STATUS = 1
    ORDER BY id DESC
    LIMIT 1;
    
            -- Fetch the JSON data from temp_register where 'deleted_at' is NULL
    SELECT json_data INTO v_json_data 
    FROM temp_register
    WHERE mobileno = p_mobileno AND deleted_at IS NULL LIMIT 1;
IF v_json_data IS NOT NULL THEN
    IF v_validity IS NOT NULL AND v_validity > p_transtime THEN
        -- OTP success, mark as used
        UPDATE otptable
        SET STATUS = 0
        WHERE mobileno = p_mobileno AND otpcode = p_otpcode;

    -- Update the 'deleted_at' column with the current timestamp
    UPDATE temp_register
    SET deleted_at = CURRENT_TIMESTAMP
    WHERE mobileno = p_mobileno AND deleted_at IS NULL;

        
        -- Extract JSON values into variables
        SET v_username = JSON_UNQUOTE(JSON_EXTRACT(v_json_data, '$.username'));
        SET v_password = JSON_UNQUOTE(JSON_EXTRACT(v_json_data, '$.password'));
        SET v_name = JSON_UNQUOTE(JSON_EXTRACT(v_json_data, '$.name'));
        SET v_email = JSON_UNQUOTE(JSON_EXTRACT(v_json_data, '$.email'));
        SET v_schoolcodes = JSON_EXTRACT(v_json_data, '$.schoolcodes');
        SET v_fullAddress = JSON_UNQUOTE(JSON_EXTRACT(v_json_data, '$.fullAddress'));
        SET v_locationDetails = JSON_UNQUOTE(JSON_EXTRACT(v_json_data, '$.locationDetails'));
        SET v_landmark = JSON_UNQUOTE(JSON_EXTRACT(v_json_data, '$.landmark'));
        SET v_city = JSON_UNQUOTE(JSON_EXTRACT(v_json_data, '$.city'));
        SET v_state = JSON_UNQUOTE(JSON_EXTRACT(v_json_data, '$.state'));
        SET v_country = JSON_UNQUOTE(JSON_EXTRACT(v_json_data, '$.country'));
        SET v_pincode = JSON_UNQUOTE(JSON_EXTRACT(v_json_data, '$.pincode'));
        SET v_alternatemobileno = JSON_UNQUOTE(JSON_EXTRACT(v_json_data, '$.alternatemobileno'));
        SET v_status = 1;

        -- Insert into users table
        INSERT INTO users (username, password, name, email, mobileno)
        VALUES (v_username, v_password, v_name, v_email, p_mobileno);
        
         -- Get the user ID of the newly created user
        SELECT userid INTO v_user_id FROM users WHERE email = v_email LIMIT 1;

        -- Insert school mappings for the user
        WHILE idxinsert < JSON_LENGTH(v_schoolcodes) DO
            SET code = JSON_UNQUOTE(JSON_EXTRACT(v_schoolcodes, CONCAT('$[', idxinsert, ']')));

            SELECT schoolid INTO school_id FROM school WHERE schoolcode = code;

            IF school_id IS NOT NULL THEN
                IF NOT EXISTS (SELECT 1 FROM usersschoolmap WHERE userid = v_user_id AND schoolid = school_id) THEN
                    INSERT INTO usersschoolmap (userid, schoolid) VALUES (v_user_id, school_id);
                END IF;
            END IF;

            SET idxinsert = idxinsert + 1;
        END WHILE;
        
            -- Insert into address table including fullAddress and locationDetails
    INSERT INTO address (
        userid, name, fullAddress, locationDetails,landmark, city, state, country, 
        pincode, email, mobileno, alternatemobileno, status, 
        createdby, createdon, lastmodifiedby, lastmodifiedate
    )
    VALUES (
        v_user_id, v_name, v_fullAddress, v_locationDetails,v_landmark, v_city, v_state, 
        v_country, v_pincode, v_email, p_mobileno, v_alternatemobileno, v_status, v_user_id, p_transtime, v_user_id, p_transtime
    );
     -- Retrieve the role ID from the roles table
    SELECT rolesid INTO p_roleid
    FROM roles
    WHERE name = 'online' LIMIT 1;
    
    -- Check if the role ID exists and assign the role
       -- IF p_roleid IS NOT NULL THEN
           INSERT INTO userrolemap (userid, roleid)
            VALUES (v_user_id, p_roleid);
      --  ELSE
      --      SET p_result_status = 'FAILURE';
      --      SET p_result_message = 'Role ID for "online" not found';
      --  END IF;
      --      INSERT INTO userrolemap (userid, roleid)
      --      VALUES (v_user_id, p_roleid);
        -- Success response
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'OTP verification successful';

    ELSE
        -- OTP verification failed
        SET p_result_status = 'ERROR';
        SET p_result_message = 'Invalid OTP or OTP expired';
    END IF;
    ELSE
        -- OTP verification failed
        SET p_result_status = 'ERROR';
        SET p_result_message = 'User Details Not Found Try After Sometimes';
    END IF;
    -- Output the result
    SELECT p_result_status AS status, p_result_message AS message;
    
    SELECT * FROM users;
   
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `test` (IN `p_schoolcode` JSON)  BEGIN
DECLARE query VARCHAR(5000);

set @query = concat ('SELECT count(*) FROM school where schoolcode in (', (REPLACE( 
REPLACE(
    REPLACE(JSON_EXTRACT(p_Schoolcode, '$.name'),'[',''), ']',''),'\"','\'')), ')');
SELECT @query;

PREPARE stmt from @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `Test_AddProduct` (IN `p_barcode` VARCHAR(100), IN `p_masterid` BIGINT, IN `p_name` VARCHAR(100), IN `p_description` VARCHAR(500), IN `p_price` DECIMAL(10,0), IN `p_gst` DECIMAL(10,0), IN `p_discount` DECIMAL(10,0), IN `p_productstatus` VARCHAR(100), IN `p_ispublic` BIT(1), IN `p_isuniform` BIT(1), IN `p_createdon` DATETIME, IN `p_createdby` BIGINT, IN `p_schoolid` JSON, IN `p_imageseq` JSON, IN `p_image` JSON, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE product_exists INT;
    DECLARE p_productid BIGINT;
    DECLARE idx INT DEFAULT 0;
    DECLARE code VARCHAR(50);
    DECLARE codeimage LONGTEXT; 

    SET product_exists = NULL;

    
   SELECT COUNT(*) INTO product_exists
FROM product
WHERE barcode COLLATE utf8mb4_unicode_ci = p_barcode COLLATE utf8mb4_unicode_ci;

    
    

    IF product_exists IS NOT NULL AND product_exists > 0 THEN
        
        SET p_result_status = 'ERROR';
        SET p_result_message = 'Product already exists';
    ELSE
        
        INSERT INTO product (
            barcode, masterid, name, description, price, gst, discount,
            productstatus,ispublic, isuniform, createdon, createdby
        )
        VALUES (
            p_barcode, p_masterid, p_name, p_description, p_price,
            p_gst, p_discount, p_productstatus,p_ispublic, p_isuniform, p_createdon, p_createdby
        );

        SET p_productid = LAST_INSERT_ID();

        
      

        
        WHILE idx < JSON_LENGTH(p_schoolid) DO
            SET code = JSON_UNQUOTE(JSON_EXTRACT(p_schoolid, CONCAT('$[', idx, ']')));
            
            

            
            INSERT INTO productschoolmap (productid, schoolid)
            VALUES (p_productid, code);

            
          

            SET idx = idx + 1;  
        END WHILE;

        
        
SET idx = 0;


WHILE idx < JSON_LENGTH(p_imageseq) DO
    SET code = JSON_UNQUOTE(JSON_EXTRACT(p_imageseq, CONCAT('$[', idx, ']')));
    
    
    
   

    
    INSERT INTO productimage (productid, imageseq, image)
    VALUES (p_productid, code, NULL); 

    
   

    
    IF JSON_LENGTH(p_image) IS NOT NULL AND JSON_LENGTH(p_image) > 0 THEN
        
        SET codeimage = JSON_UNQUOTE(JSON_EXTRACT(p_image, CONCAT('$[', idx, ']')));

        
      

        
        UPDATE productimage
        SET image = FROM_BASE64(codeimage)
        WHERE productid = p_productid AND imageseq = code; 

        
       
    END IF;

    SET idx = idx + 1; 
END WHILE;



        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Record inserted successfully';

        
    END IF;

         SELECT p_result_status AS status, p_result_message AS message;
    COMMIT;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `test_binary` (IN `p_role` BINARY(100))  BEGIN
SET @query = CONCAT('INSERT INTO testbinary (test) VALUES (b', p_role , ')');
 PREPARE stmt FROM @query;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `Test_SignUpUserWithSchool` (IN `p_username` NVARCHAR(100), IN `p_password` NVARCHAR(250), IN `p_name` VARCHAR(100), IN `p_address` NVARCHAR(500), IN `p_email` NVARCHAR(50), IN `p_mobileno` VARCHAR(10), IN `p_schoolcodes` JSON, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE v_username_count INT;
    DECLARE v_mobileno_count INT;
    DECLARE v_email_count INT;
    DECLARE v_user_id BIGINT;
    DECLARE school_id BIGINT;
    DECLARE idx INT DEFAULT 0;
    DECLARE code VARCHAR(50);

    
    SELECT COUNT(*) INTO v_username_count FROM users WHERE username = p_username;
    SELECT COUNT(*) INTO v_mobileno_count FROM users WHERE mobileno = p_mobileno;
    SELECT COUNT(*) INTO v_email_count FROM users WHERE email = p_email;

    
    IF v_username_count > 0 THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'Username already exists';
    ELSEIF v_mobileno_count > 0 THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'Mobile number already exists';
    ELSEIF v_email_count > 0 THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'Email already exists';
    ELSEIF LENGTH(p_mobileno) <> 10 THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'Mobile number must be a 10-digit number';
    ELSEIF LENGTH(p_email) > 0 AND NOT REGEXP_LIKE(p_email, '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}$') THEN
        SET p_result_status = 'FAILURE';
        SET p_result_message = 'Invalid email format';
    ELSE
        
        INSERT INTO users (username, password, name, address, email, mobileno)
        VALUES (p_username, p_password, p_name, p_address, p_email, p_mobileno);

        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'User created successfully';
        
        SELECT userid INTO v_user_id FROM users WHERE email = p_email;

        
        WHILE idx < JSON_LENGTH(p_schoolcodes) DO
            
            SET code = JSON_UNQUOTE(JSON_EXTRACT(p_schoolcodes, CONCAT('$[', idx, ']')));

            
            SELECT schoolid INTO school_id FROM school WHERE schoolcode = code;

            IF school_id IS NOT NULL THEN
                
                IF NOT EXISTS (SELECT 1 FROM usersschoolmap WHERE userid = v_user_id AND schoolid = school_id) THEN
                    
                    INSERT INTO usersschoolmap (userid, schoolid) VALUES (v_user_id, school_id);
                END IF;
            END IF;

            SET idx = idx + 1;
        END WHILE;
    END IF;

    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `TEST_SP_DB_AllGetOrderDetailsByStatus` (IN `p_status` VARCHAR(50), IN `p_index` INT, IN `p_pageno` INT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE start_index INT;
    DECLARE offset_val INT;
    
    SET p_result_message = 'Transaction ID does not exist';

    IF EXISTS (
        SELECT 1
        FROM `transactions`
        WHERE status = p_status
    ) THEN    
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Order details retrieved successfully';   
		  SELECT p_result_status AS status, p_result_message AS message; 

        -- Calculate start index and offset
        SET start_index = (p_pageno - 1) * p_index;
        SET offset_val = start_index + p_index;

              --  JSON_OBJECT("image", IFNULL(TO_BASE64(c.image), ""), "imageseq", IFNULL(c.imageseq, "")) AS image_details,
        -- Prepare and execute dynamic SQL
        SET @sql = CONCAT(
            'SELECT
    a.ordernumber,
     a.status,
    JSON_OBJECT(
        "address_name", IFNULL(MAX(e.name), ""),
        "addressline1", IFNULL(MAX(e.address1), ""),
        "addressline2", IFNULL(MAX(e.address2), ""),
        "city", IFNULL(MAX(e.city), ""),
        "pincode", IFNULL(MAX(e.pincode), "")
    ) AS address_details,
    JSON_ARRAYAGG(
        JSON_OBJECT(
            "productid", b.productid,
            "name", b.name,
            "description", b.description,
            "price", b.price
        )
    ) AS products
FROM
    transactions a
    LEFT JOIN product b ON a.productid = b.productid
    LEFT JOIN address e ON e.addressid = a.addressid
    WHERE
                a.status = ', p_status, '
GROUP BY
    a.ordernumber
ORDER BY
    MAX(a.lastmodifiedat) DESC
           LIMIT ', start_index, ', ', offset_val
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
        
    ELSE
        SET p_result_message = 'No Data Found';
        SET p_result_status = 'SUCCESS';
        SELECT p_result_status AS status, p_result_message AS message;
        SELECT NULL AS empty_result WHERE FALSE;
    END IF;

    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `TEST_SP_DB_GetRevenueTrend` (IN `p_startdate` DATE, IN `p_enddate` DATE, IN `p_status` VARCHAR(15), OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    -- Initialize output parameters
    SET p_result_status = 'SUCCESS';
    SET p_result_message = 'Revenue trend retrieved successfully';
 -- Return status and message
    SELECT p_result_status AS status, p_result_message AS message;
    -- Debug statements
   -- SELECT p_startdate, p_enddate, p_status;
    SET @@cte_max_recursion_depth = 20000; -- or any other larger value you need


    -- Retrieve revenue trend data
    WITH RECURSIVE date_range AS (
        SELECT p_startdate AS date_value
        UNION ALL
        SELECT DATE_ADD(date_value, INTERVAL 1 DAY)
        FROM date_range
        WHERE date_value < p_enddate
    )
    SELECT 
        dr.date_value AS x_data,
        COALESCE(SUM(p.price), 0.00) AS y_data
    FROM date_range dr
    LEFT JOIN transactions t ON DATE(t.createdon) = dr.date_value AND t.status = p_status
    LEFT JOIN product p ON t.productid = p.productid
    GROUP BY dr.date_value
    ORDER BY dr.date_value;

   
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `Test_SP_GetOrderDetails` (IN `p_userid` INT, IN `p_limit` INT, IN `p_page` INT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255), OUT `p_order_details` JSON)  BEGIN
    
    SET p_result_status = 'FAILURE';
    SET p_result_message = 'transaction id not exists';

    
    SET @start_index := (p_page - 1) * p_limit;

    
    CREATE TEMPORARY TABLE IF NOT EXISTS temp_order_details
    (
        id INT,
        ordernumber INT,
        status VARCHAR(255),
        createdon DATETIME,
        name VARCHAR(255),
        description TEXT,
        price DECIMAL(10, 2),
        image_details JSON,
        address_name VARCHAR(255),
        address_details JSON
    );

    
    IF EXISTS (
        SELECT 1
        FROM `transactions`
        WHERE userid = p_userid
    ) THEN
        
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Order details retrieved successfully';
         
    SELECT p_result_status AS status, p_result_message AS message, p_order_details AS order_details;

        
        SET @sql = CONCAT(
            'INSERT INTO temp_order_details
            SELECT
                a.id,
                a.ordernumber,
                a.status,
                a.createdon ,
                b.name,
                b.description,
                b.price,
                JSON_OBJECT("image", IFNULL(c.image, ""), "imageseq", IFNULL(c.imageseq, "")) AS image_details,
                IFNULL(e.name, "") AS address_name,
                JSON_OBJECT("addressline1", e.address1, "addressline2", e.address2, "city", e.city, "pincode", e.pincode) AS address_details
            FROM
                `transactions` a
                LEFT JOIN product b ON a.productid = b.productid
                LEFT JOIN productimage c ON c.productid = b.productid AND c.imageseq = 1
                LEFT JOIN address e ON e.userid = a.userid
            WHERE
                a.userid = ', p_userid, '
                AND a.status IN ("ordered", "shipped", "outfordelivery", "delivered", "deliverfail")
            ORDER BY
                a.lastmodifiedat DESC
            LIMIT ', @start_index, ',', p_limit
        );

        
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;

        
        SELECT JSON_ARRAYAGG(JSON_OBJECT(
            'id', id,
            'ordernumber', ordernumber,
            'status', status,
            'createdon', createdon,
            'name', name,
            'description', description,
            'price', price,
            'image_details', image_details,
            'address_name', address_name,
            'address_details', address_details
        )) INTO p_order_details FROM temp_order_details;

        
        DROP TEMPORARY TABLE IF EXISTS temp_order_details;

    ELSE
        
        SET p_result_message = 'User has no orders';
    END IF;

    
    SELECT p_result_status AS status, p_result_message AS message, p_order_details AS order_details;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `TEST_SP_InsertTransactionBulk` (IN `p_userid` INT, IN `p_productid` JSON, IN `p_addressid` INT, IN `p_status` VARCHAR(50), OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE current_productid INT;
    DECLARE idx INT DEFAULT 0;
    
    SET p_result_status = 'FAILURE';
    SET p_result_message = 'Error inserting transactions';

    IF NOT EXISTS (SELECT 1 FROM users WHERE userid = p_userid) THEN
        SET p_result_message = 'User ID does not exist';
    ELSE
        -- Generate the order number
        SET @date_string = DATE_FORMAT(NOW(), '%d-%m-%Y');
        SET @sequential_number = (
            SELECT LPAD(COALESCE(MAX(CAST(SUBSTRING_INDEX(ordernumber, '-', -1) AS UNSIGNED)), 0) + 1, 4, '0')
            FROM transactions
            WHERE DATE(createdon) = DATE(NOW())
        );
        SET @order_number = CONCAT('2CQR-', @date_string, '-', @sequential_number);

        WHILE idx < JSON_LENGTH(p_productid) DO
            SET current_productid = JSON_UNQUOTE(JSON_EXTRACT(p_productid, CONCAT('$[', idx, ']')));
            -- SELECT current_productid AS debug;
            -- Check if the product ID exists
            IF EXISTS (SELECT 1 FROM product WHERE productid = current_productid) THEN
                -- Insert the transaction
                INSERT INTO transactions (userid, productid, addressid, status, ordernumber)
                VALUES (p_userid, current_productid, p_addressid, p_status, @order_number);

                -- Get the ID of the inserted transaction
                SET @last_inserted_id = LAST_INSERT_ID();

                -- Insert a corresponding log entry
                INSERT INTO transactionlog (transtableid, status, createdby)
                VALUES (@last_inserted_id, p_status, p_userid);

                SET p_result_status = 'SUCCESS';
                SET p_result_message = 'Transaction(s) inserted successfully';
            ELSE
                SET p_result_message = CONCAT('Product ID ', current_productid, ' does not exist');
            END IF;
            
            SET idx = idx + 1;
        END WHILE;
    END IF;

    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `TEST_SP_School_DB_GetRevenueTrend` (IN `from_date` DATE, IN `to_date` DATE, IN `p_schoolid` INT, IN `p_status` VARCHAR(15), OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    -- Initialize output parameters
    SET p_result_status = 'SUCCESS';
    SET p_result_message = 'Revenue trend retrieved successfully';
    
    -- Return status and message
    SELECT p_result_status AS status, p_result_message AS message;
    
    -- Debug statements
    -- SELECT from_date, to_date, p_schoolid, p_status;
    
    SET @@cte_max_recursion_depth = 20000; -- or any other larger value you need

    -- Retrieve revenue trend data
    WITH RECURSIVE date_range AS (
        SELECT from_date AS date_value
        UNION ALL
        SELECT DATE_ADD(date_value, INTERVAL 1 DAY)
        FROM date_range
        WHERE date_value < to_date
    )
    SELECT 
        dr.date_value AS x_data,
        COALESCE(SUM(p.price), 0.00) AS y_data
    FROM date_range dr
    LEFT JOIN transactions t ON DATE(t.createdon) = dr.date_value AND t.status = p_status
    LEFT JOIN product p ON t.productid = p.productid
    JOIN productschoolmap ps ON p.productid = ps.productid
    WHERE ps.schoolid = p_schoolid
    GROUP BY dr.date_value
    ORDER BY dr.date_value;

END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `TEST_SP_searchproductother` (IN `p_masterid` BIGINT, IN `p_subdataid` BIGINT, IN `p_limit` BIGINT, IN `p_pageno` BIGINT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE result_count INT; 
    DECLARE offset_value INT;
    
    SET offset_value = (p_pageno - 1) * p_limit;

    
    SELECT COUNT(*) INTO result_count
    FROM
        product a 
    LEFT JOIN
        productschoolmap b ON a.productid = b.productid
    LEFT JOIN
        productimage c ON a.productid = c.productid
    LEFT JOIN
        producttext d ON d.productid = a.productid
    WHERE
        d.subdataid IN (p_subdataid) AND a.masterid = p_masterid
    GROUP BY
        a.productid;

    IF result_count > 0 THEN
        
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Data retrieved successfully';
        SELECT p_result_status AS status, p_result_message AS message;
        
        
        SELECT
            a.name,
            a.price,
            GROUP_CONCAT(
                JSON_OBJECT(
                    'image', TO_BASE64(c.image),
                    'imageseq', c.imageseq
                ) SEPARATOR ', '
            ) AS images
        FROM
            product a
        LEFT JOIN
            productschoolmap b ON a.productid = b.productid
        LEFT JOIN
            productimage c ON a.productid = c.productid 
        LEFT JOIN
            producttext d ON d.productid = a.productid 
        WHERE
            d.subdataid IN (p_subdataid) AND a.masterid = p_masterid
        GROUP BY
            a.productid
        ORDER BY
            a.lastmodifiedate DESC
        LIMIT p_limit
        OFFSET offset_value;
    ELSE
        
        SET p_result_status = 'ERROR';
        SET p_result_message = 'No data found';
        SELECT p_result_status AS status, p_result_message AS message;
    END IF;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `TEST_SP_searchproductschool` (IN `p_userid` BIGINT, IN `p_masterid` JSON, IN `p_subdataid` JSON, IN `p_limit` BIGINT, IN `p_pageno` BIGINT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE result_count INT; 
    DECLARE offset_value INT;
    DECLARE masterid_values VARCHAR(255); 
    DECLARE subdataid_values VARCHAR(255); 

    
    SET SESSION group_concat_max_len = 10000000; 

    
    SET offset_value = (p_pageno - 1) * p_limit;

    
    SELECT COUNT(*) INTO result_count
    FROM
        product a 
    LEFT JOIN
        productschoolmap b ON a.productid = b.productid
    LEFT JOIN
        productimage c ON a.productid = c.productid
    LEFT JOIN
        producttext d ON d.productid = a.productid
    WHERE
        b.schoolid IN (SELECT schoolid FROM `usersschoolmap` WHERE userid = p_userid);

    IF result_count > 0 THEN
        
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Data retrieved successfully';
        SELECT p_result_status AS status, p_result_message AS message;
        
        
        SELECT GROUP_CONCAT(value) INTO masterid_values
        FROM JSON_TABLE(p_masterid, '$[*]' COLUMNS (value INT PATH '$')) AS m;

        
        SELECT GROUP_CONCAT(value) INTO subdataid_values
        FROM JSON_TABLE(p_subdataid, '$[*]' COLUMNS (value INT PATH '$')) AS s;

        
        SET @sql = CONCAT(
            'SELECT
                a.productid,
                a.name,
                a.description,
                a.price,
                a.masterid,
                d.subdataid,
                JSON_ARRAYAGG(
                    JSON_OBJECT(
                        ''image'', TO_BASE64(c.image),
                        ''imageseq'', c.imageseq
                    )
                ) AS images
            FROM
                product a
            LEFT JOIN
                productschoolmap b ON a.productid = b.productid
            LEFT JOIN
                productimage c ON a.productid = c.productid 
            LEFT JOIN
                producttext d ON d.productid = a.productid
            WHERE 1=1',
            CASE
                WHEN masterid_values IS NOT NULL AND subdataid_values IS NOT NULL THEN
                    CONCAT(
                        ' AND a.masterid IN (', masterid_values, ')
                        AND d.subdataid IN (', subdataid_values, ')'
                    )
                WHEN masterid_values IS NOT NULL THEN
                    CONCAT(
                        ' AND a.masterid IN (', masterid_values, ')'
                    )
                WHEN subdataid_values IS NOT NULL THEN
                    CONCAT(
                        ' AND d.subdataid IN (', subdataid_values, ')'
                    )
                ELSE
                    ''
            END,
            ' AND b.schoolid IN (SELECT schoolid FROM `usersschoolmap` WHERE userid = ', p_userid,')',
            ' GROUP BY
                a.productid, a.name, a.price, a.masterid, d.subdataid
            ORDER BY
                a.lastmodifiedate DESC
            LIMIT ', p_limit,
            ' OFFSET ', offset_value, ';'
        );

        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    ELSE
        
        SET p_result_status = 'ERROR';
        SET p_result_message = 'No data found';
        SELECT p_result_status AS status, p_result_message AS message;
    END IF;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `Test_SP_SignUpUser` (IN `p_username` NVARCHAR(100), IN `p_password` NVARCHAR(250), IN `p_name` VARCHAR(100), IN `p_address` NVARCHAR(500), IN `p_email` NVARCHAR(50), IN `p_mobileno` VARCHAR(10))  BEGIN

  DECLARE v_username_count INT;
  DECLARE v_mobileno_count INT;
SELECT COUNT(*) INTO v_username_count FROM users WHERE username = p_username;
SELECT COUNT(*) INTO v_mobileno_count FROM users WHERE mobileno = p_mobileno;


IF v_username_count > 0 OR v_mobileno_count > 0 THEN
    SELECT 'Username or mobile number already exists' AS message;

ELSEIF LENGTH(p_mobileno) <> 10 THEN
    SELECT 'Mobile number must be a 10-digit number' AS message;

ELSE
    INSERT INTO users (username, password, name, address, email, mobileno)
    VALUES (p_username, p_password, p_name, p_address, p_email, p_mobileno);
    SELECT 'User created successfully' AS message;
END IF;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `Test_SP_SignUpUserWithSchoolandAddress` (IN `p_username` VARCHAR(50), IN `p_password` VARCHAR(150), IN `p_name` VARCHAR(100), IN `p_email` VARCHAR(50), IN `p_mobileno` VARCHAR(10), IN `p_schoolcodes` JSON, IN `p_Address1` VARCHAR(500), IN `p_Address2` VARCHAR(500), IN `p_Address3` VARCHAR(500), IN `p_Address4` VARCHAR(500), IN `p_Address5` VARCHAR(500), IN `p_Address6` VARCHAR(500), IN `p_Address7` VARCHAR(500), IN `p_Address8` VARCHAR(500), IN `p_Landmark` VARCHAR(500), IN `p_city` VARCHAR(100), IN `p_state` VARCHAR(100), IN `p_country` VARCHAR(100), IN `p_pincode` VARCHAR(6), IN `p_alternatemobileno` VARCHAR(10), IN `p_isprimary` BIT, IN `p_iswork` BIT, IN `p_status` BIT, IN `p_createdby` BIGINT, IN `p_createdon` DATETIME, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    
    DECLARE v_user_id BIGINT;
DECLARE p_result_status_school VARCHAR(50);
DECLARE p_result_message_school VARCHAR(255);


    
    SELECT
        CASE
            WHEN COUNT(*) > 0 OR LENGTH(p_mobileno) <> 10 OR LENGTH(p_pincode) <> 6
                OR LENGTH(p_email) > 0 AND NOT REGEXP_LIKE(p_email, '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+.[A-Z|a-z]{2,}$')
                OR EXISTS (SELECT 1 FROM users WHERE username = p_username)
                OR EXISTS (SELECT 1 FROM users WHERE mobileno = p_mobileno)
                OR EXISTS (SELECT 1 FROM users WHERE email = p_email)
            THEN 'FAILURE'
            ELSE 'SUCCESS'
        END AS p_result_status,
        CASE
            WHEN COUNT(*) > 0 THEN
                CASE
                    WHEN LENGTH(p_mobileno) <> 10 THEN 'Mobile number must be a 10-digit number'
                    WHEN LENGTH(p_pincode) <> 6 THEN 'Pin code must be a 6-digit number'
                    WHEN LENGTH(p_email) > 0 AND NOT REGEXP_LIKE(p_email, '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+.[A-Z|a-z]{2,}$') THEN 'Invalid email format'
                    WHEN EXISTS (SELECT 1 FROM users WHERE username = p_username) THEN 'Username already exists'
                    WHEN EXISTS (SELECT 1 FROM users WHERE mobileno = p_mobileno) THEN 'Mobile number already exists'
                    WHEN EXISTS (SELECT 1 FROM users WHERE email = p_email) THEN 'Email already exists'
                END
            ELSE 'SUCCESS'
        END AS p_result_message
    FROM users
    WHERE username = p_username OR mobileno = p_mobileno OR email = p_email;

    
    SELECT
        CASE
            WHEN COUNT(*) = JSON_LENGTH(p_schoolcodes) THEN 'SUCCESS'
            ELSE 'FAILURE'
        END AS p_result_status_school,
        CASE
            WHEN COUNT(*) <> JSON_LENGTH(p_schoolcodes) THEN 'One or more School Codes Not Found'
            ELSE 'SUCCESS'
        END AS p_result_message_school
    FROM JSON_TABLE(
        p_schoolcodes,
        '$[*]' COLUMNS (
            code VARCHAR(255) PATH '$'
        )
    ) AS school_codes
    LEFT JOIN school ON school.schoolcode = school_codes.code
    WHERE school.schoolid IS NULL;

    
    IF p_result_status = 'SUCCESS' AND p_result_message = 'SUCCESS' AND p_result_status_school = 'SUCCESS' THEN
        
        INSERT INTO users (username, password, name, email, mobileno)
        VALUES (p_username, p_password, p_name, p_email, p_mobileno);

        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'User created successfully';

        
        SELECT userid INTO v_user_id FROM users WHERE mobileno = p_mobileno;

        
        INSERT INTO usersschoolmap (userid, schoolid)
        SELECT v_user_id, school.schoolid
        FROM JSON_TABLE(
            p_schoolcodes,
            '$[*]' COLUMNS (
                code VARCHAR(255) PATH '$'
            )
        ) AS school_codes
        JOIN school ON school.schoolcode = school_codes.code;

        
        CALL SP_InsertAddress(
            v_user_id,
            p_name, p_Address1, p_Address2, p_Address3, p_Address4, p_Address5, p_Address6,
            p_Address7, p_Address8, p_Landmark, p_city, p_state, p_country, p_pincode,
            p_email, p_mobileno, p_alternatemobileno, 1, 0, 1,
            v_user_id, p_createdon, @v_result_status, @v_result_message
        );
    END IF;

    
    SELECT p_result_status AS status, p_result_message AS message;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `Test_UpdateProduct` (IN `p_productid` BIGINT, IN `p_barcode` VARCHAR(50), IN `p_masterid` BIGINT, IN `p_name` VARCHAR(100), IN `p_description` VARCHAR(500), IN `p_price` DECIMAL(10,0), IN `p_gst` DECIMAL(10,0), IN `p_discount` DECIMAL(10,0), IN `p_productstatus` VARCHAR(100), IN `p_ispublic` BIT(1), IN `p_isuniform` BIT(1), IN `p_lastmodifiedate` DATETIME, IN `p_lastmodifiedby` BIGINT, IN `p_schoolid` JSON, IN `p_imageseq` JSON, IN `p_image` JSON, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
    DECLARE product_exists INT;
    DECLARE idx INT DEFAULT 0;
    DECLARE code VARCHAR(50);
    DECLARE codeimage LONGTEXT;

    SET product_exists = NULL;

    
    SELECT COUNT(*) INTO product_exists
    FROM product
    WHERE productid = p_productid;

    
    

    IF product_exists IS NOT NULL AND product_exists > 0 THEN
        
        UPDATE product
        SET
            barcode = p_barcode,
            masterid = p_masterid,
            name = p_name,
            description = p_description,
            price = p_price,
            gst = p_gst,
            discount = p_discount,
            productstatus = p_productstatus,
            ispublic = p_ispublic,
            isuniform = p_isuniform,
            lastmodifiedate = p_lastmodifiedate,
            lastmodifiedby = p_lastmodifiedby
        WHERE productid = p_productid;

        
        

        
        DELETE FROM productschoolmap WHERE productid = p_productid;
        
            IF JSON_LENGTH(p_schoolid) IS NOT NULL AND JSON_LENGTH(p_schoolid) > 0 THEN

        
        WHILE idx < JSON_LENGTH(p_schoolid) DO
            SET code = JSON_UNQUOTE(JSON_EXTRACT(p_schoolid, CONCAT('$[', idx, ']')));
            
            

            
            INSERT INTO productschoolmap (productid, schoolid)
            VALUES (p_productid, code);

            
            

            SET idx = idx + 1;  
        END WHILE;
        END IF;

        
        SET idx = 0;

        
        DELETE FROM productimage WHERE productid = p_productid;

        
        WHILE idx < JSON_LENGTH(p_imageseq) DO
            SET code = JSON_UNQUOTE(JSON_EXTRACT(p_imageseq, CONCAT('$[', idx, ']')));
            
            

            
            INSERT INTO productimage (productid, imageseq, image)
            VALUES (p_productid, code, NULL); 

            
            

            
            IF JSON_LENGTH(p_image) IS NOT NULL AND JSON_LENGTH(p_image) > 0 THEN
                
                SET codeimage = JSON_UNQUOTE(JSON_EXTRACT(p_image, CONCAT('$[', idx, ']')));

                
                

                
                UPDATE productimage
                SET image = FROM_BASE64(codeimage)
                WHERE productid = p_productid AND imageseq = code;

                
                
            END IF;

            SET idx = idx + 1; 
        END WHILE;

        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Record updated successfully';

        
        
    ELSE
        
        SET p_result_status = 'ERROR';
        SET p_result_message = 'Product does not exist';

        
        
    END IF;
     SELECT p_result_status AS status, p_result_message AS message;

    COMMIT;
END$$

CREATE DEFINER=`cqr`@`%` PROCEDURE `Working_SP_searchproductother` (IN `p_masterid` JSON, IN `p_subdataid` JSON, IN `p_limit` BIGINT, IN `p_pageno` BIGINT, OUT `p_result_status` VARCHAR(50), OUT `p_result_message` VARCHAR(255))  BEGIN
  
    DECLARE offset_value INT;
    DECLARE masterid_values VARCHAR(255); 
    DECLARE subdataid_values VARCHAR(255); 

    
    SET SESSION group_concat_max_len = 10000000; 

    
    SET offset_value = (p_pageno - 1) * p_limit;

    
  
  
  
  
  
  
  
  
  

   
        
        SET p_result_status = 'SUCCESS';
        SET p_result_message = 'Data retrieved successfully';
        SELECT p_result_status AS status, p_result_message AS message;
        
        
        SELECT GROUP_CONCAT(value) INTO masterid_values
        FROM JSON_TABLE(p_masterid, '$[*]' COLUMNS (value INT PATH '$')) AS m;

        
        SELECT GROUP_CONCAT(value) INTO subdataid_values
        FROM JSON_TABLE(p_subdataid, '$[*]' COLUMNS (value INT PATH '$')) AS s;

        
        SET @sql = CONCAT(
            'SELECT
                a.productid,
                a.name,
                a.description,
                a.price,
                JSON_ARRAYAGG(
                    JSON_OBJECT(
                        ''image'', TO_BASE64(c.image),
                        ''imageseq'', c.imageseq
                    )
                ) AS images
            FROM
                product a
            LEFT JOIN
                productschoolmap b ON a.productid = b.productid
            LEFT JOIN
                productimage c ON a.productid = c.productid 
            LEFT JOIN
                producttext d ON d.productid = a.productid
            WHERE 1=1',
            CASE
                WHEN masterid_values IS NOT NULL AND subdataid_values IS NOT NULL THEN
                    CONCAT(
                        ' AND a.masterid IN (', masterid_values, ')
                        AND d.subdataid IN (', subdataid_values, ')'
                    )
                WHEN masterid_values IS NOT NULL THEN
                    CONCAT(
                        ' AND a.masterid IN (', masterid_values, ')'
                    )
                WHEN subdataid_values IS NOT NULL THEN
                    CONCAT(
                        ' AND d.subdataid IN (', subdataid_values, ')'
                    )
                ELSE
                    ''
            END,
            ' GROUP BY
                a.productid, a.name, a.price
            ORDER BY
                a.lastmodifiedate DESC
            LIMIT ', p_limit,
            ' OFFSET ', offset_value, ';'
        );

        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
  
        
  
  
  
  
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `addressid` bigint NOT NULL,
  `userid` bigint NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fullAddress` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `locationDetails` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `landmark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pincode` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobileno` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `alternatemobileno` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isprimary` int DEFAULT '0',
  `iswork` int DEFAULT '0',
  `status` int DEFAULT '1',
  `createdby` bigint DEFAULT NULL,
  `createdon` datetime DEFAULT (convert_tz(now(),_utf8mb4'+00:00',_utf8mb4'+05:30')),
  `lastmodifiedby` bigint DEFAULT NULL,
  `lastmodifiedate` datetime DEFAULT (convert_tz(now(),_utf8mb4'+00:00',_utf8mb4'+05:30'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`addressid`, `userid`, `name`, `fullAddress`, `locationDetails`, `landmark`, `city`, `state`, `country`, `pincode`, `email`, `mobileno`, `alternatemobileno`, `isprimary`, `iswork`, `status`, `createdby`, `createdon`, `lastmodifiedby`, `lastmodifiedate`) VALUES
(25, 54, 'balaji', '', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'near cub', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'msarun@gmail.com', '8940900292', '', 0, 0, 0, 54, '2024-02-06 22:30:59', 54, '2024-02-06 22:30:59'),
(32, 58, 'karthi', '', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'near cub', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'raghul1a@mail.com', '8940900292', '', 0, 0, 0, 58, '2024-02-08 13:20:54', 58, '2024-02-08 13:20:54'),
(65, 82, '2cqr', 'thiruvanaikoil', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'near cub', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'santhiram@gmail.com', '8940900292', 'undefined', 1, 0, 1, 82, '2024-03-04 12:30:27', 82, '2024-03-04 12:30:27'),
(66, 82, 'arun', '', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'near cub', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'arun@gmail.com', '8940900292', '8903061357', 0, 0, 1, 82, '2024-03-04 20:44:12', 82, '2024-03-04 20:44:12'),
(69, 85, 'kannan', 'undefined', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', '', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'kannan@gmail.com', '9600724179', '', 1, 0, 1, 85, '2024-10-02 00:00:00', 85, '2024-10-02 00:00:00'),
(71, 87, 'balu', '', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'near cub', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'abc@gmail.com', '8903061357', 'undefined', 1, 0, 1, 87, '2024-03-07 15:34:39', 87, '2024-03-07 15:34:39'),
(77, 82, 'balaji', '', 'varalsaravakam', 'near cub', 'chennai', 'Tamil Nadu', 'India', '600086', 'balaji@gmail.com', '8940900292', '8903061357', 0, 0, 1, 82, '2024-03-09 13:32:45', 82, '2024-03-09 13:32:45'),
(78, 93, 'Bharathi2', '', 'kasthurinaicken palayam', '', 'coimbatore', 'Tamil Nadu', 'India', '641041', 'bharathi@gmail.com', '9600420101', 'undefined', 1, 0, 1, 93, '2024-03-12 05:43:33', 93, '2024-03-12 05:43:33'),
(79, 94, 'ADMIN@123', '', '', 'opp CUB', 'Chennai', 'Tamilnadu', 'India', '600024', 'a@gmail.com', '9894749740', 'undefined', 1, 0, 1, 94, '2024-03-14 05:31:49', 94, '2024-03-14 05:31:49'),
(80, 95, 'ADMIN@0612', '', '2cqr', 'opp CUB', 'Chennai', 'Tamilnadu', 'India', '600024', 'g@gmail.com', '8248498874', 'undefined', 1, 0, 1, 95, '2024-03-14 06:01:24', 95, '2024-03-14 06:01:24'),
(81, 96, 'Gomathi Asaithambi Sundari', '', '2cqr Automation Private limited ,shridevikuppam main road', 'opp CUB', 'Chennai', 'Tamilnadu', 'India', '600001', 'h@gmail.com', '6379148114', 'undefined', 1, 0, 1, 96, '2024-03-14 10:19:39', 96, '2024-03-14 10:19:39'),
(82, 96, 'Gomathi', '', 'kkhlisurt274', 'khv', 'kanyakumari', 'Tamilnadu', 'India', '600002', 'g@gmail.com', '6374573725', '9894749740', 0, 0, 1, 96, '2024-03-14 10:29:38', 96, '2024-03-14 10:29:38'),
(83, 97, 'ganesh', '', '123', 'near cub', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'msarun1999@gmail.com', '8940900292', 'undefined', 1, 0, 1, 97, '2024-03-26 20:03:50', 97, '2024-03-26 20:03:50'),
(84, 98, '2cqr2011', 'undefined', 'undefined', '', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', '2cqr2013@gmail.com', '9600724179', '', 1, 0, 1, 98, '2024-03-27 10:44:11', 98, '2024-03-27 10:44:11'),
(85, 99, 'ganga', '', '186', 'near cub', 'chennai', 'Tamil Nadu', 'India', '600086', 'blastganesh@gmail.com', '7708668443', 'undefined', 1, 0, 1, 99, '2024-03-27 10:48:38', 99, '2024-03-27 10:48:38'),
(86, 100, 'cqr', '', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'near cub', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'cqr@gmail.com', '9791344113', 'undefined', 1, 0, 1, 100, '2024-03-27 16:28:26', 100, '2024-03-27 16:28:26'),
(87, 101, 'arun', '', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'near cub', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'muthiah1006@gmail.com', '8940900292', 'undefined', 1, 0, 1, 101, '2024-03-27 17:14:06', 101, '2024-03-27 17:14:06'),
(88, 102, 'cqrcqr', '', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'near cub', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'cqr2011@gmail.com', '8940900292', 'undefined', 1, 0, 1, 102, '2024-03-27 17:37:10', 102, '2024-03-27 17:37:10'),
(89, 103, 'prem', '', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'near cub', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'prem@gmail.com', '8940900292', 'undefined', 1, 0, 1, 103, '2024-03-27 17:40:36', 103, '2024-03-27 17:40:36'),
(90, 104, 'karthi', '', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'near cub', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'karthi@gmail.com', '8940900292', 'undefined', 1, 0, 1, 104, '2024-03-27 17:42:47', 104, '2024-03-27 17:42:47'),
(91, 105, '2cqr', 'valarasaravakam', 'chennai', '', 'chennai2', 'Tamil Nadu', 'India', '600086', '2cqr2011@gmail.com', '8940900293', '', 0, 0, 0, 105, '2024-03-27 18:18:23', 105, '2024-03-27 18:18:23'),
(92, 106, 'ganesh', 'undefined', 'undefined', '', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'ganesh@gmail.com', '8903061357', '', 1, 0, 1, 106, '2024-03-27 18:22:56', 106, '2024-03-27 18:22:56'),
(94, 108, 'StoreManger', 'undefined', 'kasthurinaicken palayam', '', 'coimbatore', 'Tamil Nadu', 'India', '641041', 'bharathi@gmail.com', '1234567890', '', 1, 0, 1, 108, '2024-03-28 12:40:23', 108, '2024-03-28 12:40:23'),
(95, 109, 'bharathiTest', '', 'kasthurinaicken palayam', '', 'coimbatore', 'Tamil Nadu', 'India', '641041', 'bharathi123@gmail.com', '9600420101', 'undefined', 1, 0, 1, 109, '2024-03-28 13:11:49', 109, '2024-03-28 13:11:49'),
(96, 110, 'Onlinestore Admin', 'undefined', 'undefined', '', 'kanyakumari', 'Tamilnadu', 'India', '600002', 'a@gmail.com', '6374573725', '', 1, 0, 1, 110, '2024-03-28 14:20:16', 110, '2024-03-28 14:20:16'),
(97, 111, 'arun', '', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', '', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'msarun1999@gmail.com', '8940900292', 'undefined', 1, 0, 1, 111, '2024-03-28 16:13:18', 111, '2024-03-28 16:13:18'),
(98, 112, '2cqrcqr', '', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', '', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'santhiram@gmail.com', '8940900292', 'undefined', 1, 0, 1, 112, '2024-03-28 16:25:41', 112, '2024-03-28 16:25:41'),
(99, 113, 'arun', 'undefined', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', '', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'muthiah@gmail.com', '8940900292', '', 0, 0, 0, 113, '2024-03-28 16:29:30', 113, '2024-03-28 16:29:30'),
(100, 113, '2cqr', '', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'near cub', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', '2cqr2011@gmail.com', '8940900292', '8903061357', 0, 0, 1, 113, '2024-03-28 23:31:37', 113, '2024-03-28 23:31:37'),
(101, 114, 'Ganesh', 'undefined', 'undefined', '', 'Chennai', 'TN', 'IN', '600103', 'ganesh@2cqr.in', '7708668443', '', 1, 0, 1, 114, '2024-03-29 18:34:25', 114, '2024-03-29 18:34:25'),
(102, 115, 'Ganesh', 'undefined', 'undefined', '', 'CH', 'TN', 'IN', '600103', 'ganesh1@2cqr.in', '7708668433', '', 1, 0, 1, 115, '2024-03-29 18:49:30', 115, '2024-03-29 18:49:30'),
(103, 116, '2cqr', 'undefined', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', '', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'msarun1999@mail.com', '8940900292', '', 0, 0, 0, 116, '2024-04-01 11:29:16', 116, '2024-04-01 11:29:16'),
(104, 117, 'bharathi', 'R.S. Puram', 'kasthurinaicken palayam', '', 'coimbatore', 'Tamil Nadu', 'India', '641041', 'bharathi@2cqr.in', '9600420101', 'undefined', 1, 0, 1, 117, '2024-04-01 11:43:05', 117, '2024-04-01 11:43:05'),
(105, 118, 'Ganesh', 'undefined', 'Ganesh', '', 'Chennai', 'TN', 'IN', '600103', 'ganesh@2cqr.in', '7708668443', '', 0, 0, 0, 118, '2024-04-01 13:22:58', 118, '2024-04-01 13:22:58'),
(106, 119, 'Ganesh', 'undefined', 'Ganesh', '', 'CHN', 'TN', 'IN', '600103', 'ganesh11@2cqr.in', '9344002002', '', 1, 0, 1, 119, '2024-04-02 16:06:22', 119, '2024-04-02 16:06:22'),
(107, 120, 'arun', '', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', '', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'arunmuthiah100699@gmail.com', '8903061357', 'undefined', 1, 0, 1, 120, '2024-04-02 19:09:43', 120, '2024-04-02 19:09:43'),
(108, 121, 'bharathi2', '', '137,West Sambantham Road', '', 'Coimbatore', 'Tamil Nadu', 'India', '641002', '123somu@gmail.com', '9884302002', 'undefined', 1, 0, 1, 121, '2024-04-03 10:49:42', 121, '2024-04-03 10:49:42'),
(109, 122, 'Gomathi', 'undefined', '2cqr Automation Private limited ,shridevikuppam main road', '', 'Chennai', 'Tamilnadu', 'India', '600024', 'a@gmail.com', '6374573725', '', 0, 0, 0, 122, '2024-04-05 11:45:24', 122, '2024-04-05 11:45:24'),
(110, 116, 'Gomathi', '', '2cqr Automation Private limited ,shridevikuppam main road', 'OPP cub', 'Chennai', 'Tamilnadu', 'India', '600024', 'a@gmail.com', '6374573725', '9894749740', 0, 0, 1, 116, '2024-04-11 16:42:55', 116, '2024-04-11 16:42:55'),
(111, 123, 'Ahtina', 'undefined', '2cqr Automation Private limited ,shridevikuppam main road', '', 'Chennai', 'Tamilnadu', 'India', '600024', 'a@gmail.com', '6374573725', '', 1, 0, 1, 123, '2024-04-11 17:55:05', 123, '2024-04-11 17:55:05'),
(114, 126, 'tiaraadmin', 'undefined', 'tiaraadmin', '', 'CH', 'TN', 'IN', '600103', 'tiaraadmin@gmail.com', '7845532002', '', 1, 0, 1, 126, '2024-04-12 12:56:34', 126, '2024-04-12 12:56:34'),
(115, 127, 'tiaraclothing', '', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', '', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'muthiah1006@gmail.com', '8940900292', 'undefined', 1, 0, 1, 127, '2024-04-30 11:50:28', 127, '2024-04-30 11:50:28'),
(116, 128, 'tiaraclothing', '', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', '', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'muthiah1006@gmail.com', '8940900292', 'undefined', 1, 0, 1, 128, '2024-04-30 12:05:12', 128, '2024-04-30 12:05:12'),
(122, 134, 'anitha', 'Apt 4B', '123 Main St', 'Near Park', 'Cityville', 'Stateville', 'Countryland', '123456', '', '8989891234', 'undefined', 0, 0, 0, 456, '2024-01-24 12:00:00', 456, '2024-01-24 12:00:00'),
(125, 137, 'Laksmi', 'Apt 4B', '123 Main St', 'Near Park', 'Cityville', 'Stateville', 'Countryland', '123456', 'lak@gmail.com', '9894749740', 'undefined', 0, 0, 0, 456, '2024-01-24 12:00:00', 456, '2024-01-24 12:00:00'),
(126, 138, 'arun', 'undefined', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'undefined', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'muthiah1006@gmail.com', '8903061357', 'undefined', 0, 0, 0, 126, '2024-06-11 16:45:07', 126, '2024-06-11 16:45:07'),
(127, 139, 'arun', 'undefined', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', '', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'muthiah1007@gmail.com', '8903061357', '', 1, 0, 1, 139, '2024-06-11 17:05:09', 139, '2024-06-11 17:05:09'),
(133, 145, 'balaji', 'undefined', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'undefined', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'balaji@gmail.com', '9791344113', 'undefined', 1, 0, 1, 145, '2024-06-22 00:00:00', 145, '2024-06-22 00:00:00'),
(134, 146, 'fdsf', 'undefined', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'undefined', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'santhiram@gmail.com', '9600724179', 'undefined', 1, 0, 1, 146, '2024-06-22 00:00:00', 146, '2024-06-22 00:00:00'),
(135, 147, 'karthi', 'undefined', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'undefined', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'abc@gmail.com', '1234567890', 'undefined', 1, 0, 1, 147, '2024-06-22 00:00:00', 147, '2024-06-22 00:00:00'),
(136, 148, 'prem', 'undefined', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'undefined', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'abcdf@gmail.com', '1234567899', 'undefined', 1, 0, 1, 148, '2024-06-22 05:30:00', 148, '2024-06-22 05:30:00'),
(137, 149, 'tiaraadmin', 'undefined', 'undefined', 'undefined', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'muthiah1008@gmail.com', '8940900292', 'undefined', 1, 0, 1, 149, '2024-06-22 00:00:00', 149, '2024-06-22 00:00:00'),
(138, 150, 'tiaraadmin', 'undefined', 'undefined', 'undefined', 'chennai', 'Tamil Nadu', 'India', '600103', 'muthiah1008@gmail.com', '8940900292', 'undefined', 1, 0, 1, 150, '2024-06-22 00:00:00', 150, '2024-06-22 00:00:00'),
(139, 151, 'mukilan', 'undefined', 'undefined', 'undefined', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'mukilan@gmail.com', '9443435089', 'undefined', 1, 0, 1, 151, '2024-06-22 00:00:00', 151, '2024-06-22 00:00:00'),
(140, 152, 'ganesh', 'undefined', 'undefined', 'undefined', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'ganesh@gmail.com', '1234567894', 'undefined', 1, 0, 1, 152, '2024-06-24 00:00:00', 152, '2024-06-24 00:00:00'),
(149, 126, 'arun', 'undefined', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'near cub', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'arun@gmail.com', '8940900292', '8903061357', 0, 0, 1, 126, '2024-08-29 12:16:09', 126, '2024-08-29 12:16:09'),
(150, 126, 'tiarabangalore', 'undefined', 'bangalore', 'near school', 'bangalore', 'karnataka', 'India', '500025', 'tiarabangalore@gmail.com', '9600724179', '8903061357', 0, 0, 1, 126, '2024-09-03 11:30:56', 126, '2024-09-03 11:30:56'),
(151, 159, '2cqr varalasaravakam', 'undefined', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'undefined', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'arun@2cqr.in', '8940900292', 'undefined', 0, 0, 0, 126, '2024-09-03 03:03:10', 126, '2024-09-03 03:03:10'),
(161, 168, 'tiarapacked', 'undefined', 'undefined', 'undefined', 'bangalore', 'karnataka', 'India', '500025', 'tiarapacked@gmail.com', '9600724179', 'undefined', 1, 0, 1, 168, '2024-09-06 00:00:00', 168, '2024-09-06 00:00:00'),
(162, 169, 'onlinecustomer', 'undefined', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'undefined', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'msarun1999@gmail.com', '8940900292', 'undefined', 0, 0, 0, 126, '2024-09-03 03:03:10', 126, '2024-09-03 03:03:10'),
(163, 170, 'tiarashipped', 'undefined', 'undefined', 'undefined', 'bangalore', 'Tamil Nadu', 'India', '500025', 'tiarashipped@gmail.com', '9600724179', 'undefined', 1, 0, 1, 170, '2024-09-06 05:30:00', 170, '2024-09-06 05:30:00'),
(165, 172, 'onlineschoolcustomer', 'undefined', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'undefined', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', '2cqr2011@gmail.com', '6369515090', 'undefined', 0, 0, 0, 126, '2024-09-03 03:03:10', 126, '2024-09-03 03:03:10'),
(166, 173, 'tiara', 'undefined', '123', 'undefined', 'Banglore', 'karnataka', 'India', '600012', 'test123@gmail.com', '9900557609', 'undefined', 0, 0, 0, 169, '2024-09-03 03:03:10', 169, '2024-09-03 03:03:10'),
(167, 174, 'arun_REG', 'new', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'new cub', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'raghul1a@mail.com', '8940900292', 'undefined', 0, 0, 1, 174, '2024-09-26 23:40:52', 174, '2024-09-26 23:40:52'),
(168, 184, 'aravindotp', 'new', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'undefined', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'aravindotp@mail.com', '9361621891', 'undefined', 0, 0, 1, 184, '2024-09-27 19:00:54', 184, '2024-09-27 19:00:54'),
(169, 186, 'aravindotp', 'new', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'undefined', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'aravindotp@mail.com', '9361621891', 'undefined', 0, 0, 1, 186, '2024-09-27 19:06:14', 186, '2024-09-27 19:06:14'),
(170, 187, 'arun', 'new', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'undefined', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'raghul1a@mail.com', '8940900292', 'undefined', 0, 0, 1, 187, '2024-09-27 20:14:25', 187, '2024-09-27 20:14:25'),
(171, 188, 'arun', 'new', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'undefined', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'msarun@gmail.com', '8940900292', 'undefined', 0, 0, 1, 188, '2024-09-27 22:16:01', 188, '2024-09-27 22:16:01'),
(172, 189, 'arun', 'new', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'undefined', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'dsfds@gmail.com', '8903061357', 'undefined', 0, 0, 1, 189, '2024-09-27 22:19:05', 189, '2024-09-27 22:19:05'),
(173, 190, 'ar', 'new', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'undefined', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'raghul1a@mail.com', '8940900292', 'undefined', 0, 0, 1, 190, '2024-10-01 14:52:59', 190, '2024-10-01 14:52:59'),
(174, 191, 'admin', '2', 'kamaraj street', 'undefined', 'Villupuram', 'tamilnadu', 'India', '604202', 'a@gmail.com', '6374573725', 'undefined', 0, 0, 1, 191, '2024-10-01 23:01:29', 191, '2024-10-01 23:01:29'),
(175, 192, 'Test', '172/1', '2cqr Automation Private limited ,shridevikuppam main road', 'undefined', 'Chennai', 'Tamilnadu', 'India', '600024', 'b@gmail.com', '6379148114', 'undefined', 0, 0, 1, 192, '2024-10-02 05:34:09', 192, '2024-10-02 05:34:09'),
(176, 193, 'Gomathi', '172', '2cqr Automation Private limited ,shridevikuppam main road', 'undefined', 'Chennai', 'Tamilnadu', 'India', '600024', 'h@gmail.com', '9345002002', 'undefined', 0, 0, 1, 193, '2024-10-02 05:53:55', 193, '2024-10-02 05:53:55'),
(177, 194, 'arun', 'new', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'undefined', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'santhiram@gmail.com', '8940900292', 'undefined', 0, 0, 1, 194, '2024-10-03 17:13:33', 194, '2024-10-03 17:13:33'),
(178, 195, 'arun', '78A/2 new no 93', ' south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'undefined', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'arunmuthiah100699@gmail.com', '8940900292', 'undefined', 0, 0, 1, 195, '2024-10-24 19:46:54', 195, '2024-10-24 19:46:54'),
(179, 196, '2cqr', 'new cub', 'valarasaravakam', '', 'chennai', 'Tamil Nadu', 'India', '600028', '2cqr2024@gmail.com', '8940900292', 'undefined', 0, 0, 1, 196, '2024-10-26 18:04:15', 196, '2024-10-26 18:04:15'),
(180, 197, 'arunMuthiah', '78', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'undefined', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'abc@gmail.com', '8903061357', 'undefined', 0, 0, 1, 197, '2024-10-28 16:11:21', 197, '2024-10-28 16:11:21'),
(181, 198, 'Anitha', 'No:20', '2cqr Automation Private limited ,shridevikuppam main road', '', 'Chennai', 'Tamilnadu', 'India', '600024', 'a@gmail.com', '6374573725', 'undefined', 0, 0, 1, 198, '2024-10-28 18:47:33', 198, '2024-10-28 18:47:33'),
(182, 199, 'Anitha', '20', '2cqr Automation Private limited ,shridevikuppam main road', '', 'Chennai', 'Tamilnadu', 'India', '600024', 'a@gmail.com', '6374573725', 'undefined', 0, 0, 1, 199, '2024-10-28 19:05:52', 199, '2024-10-28 19:05:52'),
(183, 200, 'Anitha', '32', '2cqr Automation Private limited ,shridevikuppam main road', '', 'Chennai', 'Tamilnadu', 'India', '600024', 'n@gmail.com', '9894749740', 'undefined', 0, 0, 1, 200, '2024-10-28 19:41:15', 200, '2024-10-28 19:41:15'),
(184, 201, 'Gomathi', '2', '2cqr Automation Private limited ,shridevikuppam main road', '', 'Chennai', 'Tamilnadu', 'India', '600024', 'g@gmail.com', '8248498874', 'undefined', 0, 0, 1, 201, '2024-11-05 16:48:09', 201, '2024-11-05 16:48:09'),
(185, 202, '2cqr', '78 a/2 south inside street', 'thiruvanaikoil', 'near cub', 'trichy', 'Tamil Nadu', 'India', '620005', '2cqr2024@gmail.com', '8940900292', NULL, 0, 0, 1, 202, '2024-11-06 02:38:54', 202, '2024-11-06 02:38:54'),
(186, 203, 'testing', '2448', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'near school', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'testing@gmail.com', '8903061357', 'undefined', 0, 0, 1, 203, '2024-11-06 18:59:00', 203, '2024-11-06 18:59:00'),
(187, 204, 'testing', '789', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'near valasaravakam', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'testing@gmail.com', '8903061357', 'undefined', 0, 0, 1, 204, '2024-11-06 19:21:30', 204, '2024-11-06 19:21:30'),
(188, 205, 'Anitha', '21', '2cqr Automation Private limited ,shridevikuppam main road', '', 'Chennai', 'Tamilnadu', 'India', '600024', 'a@gmail.com', '6374573725', 'undefined', 0, 0, 1, 205, '2024-11-07 18:56:04', 205, '2024-11-07 18:56:04'),
(195, 206, 'Test', 'AO98, Elan', 'Thazambur', '', 'Chennai', 'Tamil Nadu', 'India', '641041', 'bharathi@2cqr.in', '9600420101', 'undefined', 0, 0, 1, 206, '2024-11-11 17:13:56', 206, '2024-11-11 17:13:56'),
(196, 207, 'test12', 'fadsf', 'adfa', '', 'adfa', 'Tasd', 'idhsfg', '641041', 'bharathi@2cqr.in', '9600420101', 'undefined', 0, 0, 1, 207, '2024-11-11 21:24:48', 207, '2024-11-11 21:24:48'),
(221, 202, 'karthi', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'undefined', 'undefined', 'Tiruchirappalli', 'Karnataka', 'India', '620005', 'msarun@gmail.com', '8989898989', '3424324324', 0, 0, 0, 202, '2024-11-13 11:44:34', 202, '2024-11-13 11:44:34'),
(222, 208, 'arun', 'dfs', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', '', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'santhiram@gmail.com', '8940900292', 'undefined', 0, 0, 1, 208, '2024-11-14 22:45:46', 208, '2024-11-14 22:45:46'),
(223, 209, 'arun', '34324', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', '', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'raghul1a@mail.com', '8940900292', 'undefined', 0, 0, 1, 209, '2024-11-14 22:47:33', 209, '2024-11-14 22:47:33'),
(224, 210, 'fds', 'fvsafde', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', '', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'raghul1a@mail.com', '8940900292', 'undefined', 0, 0, 1, 210, '2024-11-14 22:52:48', 210, '2024-11-14 22:52:48'),
(225, 211, 'Anitha', '4', '2cqr Automation Private limited ,shridevikuppam main road', '', 'Chennai', 'Tamilnadu', 'India', '600024', 'an@gmail.com', '9894749740', 'undefined', 0, 0, 1, 211, '2024-11-15 20:55:19', 211, '2024-11-15 20:55:19'),
(226, 216, 'Anitha', '9090', 'hiug', '', 'ftfuyhjvnbk', 'ghfkjkh', 'gfhjkl', '768123', 'an@gmail.com', '9894749740', 'undefined', 0, 0, 1, 216, '2024-11-15 21:11:26', 216, '2024-11-15 21:11:26'),
(227, 224, 'arun', 'fds', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', '', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'msarun@gmail.com', '8940900292', 'undefined', 0, 0, 1, 224, '2024-11-15 23:06:57', 224, '2024-11-15 23:06:57'),
(228, 225, 'arun', 'fds', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', '', 'Tiruchirappalli', 'Tamil Nadu', 'India', '620005', 'arunmuthiah100699@gmail.com', '8940900292', 'undefined', 0, 0, 1, 225, '2024-11-15 23:08:07', 225, '2024-11-15 23:08:07'),
(229, 226, 'anitha', '23', '2cqr Automation Private limited ,shridevikuppam main road', '', 'Chennai', 'Tamilnadu', 'India', '600024', 'an@gmail.com', '9894749740', 'undefined', 0, 0, 1, 226, '2024-11-15 23:17:27', 226, '2024-11-15 23:17:27'),
(230, 227, 'Ahtina', '1', '3rd cross street', '', 'Chennai', 'Tamilnadu', 'INDIA', '600024', 'anithaalex958@gmail.com', '8248498874', 'undefined', 0, 0, 1, 227, '2024-11-19 21:01:53', 227, '2024-11-19 21:01:53'),
(231, 228, 'Tiara', '2', 'Whitefield', '', 'Bangalore', 'Karanataka', 'INDIA', '560066', 'anithaalex958@gmail.com', '9894749740', 'undefined', 0, 0, 1, 228, '2024-11-20 18:43:44', 228, '2024-11-20 18:43:44'),
(232, 229, '2cqr', '546', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', 'near valasaravakam', 'Tiruchirappalli', '23', 'India', '620006', 'msarun19949@gmail.com', '8903061357', 'undefined', 0, 0, 1, 229, '2024-11-21 22:22:58', 229, '2024-11-21 22:22:58'),
(233, 230, 'arun', '93', '78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy', '', 'Tiruchirappalli', '23', 'India', '620005', 'muthiah1006@gmail.com', '8940900292', 'undefined', 0, 0, 1, 230, '2024-11-21 22:29:00', 230, '2024-11-21 22:29:00'),
(234, 227, 'Ani', 'Chennai', 'undefined', 'undefined', 'Chennai', 'Tamil Nadu', 'India', '600023', 'a@gmail.com', '6374573725', '', 0, 0, 0, 227, '2024-11-22 10:09:13', 227, '2024-11-22 10:09:13');

-- --------------------------------------------------------

--
-- Table structure for table `addtocarttable`
--

CREATE TABLE `addtocarttable` (
  `atcartid` bigint NOT NULL,
  `userid` int DEFAULT NULL,
  `productid` int DEFAULT NULL,
  `variantid` bigint DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `status` varchar(100) DEFAULT 'incart',
  `createdby` bigint DEFAULT NULL,
  `createdon` datetime DEFAULT (convert_tz(now(),_utf8mb4'+00:00',_utf8mb4'+05:30')),
  `lastmodifiedby` bigint DEFAULT NULL,
  `lastmodifiedate` datetime DEFAULT (convert_tz(now(),_utf8mb4'+00:00',_utf8mb4'+05:30'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `addtocarttable`
--

INSERT INTO `addtocarttable` (`atcartid`, `userid`, `productid`, `variantid`, `quantity`, `status`, `createdby`, `createdon`, `lastmodifiedby`, `lastmodifiedate`) VALUES
(98, 202, 336, 539, 5, 'Ordered', NULL, '2024-11-12 16:40:01', NULL, '2024-11-12 16:40:01'),
(99, 202, 336, 540, 9, 'Ordered', NULL, '2024-11-12 16:40:24', NULL, '2024-11-12 16:40:24'),
(107, 202, 336, 540, 13, 'Ordered', NULL, '2024-11-13 11:32:43', NULL, '2024-11-13 11:32:43'),
(108, 202, 336, 541, 8, 'Ordered', NULL, '2024-11-13 11:35:17', NULL, '2024-11-13 11:35:17'),
(113, 202, 334, 535, 1, 'Ordered', NULL, '2024-11-13 11:46:04', NULL, '2024-11-13 11:46:04'),
(114, 202, 336, 540, 1, 'Ordered', NULL, '2024-11-13 11:54:22', NULL, '2024-11-13 11:54:22'),
(115, 202, 336, 540, 1, 'Ordered', NULL, '2024-11-13 11:56:38', NULL, '2024-11-13 11:56:38'),
(117, 202, 334, 536, 2, 'Ordered', NULL, '2024-11-13 12:46:34', NULL, '2024-11-13 12:46:34'),
(118, 202, 334, 537, 1, 'Ordered', NULL, '2024-11-13 12:47:01', NULL, '2024-11-13 12:47:01'),
(119, 202, 336, 540, 1, 'Ordered', NULL, '2024-11-13 12:47:46', NULL, '2024-11-13 12:47:46'),
(120, 202, 334, 535, 1, 'Ordered', NULL, '2024-11-13 13:13:21', NULL, '2024-11-13 13:13:21'),
(121, 202, 336, 540, 1, 'Ordered', NULL, '2024-11-13 13:18:27', NULL, '2024-11-13 13:18:27'),
(122, 202, 336, 540, 1, 'Ordered', NULL, '2024-11-13 13:19:33', NULL, '2024-11-13 13:19:33'),
(123, 202, 334, 535, 1, 'Ordered', NULL, '2024-11-13 13:20:26', NULL, '2024-11-13 13:20:26'),
(126, 202, 336, 540, 1, 'Ordered', NULL, '2024-11-13 13:30:14', NULL, '2024-11-13 13:30:14'),
(127, 202, 334, 535, 2, 'Ordered', NULL, '2024-11-13 13:41:10', NULL, '2024-11-13 13:41:10'),
(128, 202, 334, 535, 1, 'Ordered', NULL, '2024-11-13 14:02:14', NULL, '2024-11-13 14:02:14'),
(129, 202, 334, 535, 1, 'Ordered', NULL, '2024-11-13 14:43:51', NULL, '2024-11-13 14:43:51'),
(130, 202, 336, 540, 1, 'Ordered', NULL, '2024-11-13 14:51:32', NULL, '2024-11-13 14:51:32'),
(131, 202, 336, 541, 1, 'Ordered', NULL, '2024-11-13 14:51:41', NULL, '2024-11-13 14:51:41'),
(133, 205, 329, 493, 482, 'Ordered', NULL, '2024-11-13 14:54:29', NULL, '2024-11-13 14:54:29'),
(134, 205, 331, 503, 1, 'Ordered', NULL, '2024-11-13 14:57:37', NULL, '2024-11-13 14:57:37'),
(135, 202, 334, 535, 2, 'Ordered', NULL, '2024-11-13 15:05:25', NULL, '2024-11-13 15:05:25'),
(136, 202, 334, 536, 1, 'Ordered', NULL, '2024-11-13 15:06:37', NULL, '2024-11-13 15:06:37'),
(137, 205, 329, 494, 1, 'Ordered', NULL, '2024-11-13 15:06:54', NULL, '2024-11-13 15:06:54'),
(138, 205, 329, 495, 1, 'Ordered', NULL, '2024-11-13 15:11:50', NULL, '2024-11-13 15:11:50'),
(139, 205, 332, 516, 1, 'Ordered', NULL, '2024-11-13 15:13:20', NULL, '2024-11-13 15:13:20'),
(140, 205, 337, 542, 1, 'Ordered', NULL, '2024-11-13 15:15:22', NULL, '2024-11-13 15:15:22'),
(145, 205, 337, 542, 1, 'Ordered', NULL, '2024-11-13 15:23:40', NULL, '2024-11-13 15:23:40'),
(146, 205, 337, 542, 1, 'Ordered', NULL, '2024-11-13 15:25:28', NULL, '2024-11-13 15:25:28'),
(155, 205, 329, 493, 1, 'Ordered', NULL, '2024-11-13 15:35:17', NULL, '2024-11-13 15:35:17'),
(156, 205, 331, 503, 9, 'Ordered', NULL, '2024-11-13 15:35:34', NULL, '2024-11-13 15:35:34'),
(157, 202, 334, 534, 1, 'Ordered', NULL, '2024-11-13 15:39:20', NULL, '2024-11-13 15:39:20'),
(158, 205, 331, 503, 1, 'Ordered', NULL, '2024-11-13 15:52:59', NULL, '2024-11-13 15:52:59'),
(159, 205, 329, 493, 1, 'Ordered', NULL, '2024-11-13 15:53:32', NULL, '2024-11-13 15:53:32'),
(171, 202, 336, 539, 2147483647, 'Ordered', NULL, '2024-11-13 17:27:08', NULL, '2024-11-13 17:27:08'),
(176, 205, 339, 546, 2, 'Ordered', NULL, '2024-11-13 17:56:42', NULL, '2024-11-13 17:56:42'),
(177, 205, 332, 516, 1, 'Ordered', NULL, '2024-11-13 17:57:00', NULL, '2024-11-13 17:57:00'),
(178, 202, 336, 540, 1, 'Ordered', NULL, '2024-11-14 10:22:17', NULL, '2024-11-14 10:22:17'),
(179, 205, 340, 548, 3, 'Ordered', NULL, '2024-11-14 10:29:25', NULL, '2024-11-14 10:29:25'),
(180, 202, 336, 540, 1, 'Ordered', NULL, '2024-11-14 11:30:36', NULL, '2024-11-14 11:30:36'),
(182, 202, 334, 534, 4, 'Ordered', NULL, '2024-11-14 11:36:27', NULL, '2024-11-14 11:36:27'),
(183, 207, 334, 534, 1, 'Ordered', NULL, '2024-11-14 15:39:05', NULL, '2024-11-14 15:39:05'),
(184, 207, 334, 534, 1, 'Ordered', NULL, '2024-11-14 16:17:35', NULL, '2024-11-14 16:17:35'),
(185, 202, 338, 544, 2, 'Ordered', NULL, '2024-11-14 16:49:55', NULL, '2024-11-14 16:49:55'),
(186, 207, 338, 544, 10, 'Ordered', NULL, '2024-11-14 16:54:19', NULL, '2024-11-14 16:54:19'),
(187, 202, 338, 544, 2, 'Ordered', NULL, '2024-11-14 16:54:25', NULL, '2024-11-14 16:54:25'),
(188, 202, 336, 539, 1, 'Ordered', NULL, '2024-11-14 18:02:34', NULL, '2024-11-14 18:02:34'),
(189, 202, 334, 535, 1, 'Ordered', NULL, '2024-11-15 11:29:27', NULL, '2024-11-15 11:29:27'),
(193, 202, 334, 534, 1, 'Ordered', NULL, '2024-11-15 11:42:10', NULL, '2024-11-15 11:42:10'),
(194, 202, 338, 544, 1, 'Ordered', NULL, '2024-11-15 11:44:36', NULL, '2024-11-15 11:44:36'),
(195, 202, 334, 534, 7, 'Ordered', NULL, '2024-11-15 11:50:04', NULL, '2024-11-15 11:50:04'),
(196, 202, 336, 539, 7, 'Ordered', NULL, '2024-11-15 11:52:02', NULL, '2024-11-15 11:52:02'),
(197, 207, 334, 534, 1, 'incart', NULL, '2024-11-15 12:28:33', NULL, '2024-11-15 12:28:33'),
(198, 202, 338, 544, 1, 'Ordered', NULL, '2024-11-15 12:54:06', NULL, '2024-11-15 12:54:06'),
(199, 202, 334, 534, 1, 'Ordered', NULL, '2024-11-15 12:58:15', NULL, '2024-11-15 12:58:15'),
(200, 202, 334, 534, 1, 'Ordered', NULL, '2024-11-15 13:01:18', NULL, '2024-11-15 13:01:18'),
(201, 202, 334, 534, 1, 'Ordered', NULL, '2024-11-15 13:02:57', NULL, '2024-11-15 13:02:57'),
(202, 202, 338, 544, 1, 'Ordered', NULL, '2024-11-15 13:03:09', NULL, '2024-11-15 13:03:09'),
(203, 202, 334, 534, 1, 'Ordered', NULL, '2024-11-15 13:07:00', NULL, '2024-11-15 13:07:00'),
(204, 202, 334, 534, 1, 'Ordered', NULL, '2024-11-15 13:07:32', NULL, '2024-11-15 13:07:32'),
(205, 202, 338, 544, 1, 'Ordered', NULL, '2024-11-15 13:07:41', NULL, '2024-11-15 13:07:41'),
(206, 202, 334, 534, 2, 'Ordered', NULL, '2024-11-15 13:08:48', NULL, '2024-11-15 13:08:48'),
(207, 202, 338, 544, 2, 'Ordered', NULL, '2024-11-15 13:08:59', NULL, '2024-11-15 13:08:59'),
(208, 202, 334, 534, 1, 'Ordered', NULL, '2024-11-15 13:41:26', NULL, '2024-11-15 13:41:26'),
(209, 205, 329, 493, 2, 'Ordered', NULL, '2024-11-15 16:22:05', NULL, '2024-11-15 16:22:05'),
(210, 202, 334, 534, 1, 'Ordered', NULL, '2024-11-18 10:51:32', NULL, '2024-11-18 10:51:32'),
(211, 202, 336, 539, 1, 'Ordered', NULL, '2024-11-18 11:20:24', NULL, '2024-11-18 11:20:24'),
(212, 202, 336, 539, 1, 'Ordered', NULL, '2024-11-18 11:27:38', NULL, '2024-11-18 11:27:38'),
(213, 202, 336, 541, 7, 'Ordered', NULL, '2024-11-18 12:27:40', NULL, '2024-11-18 12:27:40'),
(214, 202, 336, 539, 1, 'Ordered', NULL, '2024-11-18 12:35:31', NULL, '2024-11-18 12:35:31'),
(215, 202, 334, 534, 3, 'Ordered', NULL, '2024-11-18 12:59:25', NULL, '2024-11-18 12:59:25'),
(216, 202, 338, 544, 1, 'Ordered', NULL, '2024-11-18 13:47:50', NULL, '2024-11-18 13:47:50'),
(217, 202, 334, 534, 1, 'Ordered', NULL, '2024-11-18 13:53:16', NULL, '2024-11-18 13:53:16'),
(218, 202, 334, 534, 1, 'Ordered', NULL, '2024-11-18 20:12:28', NULL, '2024-11-18 20:12:28'),
(229, 227, 329, 493, 1, 'Ordered', NULL, '2024-11-19 15:36:34', NULL, '2024-11-19 15:36:34'),
(230, 202, 336, 539, 1, 'Ordered', NULL, '2024-11-19 15:50:00', NULL, '2024-11-19 15:50:00'),
(233, 202, 336, 541, 0, 'Ordered', NULL, '2024-11-20 14:27:05', NULL, '2024-11-20 14:27:05'),
(236, 202, 334, 536, 1, 'Ordered', NULL, '2024-11-21 11:20:15', NULL, '2024-11-21 11:20:15'),
(237, 202, 334, 535, 1, 'Ordered', NULL, '2024-11-21 12:55:16', NULL, '2024-11-21 12:55:16'),
(238, 202, 334, 534, 1, 'Ordered', NULL, '2024-11-21 12:56:10', NULL, '2024-11-21 12:56:10'),
(239, 202, 336, 539, 1, 'Ordered', NULL, '2024-11-21 12:58:22', NULL, '2024-11-21 12:58:22'),
(240, 202, 336, 539, 1, 'Ordered', NULL, '2024-11-21 13:06:06', NULL, '2024-11-21 13:06:06'),
(241, 202, 336, 539, 1, 'Ordered', NULL, '2024-11-21 13:06:50', NULL, '2024-11-21 13:06:50'),
(242, 202, 334, 534, 1, 'Ordered', NULL, '2024-11-21 13:37:31', NULL, '2024-11-21 13:37:31'),
(243, 202, 338, 544, 1, 'Ordered', NULL, '2024-11-21 13:37:41', NULL, '2024-11-21 13:37:41'),
(244, 202, 334, 534, 1, 'Ordered', NULL, '2024-11-21 13:39:06', NULL, '2024-11-21 13:39:06'),
(245, 202, 338, 544, 1, 'Ordered', NULL, '2024-11-21 13:39:15', NULL, '2024-11-21 13:39:15'),
(246, 202, 336, 539, 1, 'Ordered', NULL, '2024-11-21 14:46:15', NULL, '2024-11-21 14:46:15'),
(247, 202, 334, 534, 1, 'Ordered', NULL, '2024-11-21 15:21:17', NULL, '2024-11-21 15:21:17'),
(248, 202, 338, 544, 1, 'Ordered', NULL, '2024-11-21 15:21:25', NULL, '2024-11-21 15:21:25'),
(249, 202, 334, 534, 1, 'Ordered', NULL, '2024-11-21 15:22:37', NULL, '2024-11-21 15:22:37'),
(250, 228, 348, 585, 1, 'Ordered', NULL, '2024-11-21 16:11:06', NULL, '2024-11-21 16:11:06'),
(251, 202, 334, 534, 2, 'incart', NULL, '2024-11-21 16:54:01', NULL, '2024-11-21 16:54:01'),
(252, 230, 348, 585, 1, 'Ordered', NULL, '2024-11-21 16:59:24', NULL, '2024-11-21 16:59:24'),
(253, 230, 349, 590, 1, 'Ordered', NULL, '2024-11-21 17:03:19', NULL, '2024-11-21 17:03:19'),
(254, 230, 348, 585, 2, 'Ordered', NULL, '2024-11-21 17:06:22', NULL, '2024-11-21 17:06:22'),
(255, 230, 349, 590, 1, 'Ordered', NULL, '2024-11-21 17:39:17', NULL, '2024-11-21 17:39:17'),
(256, 230, 348, 587, 1, 'Ordered', NULL, '2024-11-21 19:10:20', NULL, '2024-11-21 19:10:20'),
(257, 230, 349, 592, 1, 'incart', NULL, '2024-11-21 19:14:15', NULL, '2024-11-21 19:14:15'),
(258, 227, 351, 600, 2, 'Ordered', NULL, '2024-11-22 10:38:11', NULL, '2024-11-22 10:38:11'),
(261, 227, 356, 628, 4, 'Ordered', NULL, '2024-11-22 10:41:40', NULL, '2024-11-22 10:41:40'),
(262, 227, 359, 638, 1, 'Ordered', NULL, '2024-11-22 10:42:28', NULL, '2024-11-22 10:42:28'),
(265, 227, 348, 585, 1, 'Ordered', NULL, '2024-11-22 18:00:59', NULL, '2024-11-22 18:00:59'),
(267, 227, 359, 637, 1, 'Ordered', NULL, '2024-11-22 18:03:18', NULL, '2024-11-22 18:03:18'),
(280, 227, 348, 585, 2, 'Ordered', NULL, '2024-11-23 11:05:02', NULL, '2024-11-23 11:05:02'),
(281, 227, 348, 585, 1, 'Ordered', NULL, '2024-11-23 11:19:40', NULL, '2024-11-23 11:19:40'),
(282, 227, 360, 639, 234, 'Ordered', NULL, '2024-11-23 11:39:33', NULL, '2024-11-23 11:39:33'),
(288, 227, 348, 585, 1, 'Ordered', NULL, '2024-11-23 14:09:22', NULL, '2024-11-23 14:09:22'),
(289, 227, 348, 588, 1, 'Ordered', NULL, '2024-11-23 14:09:52', NULL, '2024-11-23 14:09:52'),
(290, 227, 354, 615, 1, 'Ordered', NULL, '2024-11-23 14:12:38', NULL, '2024-11-23 14:12:38'),
(291, 227, 348, 585, 1, 'Ordered', NULL, '2024-11-23 14:13:59', NULL, '2024-11-23 14:13:59'),
(292, 227, 351, 600, 99, 'Ordered', NULL, '2024-11-23 15:18:44', NULL, '2024-11-23 15:18:44'),
(293, 227, 348, 585, 1, 'Ordered', NULL, '2024-11-23 15:30:47', NULL, '2024-11-23 15:30:47'),
(294, 227, 348, 585, 1, 'Ordered', NULL, '2024-11-23 15:32:27', NULL, '2024-11-23 15:32:27'),
(300, 205, 329, 493, 1, 'Ordered', NULL, '2024-11-26 15:26:07', NULL, '2024-11-26 15:26:07'),
(301, 205, 329, 493, 1, 'Ordered', NULL, '2024-11-26 15:37:42', NULL, '2024-11-26 15:37:42'),
(302, 205, 329, 493, 1, 'Ordered', NULL, '2024-11-26 18:10:34', NULL, '2024-11-26 18:10:34'),
(303, 205, 329, 493, 1, 'Ordered', NULL, '2024-11-26 18:24:55', NULL, '2024-11-26 18:24:55'),
(304, 205, 331, 503, 1, 'Ordered', NULL, '2024-11-26 18:31:12', NULL, '2024-11-26 18:31:12'),
(305, 205, 329, 493, 1, 'Ordered', NULL, '2024-11-26 18:32:19', NULL, '2024-11-26 18:32:19'),
(306, 205, 329, 493, 1, 'Ordered', NULL, '2024-11-26 18:46:22', NULL, '2024-11-26 18:46:22'),
(307, 205, 329, 493, 1, 'Ordered', NULL, '2024-11-26 18:47:58', NULL, '2024-11-26 18:47:58'),
(308, 205, 329, 493, 1, 'Ordered', NULL, '2024-11-26 18:50:40', NULL, '2024-11-26 18:50:40'),
(309, 205, 354, 615, 1, 'Ordered', NULL, '2024-11-26 18:54:33', NULL, '2024-11-26 18:54:33'),
(310, 205, 329, 493, 1, 'Ordered', NULL, '2024-11-27 10:27:25', NULL, '2024-11-27 10:27:25'),
(311, 205, 329, 493, 11, 'Ordered', NULL, '2024-11-27 10:46:56', NULL, '2024-11-27 10:46:56'),
(312, 205, 329, 493, 2, 'Ordered', NULL, '2024-11-27 12:56:12', NULL, '2024-11-27 12:56:12'),
(313, 205, 329, 493, 20, 'Ordered', NULL, '2024-11-27 13:35:23', NULL, '2024-11-27 13:35:23'),
(316, 205, 329, 493, 7, 'Ordered', NULL, '2024-11-27 16:01:33', NULL, '2024-11-27 16:01:33'),
(317, 205, 329, 493, 3, 'Ordered', NULL, '2024-11-27 16:02:13', NULL, '2024-11-27 16:02:13'),
(318, 205, 332, 516, 2, 'Ordered', NULL, '2024-11-27 16:02:25', NULL, '2024-11-27 16:02:25'),
(319, 205, 346, 579, 4, 'Ordered', NULL, '2024-11-27 16:02:37', NULL, '2024-11-27 16:02:37'),
(320, 227, 354, 615, 8, 'Ordered', NULL, '2024-11-27 16:06:14', NULL, '2024-11-27 16:06:14'),
(321, 205, 332, 516, 2, 'Ordered', NULL, '2024-11-27 16:09:56', NULL, '2024-11-27 16:09:56'),
(323, 205, 329, 493, 6, 'Ordered', NULL, '2024-11-27 16:11:52', NULL, '2024-11-27 16:11:52'),
(324, 205, 329, 493, 5, 'Ordered', NULL, '2024-11-27 16:16:52', NULL, '2024-11-27 16:16:52'),
(325, 228, 348, 585, 1, 'incart', NULL, '2024-11-27 17:33:11', NULL, '2024-11-27 17:33:11'),
(326, 227, 348, 585, 2, 'Ordered', NULL, '2024-11-27 17:37:18', NULL, '2024-11-27 17:37:18'),
(327, 227, 348, 585, 2, 'Ordered', NULL, '2024-11-27 17:39:27', NULL, '2024-11-27 17:39:27'),
(328, 227, 354, 615, 2, 'Ordered', NULL, '2024-11-27 17:51:18', NULL, '2024-11-27 17:51:18'),
(329, 227, 348, 585, 1, 'Ordered', NULL, '2024-11-27 17:56:24', NULL, '2024-11-27 17:56:24'),
(331, 227, 354, 615, 1, 'incart', NULL, '2024-11-27 18:06:25', NULL, '2024-11-27 18:06:25');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(1, 'Shirt'),
(2, 'Pant'),
(3, 'saree'),
(4, 't shirt');

-- --------------------------------------------------------

--
-- Table structure for table `color`
--

CREATE TABLE `color` (
  `id` int NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `color`
--

INSERT INTO `color` (`id`, `name`) VALUES
(1, 'Blue'),
(9, 'Black'),
(10, 'Green'),
(11, 'Yellow'),
(12, 'Pink'),
(13, 'Grey'),
(14, 'Brown'),
(15, 'White'),
(16, 'Red'),
(17, 'Lavendar');

-- --------------------------------------------------------

--
-- Table structure for table `daily_reset_counter`
--

CREATE TABLE `daily_reset_counter` (
  `counter_date` date NOT NULL,
  `counter_value` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `daily_reset_counter`
--

INSERT INTO `daily_reset_counter` (`counter_date`, `counter_value`) VALUES
('2024-06-28', 11),
('2024-06-30', 2),
('2024-07-01', 4),
('2024-07-10', 1),
('2024-07-11', 1),
('2024-08-29', 3),
('2024-09-02', 1),
('2024-09-04', 1),
('2024-09-06', 7),
('2024-09-07', 2),
('2024-09-27', 3),
('2024-11-07', 1),
('2024-11-08', 10),
('2024-11-11', 18),
('2024-11-12', 18),
('2024-11-13', 33),
('2024-11-14', 11),
('2024-11-15', 19),
('2024-11-18', 9),
('2024-11-19', 7),
('2024-11-20', 10),
('2024-11-21', 21),
('2024-11-22', 6),
('2024-11-23', 10),
('2024-11-25', 6),
('2024-11-26', 13),
('2024-11-27', 54);

-- --------------------------------------------------------

--
-- Table structure for table `gender`
--

CREATE TABLE `gender` (
  `id` int NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `gender`
--

INSERT INTO `gender` (`id`, `name`) VALUES
(1, 'Male'),
(5, 'Female');

-- --------------------------------------------------------

--
-- Table structure for table `grade`
--

CREATE TABLE `grade` (
  `id` int NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `grade`
--

INSERT INTO `grade` (`id`, `name`) VALUES
(1, 'grade 1'),
(2, 'grade 2'),
(3, 'grade 3'),
(5, 'grade 4');

-- --------------------------------------------------------

--
-- Table structure for table `gst`
--

CREATE TABLE `gst` (
  `id` bigint NOT NULL,
  `name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cgst` int DEFAULT '0',
  `sgst` int DEFAULT '0',
  `igst` int DEFAULT '0',
  `status` int DEFAULT '1',
  `createdby` bigint DEFAULT NULL,
  `createdon` datetime DEFAULT CURRENT_TIMESTAMP,
  `lastmodifiedby` bigint DEFAULT NULL,
  `lastmodifiedon` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `gst`
--

INSERT INTO `gst` (`id`, `name`, `cgst`, `sgst`, `igst`, `status`, `createdby`, `createdon`, `lastmodifiedby`, `lastmodifiedon`) VALUES
(1, 'No Tax', 0, 0, 0, 1, 2, '2024-10-16 11:27:14', NULL, '2024-11-11 11:51:32'),
(2, 'GST 12%', 6, 6, 0, 1, 2, '2024-10-16 11:27:14', NULL, '2024-11-27 13:18:43'),
(3, 'Zee School Tax', 6, 6, 12, 1, 2, '2024-10-16 11:27:14', NULL, '2024-11-27 13:19:26'),
(5, '23 %', 0, 0, 0, 1, 0, '2024-11-29 17:07:50', 0, '2024-11-29 17:07:50'),
(6, '33 %', 0, 0, 0, 1, 0, '2024-11-29 17:09:06', 0, '2024-11-29 17:09:06'),
(7, 'GST 5%', 0, 0, 0, 1, 0, '2024-11-29 17:12:19', 0, '2024-11-29 17:12:19'),
(9, '77', 0, 0, 0, 1, 0, '2024-11-29 17:17:01', 0, '2024-11-29 17:23:30');

-- --------------------------------------------------------

--
-- Table structure for table `masters`
--

CREATE TABLE `masters` (
  `masterid` bigint NOT NULL,
  `mastername` varchar(255) NOT NULL,
  `category` int NOT NULL,
  `status` int NOT NULL,
  `addmaster` int NOT NULL,
  `view` int NOT NULL,
  `image` longblob,
  `createdon` datetime NOT NULL DEFAULT (convert_tz(now(),_utf8mb4'+00:00',_utf8mb4'+05:30')),
  `createdby` bigint NOT NULL,
  `lastmodifiedby` varchar(255) NOT NULL,
  `lastmodifieddate` datetime DEFAULT (convert_tz(now(),_utf8mb4'+00:00',_utf8mb4'+05:30'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `masters`
--

INSERT INTO `masters` (`masterid`, `mastername`, `category`, `status`, `addmaster`, `view`, `image`, `createdon`, `createdby`, `lastmodifiedby`, `lastmodifieddate`) VALUES
(96, 'leg length', 94, 1, 0, 0, NULL, '2024-01-12 08:44:41', 21, 'defaultValue', NULL),
(98, 'Color', 9998, 1, 0, 0, NULL, '2024-01-19 04:34:35', 21, '116', '2024-04-02 11:14:47'),
(99, 'Size', 9998, 1, 0, 0, NULL, '2024-01-19 04:37:10', 21, '105', '2024-03-29 05:29:15'),
(103, 'Gender', 9998, 1, 0, 0, NULL, '2024-01-24 11:45:25', 45, '85', '2024-03-26 16:46:57'),
(113, 'Location', 9998, 1, 0, 0, NULL, '2024-02-26 09:47:08', 44, 'defaultValue', NULL),
(135, 'Brands', 9998, 1, 0, 0, NULL, '2024-03-23 11:36:12', 85, 'defaultValue', NULL),
(136, 'Price', 9998, 1, 0, 0, NULL, '2024-03-23 11:36:53', 85, '116', '2024-04-03 13:32:48'),
(137, 'Style type', 94, 1, 0, 0, NULL, '2024-03-26 16:40:16', 85, '85', '2024-03-26 17:01:12'),
(140, 'Waistrise', 94, 1, 0, 0, NULL, '2024-03-26 17:04:39', 85, 'defaultValue', NULL),
(141, 'Fabric', 94, 1, 0, 0, NULL, '2024-03-26 17:06:00', 85, 'defaultValue', NULL),
(182, 'Gst', 9998, 1, 0, 0, NULL, '2024-09-03 05:57:23', 126, 'defaultValue', NULL);
INSERT INTO `masters` (`masterid`, `mastername`, `category`, `status`, `addmaster`, `view`, `image`, `createdon`, `createdby`, `lastmodifiedby`, `lastmodifieddate`) VALUES
(185, 'Shirt', 0, 1, 0, 0, 0xffd8ffe000104a46494600010101004800480000ffe201d84943435f50524f46494c45000101000001c800000000043000006d6e74725247422058595a2007e00001000100000000000061637370000000000000000000000000000000000000000000000000000000010000f6d6000100000000d32d0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000964657363000000f0000000247258595a00000114000000146758595a00000128000000146258595a0000013c00000014777470740000015000000014725452430000016400000028675452430000016400000028625452430000016400000028637072740000018c0000003c6d6c756300000000000000010000000c656e5553000000080000001c007300520047004258595a200000000000006fa2000038f50000039058595a2000000000000062990000b785000018da58595a2000000000000024a000000f840000b6cf58595a20000000000000f6d6000100000000d32d706172610000000000040000000266660000f2a700000d59000013d000000a5b00000000000000006d6c756300000000000000010000000c656e5553000000200000001c0047006f006f0067006c006500200049006e0063002e00200032003000310036ffdb0043000a07070807060a0808080b0a0a0b0e18100e0d0d0e1d15161118231f2524221f2221262b372f26293429212230413134393b3e3e3e252e4449433c48373d3e3bffdb0043010a0b0b0e0d0e1c10101c3b2822283b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3bffc000110801e001e003012200021101031101ffc4001c0001000203010101000000000000000000000506030407020108ffc4004910000104010204030605010505070109000100020311040521061231411351611422718191a10732b1c1d123154252e1f024336282f143537292a2b2c2631617252635557394d2ffc400190101010101010100000000000000000000000201030405ffc40023110101000202030003010101010000000000010211213103124122325113614271ffda000c03010002110311003f00ecc88880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088a1b8a7567691a34b344e02520869bfcbb755b26eea32dd22b8a3f11f45e197ba0773e5e537ac5110034f9177f16a8b93f8dfab39e7d9348c5633b789cef3f621730d4b50933f3e598b8f2971228f5588caf2c0081cc77df7d9779863f59bae9f1fe376bf603b4ac1779f2b241ff00c94c627e2dea593131dfd90c0e2db7531d43eeb8cb5eee625ad02cdf4535a465e401cad8633fd32058f52aa618df8cdd759ffef2b5774cc0cd2236c6e6924bdae06c7cd61978ff005dc8730430c31733a872069b15ea4eea87cd9d2e5b6847080c27dd00f514bcb9d3c504026ca73bc390ec4d022be2b7fcf19f13ed56ad438db8bdc1cd195898ecdeacd3cfd00537c27c719cf8226ea4e6e4b49a91ccb25bbd583dc03b1b5c933738473c7e1ca4021cc7007ced6d7056a71e0f126245249fd3924311b76dcafdbec68fd52e38f5a6eef6fd2d1c8c9636c91bc3d8e16d734d8217a5ca9bc5f97c23af98256bb2302669261e616c20ee5b7debb7434ba4e95ab616b5811e6e04ed96178ea3ab4f911d8fa2f3e58dc572cadc44450d11110111101111011110111101111011110111101111011110111101111011110111101111011110111101111011110111101111011639a78a0617cb2358d1dc951395c4f87010236ba6f3adbf55531b7a65b2269797bdb1b0bdee0d6b459738d00152327f129b84d7fb4e9945848b1355d7c5aa91c49c7b9dc4a71b0607b618b2a66c618cedcc40b27bf5553c596f967b476276b180307db19931be2736d841fcfe54b9e71a6a7e3e933c8ee70e75924b081d0a97cae4c68638223e11600d6b58ce778000000ec36aeaaafc5ed77ff67b2ace4df8668bc83bd15df0c263cb9db6b97bbd8d9182e88175753b5ad291ec0e258d207c578707136493f142d3496d5c7a6bec802c2dfc191ec2395c476d875fb28e61a2149e248c2f68a37df75c6f92ce9724a94391349235b13dece601a4b9e7f66af99182d0c3e36731e6eeac9fdff65ea095ad7f3900002f72b601f68c96b4b0915b9ad87a959fed7ec57f9c45bb4989ce0492e6916080403f60a6b46c2c6c5cb63844d6b9ae6b9a6813b15f326407566e2824363879e874249dbec3eeb2e9d207e496106c034bd3e3b32c65d386735751b7f8859059adc4e0e8f624817b8b1dd47687c4da96859666d3720c5ce2a46821cd3ff29eb4b73f104dea70d39a2858a6fa79f755b07768018f3606e282ab3735591d63857f161d96d18fadc0d12c64b24961154477e5ee3e0ba462e5419b8ecc8c695b2c4f16d7b4d82bf30e348ec3d7da7a09a3693eb63f90ae6759cdd32164d85972c0e713cdc8f2de6af3f35c2f8b7faafdb4ee28b95e9bf8b39620f072b0a3c99c8f7246bb93e6e001dbe8b6b03f10f528b21f3ea0237e3b8ed1720696ff00e123cbd6d73ff2c9bed1d29168e95ac616b38a3230e5e607ab1db39bf11d96f2e6a111101111011110111101111011110111101111011110111101111011110111101111011110111101111011799246451ba491c1ac68b2e26800a9bacf1cb62262c1f777a0f70b71f80558e372bc32d93b58358e20c1d1a3febbf9e53d2369dfe7e4a899dc759d9929f0e6f021ba022dbefd557f53c8c8d41ee2e12812592e364df75072e472bcc6d2072fba493547b2f561e2c676e572b575935f932f77bdd239a28b8bad636e4ba864643a9a053403d7d144e911c9233c511bdc1c2892287d4d05f751c96b8985d9ac610368f1e332c87a761d3e842be13a57f8ab3a5c9328140b5dca40edb6df51fba8ae1b8df99c4ba5e2f3572e435c4f5d9a4b8fd82907881ce9e56e0c92991bce0e53c0142c5d0077baec165e1115c5b2c8ec7843a1c695ecf081001a02fe84fd54e5bab9351d7279187239180003734156b8aded934ac9613d5a40fa2db198f324b24925017406cab7aa6409fc461909bb35beeba4c51be5cc0fbb60f50697cb5ef358639891d1f7f51b15ad6571b96ae9d67f59a3dfaadec62d177d6b62b4228e423dd692b6628e78c125a011b104d1fd179f297b7496266391b191405f4249b2b661ca77b53628c17c8456fdbe3e8a140cfb611111ce7dd25c45fcd4a60606a92e588b19d189e406cb5a5e6317d5c4ec0f90dcae731b6e95ed276c66731f14ccd2fe6b01a4f9501b7eaa4348323b88608b948e7940208ecb771781ce2677b44da8191c4d9b66e49ef76a521d1e1c4d4c67195c4444168000b2456ff55eef1cf5c755e6ceeeed0dc7337b46b6d6462c834005a38d8d1630699a4687136413d16b6a99a1fa9c930366c91bf45e31193e64f6c69756fb8d82b67c66d6dd145369d94411cf0bdbb0bdc38d1e9eaa55d2e3e662471e3e40360bbde1566cdfadf4eca238958e8b0b4b321b204cdfa3c1fdd63d3a7600d8e4687543b5f6277518de6c57c4de8ba639b2096663c3a73cac7b47300c17641ed747af9053134706448d823371802b7e814562e4e463184634a58e0c0ca22c0142c01dba762b7337598719e1d9b1503b17b37dced67babb2c4d6d49953e9f3c6fc699f039967c569ae503bab2693f8aae8a46c3ace2174640a9e11ef7c4b7a1f92a7cb2479d1b44390c9a320120904d76163ebb851f9b11f10020c609ab2361f3e9f7519638e5daa5b1df74cd6b4cd66232e9d9b16434750d3ef0f883b8f9ade5f9db19d998592c9b0a6747230d8923716b9be97f05d03877f12df196e36bc399bb06e531bb8ff00c40751ea37f45c33f159d2e651d251798e464d1b6489ed7b1e016b9a6c107b82bd2e2a1111011110111101111011110111101111011110111101111011110111101111011110147ea7ae6069000ca9a9e5bcc236eeeaf3f41f1f22bc710eb78fc3da34fa8e46e2314c6ff89dd82e3d36a191979fe26a1339fa86408cf5a0c2f249fa3406fc2fccae9861ec9cb2d2d536b399ae67653e67f8708c7698e269a01a493f53414331b14139739e1cf02f98900341dc127a797aac706683230b79817c24963186c9bba04f6167735d1787623f27030a73ca22964b2d69243403b0bee6c59276e943b9f563ac788e5cfd686abafc032462e363fb54ae06405f6c8c50ea0753f42abd2eafa8095ce60c48b9b6351d745bdc4719c7e32c7e5000b6b0d1ec451bfaad6d47462ccd6c418794100efb1ecb64fb553513da360bb3f1a3cad472e4c907a440f2300bf21d7a77b5219f9d1e1e0650c68990b5a2872802fe8b7b0b01b81a146f2da019436554d6726f4e746db26471bf80ff00aa7c4fd55bfb4e538e23276f0837af99254ff0c58d7f36468dfd865237eb45aab50e24b34e2268dc72f5578d034c743ad96970267c5963a1bd12db1fa29e75ca9231cf6c9e3db99a77df72a3321e44a4804ed4294b33c2c7cb8f1c9372461e401bd903b949b103aea290f63561779621cd352c7709276b811cafe603d085831db1f84d7068b3d4f7568e22d38c52c6f6c4e6078e4249ee3a7755507c2718cd816687905c33925dae5dc660e21e3d0ab3e269b8fa8e346246d38d0e60688beeaa4241cd7befbecacfa34fccc682d2455d51edf049ab3553773948e3f0b3e3cb70c9cc020828800104b762772686c7a8fb2b4364c2c79c45098d8d2c0406ec056c7f451be3456d706c972434088c9ec7cfe4be3b31ce1138bdeca8c825d206f61fe6a66325dc6db6f6dacece8012ee6140f527c96aea531669cc731a4b490e73afa591ebbad19257644cd82378797b83456482689dcd2cdc4d01662c6d6c6c07c40d8c5d906c007cbbf65d2314983124cdcda009b34685fc95a7d872f0f1431901858455be812a7b0707078774f6b9cc6c9955b922c83dd4165ea191a86a5132ec120d760822389b0e76685892c8dbf0f21ece6e6b3ef006aaba6ca231891961bb8a01bd2fa0015d38a319eee1a9f9f6743951b8806f622af755189fe1e546e1ff00787f501739dd57c58f058e927ddc76daa97ce25d3e4934e91cd6b8f2107a1eca6b49239c11d49dfeaa67528dafd3a4077e6ab1d7baeb6a7eb9be99089e2f10b8b4b76b06949197321a11c86517439c5ee7d7aac580ff0061d41f8c68b49b04856e66247970464b1849363659b9f5b6a12076349718ff0067901ab22da7f6fd1666e287486499a180921808d8d7536beeab82cc5c8608fdd8effa9dec5eeb19ca9b11d331f199b0d81a0007de1cc6f6f3edb1f914d8b4f0af12c9a1ce609dce7e0bddbb6ffdd7a8fdc2e998f910e5c0c9f1e56cb1482daf61b042e0d3cedf66f121979e37921a7fc46f70475045fd7aed6ac3f863c49362eaf26993bcbb0f26bc3713b324ed5e87617df62bcfe4c277178df95d751117058888808888088880888808888088880888808888088880888808888088880be1342cafaaabc61c40313065c5c6786cb5ef9758f90558e372ba8cb75109c6b2b78833598b8f2f898d036e403a5dd93f4a5cc1da83b3b8ddeeba6b79c803b53080aefa6ced6e85a9e4b9d7239a197f1eab9c68c09e28c87d9b647211f4afdd7af5eb8c91ca737756bd05f166627bc5e7c399d0ca06c4d9b049f2fcbb74eaad4f8c1d0b131e2680219b9280a03deb02be042e67a1ea1e16b3958e688ca040b34011746fce893f25d0b869ced5f1a50e73df4f63f9192002ec83d37ab0b36daaaf17b6b8a79a8011b99b795529acfc6f68cb81ec00d804efd156f8acb5badc85d1c60f8801e57b89f9952cccda3116387a06ca09143d42b95953dc459a23d2a2c78ddb7281b2a0654a4b1e09ec694bea995318e06734df92cdf29efe615673a67d16f33f706ee827c646ce0444c92cb5b06355d38724275763880394ba8017fdc3fcaaa3627c5a7e410f00d306f20fe159f85a20dce69f118498dce27c427fba7d14eda9264d217624a23279a16ef43c96ec9ed52b766866e3aed4be63623e4d2f05b0b242e642d04d1da874dc0efeabce7e7e9ba600ed53508e0048a61773b8ed7d06dfaa6e699ae509aee286c479e9f20b70005d51bb2550b88317c23ed0c6002e8d74dc9fdc1fa8562d6f8e34a91e5b8787265383683a734c6ed5d3bfd028ad39c35c89e23859ed05e43e160a05a770403b6c762b2e532e15259caae26703b50f9294d3751ca8eb926200d8501b7d96ce6f0c64349741154837315d837d394f7f81fba8cc68e4865747234b1ed345ae1441f5054e32cbcaad962d4ccfcb76244f7ceebe5237037b1f051ffda197ce1ed9de088db42e80b59a6788b0e0f785d0009f5056ce8c20d163c5d5f3b1bdaa4a0f640e6db5acba0f20f5268903a6d67b2eb78e22226f8774ace8b972326494cf3d7871bac96b01b2e23b58040f21bf75f35e965c9d4707163700f9262e01d272801a49bba35b81bfaac59dc71163ea12cb891cb2e49b0e73c823b0dabd150f53cecbd4731d959321323ba0e800f20145ba9b91b26eaf39e33002d7e9d94e6d91cf0e487dd79002fafa2c1a71c112b65f132e1941aa796ddfcc2a5636a59f8ee062cb9994280e6247d0ecac589c55aa42c8c4ac8721a0580f6904ed5d47f0b265b2e2b165490e6636a18625c87c9263b5ede70d2011cc46c05f50a86f9006c6e6b81f7c9dc11dd5859c6b90324b9ba7e382e6061a3d3aefd3d5414d116c4c01c480eadc7aad87c5bb45d45c18db7420df52f2ac1939924988e02586a81a0d2555387839f4048451ec00fd95b9f0b8e201ed1351aee07ecad0a36a3316ea2d7874648a24d11dd5c748ce7be385be131e2c0da40aa9a9c779ad6f8921dc01601bdd5b74cc43188487b08bb3cd183d12b6f4c9ad3237b64058f89c058b1b1f9a8671f69d0a30cddc643192059d8d035de81fb29ed5f19c70e7059ca5cc3bc6491d36b07f654ed3b39f068d0b1ed36d90bc9045935d28fc965e211250680e94ba512110902da2acb46c00f526c13d681f35834bc98ddafea188ef71d196be30d1b9200040fa0562d1b2e3974c9399c5ac320823377cc436cd7cc91f2540c6ce38dc6524801a33169f323a55f60b1afd1bc3faa0d5f45832ced216f2ca3b878ebfcfcd492e79c2ba9b745d40e3cce071f2881605061ec7e1bae86bc99e3eb74eb2ee0888a5a2222022220222202222022220222202222022220222202222022220c19b30c7c2965e60d2d69a24f7ecb92f1566991ae2f77896772f77357cfa8fbabaf13eb9016fb3c3292d68b7902c13d9725e22cef1a76b41045f50762bd5e2c75375c72bbadac5c87e2f0b653de5dcb3cc5adb3741a28fdc9dfd15734088c9c51231bb99217803ccd053dad40f8747d3f10b480210e24f724d90a2344031b8930e6e6d8bb96c8ad88aa3ebd975bcb2544cc5da7ebf14c2c164e09ad8d03b8fd5769e1981b0666572d80f1cdf607f52572de35d3cc1ad99e36fbae7072e8fa66b2048e3073389c4049e40d16476bb3d946adb5b6f0a0f15381d5dbb6c5d767ba99c76b64c28dcf0d3b1ab174a97abea6f9f502e787120efb83dfe1e8a6a1d75acc26b038b4b477658fb157215b79f1c658c258dd9806c02abe5f2f8fb35bf452f97aab0e3464b81b6d8f74855cc9cc0f94b8591f0afdd32ba8c8bb786d3853811b07b8d3b01e4ad3a5c4e8c31cdf7498cb41037dc116a938ba9b9f0b80121fe9007dd03f9f356c83537c7034d11b0a05c07e816485ac9c478b930f0acef8f51ca12b00a79988db615b52e47331ce7b9cf717b8f571364fcd757d672e5c8d1a48490c6c8db200b2771d49b2b9567874590e613601ee16658ea72ac6b58b57bc69e7c4944b8d2ba278d8169a588babb05e4486fa1faae378ae9a5931f8bb2e37933343dc4005dd7a7c579ce91bad4e32f15dfed0d653e1229cf00ec5a7b9adabaedb5a806badc2cfd949e9f8c26940e600dd820d104770ba636ded364892d2f10eab20121e4c6c6a92679354c16081ea6e87aefd02dfd5b2df971643dfb0f10318c1b00000001e8050f92c59b92dc1c2c58011cf213913beab9dce3601aea00036e9b9f350f959cf970c583fef9c7ad75b3d02e9389ba8bcdd4638226d9b207c765a990d68029c08f42bd4333e8d50dba81fcad492479ae6713bf9a8b7515272f719683beca5818c442acedd81506d26fa9faade6173e8127a799598de1b946cc11b4ca3dd71b78ecb6b259707372380120ea0790f22b561840209dede1679210315c6ae9e3b7a05725426787a60c70043eafb02adb2e635b036db2511d40f45ceb0185b3f28db7539940fb3466ea89eeae466b96b65e4c6ed66305d401b3cc08fd55ef10b0e1095a58795a0020ae4b34b27f6a308738106ac12ba062e5e40d18832120f67006c529936dbc2c534cdc9c37117b037bae7396e8e29c90c706b1c492c340d1b163e4a4f075d7633a48a405b19166858fa1fd8aafeaf916d9b979288bb008249bdba7929cb8848bc694f1070c60b9c40926b949f2e724924fadd0f3542d583b1b88f21c36224e61f4055df4a2dcbe1681ae6db991b1ccdeec8aa27d474ae815338b8726b3e20ffb48c38fc771fb27525277a5f65cc649a44338a2fe40492680dbb95d43853561acf0fe3e4f3733da3c390d771fe54b8568792733486b1eebf04d017b0574fc3dd78e9bab370667d63e53bc3b3fdd7ff74fedf353e5c378ee371baba75a4445e47511110111101111011110111101111011110111101111011110155b8bf556c509c566e19ef3c8f3ecdfdd58b3325b898924ee35ca36f53d9731d6b503912bacf3b89b71ee4aefe1c3daedcf3ba9a55355c92d79787961bb241ab3f155bc1926d638871f12897644c2327bd13449f95a95e2195b1c6f0ddacd0076b5a9c05193c4cdc8e50e18f13e437d8d50fd7ecbd39df88c7feadbc5e049388c7e520815daba2ac60c45f9403da0b9a6c81dfc8853daee40c9c80d3dac8f3f507d47dd6960e3874fce0805a2c1f2afe566991b3c48d195a583259918072b87f7c1e847cd496895ecdcde78c07d09fe56a6435b985a08e56c6776f7613b13f023603b1dd4969c0e261c91160e78e12d209baa206febbac34e4f9c2b364bece23eeb6f1819180513b0b37d963d699e1ead38d802e2765b183208f1dce3e6b677a5de9e7527800016001407928720b9f43b9a5259b2895e7957cc6c42f7b49aea0fdd329bac9c27f1e1732092da40000fbab04114b3be38d94050ef6a3e6e56e34a4558207dd4e70f912344846c0582aa4d269ac425b0117d0500365ce75e879331c6c7c9745d6e6d9c681360755cfb5c91af9ec7aeeb729b9c98ef68631b88fbaf22324d10b3b3df7b5be6696fcd82616364edb5ae170df31d6e5a6b61623a4948ad800b7a094c59a31bc3a7487c316288bd811e7baddd1a16bf20d81f945ab2e169f8efca85ce6d10e06ebc8dab985d768b973cab3c401b26a32b61dd90b8300e9400afd944ca2f11a3ce6791f2ff00aa97cf8f18493be9cf73e7701ce3d405139240c6c7a045c8f17dba84a46186120124ed5616b4ac03eaa70e27f48103a8515247bf6ea56e538d3656ab1bef296c4c669e5dac95a51436f374ac1831c71c6d26ac806d30c4b5f461801beed7be1669b19adc079a00f88165924606b6cec1c37af54c999a7025a20ff555a0c2c46fb58a68aabdca94ccc563a00daaab5aba7c8d2f0e04745b99b92c18e1bcc09bdfe8aa0a6e5c006a31916017807d15edb013a444d1b92dbe8a999a5ae918e045f30fd55f31646bb4bc7248af0c7e8b1b551d431a564a638db46421a281519ae42f8b15fcc7612720dcd90287ec55bf22484c91905a1de25ee77a07fc953f889eef6789a5c492798ef7b9b27f55c7c9d56e3795b784e6e7e1e69047346da249e8155f8bc0765c5200407348009dc0bdafea54bf0ac92c3a435ac17ce680e805f73e6a3b89b15d0c00bf721e49277dcf55567e3b6fd78e14c96b44b139d42aeafaa909b2648b2399a4c62eac751ebfbfc95734093c3d4d80f475856d9b4f7482c34b9db826a80298dde2cb39774e1ad4ceb1c3b859ce36f923024ffc63677dc1528b9e7e1665ba083234d964bbfea305ec0f435f115f45d0d78b29aba75977044452d111101111011110111101111011110111101111011179790237173b94006dde48287c63c41e24eec587fdcc161c7b972a4fb7094925a46c49dba1533c4582c6b9ec84f8801b241e52556e7c774303f6364014451faafa18498cd470bcddab7c43902590804100f5f5565e00c010e8d9ba9beae5788da7d1a2cfdcfd951f537bbdadcd36083545757e16c431701e0b5cd00ca0c95e7cce241fa52cb77936f114dd5f21fed4e91a496dee3cbfcd4af0cbe3c98a4c9c821a1879411b827d0773e8b5b5bd304b38635fcb1dd9774b3e43e0abfa8ea261708b16d90c42855827d56d645e1d9711cd8fc1a04389001b24f707d7f4eca4a48446325c363e0124df525c150b40cd73f2048f90b9c7a93dc7a2e93810c73e899790f692e70e404f4a041fd567fd1c87894fff0088f38e8e1fb95a0cca73610c048defaab07116144f6f33006b8388246fb03d54545a4c6f739a67941048da071ff5b57d54db65e15356356377351a24a91c690800f4dc750bd45a463b05be5ca22f62cc723f5056f6161e9ee95b198b324b241b21801fa0552dd32c6c6565b8e26400e0458edea3f9562d065f074df15ef03dda1d931b42d3f2e1b6614c448d2e21f924103a0bae84d2909445890371e3c7005530364367cbb5ad95962adad6697878607bc907716553f39ef32fbc08db7042e96ed3f0f34c8e99848d858c97017dc0a02fe2a225d0b4d329071011560fb53ff84b77386ce14485c44b1f5ea158b26df8479492689dd4c41c238f206c91e0c8f0fb03932c12d751236205ee077eeb7342d3866e1133b5a2816903cc583fa299750caaa7a165f879525efb50055b30b5277b406860d9ae36479349fe1428d1dfa7f1247180c2d9c902f616ad9268d910e1cf31e46ff45c051decd0fdd6ef8d32a8334b248f8ea0612e2e793e764ff0b473798e134b801c93b801e5767f65398fa53a4c9b9662c11c6050b27a0fe568e669fcba6407dea9725d4e236340f9f553be1b1290e33a7c46efb50f9a81c9c7f0e40cea6e8fa05d5387b43c566951c9247cee2defb81b7928e834b696097c5898d396f686080122984dd9f874a5572df1131cde10c0e36e6837b590a66105f13396cd802c0b0ade31a99eee5cb5e40300fb0476297dd4f90687fde11fa52b9c46daaacd0c8630046fbe61b721f3f82fb2c2e3a6ce4b5c5c24baadfe8a74c6d64843b232055ee26711d3e2b5a59892628f2f203ef71e25d7d426c6ae145e1b0036091744267f318c0076a3b9a5bbe1cfca2b3320bddb81cc06de7d364c69668e623db26746d152486a87a8db7f5f24dd15d300e40092401bd55ab1e841b93a7ba090480c147f291b1ff3056d4ed932002dcfc9800174c70b35dcd83b57d96ee899dffe6bc3c739b2ca0e981cf33bc1b2483b6c3c94dcac6f68d971a28de1d1bcb8b4d105be7b7eea9dc44c2722169681cf5b8157b0174bb1ea4626897c3c76c85edd8b1edea3e242e5fc4e04fae62070f0daf7120120d6f7db6eea32bb8458749c28e0c18db4000d0a1f881cccc6490b289adcfa8e8a62594ba111c76050143a950f36338ce080459a35e7d974bad693151d3dde0ea3139c3a3c136bab4a192e1c523000d7b45d74069730d5b1dd87a9bda5a4104102abaeeaf7a46a1ed1c385a4d720d893b923b00b9ce26957e56fe89a9bb49d6a2c88c39e58ff0079adee3b85d9e09a3c98239e1707c723439ae1dc15c1b4e2f9a5901683b821b7b0f895d6782b279b4b7e2b9c4f84ee666c0535dd87c0dfd572f2cfaac2fc59111179dd04444044440444404444044440444404444044440511af6a90e261bd85e798ec793723d0d6e3e8a5d73ee36d5a3932bd9985c5b09b7073bdd2eaf2ea3e4ba78f1de49caea217272064c865e66b9bb9041ea5694cf8a681e4d39a2c6f4a2f3b30b438827989176773f03dfe6b04da8f2e9dcb46cec76a7007cc797a85eb8e2a6eb2d1edb239b744defd9760c693d9b86f03163a6b863318d04f4f74595c92288e7eab1c3d7c590376f52baceaf86e8cb211d3c3f0c6f54d0373e97402c939db6f334ae674665797b9c463c6c2059b2e37dfd2f7f534a9fabc1cb0991ada01e2fe0ac39f9e649806ed034d0076d86d6a135599ae8a50d702d22b6e9615dd59c9386860641c32d91c69b60edd41f30bb0e14e31b829b2e472073e30e781b1b22fbfa10b88cd282f8c6f43a8b5d9b886576370be0e30f75d3461ce00f4245d7c850f92e52eee9b66b973bd5f20c913896ed44dd1144fa8527a472cd8904b40f8910e6aec46c7ed4a135260f143285005c476b5b9c3d9a71e5874d92373c3da246907761209af87c7cd2dd56ce92f9ac10c161c40036b2763d947e9e1c1e5eeb7124002b737d07cfa9f45b59f37b5b3c28246c801a3ca795e2bcc1dafe6b6f468639e51e24191ee8f75e23269c7a9d87c07cd5ee5644ce364c7838dfed3235adeb23dc40167a593f44ca91b234c85c288bb02c06f90f22563ced164d4312481e1ceb21ec73a370048361a4574db723d545e4e26661e93162085e1c092e0db21a2f6682689a000b2b25e74df8d0cad58b33408c9e468d81dc5263ea0d99e0902cee41fdbcd42e4c791ce5decaf07b5b87f2bde089a2984b3358003603a4157f016abda4e0d55d5f9a21c48803c8ee761046d5441fa285d1b5d971b372a20d63e274f21177b5b8f903e6b473f88418db192090e04f84491b1fd163e1dc364d2cae73412d90ee7af52a2ddb35c2575fcd79962ca1106ba295af6efd7cfa80adf95a8b32b437b830b4ba2041205751eaaabc478ec661369a472917bddf97e8ac7a547143811307f539e134395a00d81be9e896314a835e661e739ac8cbdb4c63de4ec09000efe87a05b5aeb43f42d36524730cb734d1bea0df61dc2f58ba6614d98ec89b08ba58a42d6dba838826ac0eb54b619a6cd9f3e858c5ac0249679df546a88ff00fd299b9daf8d2e9a7b9d1e8d1318430358399c459e9bd01fbd280d1f262c8c4cb8dee3eee7bcc3ce402f1c82c6db580e27e4ad3a8b62c2d25fced2f0050046df4e8a8782e8648311c7fa6d12654800154e05ad04d790246fe6abeed112795871c0f243a487606de0869b26a8f4fba889f56690228e7600490497816475037dd6e7b2e7e4b9d261e7bf14d80621bb4fa807b2c72e9bc40e9031f9d8d313ddf0ff00055cb608c7e6487fa6c1ccdff113d543e765e562e6473461e1ce7f281561dd36f8eea4b3467e97396e4e9d87213fde63392fe7baf1fdbb0471d3b47782761531009ff5e4b32bb8a9c27256f87188dee01c5a1d2bc7f70790fd3e2b1ba26900cac218c371b2aafc89fe3f751a3883186e7499886104ff00b41279bb7c48155e4be3b5c6ca091a2bdeeaeaf9891d3d52566920dc9712ee50e04fb8d35b071e837dafd160d0a6195f887ee86c91c51988770400b426cfd4b2e32218a1c214417016fae840342967fc3b800e27b73c5864a0927afe5dd4d97709269d232f4d74fb47044456e4802bea1725e336371f3b1e38d82331b4805a46e4103b7c1763d4350860c77812ee411b027f40b89f164de3e682497536c13d7727fc94e5bd18f6bd70d46353d123ca8f941aa909dc821659712104b982dc0d827cfe0a13f0b750e739da6b8ddc6256027b8346bea15832a68a0c973490f37640dc0f8ff0ae5dc659aaa371bc35a8c53551919bfcbfeab270c6486c7e1487dd76c77dfebd964e2c8ccc1b2907dd35bf974fe14269d9231e504ba802b35aaaee3a169d8e63e60d0036fafa79ab2f0ceb30e9da9c6d7bc863dfe1b9c48028fc7c8eea94dd543f1d8d8eb98b371563e27ccfa7d7c969992dcf7484d90372772aae1b9654cedfa2d14570c6a2756e1bc1cd7925ef880793d4b9beeb8fd4152abc0ee2222022220222202222022220222202222022220af711712b74a0e86117235b6e76c437fcd71ed435c6ea594e73a4365e5d6763d7b8fdd59b8c32a51859123bf34ee375dbb95cb9f39f10b438823a1ee0af6618cc7171b7753993723e38186c9a147bdafbaa86470784d04002b7f3ee41ecb474dce0325ae9c025a0916681db6dfb7e8b16a79c2524026ea883d42a66b978e156789c538409dbc604df7add76fd6b0239f4d9a420788e0180dd6dd4d7c971ee06c7f178861988b11924fd0aebbaee518f44632e89d8827704effa2ce770b5c9b5e0639431a3940e83c82ad65ce794b4826fafa2b76b6f8a43e1b9b67737dc2e85a17e1270ec9a662656a314f3e53e36be40652d04917542b659e4cb5158cdb86e95892e5ea503446e734cac6bc816002e037f2eaba271b6b2e766362e57011b28104103ede8ba3ea9a1e99a2e87918fa760c38f182c34c6ee4820d93d4fcd71ce2632499f273348a154b3c3372d33bcc8aee76739e4f5b200b2074563e1a631d959792f25a795b1820f4046e00f32aa594d20026fa2ba709c2063654cedcb0b6b6e87906ff75bde5aa5d6b845ea7885b9ae1cad006d18b3b8ec2fad859b498248ded7c79d930b1cea6f23ba1f220ed6b7b558d8e01ced88dc1ee0fa2d284c8c780d20123fa8c07778f4f23e6aec88956b822d41f8fb6b7960d9d806103e7caaa3c4189aa32727fb472266fa9afd2958b173c3e26c409a365a6aac791f51f75f32f19f3d122b6d879aaf59adb65ae76ec7c873c07bdc7e2495b38f81d1cebaec0ef6ac79ba4186e420077522beff0015a00168bad81a2b9c917bdbc4d1b4e138358d04027c80539c2b20c79f35ae6825925f4bea2fbfc557bc43217738f740d9bfe23fc294d2267373b25a2ae68239056c2f942dd729bd36b88b5a13432b48341c00b02ba1f2a52fa16b714cfc58b9982e170e8e076613e47c953b5364af8b21ce048001b036bba5b1c38249354c789868989f46ebfb852f1744935b5a345cb8063cb21744c0f9e52087836398f4badbd565c5d422872743922731c44d34649374083e567a80a1b0f122c7d3a273e26be67079f788a1b9dd617e77b3c5a3125c2b2657900501648d877ebd548b5716ebfe0e1ba36973dc760000d1fb9559e1e9659b1b1487115264b483b820f21adfced6be4439bace5be46b1fe18753090694c70e6952c104114ad01e72a41f23137f701559ad3274df82521cd732c11b349dcb7d0f9852f8ee6b5de24c7fa828381e811f830e246648da01365c0f577afc5473a476438063c8881a693dbcc1f3268fc3e2b76c64d4b123d5838bcf2471eec7577fe151f518a4c6c8736714f6ed5d7901e9b799ea17428dedf0438b4318ce91bfa0aee7d3cbcd57b5bc06e54826e8e06c02373ea4f99ede492fc6ab788799e1ae68000a0076ff003f32a5f1e30d208713636bf55a11c0e8c3ac5389360f50b771242c2013b01b1570db34b885e2c6c7b8f351dc3d2c9a76ba1cc90b3c4e76fbbd47e4eff35273e50700d6105b7ef11fa288c48c49a8b1eddc87c87637b533f94bf09d2d59d24ee89dcd2c84806bdf23f75cd3577be4c80d717121a3f3124f7f35d50e289a26c849a70b36b9c6b384e6f1237100b2e70007c495cfcbfaf0dc3b6d700c8fc2e2bc60ed9b3b1f19375d5a4fec15a32a3946a2e02fc2068bc8afa0fdd46c3a53f4de2dd19af8cb0196eeba8e8559f570d39b28342306cedb951e3e9b9f6ad715b238e1691d2461af90afd82a219097797aab67176599a0818dfcac71048efd36fb2a8b853be2995d5d3718b7684d76440c0091b116a4df1318f6822fa824ad4e146d607377b59b3e66b2536e00837d57a675117b754fc2eccf1744c9c326ce3cdcc3ff000b86df707eaaecb94fe1767319afcf8dcf427c7b68f373483fa12bab2f9fe59acebb4e84445cda2222022220222202222022220222202c593208b1659092035a4edd565515c4592ec6d35bcbd659033ad7627f65b8cddd32b9971abc331a38af626cae6995154ae20d0bb0af9c6d339ef8c91d45ec3c8aa3e4b83a4be83a9b5ef93e384ba60e67471104ee459f40a3a69dc5f40f75b93bc08c8277eaa37a9f89d94792eb523a63cf2e89f86d08932c56ce76c0f993d6bd40575e357b844d64649730f35dd13dbe17e87aaa5fe170275a1238d470b49af32450fd55db899ed3139eeaa236245a4ee22f6e6f0364cbd5e18a41666998c06a88b20743f1ec57e806db581a09000a02fc971ce08c1f6ee30c43e1dc703cccea26855d7dc85dbfd9233d49faae1e6bcc8e984e10dc4aeae1a79adcb9a09f9ae23ad0bcc738ef6772bb47194861d06589a6807368fced70ad4b29cec97f3106ced4bb7838c6a33ed0da8461b193e448fd558386734334ec90f701cd2026fb8000dbd7655fcf7974241ff103f55f3072443150be606c1ec0aaff00d96709fce9cc9273bac01f95be5ea5478c9fea513df637d0ac4fcb74b65c6c9ebbf5586216f0483d680015dbfc4c8b4e9c5d390d3649ab0075f220798efe615db0f0c330c3e401f2d0b35b0f87c55638771030b6491c6cd16f983e6ae25cc8b1cbdc4318c1648db96fbfc0f7536dd6a0ad6a90000c8f2055ed7b0f8aa967c7cdfd40c22271a046c5e7d3c82b7ea71bb25dcd334b58776c2762e3e67d143498e725c6cdb7a39c0761d8790f5584ba57991b9ef37b0aa711b0f805bd86e69d770c37f29c38c117e4288fb2f5950b715fca3f281636d946e0cc64d6b11cd046dcbb6d62cfed4b6dd58adee2d1ace0b19a3e5b801cc63bfa151bc35ca357c61b02d8e4276edc85486b45c312469b371bafa91d028ce1821daeb5db10cc4793bf43407ee997f489a760e2989a679de00e601ad340ee7e77d568676347243a447890807dae46175124ee6ac9bec0eca3a4d52b5011bf68e3a68796870b76e2ec93dfb29cc99863e9da4c8c92ab39eeb20003675ed5b289656eaa7b3a5834ac300005f5407aad4d2b3d98ec8b226a71e591e05efbbc34103bd069553d5b569b50cbe481c5e5c681eab73203f1b1f098e710e6e2b45dd757bef6577f8991687663b5096c1a8c5511bdfa0f35b2fc60d6090b072816e87a0aece3e7f0efb0eca0b41cc64723b9e8340aa22c301d8579deff00f45637c80b43893560817641f5f33fa2c11ef99ce7170b27b13b193d4fafa761f1dbcc81ae0013609b37f559b3636c5178aed9a772d1b11ea3f751a5cfe7043493d481b070f3083e6469e325c6468a7f5001d8a89cb63a00400411b1046e3d558fda628621203648b02bad28fca8865dc84ff52aeebaaa97fa2b266ab6b8edd2af62b36972b192c6e00d54a761e6583f64cbc5e49480394dd1f55ef0b1a52d25bd191ef567773dc687c803f3556f31b3a5bb072db369c1db80090ab870467718c53b232ff0b91f43b807aab0e9d83247a635ae0e17649a52df8738cd878cb31b200e77b15b091e4f009fbae7e5bf8d30ed93f10f4d8b1758d073226f23017923a9b1ca7f7558d6321f90f7c87661355dcfc4f97a057afc4b039f4a711b34cbbf97e4540ce8e59b15c1ada037b2b3c3faedb9f6a96b8e1246da6802f6f4a5052f5b1f1a53dac33c3819d6fc437f42a01e6fa7659e4ed58f4b970b4cd1a516823983883e8bcea31c865340fc4f75a5c08e326badc4d8b6669b07a020583faab46a38710c92d75bf7add74c72dc88b355b1c033bb0f8a74d95d45af77847fe605bfa90bb92e27a4c51e298266c5187446c1aee0d85daa37b658db230db5e0381f305797cd39daf0e9e91117158888808888088880888808888088880a178931a6c9c781b1025ad92ddf434a6969ea8f0cc226c5970af5dd563dc65e9cb78ab459a4818e7446c022c1bf35cfb3b4d9628f98c6f6816371dbb2eddacc7e361170de88236ba0551e78e3939e378045906c6c42f64ae2e5593259eab0002ebfd05bbad60bb4fd525c7ad83adbea0ee168036f00f9ae595e5d24e1d03825e707064949a748eb1f00149ebbc4ac388622e03985806c815e47a8f9dfc540e9392d6e9d5cc050bd942eab92726535b8a205f6d976ba936e726ebb97e1ef0cff0065e8cdd42503da339ad90ef7c8cea00f96e7e2ae5ed71f99fa2d6d1b261ccd0b0b22020c72e3b1cd23c8b42f146ba1fa2f0db6de5da4d4d46971262bb3b069a4723ddd4ed540ae23a9689278ce7000d3a8927d5774d55e19850b4b80e627a9aecb946a3230cee01cd3b9160df75e9f0db23965da95a86932331e770029a03b637e6a1795d1485a771d41f30af3974f8646db778c822d552289b90035d4248fddb3dc0e97fa7c95e5decc6f1a60009367bf6f3529a6c7e24ade60011b8056b8c7e43ef03cc0d51f35edb2885e08b06f603637e8aa162f1a438300b21a00ea763f15608e53901ae23dd1b46c3ff686bbdf41ff005555d09efc9601301ceca718ef600f424f92b6e0c0720026cc44573777d7603b37f558945e7633b2038b09119d8bbb93fe01e43c8a8c9a4644c2d68aa155f0ecacbabb808c8008005100751e407a2e79acea94f2d8dc48ddae23fbde441f2f32b61235759ce6c87c369b037242cbc1da77b7f10e2b5c4ec038d6ddaff7509338b89e626cedf2572fc381cdaac9945aca60a0493fb0596f2aea2d1c4fa4e3b34b9dd1f3021a40b3e8aa9c2b80fc6d75963c4f1b124036e9bb55c78a3299fd952b5e1a0990b453a8f4f50156f40cd89faee9ec841e60d9398bc76e426becb2ddc23c1d3192321c8934e63e560ae7e4b208e9b0eb47cd44eb714e744c26ba37b07b5c80122ac9e6f556e13db24124649f109a040d8d77b509ae061d1b0396320ff68bc6e41bd9f5d0a9e0959f44e1bc6831a39e5699321fb807a05a9c4718c6d46263ab687948a1bfbc7f9e9fb2b260ced85a3c52d1cad0036ecdfc02af710c73cd9032e40767b9a4551e4201040ea68daafa34b09c6122469a70e809b00771eb7dd58f0339a5ad6b9dee83b59fca7c8fa7aaaac13073f9438380d811b83eab6e395d1bf99b7b6d47a10baea58cd2e33ba3730976e4ef4543e572e34064759077681d5a7cc7a79ad766ad188c46f71240d85ee3c813e5eabebdc6620bdc49aec3ec3d1469ba470ca95f905f213cc77201d9c3cc29380f8b4e029b7b5f507d569498828b98d1e18dc807706fa8fe3badbc22d61124d235ac1403c1204a3c801dfee869b5fd9e2781f396802104b491649ec3eb4b6340c46470cbcb46e4e50eeb618032c7cc1517ab6bf24aff00ecfc36189c00a6f2d96ffc4f02e80ea01dc9aedd64b46fe8e34514729f0e301ad3cc4135d4f4ea7afcd66cbc45e2285b0e235b43616547e9ae8a2e34c1969ad739af8cbaab62dd87d405833350f0d8efeab8903bc847ea144e81992e5f1b69ec717b9be2134407014d3dc7f0b9d9f8ddb31ed7fe2dd263d4f482f2db9315de2b08f2ee3e9fa2e65a910039a050adfe0bb06a9b69399fff0003ff00f695c3b5bc977bed8efc8bbb0f4053c178d2b39caa5aec9e245cace8c7dfeaa0db1b9e40aabd94f4903a67ba33bd827a74519246237728ff00455e73776ac562e0085b1f11c37bba9dbfc8ab26aef0d9492e037e876557e1099d1f11e2386c0f3035dbdd2b3eada84af96421a1a4122c8b3f52b719fc4ded63c2cb88c0ef789dc1f75a4f5f92eadc21a8b751e1e85d64be03e0bec551155f6217e7ac29a59e27b5f23de6aa8935b2e91f843a918b55cdd35eff007678448c693dda6881f277d9479b1e36dc78aeb0888bc8e82222022220222202222022220222202ad714643c4d0c1e200c0398b79b977dfa9fd82b2aaaf130e5cf0eea7c315b74dcff000ba78ff64e5d2384866d3e467310400400681faaa0e79f0f35d6f7837b13201dfc82bde364b79e9e68386e0791ff00355ad7b0db1e697786d06eeeba2f4c7154b5fd37fb4710644243e7805101d65ccfe41fb2a4491ba290870208347e2ba762649195cb2101aeb14428fd6b84e399e64c568773592c1b11ea3cfe0a72c77d2e5d2a187a83a361617558a1e48e9849b9a07cd7b9f43ca88b8c6d32b5bd401b8f88eab4db0c974012937ad5571dc773fc1dce9b2f851f0cae2462e518e324d90d21aeaf912574d0b9d7e0de94fc4e0b7e4cc37cbc97cb1ed5ee801a0fccb49577f6a97cc7d17972ed511fae731c86015bdf5f805c8f5081e32642403b9eb5e7f05d77577b47b33dce6b5cf2eea6af65cc755af15ce6907724500bd3e2e9cb2ed5d31badc03437dc206e2c7d95632daec7cb2e6904f43eaadaf780e3cc46c1c49f92aaea2f0e9091bef7d15e538db31edb50e74793108a665480507d807d059d8fd964c7c61138c92381b3ef48d7021a3c80bbb3e754a3f06467300ebab17b12ac78f83a66511e218c1f534527315786e69206d2cc3c284025b8eeeb20f379ef7e5ff45d023cb860c3134cf6b19cbb6e36f415fb2a545a44a40661ea6031adbe596a41608f3deb7f352274ad621c76984e1643dad04734859cbb75028d7c884a835fd4bc48c83fd0808341dd4f91f4f8755cfb2dc1d210d01ad1b58166bc80f2f2561cfd2b2dcf326a5970b3ad32376dd7b93b9f995039be0c26411904026881b2df8a88f6b0c92380bd850df72bacf036951e0e911bddcc5f290e34485caf4d7324c900efb8bdc05d874dd421c7c48980b000d03724fe8166b7370c9e38aa38ce14cd1cdd79b6713dc79aa8f0cbb975fd3de0d9b7b4d017bb08f829ae22d7627c3346248c97123a3876beb455738633587895a051645cf21a20ec1a7d7cc84d7f489e967683282580788457b3937db717f650faac6d768d82472301d488b10f211b3f73e9e8b345af60c7249e3075be42580c77b5ed576568eb79f16568d86181ed0ece73ecc65a2a9c07a29bcf108b8e97062b585ce7be600026cd34fc800abdc4b98d9992b98c631974285915ebd56fc19d8d0e90da941db725d57b790b2aadadea110c6e569b27b06d79f73fc2ad118b4e8b2a660918e8e66dd112b4dfd451fadadd9e2c88581e62918d03a91ced1dba8163e60fc54468da9785196d3eac9b042b6e36b0d385f925377d5addbeeaa6f45e15a617c53788d6ba524ee62a7dfd37fa8521879c411196485a010e2f6f2727a926857a75f25a7a864624d3f23a325c4d12d8c027e6b6b54c4c0c58f34b315f407b85efb23b74213912275086695b0e3ba4ca93a16620a1d3bc8457d0765b72699962312e64a315a6c331f1c92f37d6de77fa52d0e15d4dacc605913890059207f056d67eb4f3917e1bec024591636f826ad36f387063e2452361804767cf73ea4f7569d18110420f77593febe0a8635870e5058f22af723afd159b44d71a191388905581b0207e8965f8cab2674a1a097b857eaa27849ac7f1c69f20636ee6f780edc8e5a3ad6be1b193cce0003b7863f95f7f0f352195c6783192c27c290ec083bb5c7a74519cfc698f6ebda830c9a6e531a2cba17803cf62b8feafa517bc788eb1fe068dbeabb4116080b986635b300e713cbb59e83eab9787eba66a4e7634788c75343472d954cc8939e52ee82ed5cf8bb247378311b24006bcbcabaaa63d81a4edbdfd176caf09c537c20c275a8eba461ee248f3691fbac9a9b1ded13b7a10f3badce04c6b6e6e7b9bb46c6c60fa9249fb01f55835723da7208e976afc7d32de5a9a34624739bcdd6c6c158f84324e97c61a66402403902179276a7fb86fd3debf92aee80e06670f55bd945cc36c34e0eb04763b2ab378e99bd57e9145a1a1ea4dd5f43c2d45a47fb442d79a15448dc7d6d6faf9aee2222022220222202222022220222202a971a4edc77b08ae7f0ecd9e50059dc9fd95b573bfc4973c674001a6f803eb6e5d3c5fb272e94f9b5a7327f74190925bccf3ca013d280fdd6ecfaa9cec00f98c7ce003601f97e95f2556ca75b49209bd8923cb65e74ece9639046f05c0dd03dc1d881eb5b8f50bd7a737b9b5068c90e6bc000ef5192477ee42906eab2e4e33636020b4901cf37446e0d0ad8a8dd4f0fc2903a3dda7769f315b15821c86c5218dc400f02893d0f64d09a73d9a8461cf0c87246c1ec146c763e63e2a27262619dd167638125589583623cec755e9f2b84ac95af003f6343a11fea94a4334324553b44a07507a2dd33a767d1e2834ed1b1302169e48616b1a7ce80dff0075b9ec67fc43e8a9fc21c4433591e16490d905088ff8c0ec7d42bc788cff0018faaf0e78d979769659c2a1c6d34906362471901c1ee049008dc7aae419d97296bedccd8d0b605d838de3f123c720ec65a047c29721cfc337280e200711befdd7afc33f071cfb423b2a40f3bb41362c3403b83de943e597179b24efdcda977c3fd46dbbb9fd0a8ccd8c35eeaf35594e2b71b36c18e4878a246e3a1566d366c80d204cf03d4daad63006400f9ab36990821db91e4a7c7386e5794ac193399082f07fa66ee307b8f45370e64f0b8578607823fec9bfc287c0c40e9e5a758119bdbd4290ce63a10e01c00f0c0b3b765d34857756d57226c834f6800d7bb181fa0559cd95f24ae2f7b8efdcda969d81cf712e356a2a668331dbbacca70dc7b48f0ec1e2650277029744e5e466e2c01e6aa7c298a0174ae0695933b508e16905c0027a2d935196f2af6aef748f735a2cf886b7f30a3344118d4f2c48d047b2bc81ebb297cd232258aa406df60773b151da74318e25f0a48c39afc770e53d01e5ff0025394faa95a6fd2a598c72c7910f86f02cb88063af2efebb2f7aacc24d2f1e013ba43ed0f2011d00240fd54dc58503e063fd9e30058b7380bdcfcd4566c2c6c5865cd840194e04b5e09a249dc00001b28f59398d96a631e0f0f4dc78ced600215775d71392e634506ecae84db238e08c1772ee7ad0552d6d823cb900209bdc8f82eb670988ec025876f8ab043e2be00c8da7bdec4a84c2ae602ac2b56966f0cbbccd15b270db509eccff006b01cd24820f4535c451bbd9652e1bbb6ffd45797457965d5b55dadde2478114a2ba81f7369626a2385232e8dcd167af7523998cfe72e2de80d6f56b5783eccb2771b9ab527a94ed1239bca3604f5ab2b61be55c746fd851b1e646ca5f4c2f635b6d758776e9ba8d73c13d8026c57c14c69a7dc35e761696bd6ab0b9f8cf2411409aea7a2f5f867ee7e20e9c2ab999201b7ff4dea4f2a26ba070a06c55dad3e01688b8ff004de62072be56fd6372e7e5fd2b71bcbb84f3478d8f24f29a8e2617b8f9002cae4f9397fec9196308b68e52f22fe3dcfe8af1f885a93b4be08d4a661689246081b7ff00d47061fa0713f25cb4ea1118222cf7886817d00f9f9af3786775d3343e7c279df348e2e26c971f5f2f9aa764cd733c0d8592a7f5cd4cccf31c7b346d676bf80ecab326ef27e6bae76c8cc1d1f871adc1e08f108a76448f79dfe43f455ed5f209c8948d8101591f0fb370e63e28dc320613ea4137f72ab1a942e24b836c160dfb74578ee488bcddb5f4490fb43a8d6fe6a4731ce2f700e3dfa1eabc70c69efc8c97101840f353b9da53e373896c60035d7fc954bc6ab75cba57e12e5bf27829b1bdc4fb364c918bf234ff00d5c55d9734fc227bb1ddaa6048e1b964cc68f9877ff15d2d78739acabace844450d1111011110111101111011110151bf132027170a703fbcf6177c4023f42af2a038df4f3a870ae5b58d2e9211e3328ff0087affe9e65785d652b2cdc7137b00bb342ec12a3e701ac2e029cd23d08f55bf24c0b090371b1dba10a272e40c7733b727a8bf3f82f6b94897c0cc66a586617ed234d0aec4f90f23f636a17538fc2b1b870357e74b4d92cb8f399a327985d8ece07b15219321d4203235aee60013dec76343bf9fd564a69ad83a873b8c523ba8b6edd08ebf55290e6b5ac3601703448e8aa8e12472d8b0e06c7c56fb6492401e1c435c288f223b26397ca58b3c5ac9c62d9049cae06c729dc11dc2e93c1fc7189ae96e9f90ff0f3c0b008a1301dc7af98f9ae241ae3d013e6696680cf0bdb2c6e70923360b4d11f3539e33284bae9dc78ef21b069fa712400663f3aa5cd33b7972074f7c91bfaac9ac711ea7c43a06363e43d8e9f0c97037464143af6bdbe6a3848e9b35db9a919cc41ec682df1cf59aaccb9bb474cda783e47f62a13388e723d54b6492320377d8ee00f8a87cc8dc25360aaceee68c7b6088d3dbf1564d2a70d63acee7a2ac869e71b77537a744f24d349dc7451e3bf2ab25cb4a8c7872b851258074eb66d6b71367f2e5bb1d846cd00eeb2e9d0b9b8ef710e1658d17ea555b569649756cb71b352103e00d7ecba6f551adb1cd2000ee3751edfea4f5d775ecb1c7b1eab7348d3649b20b88a00f52b2db6b64d45831b259a7e9cca6d1abdfba85cdd465ce9dad6124b88000f8adbd623734c7180fa00ee05059340d1669f558098ada1c09b2074dd55bfc24e3692ca6c380fc58cc61f2000937d3650b8921c9e2389ec047342e3d2e8729ed615ab56d2727da04a62711caf208a23a1fdd5674ec690712b632d20b3189dcd7f73f92a32bb8d9dbcb31f1cc1723b209e7341ac15d4fa95a398d647840b39ebdac804803b1fbeea6e18f2208b7971dad2e71a94827a951396c74d144d1e1b8bb36bfa66eec29bd12ae0c9fd9b0181ad05e5bb927d15235490bb264277376afb91812ba16b43241437a6fa2a86b1a5cd164389888045db8d2ab7864ed138d339849db61b6cacda64ef186050ebbede7ff55058582e7903946e7a13d15bb4dd2a438eeb8d8771643aa931bc72da8ec89e4e7ea050a3b6cbef104ee922969e081cbb55765beed1e5339688e3bf226d6dea7a0bce16439ef60ae4d80bbd87a2ab62505c3123a20eaa048add3509a4765bb726aead49e83a3ba87bd18dabbadbcce1e77339c6560b35b84dc15232bc10491b0b1b294d3721dd0bbb0edeabecda310053a302eba292d2f4671b27c22081437fd9256b6e5c8262036ba0761d569f0c64187f1034cafef64869dabab4856676872fb38a6c5bb46f7e8a0f1347c8c3e32d2b2c061e5cc8416b49e85ed07ec495395971a63dba17e2869793aaf03e5331417498ef6641601bb9ad3640f959f92e1c3380c4046ee228127a2fd3ebf3bf1a68b0e87c59a8e2c2de58b9fc584760d78e6a1f036179fc379d3a673854b28b9c4b9c08f8ad3c488e467c31d5f892015f12b63364e63ca0a9fe17d141d7348f19bfef64268f701a48fd174ce6eb25d4741769519d35af906e63701e55608fd151f8879610d8db40060b005772ba5eb12478f8ed801003051f983fc2e47af6678d9d2d114d3ca2cf5a572a349ae0765c9213d8a9ad66400b9b55b8eca1b8189f0e475beafa340fd4ac9a9e43a5c83cce3d4f5900fd136d9dacdf87b95ecbc53182e0d6e446e88df72771f70baeafcf3a7643a0c964d148c6c91c8d735dcee241b1d297e80c39fdab0a0c8aaf1636bebcac5af379673b74c6b32222e4a111101111011110111101111017992364b1ba391a1cc782d703dc15e9107e6bd6192e95ace5614800f0e4731feb4480b55d8c6460746db3b106baab9fe2b68e61e287653000dc989b2581d0fe53fa7dd57f458848046fd81b22fa9f45edc6ef195cacd225ba7492ca1ac07986e287ea54ce0e08858c3bb5d7b807bf717e47fd7552a305ac63431b443ac002efcc15e1f118aee876783d08fe56b368ad5740c6c861971ea391c36245071f2f43f62ab039b4ecc743911bc34101e07507cc762adf264973c78639e22082e229aff4f423eeb533b059a842dbde30299291ef0f4f3faac2565c1d1f13508064634be334ede447a11e6b3bf4731b0b03435a456c2942c589ab70d4bed782ef12322e460dc11ea3f70adda3f18697aa441b344d8a7029c1ceadfd3cd265fd35f62b031278e4e4635ce91e7dd681649f87929ad3f4cc8c29e29335a4327f7091bf2b8f4f9751f1a563832715e79b1b1da0934091b9f5f87a95972608f2607c729be61540f43d8dfa1a55b66d4dcad2a139eff7ae9c0ec2bbaadeb70c71e6f235a2a82b54b30872a58e593fa91901c0026fa9047a154ed5f244ba839c01a142894bd36735e20c563e56fba2ac74d95c344d2e07871730dd800034aaf82799ccf749dc1d88574d1a66358ee60f001bae527f40a6153c74fc5c7c66535e0f88d3b9bb37b2a4e6e042eccc924b893213b9f5573cacc0fc705a1fb48d269a7a6de8aa99b2b4e7e43007126427f29dafe4b625834dd122ca96cc648ba164ab2b30b1b4b8647323632acd81bac9a2c0d8a06bbc371dc6e687ea545f136a7e1b1d1b4016e3d0d9ea7c92d6ce503a9e5fb5e7df568200f82b970de2819cd21a3dd1fb2e7104b24f9365d42c1ea015d4b46618e56d39c6c75e63e5e8166f86d6d711cde0b23036b639b43b92154f458e09389a53307169d3de472ec492583f7529c4f3971631b298c8245926ba1f30a378621c8935e864e763af108e535641048ffdbfa29a468cd9da4624e209b19ae90171758b2d1cc4024d505f0c1098f4d763b0343f54d88af227b2c9a970dc7999227719da4bdcc7f26c1e0126b7b4ca95b8edd3db1c6c608753a01ad3d9a46fe6564b77aad9a5ea4658b245806ad52b89684b7d76f223cd5a9ce9a4165fd7a5b801f41655378a4b98fe526ec58a04ab4c43e03c193968f5eff1575d31dc90581649bdcd90a89a746e74ed0184ee0ffbb27f7569c691fc818c88101bd3c33b6ff15adab0e3004b9e5a0937648e8b3ea63c48321a00a7441d75e8a331c3c3092ddcefb46eeff35b3335f2c6e02026e1a27c1afee0f32b2a5a7a0c8d12d3a89f8a99ce918e696fba00dcee37553d09930c92df048dff00c207eeac5958f9218ee48c83db768fd90b50397330ca181ed243c8355d89537a410e60228f99550cb8e6667cb138596486c0e53bdab1e870c9e0f3180efdf901bfa15bdc6aecef771db63a37b280967643ade0cae1eeb32a3713f0702b7b2f99b8e00808e5147fa47f9555cf2ee66b830d8713423aedf153ae293b7705c5ff001b719d8dade0670a0dc9c631edd7998efe241f45da173efc65d19da9708333226174981387920ff71deebbefca7e4bcb85d65b76bd383c4d19399134834e7b5bb7a901741c18ce37186914df75af7003fe434a1b83f855fa96a71cf90e0dc7c6224900dc923702fa0dc6eaf7069d14bad62e4b001e1c8e70dbb511fbaf5fcae56b0711e482f95c5c496d381236d892401fbae559849c979268137b05d178b666c0325dcd6e208e63d8790f20b9be548d339ab2287459f08bdf00e24634f7cae6071249048b5aba83c0ca2d02b73b55775b7c21971c1a38e67301dceeedfe8157353d51a73096925b641f77bfa6eab4c9da631896336039890413f15db785a4f1786f0df77b387d1c42fcf116aed0c04178177f907f2bb67e18eaa351e1d9a2e725d8d905b4e680434b5ae1d3e2572f2ce36e93b5c91117996222202222022220222202222022220ac71e68add5345f68e52e7e1dbebcda7f37d281f92e34f271b249a3b1e8bf453d8d918e63da1cd70a208b042e2dc6da31d23559208a314f05f193d390f4b3f6a5dfc597c4653e906745978e01700f2376b7a92bce463f8ef1e28a0e23918d3d3e3fe6aad8592fc694be19394b7fed88b04f901dff00456fd3b50c7cc063733c298805c0ee48f307c97745444b8b243398f259e23091ee0d98df224f9af52b1f88e2f6d4a0ece3d011e6079ffd0ab39c0648ca2c0010763d4f995159d832411b9c5a4c6db000fcc3e1fc0462286444f673633c5834584d57a0f255ed534f8f26733e3030ce0d9e51409f2f8a9c9b4e0f780488e593f2bda40045f43dc1f4fa2c595a665630f11ae1290370051af4f31eab2cdb65d23f48e269f0e538b9f6c78db9cf53f156b66b0d740d7178200b241ea7d15332e1835084990863da2b987507cbfc94199b2b09e636cce0074a276fe166ee3db752f4baea3a8e3656480fb6c80d07b77207af63d7a76553d530b2629dd90e6f3444d0906e3d2f6d8fa15aecd42470e571a3e7e6b659a8c8d05a776914e077047910b6d994d4ac92cad8d2236c92b0120d903f28571d2b11c25e50f65137b823f7553c01089db3424b4036633b91f0f3f82b8e9b931805e49b3d2c115f65bad42a532719cdc694f8918a2363cde5f155e661ba6d6a501d1f5b340f9fc54ee4e54470a63cc3620ee0f92d5d3430eb12383980117b9f544a6a2c66c18cd1ce41bb000009542e2c7dcee05c48e63d5d7dfcba2bae5663636be47ca091b00d1743e01736d7b31b364b892451277dafe5d565ba8a9db63872032e59228505d6846418981c680b25725e1acc64739aababfc85dfc2e9191ab18dacaf1092059000edeb69aba2f6d5d4dac9b536b1c2da18e7104df4143f55e318e3c3afb6a204868600c146830d814a0f3759919acb41321a61069c2c58f82c3a66bbe3f15e1b03e4b2f24788016fe420124007b1e8b2f139224582199d2b7d9de4898905e48049dfb9f551b9187248dc76b600c68d506f62f769db61e7eab621d51b21ca79f640df1aecc8f37b0e802f3fda18f0b1f31730f859d148de48680ba07726cf558dd2fee6c5838809003abb2e75c492bf272dce7d9da80f4054d676b73e4be98e79147abc003cba0559d59f2f382f7b09a3b73135f7f55727098c3a637c37d8d88562d389f14936401dbd0aa5372a48dfb16024f91fe549e1ea73b09fc80115b83bfdd34dabdb1ef90b4821a2f616b6622f7cc46f476ebff02a643ad649e50d0cebe6ebafaadec7d4b204a006b2cc9dcbbfc23d56eaa5b7a3c6e1a8ca0934c908af9ab0bf99dcef7ba833703b12a8b85a964373670d0c04c84936e3dfe2a627cb9998524b24acb3640e51dbe369aa540655b7577349b24971a1decab868bbe336b7e82bc972ecdcc9467191c417107fba2bcea80569e1cd5271034fb84df4aaadfd0acff8ab38747d47688801c491d02aa663c36eefdd049bedb2f9acebd90d8b66b0fcdc07eaa9b93ace44d239a5ac01c08eaedac7c52cb272c8fd3ab164e3c3998b2e364462486661648c3d1cd22885aba14efcae1fd3b26436f9b1227b8fa9602b7d785ddcdf3db8bc3e5da6b1f1c7c8ee4637a58ec7d76f35f70b9636098905ac6917ebb283fc40932b0ff10650325e229b1e298343b66ec5a457fc97f355ed67883223d30c024dde2c9a00d15ecc2ef1db959ce917c59ad8cad4258e3773004827b5efd1555ce74920b2492005f6490bdc4f5bb2a4347d39f97a83411eeb08bb0b39b786c924e569d26238da4b455122e954f3038c84936493dfd57409636478dc8d0050ae8a9799134107bb8f92ed670897969c20900015743a2ed1f834f260d5d95403e270f9877f0171d6c7efb47c07dd760fc1e7b41d4d82adc233d3c8bbf95c7c93f05e37974e4445e474111101111011110111101111011110157f8bf877fb7f4be58da0e4416e8da4d73edbb6fb5ab022d975c8e16de1c82495de2c9e1cccf77c3e8187b8af8ac8347971650e2e20836d947657ce34e123971c9aae943932da39a58d83fded7703fc5fafebcf60e25683ecba887300d8b87427c89edfe6bd38e72c72b2c4ce2eb511718247323906c4dd07fa8fdc755b7ecc7249731dcce22c1bdc0f41d87dd424ecd3a72d2fe506872d771f11b57c3eab2447263fea69d9a5c01b30bcec4f737d5746251da541187022dcf14f791b1f4aff0045406a78397a7c5cd01f16206c42f76fff0023bf62a5b178863c8b8278dd1cecfccc3faf9528ad57537e4c85919b1d0bba50f21fca4e59b5333a3f69c973e198c391d1d1c839493fa7cc28c31b8931c919127522ac956f9a28e78c3678db3b00d89d88f507aad37c3a748df0dd1bcb5bd5e090f8fd68751ea3e696554aa93a1746f2394ec2e88ecb7b12364acdc80479f752595a54b0b0644320ca801f748ddc07706ba8ff0054b4d98c584cb09e68aec807769f23e8b31c755b6ee377174d12481d1b8b45ef5d4add7c33e09f1419042f345c09a69f2bf5f25b78318c7c68e49985ee928450b7f3487b7c07a9ff0035338d8425b6ea7cd9123c5330e334c8c760e37477efd3cb75d2d8940b2792464ac33c841008f78f70479ad9c4c87e3cf0c826782e8f7b79dd63c8d232349cc787b4b60945c249badc9e52762481e82c6fe6b04e43598b440b8c95935535e757d4657b4b0ccf2093b179551c824ce77dc953f94d6bb98924eff050b2b01c8e503baccb15637498e1d8cf39aeb5d0057b9038c41d42e8117bf6554e1f8eab602feeaed144d3801d42f976242ad6a6937b50a464ced46791c41201dc74e8bc68d138713c6ea371b2476cfe43b31dde8d2969b123872f724fe627a6fb6cb16801b36b6e9795a7fd9a5753858208237faa9ca70a95ad063442091f90e6826420734d676dba0fd56965c9147a54ed8f90b9f90c008049a1bf53d3a292c8ccd371c98fd9f1dcf7bde0789605d9dabb05e73705b270f3e46471b7fdae324b2320006c752079851bfe379ed92066449035cd37637edd9686a18d2b5a1cf2debb6e76d9590be2c6c56b23a3400b2abbaae4920124924eff0045db5c225e50c453c9e6adbb2dbc56be47b434d9a3b95a4e7fbe6d6fe976676dec28a99daaf494c681f18bd89dbba9882095a43c815ccc2003f25a5891b9d3b4d12dea54c92d8e3f50583aaba956d8f3067c80816643dd4a67349c03cc6cbcf28005f52a135135acb9a2ff003f9faab3087c48a2690686e77fa2c8287a9e398b24d9dc1a53bc340bb1b6737e047aad2e2263465ba9a06fbdadae1720c6411b83e4a67ecab784fea78ae76373122faf554bcd85d13a4362e89042bfe5d1c66d81b8ee3aaab6a58e0b017369a0ee6ab6bdd6e5372a657e8bd2b14e168f8588763063c71fd1a07ecb2676643a7e06466e41221c689d2c84750d6824fd82ceab3f88d90717f0ff0059901209c72cdbfe221bfbaf9cf43846afc5d93aeeb991aa64d3649886b59d98c1d1a3d00fb92a1b51ce7641a06ef73f15ab142f98d35a49276dbaab168dc232e44ad9f3c88f1c1b703d5c06e405eb92faea23736d7d0f432fc73a8658e589bbc609fce7a03f052b893e2e082d63817bc924faaf1aeea0249443080c8db44346c1a06c0528ac50e93201241b37f05d31e222f2b4cf98d18c5dbfe535b2ac65c8d25837e96a72582476391dab75019b191335a081f5d955a48c31c9cd92deb57fa2eadf83b3876ab9910bdf1b98dfa387f2b9562e393238876e050b0ba77e0f44f6f12e71af7598557f178aff00da572f25fc2aa76ec2888bc6e822220222202222022220222202222022220281d6b82b87f5e63bdb34e8db2b893e3423c392cf5248ebf3b53c883897137e1d6b1c38e76468ce93330eacb7979b947939bfb854f8b5d31c9e1c824c690751d403e5e63e07eabf4ead0d4342d2356fff0051d2f0f2cf9cd035e7ea42e93c953eb1f9a33f529f30f33ee394747b5d763d4f75eb175c962021cc69ae81ebb66bbf851c39a8e9f247a762b74ecaab8e4889e507c8b6fa7c1718d6344cfe1ecf7e9daa63f86fea2f76bdbe60f71eabae19ed371484190c9c0a7020ef60f50b3cb8f17bb200011d08d885576f3624a1f8d27213b86936d3fc2da76b45cc31bc9638f5076af82edbfea757e245f9d162ca0c7235ae2776ff0071fe84763eaa4a3c6617c7237141cb9073361e8180d025f5b1aeb5ebdcec2174a8e07cbed2c81d9539781083bf3bfaec3a501bfc694f3e5761467162903f32600cf374e51e43e1b803b9dd37b3a666118d2b990bc4d96e04499040219ff08076f974adc9ecb7b0cfb23fc460123ba39cf360f9fc7e2a3716110b030b48dba773e67e3dcaf5939cde4f0a27024f520fdfd56b1279b3c59b19c72e0587770b04b48e94552f2e631e48c773807424b09f3ae87e9456d49a8331250584c92790ded68eb189e3b999b1739c8909e78ab7000ebf2e9f44de8d6de669a3311687026ac9be8a21a5a65e627becb6b95cf8400da27b247a74a656134011601dbbadb764e13ba34c19ca0309f5e8ad6eca7334e006c68f417d0a80d3b0240e68a7591d1836faab9e2e88f970da64143949a71f53d92d658e71aae548c941e7361d5d6b65e38532641ac989d643f1a460beb757fb29fd63468c48497339b9c7506b75a3a26952e3f12e9f23184b5c1c0961bfee15196eaa69a52e94ccc2e91a7222264a903835d746c51bb1d4adbd4f24ff0060e740c6b5b52309eae200208dfa2dc3116b660f8b21c44a4101c6ae879528e96374da767b4b5cd0f958003bd74f5f45324976ddd44c39d913301748e3428026d6be597902c9ebf553ba0e8c26c72f91cd69048e964d2cda968ec1082243b1dc52e9be133b5400739e7aa91d3ac4ed0491b1e8a45ba43030b8caedc123602d6f69fa644ecc85a257557603c8ff000b271cb6f2f78b23bf35bfa7995ee79dc5ae6f3484f332ac9f553f0e8cc703c8f343a1aec9fd80c707112927c48ab6e82c82b6e512a1e49326bd255ed21dbe6add0b1e630f773bb60001741616680d1c4521749d5e7b7aabc43a240cc605dce761d0d2cf6d1f1c8b5e86433bdc5ae02fb8d82f9a173b09a6bf723a0f82b7f11e9709338607d0363def251ba160c05ed1efd83d6d25d5daa74df731e60600c90ec3a7c142ea78ce3038bd8e17ee8b3e7e8ba48d371c63464920728efe8a0b5ad3b10441c1ae710491656fb464754d0247cbc3ba6c927e77e244e77c4b05aa9fe2be1cb9fa469f8c4b862bb2f9a7e53574c7117f7572d35a19a5e2347410300ffca15178ff005983232db80260d8f1c9e720ff007bbff1f55e2c26f275b75150c0d1b120609896c6d1b0686824fc1696bdaac51c6e8992dff74359b015d7758756d7a28a2708cfe504341d80dbd5549f90ecb9830104b886f52773b93d17aadd70e727d6cb0499d90238e3b7486cf735d95cf49e1e6e330493005d57bad0e1ac6c68721f24ae8f99a0002c8a3f3015872b3a263013f946e69e3f94e5376f3a9bb1e0c3e5a6593bd8ec15172a66bf2890075e94a435ad61b93922363806806edc37fba8cc58d9349cf23c513b0e602feeb65daa44de8f881d8e657d0dc9b3d00f35d67f0e741934bd227cfc9616646a4f12161eac8c5860fa127e6aa3c018f8b9dabe362c91b656b5af98b6c38536bafa5b9abaf2e1e5cbe2f19f44445c16222202222022220222202222022220222202222022220287e25e19d3f8a74b761673288b314cd1efc4ef31fb8eea61107e5cd7749c8d0b55c9d3b285ba07969701b3c0e8ef815190633b35cf71f731e21723cd1e51d80f327b05d3bf13311b3710e50732cfba6c11fe11f3550d323c76185928e4831c97c808be792f6711dc01dbd17ae6ec8e7c4adcc380e97871e43622d9b25be1e363bb631b0f526c753b127cbe2b660c0931f733132c86def70bdfcebb797c16fe918bfda3912e6e5baec011b09b01a68d83dc1ebf45b59f163c0c20bc90475ee02b9d692af66e5be18cb6271713f99ee3b7c942cb9529f76026dc68b89dc9f214b3ea39324f91ecd0b799c4d00075f82d810c7a2c61d2344fa8100b633bb6207b9fdbcd69a618b1ce246df1e0e47bcd804dc8ff0080ec3d5799750646f2d0d639c5b45a3700f99f33febd569e6e4cc7c63ce6495db4929ea49ec3c805a5097824d10450fcb6b2de746b6b568504392f0d7c4d2ebdac5ab2cd838f8be1b8b196059240549d2355971660e3540edee1dfeeb7f52e2276434b4c846d540003ee536cd5dac5a665f8fa8968a201e806c02b863481b8cdba1b1165736e12712f92573edc4ed7257e815e318f362341b24d9351b9e7ea6967c65ed5ee21203c34c8012f040beab16016c5a9e8d20781cc4b4906abdd37d161e2389c73633c8f20b8024c4d15f75830606c73e9f296ca0c3920021836b35dbe28a8cf24639f2da731b0b5b39b241b3b03b5ad46f8434cca6b720485d334016013d3b5291cec0c59353ce0ef14d481c3fa366cb47a6c3651ce863fec8cb20484b276386cf02aeba555a1ff00c7cd224a8a4006dce7bf45b395234e3d1736f980ea14669509a94061fcff00e11fb95b59914c21d9a4026f7701fa05ac69e464454e6f38b008abe8b7b479623970b8cad1b6f63d0a82787cb3b9a01b23fef080a574a8e566546d1436d8190f91f446ae0dcc8430344c2aad7bc5ca8dc1c0ca09b88d7fcc54498b20b4d729a15fef0d7e8b774f8e7e791a01b1e1935291d1df044b0e04d1cdc4d292f69a91c001b9ea7b2b964e532080586b40e85e4341554d170721dc5339318039de492fbadfd07aa97e230f8701ed1b39ee00102cd77f41f253f5aac6afa8324e6018d7120924387f9284d23244392de60fdcf40015bd97035f60caee946c593f55a18b82d3a846c6b8924826d800a0a9b3a7446e487e2c4435e450bb15d9436b597cec0d6c725004ec001f72a6e3c4e4c38da5c08000af0c50d9416a9880b8b4960058e03fa63c94fd63a868f94d6f0c61e5496d6b3118e758df66effa2fcedae6b197959523df91212f7b9ee05dfe236bb9e3c97f8612bb981e5d3651636e8c70fd97016e21ce7b8806af737d547864dd5e57a45bbc4cb9db1b41717100d6e558348d14c46396569ba326e3a0ba1fba98d17418b15af9dcdb706922c74347f7214abdac886472d011b5b18a1e42cfeabb4925dd45a87c2690257d0ddc48d968ea727bb5b6c093b2b0c7086638045922ca84d5f1ec10d02c857a66d588d865c87500294c410b608092ddc8eb7dd79c2c2a7591bdf9adec80d1e1c543de366c7459249dab7b5dff0007b11d36bbab6a0ea0dc68598ac1eae3cceffda175a54dfc2cd29da7706c7912b0364d46576574df95df93ff004807e6ae4bc195dd7582222968888808888088880888808888088880888808888088880888839c71ce0365d62590f312f634ec7d2bf6544cad298d6b9cd04386c4d0dc792e93c66f6b75121cd71b89bd076dd52a731c8446d04926cdf97d57afc7fac71bdb47032991e2331e2788dd158167a1bb20fa1ea3d561d4b51f18b986cba882c1beeb5750c56c6f32c45ed7d9be51d7f9516dc99a3cf872252f8dd19b6480014474b07b5f55d3a225b134b769f1999e58cc891bcc39c5981a7b9ed67b0d8fc815179f3364b6c2488da49e6ea643d2c9eeb6757cf7bdc219270e1202f91c0805d757f23d36ba02875511365b4821ae6003601a09fd960f4d819e039c5bfde17bfa2f50c31896405a3723afc02c4339b1e3bc731b375ee6d746bbac6dd41a1ee22ec907f2fa7c538355ee58db1834075d815ac25de80177e417c9f30483bfd2bf75a7e351efd6fa28b795495d0b86b36a20c0e6803637dd5e21c8bc666fb52e39a66acf85ed039fa83b103f656f835f93d99a08236eef1fb057dc73a91d6c178f1436c020f5baa2b5667f831c6e25db64c4eebd8b86ea33275676463c8d6b6cd50b91c3f7509abea53491ba20d01bca0d8792457c4acad9165e2ecec8c09f5095b92fe6748c63432dbd40d89ef42d6b60cd2cfa1e4482771696b1c5a403639bb9dba2d0e21cafed09e48e611b5f2471b8900921c00bdbe74b142e76263be0023635f8ee03de7b6e8120d79ac9bdab8d25f09e5993202ea04823b05b99ce8463ef2b4d1ee42a7b33e433b640182c004f2dfeb6a5e59277e2599df40834d207e8ae4da2b51ef60ce15207022ac027b7c14ce13a3f6d8ae4005d00411d42a7e4c8ff006907c471deac927ba94d36678962719a41bd58790922af4beb0c4ee56f3b4b46fd365b189342cc99ff00a8cfcacdaebfbc156a17c8e8c91933004d0fea1dbeebd62cf3fb4b9acca94173a36ffbc3e767bf904b8d4aef89911e0cb9b965e0dc9ca371b0ea7a9f82a87117123249795b90492e3d5c2abe8b26a596f8b01c5f29b90b9d6e7124ef43ec15133e4267041bea6d66b4d89d3a989aaa8937b878bfd54be850813b252d3b9bb146bef6a9300e6aa35dd4f698e6811815cadb249ee56c94ae9793a844c84359ce00147fa67f8557cfd523338039c9a71a2d23b282cfcd77216b5f5cdb1b247e8a09d212f739cf24869e84f9acb34c91de348789bf09e57f40ec0c8ffe6b8f68a63f676b89dfc80b2575ce09c57e4fe11e3e2b05be7c49d8d1e7cce7d7eab926952cd061b7c2c79a475512c8f6bf89d971f0dd5ae99f516286571848319630482893b9dc127e816a1c9716641e579e69aec02010001d7e4b59936b12485c190e20043bc4c896c8007602c7dc2d395ac999299b5874a192065c31120d77bdfb95ded448907e738805a58d144d1209fa0dd4466677be39e7613563a9efd162747a7c7ee9399904016c2ee407a1e828d2f5248e8a30e8b0e0c56b012086171366c59a16763dd67b5f8dd30479ec041321adfa33d7e2b660c8832f31b1bf25ad121f0c17308abdafafafd9636ea99521258e908ea098c01d3e2548e97993cd9b131fe19e690587c6093f4296dd3788fd0d0431e363c7044de58e2606307900282c888bc2ea2222022220222202222022220222202222022220222202222022220e4df88d234712ce3f33bc18e8574d8aa835b1c6399c05fe8af1c6fa68cce27c991d296343180729def9554a5d2228584f8ce24fd4afa1e3d7a470caf2afe616cae716900d9174147bf1da7615f1014865c344d3ddd6d68bac13ef155495e5b894f26ee856e56073002762696dc5217484df6b2b0cc40b000f8acd4d16b49eeb85deef527f45e06e5d43cbb2cce6dc03e2e1f62bec2db73bca87e8b9eb755b6ab9a7cbecb091448524f65f65a53329e54e58e9b2edef0c9120eeac90b5f2401a2ef7ba1eaab78db4815bf466f3c441df7fd974c24b13976d68349c89092db140f7ebb28fd434ccb8dee05a49208143aabe40c6c5013cb6794a8cd5f3a2c69636f202e90866fbd59009fd56d934c97945ea58b9635cc96c72c4c3180d2481b56dfb2d77e2bccf1099ec9890e17ce286c6fb15b3a8e4e0cdaeea124f0c9303210de42481b9f25a072304e4b0c70be2abab277346944d695cb471a12f8a3703407a5ab29c20ec0a2e26dbe5dd57305e3d9db7677000f356d6bc0c36f3380dba03b9d9759d22f6a8e7c2d8de2801bef456fe8f1b2596369bdc81b1e8a3753c80e7800822fb290e1b907b6071ba0361e64ac966f4ab785a5d8b080182c50e80acfa4698d9321f2d101afbb27ad0afd4afac7b083d7cc9a521ed5160e18041e670b37b77ff0043e4ab49f88fd6218ab91ac6d345024daa66ab053ecd01542852b167eac0decd3f12aa9a9e73a6937aaeca6ea12563c3884923584d126ed5bb4fc38a188b8024d5127baa343972473b4b36a2ac783ac4ad89c5c2c76598d8dca54a64e3c229de1dd6d64a84cf0d8a29088c0b237037d87f9ade6eb0f98d9600476e5b519a96499a375b6ac3ba9aadaba26578a63dbf48f0be1334fe17d331236f288f163b1ea5a09fb92b86b713271f272718c995cd0cf23391a40ae57115757dbcd7e81c56787890b3fc31b47d9719e302dd1b8a35463e76343e7f185df4780eafa92bcbe2fd9d33e91acd2c195b26496068363c52643e9b1dbafa2d29a189da648c9336436ee6a07945971ec3e0a1f3f8979e5a801908361cee87e016930ea39ac2dbe56f3004d556e7fcd77b67c4497ead11e6e99a74619146c040ea0593b6e4ad3ccd4e3cc780ca03c33d876bfe56ac3a4c0caf19f24ce22f61416ffb26041107331e4e6a70b2d26b65b37a3868cf234c64b086b4804126a97ae1f6365d6f15ad797b9d20007d57d9e4c4908b638ed62d86949707723f8cb4a6b19ee9c9658736b6bf5ea995d4db7fe47e8702850e8bea22f0ba888880888808888088880888808888088880888808888088880888838ef191963e29cd7e4c4e8c73fbb3b5c686dee837b0da956f27232a31bf2c919361c0d1ff005f35deb3f4ac3d49a3da616b9c010d7f70b99719f04334c81f9d102dc76d073d80968bdbde6f503d46cbd5e3f2cd48e596376e61979c5d6d2481f1aeea3fc72e3b59defa2decdd31dcfccc0483b82d360fc0ad138cf8ba31f6475a5d2dac9232433d3dc45f92f92485c7a6df1597170a7901706bac9f2b599fa7ca372d75faecb77c33ea3dce222343b9afa15f1921048a1b80b762d3259a22436c5937f1d8292c4e1b749296991a0068bd8a996ed5748604f2f40b5660e2fed74aef170c42d6925c0d753cbb28ad43478a399c1b20000dfdd55798c955b80d483e2adba3b8f8468906c74f828ac0d2fc69c53c017dc2bae93a508e17ff0054037d9be898d9215a8e1212d0f2f00b4d0f91505ad309d531487388e68c8fa8568d4300c7cb278cfdbd0015dd4165e9ad875cc38e4c87c83c488824802890532bb8c9c568cf8ee7ea79d2327919521df94efd7c8ad197c612b79a473a8122c1ec0faab5646207e7ea0467063449407860dedf1f5517360864a43b2d8f0217bcf2c601143e2a75c377ca3747c474cc692d041208042b1e446e8f18d308a06b6aeca4386747c73810483c524c609dc0175f05b9ae458f89a74a5b18b008b26fb2b996a6997b728ca25d9046db1a56ae12d2a4c8c82f20f2c62cd02492a2f0305d9f98da680de7166bb2eb3c3a21c68a46b29a0d0143c944e2dadb786945a6bd9ca1b03e86e4904f4dd44eb38b3cb9723447201406fb0a1d95bf3b2c89cc61db7864800f7558d4e73ed45fcd60ee28edb8ff0025532b52ad4da2cd25d455f12a2f2f43962236679752695a86645193cee68375f98151ba96647232da49a3d06fd565bb5456c69e58e1cce157d42b6e87c36ec9d2fda2325cd2faaeeabb3cb23984f27234773b93f2567e19e298b1f433891e0e4cd231f63c2697583e646c3eaa6592977619da7cb8ac2c8f1dfcc76048a55bc9c27534c8c2d1cbb923a924dabf7b66b1a8811e2e0b592bc7bacde4906dd4b5bd3e656de97f859a96a3378bad4c6288506b5e41276ea18dd86fe64fc166594d735b8cabf704ea2fd5782f4acc9053df8ed6bbd4b7ddbf9d5fcd73ff00c5fe11764ea30ebad7b9b04ac6c33068b21e2f949f4236f885d4f4ed3f1f4ad3a0c0c5696c303031a09dfe27d4f5597231a0cbc77e3e4c2c9a1905398f6d870f50bcd2eaedd34fcd987a2e9d8e43dec7c841eaf2005ba7331c5e36316892ac3636ddefdba9277f25db71b81f8631242f8b44c52e3ff78df107d1d6a5f17071305859878b0e3b0f56c518603f45d6f97f913eb7fae2da77e1d71267bd93063a2c77510d9c88fb7704737d9491fc2ee2976c32f4d0d04d0390fe87e11aebc8a3fd726fac72067e12f12482a6d5b0631ff0173bff008052fc3bf84d2695abe26a79dae1c87e2c8246c3141c8d2474b25c6fe8ba4229b9dadd411114b444440444404444044440444404444044440444404444044440444405e5ec648c7472343d8e0439ae1608f22bd220e47c67f85f958931cee1688bb1dc3fa984d3bb0f9b6fa8f4eab9dbb2b230b21f066e3ba29623cb231cd21cd3ff00134ee17ea050daff0009e8bc4b172ea584c7c80536768e5919f077ec765d31f2589b8cae1b8da9e0fb38758e727a01d3c9619676e43c86077fe53fc2bcea5f820de6749a56ae4927666532881ff8d95ffb5567338338a743737c6c39648ef7923678cc007725bb8f9d2ed3397ea3d6c63c7831e18a3639fb97806c55d0b3faa90c1f670f9e42f06df437bd805ab1c9efc624f6725a5e4ff55ccbaa1746eb7464d1b192f3c4c27989b396003f6f556cadf9b2e30000e6817bd9015773e56c8f9795ed364802faacf979d0005b1c30990900344c5e4fc805af3e91abbb18643b4d96361a754d8cf60a27b39e003f559b9091f349869c1c6badf556cd3a46f872733806d8b37e8a9f8f8996d25aed309dac90c611ff00b94ae34395c9231ba53c9344dc6c006deaf3fa2dd96549ea5978c58e0e9da0004068364daab3f2df93abe96390f378918b70aba7d027e54b673dfa8410177b17842b62f94003e400fd568e89a5eb19bad61cdec796f85b3349763e33dcd1bdddd555f7b596c849567898fc57ea12cf9d890dcc6c88cb89a036036a50b9d9b0c8cca73a463c8c691a1de1f2924815b297c66e766644ecc5c4664bdf313cd162bde583b0206c3a79ad2cce1ed7649e42d8721cf229dcda73da05f6176a7d95a48681a94c3031e186324060b713d76ecbeeb11e465614ac735d6f06808c937f1a5b987a771d0688e37b43437ab308fc8760a707e1cf116a78c7dbf899f8ae76fc8206c87e745bfa94be4919e976e70cc39b4fc46b4b251207f312d03a75f8fd94ce93a83e30001200edef9093bfc56ee4fe0ef126338c90ea306756c078ce8ddf47023eeb5a2e16e30d19c58ec1ca3dc16c4d9da7ff0021bfaa4f2635beb5bb92ed41fcb2b39c161b04b4d91dc501e4a2b334bc992cccf924dac6c0003cb727c94ab23e25983bc5c6c8223a6b8b34d9ac9efb7f92d57e89c439ee858dc4d548208206218875e96e68afaaddc4eaa0fd89b1805d2860ebbbb61f40160cdcd8228cb63719dc06e18091f3374aef85f859ab6641cd96d8318dfe4c890caef8d36c5fcd58f4cfc26d131723c7d426975022aa27011c436ff08dcfcca9be491b31ae49c3fc29c41c6b2f2e24223c40fe59273eec4cf3dfab8d1e83ecbb270dfe18681c3d0539b2674c68b9f39f76c79306df5b56dc7c7831206418d0c70c2c14c8e3686b5a3d00e8b2ae172b5d34c58f8d062c5e163411c31f5e58d81a3e81654452d11110111101111011110111101111011110111101111011110111101111011110111101111011110111101111011110619b131b24dcf8f14bdbdf6077eab57fb0346fff0068c1ff00faccfe148220c18f8389897ecd8b0c17d7c38c37f4595ec6c8c731ed0e6b851691608f25e91054e4fc3ad21d2bdf1656740d73ac31923486fa0e66935f359a3e05d3a324fb6e71e60011e23474f50dbfbab322af6bfd6690f8bc29a1624be2c7a7c6f78e8e9dce96be1ce4d7c94c222968888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088880888808888088883fffd9, '2024-09-05 08:35:47', 126, '126', '2024-09-05 08:36:54');
INSERT INTO `masters` (`masterid`, `mastername`, `category`, `status`, `addmaster`, `view`, `image`, `createdon`, `createdby`, `lastmodifiedby`, `lastmodifieddate`) VALUES
(186, 'Sleeve', 185, 1, 0, 0, NULL, '2024-09-05 08:37:38', 126, '126', '2024-09-05 08:39:17'),
(188, 'T - Shirt', 0, 1, 0, 0, 0xffd8ffe000104a46494600010101004800480000ffdb0043000a07070807060a0808080b0a0a0b0e18100e0d0d0e1d15161118231f2524221f2221262b372f26293429212230413134393b3e3e3e252e4449433c48373d3e3bffdb0043010a0b0b0e0d0e1c10101c3b2822283b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3bffc000110801e001e003012200021101031101ffc4001c0001010002030101000000000000000000000102030406070508ffc4004810000201020403050407050408070100000001020311040521310641510712226171133281c123364291a1b1d1143573e1f0173374f115245255627283931634434453a4e2c2ffc400190101010101010100000000000000000000000102030405ffc40029110101000103040104010501000000000000010203113104122141321322335114234261718191ffda000c03010002110311003f00f660000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c2ad6a74294aad59c6108abb949d92033070296799557afec2963e84eae9e053d75d8e729296cd3f42d967228008000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000d75711468d3954ab56308455db6f63e1e3f8e387b2fba9e3e15651bde34bc4d1ac71cb2e225b272ec00f3cc7f6b1848d3a8b01839d495ed09547ddf8b475fc5f6a19f56ef468aa1463256d21792f3b9df1e97572f4c5d4c63d5f33cd70593e0e58bc7578d1a51d2edeefa23c4b8df8cf19c418aab4b0d5ea432f8cbe8e9eddeb736ba9c0ce73ccd33c9c258fc54ab2a7ee45ec8f97249b77564cf66974b309bde5cf2d4df8701549a775269f5b9f672be30cfb287fea9985551b5bb92778fdc7c7ab0709b5cb9189cacdbc5748f46c176c99ad3eeac660e8d6b3f1773c375f89d8b07db1e4d55c562f0b5e85d6bdd5dfb3fc0f1716f33174f1be8debdea876abc2d5e7ddfda2b53f3a94ecbf33934fb47e16a95143fd2508ddef2d123f3e5bcc19ba58aef5fa0bfb4ae16ff00782fb89fda570b7fbc17dc7e7e04fa589bd7bb4bb5ae168ffea629fa51fe67cac776cf80a536b039755c446eece73ee7c99e3c0bf4b0fd1bd77fc476c39f4e6de1e8e1a946db4a1de7f799e4bdac6734f1f1798fb3af86d14d46366975f53cf4df848f7aa3f43ae186395db666db26efd2193712e579ee1e35705884dcafe0969256f23ea9f99a8d5ab87ad09d09ca94e2eea517aa3ef52e33e23a728cbfd2f89977794a7a31974577fb6a4d5fdbdec1e3181ed2f3ec2d493ad38622325b4d6de87decbfb598b838e3f03e3be92a72d1af4b1c72e93567adda9a98d7a483e4659c519366c92c2e369b9b76ee37695cfac9a7b3b9e6b8d976ae92eea0020000000000000000000000000000000000000000000000000000000000000136dce3661986172bc1cf178baaa9d282bb6cf2de29ed1b1398ba984ca9ba38492b39c95a72fd0eda5a396a5f0ce594c79777cff8e72ac8e72a0e7edb1116af4e0f63cf333ed1f3dc7371a15638585adf46acfef3a9b6e4eedb6fab317251dd9f4f4fa6d3c39f2f3e5a96b9188c7e2f156f6f88a952db77a468dcd4eaf958c5d567a3c461b9c92dd98bab15e66872b92ec9725d9b9d5e86bef2beda18ee425c9765a90552367bad99c59c1c1d99cab89252566ae72cf09979f6d4bb387dd7d059f436ca94a37b6a8c79f4bea79ee3b72e9bb0066e2ba32772d7d49db4dd8832ee3bdaeae63626d5402da6e651839689092d18a5776472e8c5d38746c94e946166d5df999b7a58f4e9e1dbe6b9e577f0c9d47de4f98f6afab3583af756766ceff4d02a8d33581dc9b3914eb4a2f46d3f26762ca38d73acae71f678c9d5a2a5774e6ee99d58ca3368598e536ca1e670f66c87b4dcbb1ddda399c7f63acf4efdef07e77e4774a35a9622946ad1a919c24aea51774cfcd919a97af43eae55c479ae4d7582c654a707bc2fa33c9a9d1cbe70ade3ab672fd040e819176a185c45a966b4fd84f5f1c76f23bce1b1543194bdae1eac6ac2f6bc5dcf067a79e176ca3bcca5e1b8007350000000000000000000000000000000000000000000000000f979fe7f83e1fc04b13899aef7d8827ac99c4e25e2ecbf8730efdacbdae22516e9d18bddf9be48f1ccf73ec667f8f962b153d3ec413d22ba1ead0e9eea5def0e79e731e1b33de26ccb3fc44a58aaf2f63debc28a7e189f20184de96be9b33ebcc663368f36fb92a96d8d376596fe77312550004540010000150b700806328a77ba29497c8d72a777752b18ba73b68d337682c66e12aeed1ecaa35c82a2f7ba4fc8df61627d38bdcd6a8c172b9b3600e9249c33bee5c8500400114000000019c64d733646a5b7d4d2996fa1b959b1c8efc7a9f6722e26ccb21c446785af274bbd79d16fc323aff7bd4ce1371d1bb96c994daa799c3df786b8b701c49417b17ecb1318a7528c9ecfcbaa3ef1f9c3058fc4607111c4e0ebce8d58eaa517668f58e12ed0b0d99d2587cdaad3c3e293b296d19ff33e66bf4b70fbb0e1df0d4dfc5777044d3574ee994f13a800000000000000000000000000000000000001856ad4f0f4a556acd421057949ec901936a29b6ec973679d718768b3c3579603269c2528de352b6f67d11f238d7b40a99aa9e5995b74f0b76aa554f5a8ba2e88e8e7d2e9fa5feecfff001c33d4f519d6ad52bd5954ab3739c9ddb6f73023925bb3173d15b77b1f41c59376ea6b6ff11bb31bdd6a411edb11ad6df996dfd5859db522b105fe93045405b320021401014104000500000000000000000852100004500000b7202a2dca9f33105dcd9b62f91b2152cf7d56d6345eda96faf366b76767a3f08f68b5b03ecf019b7d2e1f48c2b5fc505e7d4f54a35a9e22946ad29a9c26af192d9a3f34c26968d9daf8578e31f90d58d0a9375f04daef5396bddff97a1e3d7e9665f761cba61a9b78af6e070f2ccd3079be0e38bc1568d5a72d2e9ecfa33987ccb2cbb57a000100000000000000000000000000035d6ad4f0f46556acd421057949bd12015ab53c3d1955ab3508415e526f448f1ee39e3aa99cd596032f9b8e0a2fc525bd431e3ae3aa99dd6965f97cdc3031769493fef1fe874b5b7f5a9f4fa7e9fb7eecb970cf3dfc466977745a18ce5b453f52af0a72dcd4ddddcf75725ddeeeefc849ddb6b6d889eed6c4b90669deefa91edea4457e9a005bfc7a0feb40bef7ea37ff00300be3b139177eaee3901398b15f5e7ea1ae5a01882bf50f9eec8a80ba100000080a08200000000000010a08a8002280000000044eefd0a6307757d3526fe464cb73196ab6b953d352cbe4649b5ccd919db9f235153372b363ef70ff001263b20c57b6c1d597724d3a949bf0cd2ea7b4f0ef1360388f07edb0b3eed48695294bde8bfd0fcf6a5aff00339b96e6589cb7170c560eaba75a0ee9ae670d6d0c7566fedac73b8bf4783acf08f19e0f88f0d1a539c6963a2bc745bd5db9a3b31f272c6e376af44b2f0000ca8000000000000000001c5cc731c2e5582a98bc5d554e953576d89371b3158aa182c354c4e26ac6952a6bbd29c9d92478e71bf1ed4cfa6f0397ca54b02b76f4753d7c8e1f17f1be37892a3c3c1ba5818caf1a6bed746fa9d5d2e9f79f4f43a6edfbb2e5c33cf7f108eacc95b44f516f5b06cf73925496b6e860f60ddd9199b562fd90f62742b202d5d8c96fe4611328f5e858565ea355aedf10b47d58db6f52a26fb5fa15fe01bb0b69b6be4047e7f88f2e6561a0232797e2549e9b934b00d6de442e84d88a0000000006001002810004000114214010148450028184fdc623bb5d04f48dfe448fbccc7b5652116632df6b962ff22efe46400348b7324f4302dcd4a9b39784c6d6c26229e230f56546b537de84e2ecd33d6b82bb40a39a2a596e693ee639e919bf76a7f33c6d333854716acecd3d24b918d5d2c7566d4c72b8f0fd380f3ae08ed129e26953cb739a8d621351a75ded35e7e67a2269aba774cf91a9a7969ddabd33296785001cd40000000000f95c41c4183e1dcba58ac54d5fec413d66cb25b76836e719e60322c1cb138eaea9c526e31fb52f248f11e29e2fc7f13625fb57ecf0b09374e8c792f3eace2f1071063388730962b1527ddfb14d6d147cab753eae874f34fcde5e7cb3dd52b3f41b2f40b95ade611ea735e7b5fa98c9ec8bcd183140c79997222dccd68e61ec3a863d044c92ff003318944e12b2ba7bf52e862a45f27f99a45f3bf31a6bd08afbf32feb601cff0031e561fd589cadf9807bbf223f3dcadebaf51adf9807ebb93aea1796e37403416217d59150000000000004001000014200400011400018cfdd243df909cecdebb6e29ece56b5ce7ce4be87bddede623ef7a8fb5f96855baf99457f12925b6bb05b1a450001426406a54671935669d9ad5347a7f00f1f5fd9e539b54f2a55a4ff00067971549c5a69d9ad999d4c31d4c76ab2d97c3f4f269aba774ca79870071ff794329cdaa7952ad27f833d3934d5d3ba67c8d4d3ba776af44bba800e6a007c6e26e23c370de572c5d65dfa8f4a5493d652fd0b8e372bb42dd9b388388705c3d97cb158a9aef7d8a69eb26785e7f9fe3788b30962f173d35f674f94574356719c6333dcc278dc6d573a93d97d98ae8bc8e03d7c933eb68684d39bde5e6cb3ee342f96de647a957dc7a58371b8d3e083bf4d760249e9ea61ccac222a4b48ddec487bb72556b48f532fb2679c97d0b60f61c9063d02298b7645be8594a27a99f97234f7ed34afccdab97c863774b0f365d89a7f22f2dcd22fde47e7f70dde9e9a0f880d745aa1b216e56d48fa80bec42bd39108abe5f8900000000000001000008a00080428020008a0000d534ad2bf532a6ef1d4c64934eebed0a72f138ad52d8e33e4d7a5e4edd0c96f6f3308e91be9c8cf9f3dcd441bd35e4cbcc3bdc7daf4342800a80000000a2c64e32528bb35ccf52e01e3e5254f2acd6a7454ab49fe0cf2c2c64e324e2ecd18cf099cdaacb6798fd3e9a6ae9dd329e63c01c7dde50cab35a9d152ad27f833d3534d5d3ba67cad4d3ba776aed8e52c7cbe20cff07c3d974b178a96b6f0416f3678667f9fe3388730962f1737ff000413d208f67e30e17a5c4d96aa7deee6228ddd19724df23c3b30cbf1396632a6131949d3ad4dd9a7cfccf6f4730db7f6e5a9bffc7179df98b590fbf52f2d3e27bdc936fbc6d7f21d05fcac805babf22362f6d5e8c8f70230072b915adbef556df22b95a497522f7db31aaecd3e8ce56ed376f66d0f609a69331a8fe8e4d74376f86584e77a4da2c27749f37a18b5f40be66ba6fc715e670b959637b786c6dfb748e43dadd0e3475c47a1c96f5d0eba7ed9c97fa4c7a116f7fc8bd51d582dbfdc47b7e45e6b6dc7e804b7426c56422800000000000214800a40080000a02020a40000000a180f628e3cddbbc2968a4f9a256fef3e058b4a93eb7d4f2ff73a7a67b72f4421a984dd99b2295ba9b9ca2adf97a742f3dc91feb42ab2f2e46e22939148975654175b6a522dda288000000161194e4a115793764901b30d4aad6c4429508b95494928a8ef73f4764b85ad82c970985c454f6956952519cbab3aa701f0253c968c331cc20a78e9abc62f6a6bf53bc9f3ba8d599ded9e9db0c76f21d6f8bf8430dc4b83728a54f194d7d1d5b7e0cec80f3e395c6ef1ab377e6ccc30189cb31b53078ca6e9d6a6ecd3f91c6f5d3a9ee1c6bc15438930af118751a798538f827ca6bfd9678a62f0d5f058aa986c552952ad4a569424acd33ec68eb4d4c7fcbcd963db5a9ea4e7b731b681f923b3297fbba10babf3045168ae47a22fc092146097899aeb72b6e6d3556bdbc8e39f8c5b9cb2a6f4b743292ef45aea6149e86c2e3e617963652859f434d25f49e87d9ca787731e2075e9e5f08ca5463df9294ad75e47c651941cefa38e8ce5959dd27e9a9c33a1ad5727c8def566bc3ab41bea6c3be9cdb173cb955b15ff005a939175f4d799d193f420d350f5b80d9ea880114000000000080000400000008450004500000a401151791115eccd238d5d78933186ba799c8f6153113852a51739ce49462b765c5e13f62c6d5c33977bd9c9c6f6b5cf2e53ef759c38eefdff0087436a5cad735c577a57eacd97b6a6b1fda55d126b411feb427c7cb72c79f537ed177f805b7e646b45cd84efccbec5d9949cf994a800001e9fd9b704b93a59ee610946cfbd87a725bffc47c9e02e05a99cd686638f83860a0ef14f7a8ff43d9e31518a8c559256478fa8d6dbedc5d30c7dd5001e07500000ea7c6dc13438930af11878c69e614d7827ca6bfd9676c06b0cee1778964b36afcd18ac2d7c0e22a61b154a54ab53935384b468d3cede67b671b702d3e238bc661a6a9e3610b2bad276d93e878ce2b0b5f0589a986c4d2952ad4e5dd9424ad667d8d2d69a93c72f3658f6b4bd75dd85a7342ffe45d9fe47665898bd5ea65b6862f725588f734d6feb4373dcd15b77fa1c75386f16545e88dd14dc9462aedbb25d4d1476e676becf727a99bf14e19b82951c33f6957bcae9db9189976e1bad9bd7a9f0570d4387b87ef38358bc45352af7e4edb1e0b5e2dd4a8acf59b3f50545f4524bfd967e68c4509431d56128776519b4d3e470e9f7d4b95ad67e366a51ee414422c9ddbb6dc88bccfa0e2afa32f3bf9910b722a1a8ddf41a6ff8108a00000608000000004000050004000010004500000a429504652d8c519b5e146a23edf03e1a589e30cb946de0aca6efd11a38cf2aaf947146328d757539b9d395adde8be67d7ecd70f3adc618670b782129bbbe4ac7a8f17708e178ab051a5526e8d7a57f65552bdafbfc8f0eb6730d5f3fa75c66f8bf3da492b73db5237af439f9de518dc8b30ab80c75270ab0d9f292e4d791f3dfbcfcae74de6de119f24edabf32ad15bee445a742ad2cbcb63a4439e9c8b1d8c77b5f432e97d1f41039ee500d20765e0ee10c4f1363937170c1d37f4952df8238fc2dc2b8de27cc151a3170c3c1a75ab35a417cd9ef19565785c9f2ea581c243bb4a946cafbbf3679b5f5bb26d396f1c776ec2e168e0b0d4f0d87a71a74a9c546318ab248dc01f35d80000000000003a671ff0006ff00a7f0ab1b8284563a8ae4b5a8ba1dcc1bc33b865dd12cde6d5f996ad1a942a4e9558ca1386928b566998ec8f5ced1782d66187966f97c231c4524dd6825fde2fd4f2295d369e8fa733ec696acd4c778f3658ed76468c5ee64f4306f537522b38f577f89c8f339dc3fc3b8de25cd2385c24344fe92a35a417538ead9b378b1e1ec8f17c4198d2c0e162db9bf14ad7505cd9ef9c35c3b85e1bcaa9e0f0e94a697d255eed9cdf51c37c3782e1acb96130916db779d496f27fa1f60f9dababdde270ed8e3b319fb92f43f3966f08d1cd3171845462aac924b91fa367ee4bd0fceb9f2b66b8bfe2b3d1d1735cf57d3e6000fa0e4ab6d371a7a22ae44be8542fcefa90afaebaf32114000021480000400000000000054052100004500000a429622a36d934bf3b9a96fd0de9786fe46e335ddbb2aa329713cab2b28c2849357d75b5bf23d88f25ec9d5b3bc57f091eb47c9eaeff55e8d3f8be1715f0a60b8a72d787c4250af04dd1ac96b07fa1e039ae518ac9732ad80c646d5a93b5d6aa4baaf23f4d9d678cb8370bc51816d254f194d5e9554bf06634b53b6ed786b29bbc053ff0022eb63939965d8acab1b53078da4e9d5a6ed67b338dcf7573e94f2e22defc8abf2ea4bdeff009196ed25bbd91601daf84780f30e22a90c4d583a180babce4ace6bfe13ebf0676675b1decf31ce17b2c3e92850b78a7ebd0f5ba3469e1e8c68d1828420ad18a5a247975ba8dbc62de387eda32dcb70994e0a9e0f074953a54d592472c03e7f2ea000000000000000000008d26acd5d33cc78ff00809f8f37ca29edad5a315f8a3d3c9bee74d3d4cb4eef12e32c7e6195d37169a6b74c8a2e4cf66e32ecea867739e3b2d51a38d93f1a6ed09f9f933e370bf65b5a38ba9573eeefb2a6ed1a54e57efbeb7e87d19d46171eeb5c7b2cf0ea3c33c218fe25c5c69d28ba7864fe9310d6915e5d59edd9170fe5fc3b82585c052eec7794a5aca4fcd9cbc1e070b97e1e387c250851a51da10564720f0eb6b5d4bfe1d31c76000706d8cfdc97a1f9db3efded8afe2b3f44cfdc97a1f9db3d76cd717fc567bfa2e7271d5f4f96c8b72cb9fc8477d4fa1edc9972e62fabd75b8feb5237bf9950642bdd908a6c0000c801000000000000000014200400011400100a429a88ca3b9c88fbb6e871e3bf9733911bf755f73a466bd07b24a5dfcc31b5bc5e0845691bad6fcfe07aa9e6dd90c24a9e67369f764e9a4fadbbc7a49f1faabfd5af4e9fc4001e66dd738b383705c51864a6fd86261ee5651bb5e4cf12cf787f1fc3b8dfd971f4945ef09ad632f43f481f333ce1fcbf88707fb363e977a2b58ca2ed28bf267a34b5ae1e2f0c658eefcef81c0e2f32c5430b83a32ad5e7b460ae7af707f66b85caa31c666f4e188c67286f087eacfbfc39c2195f0d41bc1d372ad35e3ab3d5b3ef1ad5ea2e5e31e0c70db94492564ac91403cad8000000000000000000000000000000000000000319fb92f43f3be79fbdb17fc567e889fb92f43f3be75779b6339fd2c8f7f45cd71d5e23e548437233652573df3972f44b4f546257772d2f764beb74f5ea69100608a11948000045000100000000000845000450004000014a6264b63712aadee7212b2b1c78ee7216c6e315ea7d92d2eee071d53c3e29c56dae97e67a19d03b27fdd58bfe223bf9f17a9fcb5eac3e30001c1b00000000000000000000000000000000000000000000000000004dcf01e30a70a3c519a53a7151846bc924b91efe780f1afd6ccd7fc448f7745f2bfe9c75788eb923753d29b7d4d12f79237dbbb437dcfa18f35caf0c03083776691182148a3200400000000000000000008c95400195000000005455a35c8c4cd1b895568fa337c7dd468d9efc8df1f7773718af57ec9ff7562ff888efe740ec9ff7562ff888efe7c5ea3f2e4f561f18000e0d8000000000000000000000000000000000000000000000000000078476814a3478b31ddcbf8e7de77eacf773c27b45d38bb19e6d7ccf6747f3bfe9cb538753bde7637d4d2115a9a22af536f437d5bdfc91f470e2b8d6293f3b98b7d4cfecede660cdd44280c8a800200000000000000008a10a4252009adca4500000000119a76304671f53712b27a7336c3dd35356b5ae8db07789b8c57ac764ff00bab17fc4477f3a4f6598784386675d5fbf52bca32d74d2d6fcceec7c5ea3f2e4f561f18000e0d80000000000000000000000000000000000000000000000000000787f6a187fd9f8baaf8bbded29c67b6d7be87b81e2bdacfd6e5fe1e1f33d5d25fbff00e39ea70e93455ea69d4d951dea7e04c3af15f5db9963ad44fccfa98f0e17927f135b339eefd4c4b4810a4005214080a0080022aa0102a230429950852129139efb949b5d948a0000000a066bf330338b358a56714fbb66cd907e1315a24cca2ada5f637187b5766718c78429f76dad6937e2beba1db4eb1d9efd50c37abf91d9cf87adf9327af1f8c000726800000000000000000000000000000000000000000000000000003c57b59fadebfc3c3e67b51e3bdae51b67f42b787c5452db5d3ccf4f4bf918cf8746a3e184a5614b76edb123a517e6cca3a51773ebc79ab5b20608a100028608000281000455400654625214ca8429095539bb2d4a62f7d76655b6a64500140000119c796860648de295b95bbb6fe99947d4c637e57324ecb96a7461ee1d9e7d50c2dfabf91d9ceb1d9e7d4fc2fabdfe07673e0eafcebd78f10001cda00000000000000000000000000000000000000000000000000000f22ed7f5cd70dfc33d74f28ed828db1b83ade2f1c1ad63a696d9fc4f4f4df918cf879dbd28c5752cf4a490b5d5342b3d8fb0f33573001954290a00020140200001955232919aa88520311a18005139e8179681e9a934db9b32ac8113bad0a5400000c96c62648d44adb1b5bc8cd5ecd3fbcc23b79fa9b123ab0f6fecf7ea8617d5fc8ece757ecefea7617e3b7c0ed07c1d5f9d7af1e200039b400000000000000000000000000000000000000000000000000001e65db17f7796fa54ff00f93d34f39ed8293965b82aaade09c96daeb6e677e9aedab18cfe2f2c8c5a9abf430aaef37e46d82d14afba3449de4fd4fb37879a20608c8a1510a803215ec40291949cc5004299552329196a4400198d0000317ba6174d2fcc37e7b6e15ccfb5545272d35295000002a2151a895ba1b6e6c5b6d63542c6cbeda9d2315edbd9ba92e0dc377a49de4ed656b2d0ed4757ecebea6e13e3f23b41f0b57e75ecc7800073500000000000000000000000000000000000000000000000000000e81dadd29cb21a15145b846a5a52e4afb1dfce99daafd4c97f1e1f33b685db523397c5e35176a49f91a399b5bfa05e86a3ed5796042b21143244455a6a046441844f6290acc455804023315918b323165a9000114002024b6b98adf95cca5f1f812fadbe662f2ab7d2eb5e85315ad9d9156da9622800a05442a3511b20cdb1e86983e5f71ba3b2e5a1d2315edfd9d7d4dc27c7e47683abf675f53709f1f91da0f85abf3af663c00039a80000000000000000000000000000000000000000000000000000755ed221dfe0dc56ad59a7a3df73b51d5fb45fa9b8bf87cce9a5f389970f0c93fa38a359b2ae8a2ba1acfb95e4880032aa5b6842b28c5ee5442ad8914662cac84a40a885448b54c4a42d48025b5b94ca81008b0496c4576f9a2b574d18f26fc8c5537e9afe265a3b3b139dae5e5a68d960a002a05442a3512b289ba2f6bb5b1a57f48dc9beebd791d2335ee1d9d7d4dc27c7e47683abf675f53709f1f91da0f85abf3af5e3c00039a80000000000000000000000000000000000000000000000000000758ed12dff0083f157daebe67673a676a8edc1b2ff00110f99d7466fa919cb8af16abeff00c0c0b53de64e47dabcbcc80022aae4561119510a429208c818335a0a8854225190ac85a4013994ca8100b72c06609fe466cc1edea8ce4aaf4f96bb979f564f4d3f509ff4c0c81174b94a8192d8c4bc8d44ac97ad8db1dbd7a1a96ab91b637d797c4dc66bdc7b3afa9b84f8fc8ed075ce02a13a1c2182ef5bc71efc6dd19d8cf87abf3af5e3c400073500000000000000000000000000000000000000000000000000000e83dae62270e1ea1415bb952b272d35d36fccefc749ed5e8c27c23ed1c539c2bc2d2e696b73ae87e48ce5c3c5a4eeeec7201ec7da799002a20ab45b91992dbc8c196822b08327a18800c34148535128429095622ddbb149adca400b70f4416e59c8330f2b99bdcc2faef7f43392c2fbbe9d4be5baf326da5d22ae5faee4153bfa148b6d3f129a40a42a3512b24eda9b21cd6e6b46ca7a496b6f337197e82e1284e9709e5909c5c651c3c534f91f60e0647fb8f07fc289cf3e0e777cad7ae70000ca80000000000000000000000000000000000000000000000000000755ed261dfe0cc56ad59a7a3df73b51f038df072c6f09e3a9c2ee51a6e69257ef5b91d34fe7132e1e016d17991bb99c7dd4b66aff000303edbca864bd08b72f30063cca4e628a4653164ab000861551488a6a25085642522149a5df52914bd82dc8f62adc0330df5dccdee62f7bf9932222f5e82e9efb73d427b7ea13d56a65592d7d7a14c55f4fc4c8dc40a88546a22adcdb07f4b05d5ab9a96a6d4fc4a5e66d97e8bc8ff71e0ff85139e70322d723c1ff000a273cf819735eb9c000228000000000000000000000000000000000000000000000000000071334a13c4e5789a34eddf9d3695ce59a31957d860eb55f0f860df89d97de59c8fcd73baaf5579b35db433a9e2c44e4b9c98946cec8fbd3879185b405d7463c9a026c0076023642bb75219ab022db52832a22840d444605832554280412ead7be810b5d724c73d882b3077bf9fe66660d26df3f41911172f5d195696434b793e686dd4cc5557d0c8c572d363235102822dcda324eccdb16dde36f81a799b29c54aa462b9bb1a895fa0b83fea8657fe1e27da38191e1ff0065c930741d3f67ece925dcb6c73cf859ddf2b5ea9c00032a000000000000000000000000000000000000000000000000000011a524d3574f74500756c67673c378c736f092a2e4fbdf452eedbf03abe63d9154f68a597e3d38bde3563b3f5b9ea20ed8ebea63c566e18d783667c05c4595ddcf04ebc146ee741f7925e675ead46b509b856a5284a2f5525b1fa67738b8ccaf019843b98bc252ad1b3569c6e7a31eb2ff007462e94f4fcd60f7bc4767fc3588a9df796c29e96b53d11f2315d92e4751c5e1aae228db7bcbbd73b4eaf4ef2cfd3af1ab12c7ab56ec730f2a97a39ace9c6db3a5def99a9f634b9677ff00d7ff00f46bf91a5fb3b327975858f4ea9d8d54497b3ce549b7ade85acbafbc70ff00b20cd13ffcf51b7a09afa5fb3b7279f58b63be57ec973b85bd857c354befde9776c687d947125b4784ff00bbfc8dcd6d3db967b7274821ddbfb28e26e983ff00bdfc88fb27e26e5fb1ff00defe467eae9fedaedae94d27ba165d0eecbb25e25d2f3c22ff00abfc8e547b20cdddfbd8da11d74b2bdd12eb69cf676d79fdafbea12d6e7a3d1ec771d2fefb33a70f125e1a77d39bdce5aec6236b3cedbffa1ffe8cfd7d3fd9db5e5c62fde47af53ec7f2f508aa98fab2925ab51b27f89f41764fc31ce38a7eb5bf919bd4e9af65787ed7d742d9257d1599ee74fb2ce1787fedeb4f54fc552ff20fb2ce1771eefecf596daaa9ae9f033fc8c17b2bc37e0ba991ee4fb2fe1777ff0055a8af7da7d7e06c8766bc310bff00a937777d65b7e03f9381d95e15cac58c272768c5b6fa23df70dc07c3586726b2ba353bdffc8af63eae1727cb702e2f0b82a34bbaacbbb1b5916f578fa89f4ebc1301c279f6650854c2e595e74a6ecaa38f87ef3bc647d93558d6856cdf16946366e951e6ff00e6fe47a7a492b2492f229c72eaf3bc786a69c48a518a4b64ac500f23a00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003ffd9, '2024-09-06 04:44:12', 126, 'defaultValue', NULL),
(189, 'Sleeves', 188, 1, 0, 0, NULL, '2024-09-06 04:45:20', 126, 'defaultValue', NULL);
INSERT INTO `masters` (`masterid`, `mastername`, `category`, `status`, `addmaster`, `view`, `image`, `createdon`, `createdby`, `lastmodifiedby`, `lastmodifieddate`) VALUES
(190, 'Pants', 0, 1, 0, 0, 0xffd8ffe000104a46494600010101004800480000ffe201d84943435f50524f46494c45000101000001c800000000043000006d6e74725247422058595a2007e00001000100000000000061637370000000000000000000000000000000000000000000000000000000010000f6d6000100000000d32d0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000964657363000000f0000000247258595a00000114000000146758595a00000128000000146258595a0000013c00000014777470740000015000000014725452430000016400000028675452430000016400000028625452430000016400000028637072740000018c0000003c6d6c756300000000000000010000000c656e5553000000080000001c007300520047004258595a200000000000006fa2000038f50000039058595a2000000000000062990000b785000018da58595a2000000000000024a000000f840000b6cf58595a20000000000000f6d6000100000000d32d706172610000000000040000000266660000f2a700000d59000013d000000a5b00000000000000006d6c756300000000000000010000000c656e5553000000200000001c0047006f006f0067006c006500200049006e0063002e00200032003000310036ffdb0043000a07070807060a0808080b0a0a0b0e18100e0d0d0e1d15161118231f2524221f2221262b372f26293429212230413134393b3e3e3e252e4449433c48373d3e3bffdb0043010a0b0b0e0d0e1c10101c3b2822283b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3b3bffc000110801e001e003012200021101031101ffc4001c0000020301010101000000000000000000000301020405060708ffc4004710000103020405020307030203050705000100021103210412314105132251610671143281074291a1b1c1d115235233e1244362163472f0f117252644455392738293a2d2ffc400190101000301010000000000000000000000000102030405ffc4002b11000202020201020700030003000000000001021112210331410422133251617191b1a1d1f0334281ffda000c03010002110311003f00fb321084008421002108400842100210840084210021084008421002108400842100210840084210021084008421002108400a263559789713c2709c1bf178dac295266e77f017cc7d4bf6818be2a6a6178766c3e09d6ce6cf70fd95e1072e8a4a6a27bde29eb0e0bc26a1a55f13ccaa090ea748662df75ceffda57009823143cf2bfdd7c99c6299267de7550d26f22fb02ba57044c1f348fbcf0de3380e2d4b9982c4b2a4012d06edf70b72f8160f1d88c0d6a788a151d4ea832d734afa4fa63d79471cd187e2cf650c41f95fa35ffc1594f85c768d21ca9e99ed10a0104020c82a5606c08421002108400842100210840084210021084008421002108400842100210840084210021084008421002108400842100210840084210021084008421002108400842100210840084210021084008425d6ad4f0f49d56b3daca6c12e738c008062f3bea5f59607d3ed14ad88c53848a2d7683b93b2f31eacfb44797bb05c12a0c865afc4ff00fe7f95e08b9c0f35ee2e7bae7319257471f0dee4633e5ad23a1c5b8ce3f8ee2456c7d673db24b297dd64f60b98fe8708fc148ac73491aa970390ba3f15d6925d1ccdd957403246bb20b83a091002b010d048ba543439c4ce5d9016693cc17067f24e0f19675234959f3348fd53a935c4f4eda18407b4f4b7ad315c3852c2631dcec28303fca98f7dc785f49c0710c3713c2331385a81f4ddf88f75f10a324303435c3585d4e11c5b17c26b737075cb048cccd43fdc2c393893da3587235a67d910b8fc17d4983e30c0c0795880d975377e70775d85c8d35a674a69f40842141208421002108400842100210840084210021084008421002108400842100210840084210021084008421002108400842100210840084210021084008421002108400842100210bcafaabd7182e0345d430ee6e231c6c29836679729517274886d2db3b5c5f8e70fe078635f1d5dacb12d67de7c6c02f917a97d63c47d44f3473723061c4b6937ef0db3775cae27c4f19c631efc663ab732b3bffc5a3b01b059438b6c36d4aece3e251dbece69f239691681d3aceca1d50131b9dca012f07f32a1cd22fbc596c644012f2e9d340136416cbbf24bb400469aa9b65ca0db6405d80869106ca86c61a72c5ccab8a849327abca8d47481074402c0151e05be8b5b090cca0e86663548752ea6807dc85a1ad78394eb16f0807d37647662ed2e9d4ea161cce6898b7b2cb4dd3611945e4ee9ec2d260da7ba806fa18921cd209027e606fecbdaf01f573f9830fc45ed34e006d51a8ffc5fcaf08c1948906d302765a695521f95b0d1b92b394548bc64d1f62a5569d7a4dab49e1ec7090e1a1575f39e0fc7f15c2c8631e2ad1241730fedd97bbc0712c2f11a79f0f5438c02e6eedf75c928389d319a91ad0842a1704210801084200421080108420042108010842004210801084200421080108420042108010842004210801084200421080108420042108010842004210801439cd634b9c400352565e25c4b09c2706fc5e36a8a7499a93bfb2f937ab7d6789e3f51d430cf750e1e0f4b74754f27f85a438dcd9494d44ef7aafed17fd5e1fc14c9d0e281b790dfe57cddee73dce7bdce7137249d54bc8b3622155b0080742bb230515a3965272ecb0232693e5125e2fa76504e726044ab40003274dd5ca9630d01b31dd1d235d06e80c2499dd05b27c0d65014225c6499f0acd61172214b596d75b843017912e405aee061bf8ee98ca62f2248d47652e873729d8f7d13699696811ed210166360802d2342985ad78e5b4803ef127e650d0c0d736604dceb2aed05cc616b663402ff00550053693be51006dfca653600e0c73a0f72b4526123296cb06bdd156837e56007b13aa8b24a0ac338ca328dd69a643d81f7048d163349d98bb460d531ae7000974b6244fea8c1b299787825d24f65d1c2632be1aa7370f51d49f104b4fe4b954eabdd4a5b6bea2f0b453a8d8ca1c446a551a2533e87c1bd4d431c29e1f127978936d3a5cbbbae8be4a2ac46c752bd1f02f5356c1b5b87c430d5a03474f5531fbae79f1f946f1e4f0cf70849c362a863297370f55b519312d29cb1360421080108420042108010842004210801084200421080108420042108010842004210801084200421080108420042108010842004210801713d43eaae1fe9ec3b8d7aad7e223a2803d4eff65ccf55faeb0dc1995307818af8fd00fbacf27f85f29c5e2f118ec4bebe32a1ad55e65ce76ab7e3e272db329f25691a78df1ec7f1ec51af8dace2c049a7481e964ec1732a39d0d6ab0734589b1b49557406e6825a371aaeb492548e66eca9cc0873a64f6511241fbdd94c175490223cab35ad75c6da92a4032d2419f74c9cbb02e362aa7a5b7b1035d95a8e1eb57673065a7446b55fa04ba23b2587312083206a83005b7d132abe961872a8b054a96feed4dfd82978a0f712e639923e6a7a0ee553e222f831522a406ecac1d90e56913b7850ca731c9aadaa4d9a1dd24a7fc3622982fa941ed037856524fa2ae2d76272ff00f8ef74cce69b83441ee3b2a3c43435a4663af850416b09304a920736a82ee916ecb650198cb21a48b95868bb2b45ba895a5951d960b65a0fd51837b60531d5a69e54b5b23a80698d477598071a999ae0e6ccc9d42d61c5d67080d132375424396d2ecc62fb2a3e935c5c0434c408165a1b70091a6e360ad2c0402d198eb6b051649cf7173492d75c59c7652cac0006d2749b4ad75690cd96240d401772cd5a8810d6821d3b9d14906ba4f754ca06e64cea1696b9801cb60375cda53406569248d2752b5b2abc59c67b0dcaab2c75303c4b15c3aa67c3552d120b9bb3bdd7b7e11ea1c1f15fedb5dcbaed12e63bf6eebe6e1ce786c3a091b6ca1a5f4406b3a8836215250522f19b47d7d0bc8702f5692ca587e23da39f3fa8fdd7ae0e0e12d208ee1734a2e2f66f1927d12842154b021084008421002108400842100210840084210021084008421002108400842100210840084210021084008425627134709877e231151b4e95312e738c00100c2434124c01a95f3cf56fda10a7cee1dc20cbfe576241d3be5fe572bd57ebbadc59d570380a9cac09105e3e6a9fecbc617876a67b2eae3e1f3239e7c9e111d4e97d4971719249d555ceeab1b9dcec80f204932d501c0124415d2604b9e0b63eecde7750080731d0da3b290263b9d90e21b7fba5012748160359d54b017bb934999deed00bfe299470f9982a567f2a93be51f79e7b00a2be31cd6e5c130d1a0eb81373df3775572f08ba8ded97750a184667aeff0088aa24f2bee0faee975ebd5ac5aecdd324300b5bb42a3b975a8c30f56edf7dc28635ada6054249206bbace9bfbff000bda5f6fe8c635d5299a6ca639804b447e454611ce142b32954c8e264b1c75f656656821cd05a05922b5b102a011dcabb85f6caa9d748b1756a6337258e7012e24dc1eca70d88f87a42b3f1151959ade9a405a0a7b9e2a1e8b1557b4398185a0176b6d555c1bfb92a696ba27058aaf8a01f52836b16d9ce70971ecaefad8615b96e2fa0f8bb49cc01fc92cd31cc2ea4f34dc4439c36f648f870cc473f29790410d7199faaad497fd65ae32ff00a8d6d607343e9d5a6f2ebb5a4c38fd139f9e9300ab4aa36d69162b1d1a4463b9d8825b449d296ff457c23b10ec4d56d1adc8653912e311e14ae47f921f1c7f06ec2540406e6264c98d5749b4c924875c8d7b2e2e1f1d5f178a14f90caf95bb0bb8f795aa9f13c3d17163c54a667e5073dff24735e7457e1bf1b3a9558f6d3e92246caec39981a647f908bfb2b35d4df85a788a359b5a9bc9ebdc46c477baa1aa29b9c05dc0691a294ec86a86101b30334dbfd94369345cb4926c7c055a553a497193b6d0af9f2b88020ee61019b9796e3416b6cb339ed6e7cc449d256cab5409a799ad7c6dbacee6b480e8fee6c3652882b4abbc5532eea71d4278744f958eabaa31f101a48b3b5298d710c39a41fbce26ca688350c4b33cc10264aecf06f5262f8616369ff768b88cd488d3bc1d9799a95c39d90b4df4690a4621cc0435d2498eea1c535b25369e8fb1f0ce2f84e2d48bf0cf32d30e63ac42dcbe3185e2b8ac357e6e16b3a93a2338307caf79c0fd6d87c665a1c472e1eb408793d2f3fb2e69f135b47447913d33d5a1402089064152b1350421080108420042108010842004210801084200421080108420042108010842004210801085cae3fea1c17a7f046be29e0bddfe9d306ef2a52b74886e8d3c538a61383e05f8cc65514e9b7f127b05f20f53fac719ea17ba91268e083a594c6fe5ddd65f507a9317ea1c6bb118a7165161fecd006cc1fb95c67bc901bfbaece3e251dbece69f265a42c98df4dfba3e6005bb9401d1ee6e5465b660091d96a665b20b6632274566e40e3321bfa259786197193b2d547064b79f8a79a54b6636ef78f03b236904ac5d1a2ec55514a83739dcec3dca754387e1ce05c057ae2d27e567b7748af8c68a7c8a2c14e807683477bf949aaca78863721740b13a90b2726fec6b18afc8dac6ad478e743cbe0fb9566540fa2234b1be9ec9749cd6321ed2749693371babbc011369d95945bfb10e497dcb02da60b5ad9b749eca858089b03b5ecaae24139663c298027341f0b433262a3a98b0ed1baac8821d74ccee90ef95a058a8399da493dd08161ae61258eb0d130567e519dbd405caa910ed63df743c1719260ce8848d355af04fcb1b20348b87027c2466009020a1ac2e88747f0841a73014cdee426530cabab61dfe33605650fa8d07472d345f4c365cd22343ba8693ec94dae8750c1b6930b9cf1406d16cc3cacb45bff12de590fa61c1a49b4f955c4552f740712361dd6bf860dc272c8cc7500eeb371a5ed2ea56fdc3e856752c63f0d24b6a697d1db2e8b1c5e055920e84763bae353c4666d3c23691358eafddcb7e0ab97bf33a1a1d67b5a6cd77fbfecab1d3d74cb495ab7da375325b37d0ebb2b3fa99207d7f640600dcc45c6c5209a99fa4e56cfd55ccc1ce2d73cb9861aa1a08a9d2413b83d945539e05de1c2c3b25bdcdcb398b721937d549059fd52728cf1607b2abe092d2e99b3ad64b754875c66ce3527408a753202c065a358d9482955a68b80d67f449350ddc6648b002cb43c31c4bbb5ac7f24a21a5a79a644405240b6d7752bc8122fe13f9a5c2e43ad207eeb0fcae249240d3ca971d723c874cf8520f6be9df5b6238754661b16ee7609b61025ccf63b8f0be8d80c7e1b89615b89c2d40fa6efc47baf838a8d14c3a745d2e13c7b1dc12bf330b5dd0483519ab5d1b10b09f0a96d1ac391ad33ede85e7bd37eafc17a81a69da8629a24d273b51dc2f42b91a69d33a534d5a04210a090421080108420042108010842004210801084200421080108420042179af56fab687a7f0c695222a636a0e866cdf254a4dba443692b66bf537a9b09e9bc01ad5887d778228d106ef3fc2f8b716e2f8be358c7637883cd4a8ed1a3460ec15388f10c5f13c59c5e36bbabd522333b61d82c85d2f97032bb78f8d43f272ce6e451ef3a387fb2acc18937d55a0669321c8a745f89ac69d2a65eed4c2bca4a2ad9118b93a40dcb6f055a9f36b54753a4d2e70d4ec0794fa3c3eb39c5d5cf2688313bb8f60aedc432bb5b85c353652a6d33af538ff00d5dd5734d68b7c369bbd15028e11a5d488ad5c49155c3a3d8794b756739e2bbe5e6f39aee859ebd1a94712fa6e117968169534dae0e06f6362e171eea9b6feff00e116d25f6ff2c6bf25461739a000647670501ee696864c0b795066a542dd48ec80e700e825a375a28d6df666e57a5d0c8890d9cc764ab90499d614b5ce716e5fa1521b9e649b9572a0080d836ba90c2f32491175391ad89d634520e9944f7f08403b34f4899b108000dcfe3a2b104dc00084c6b0e40e3208dd0092d24dccce842b1a6e0c2d1b6a55dc32b491197432a86730bc34202a29b489cb07ba8746780e82354e3190b8ee55435b1d500f740453701f308dd497179d63c2539aed4e83453f2b649bc2021cee4bc38ec9f4f10e243a3a4ecb2bbada013ec375340e4a809b80849aaa55af4ab3ab5221b6b971dbc2e950e5e0e8d07d62ea94eb0eb6b5da0ee914c0a94e24c9163e52e8330a5d59f8eaae68637a19fe456128d3afd1b4656aff007f83ae2ab9d44d32416360cf71b2b34b1e4096c77ecb9f4716ea987041ce6836435bb53edf4fdd69a4e602d7b2cd709bee15e2ed599c953a18fcd95c080477599ccdc09cc3a478eeb63dcc88205f41dd63787176690491720fe4ac8a8a73890037455a6f6910090ede4ea15880d24c65f1d929c0eff8ab103666db763b2a567c9ca6ed06d06602a3eb4188f64b3fdb199b73dfba02ae90011f29557409dbbab082277369d804b790c22d2d94041aaea67cec3b229bef63a7e6a8ecc67a441560cbc8b8ec80db8779a445463c870b83a2f7be99fb4086d3c1f19e98b7c493f866fe57cedb5830444fd74576d40e6c3b5dbc2aca0a4b65a32717a3efd46b53c4526d5a2f0f6384b5cd36298be2fc03d558fe03598d6543570a0cbe839d633dbb15f55e0bc7f87f1ec39ab82ab25b67b1d6737dc2e39f1b89d309a91d34210b2340421080108420042108010842004210801084200421797f587abe8f00c33b0f87735f8e78e96ea298ee54c62e4e910da4ad87ac3d6343d3f87387c3b9b531ef1d2cd983b95f22c4e2abe3710fc4e2ab3aad5a865ce3baae2ead7c5577e22b54356ad4399ef7192e4983162177438d411c939b932ae04682e764a788de494dab50440161aace2bd0389a4caf9b23dd16d55a52514db2231726921d84c254c755a6cce29d32e82f71b05d760c3e1b0ed6530c69a0e24d4a4ebd5fe5454a8d63431b4b9587718a74c0cc49ec4f65871239c4d7c530532040a548687b8f0b8d2972bb975f43b5b8712a8f7f5ff443b135311886d5aa5df0ae30d6bb5a4566c551a0dabcca1521e0c5bbaabb102b8c8e7437423fc93d9486437cc08b13b2e88af1139a4fcc85d36b8bb33ccbb52360ad94e637f6f2a4d33aeddbba8100f781d96a925a464db7b64ba5a43a0f950e9709fbda9560334936f6560c300ba448b1852409630916b5d3400d816d7457008696812548a65b04fea80a4756693da55db4ba46c66e824416eea41c825dd446c10166b4475011db755b1b09035844e674efb00ac2d2275d65010e63444811e14169037572e932761f828b3a4dcf6402812c74bafd821ac249247983b2631a41bdefb85639dcecbdcee8058736ed9bee525fa924c8d815a226016c154a94c5ceb05019e003986b1752d6937062771babe59719d3b85396fa5ff4403a85673ba019205a364cc4d0cd40d47b447de396656073dd41c1e34fd57468e2056a41a4d9ddf40ab2592a2d178bb07bd9429619d46a17917751f3e53a83834c34e56b86668ede16014b0f43142a6209cad1d50eb9ec9d86a8da8c7329381a8deba2d6ebe7f1b7e0b28ba77f5fe9ac95aafa7f0de6b4c873b5893d94734030d6c13a149e673298a8224dc950c796b9c336ba4ada8c07b49e56437132442cb55f91dd2e9bcc0dd5c3cc40d4588547bc402dd66c3b2901924122ce8b8d966273c000cec3bad001226049373dd55ad2e17104f84025ce3a13226e4aa17070b13ec764cacde9cd161b1dd200305db8f9a50170438659bab00580ce8344a904e7982531e5da098d1011f3492ae6a3408982b3e71248f651d61c0ee80d2d703f7ae375bb87e3713c3f11f1182c43e8d6688ccd3b6e0ae435e43ed7d96b654e55b37bf94ec747d5fd3bebbc3e3c0c37132dc362008150986d43fb7b2f5e0822419057c158f6ba95e091baf51e9cf5ce278532961f1a1d5f04db176af67f3ecb967c3e626f0e5f123ea6859787f11c2f14c2371584aa2a5376fb8f056a5cc74021084008421002108400842100210bce7a9bd5786e100e0a8d661c7d46f434dc33c95295ba21ba5627d63eb1a3c0281c3618b6a710a83a5bb531dcff000be4d5ebd5c4e22a622bbdd52ad532e73ae49f2af897e22ae2ea55c5552fab51c4bea1d5c566a8417e86fa05ddc70504724e6e4caccce5882ab501cb960df457262413fec99472878b936d7b2d0a1cd735eeac180171ec364f68a185a4c7b5a2be2a4c661d2d1e3ca662f889e198e2c7d161c3d41fea86de7cf852dc450ad46a55a5433d47ea664b7c8f0b9e7c8f2a7a5f53a61c69c6d6dfd0551c49c03fe2810fa75065aa0ddc155d9714e351cf8689ca1298590c349c49172f8d7c7b2814da1ee73006c6ad9d55a2b25f6292f6bfab1aca7ff3452155a0cbc6e7d968bd6736ad092d8168d3c24527873f217168fd5687b68619e2b31c5af77cfd9deeb5eba326efb2431cfd6446eab90c1cb33ba4331cfc456229348683befe0775adf88387ab18aa05ac3104882df754f8b0cb1b34f853c72a16c618cd692afa820198456667eba4e046c41b25663a7e5dd686431840045d57310244dad0a24546c47fb208300491ff005764005d1179fd9482d24c1b9dd55c3aa77fd554386dd280635f945a646886be3532eecaa6e648d54d36e68ec3ba01a0c3a5ceb1d95c0265c0c09b248b3812013374e6547171823f8405fa5a46aa99e2c64efec80e266088dd4388d729ec803318d4011bea80c2e6c830d8d1580cc419fac6898e774c8daf6fdd008c920660480151c4197186826d09fd044922fb0dd2e1af75e6df804066780e6c1160af45dcb6960320eddd0e61063650c7398fe61161e101a5e195b0c739208b386e4257c46198ca4da2e7d3af1d4c0374fa41b5473010676ecab4a8e10e21adc4b4068b6606fe16335bfc9b41ebf1ff0031a4007e50c6d4199ad07e53b8552ebea27f6569a64d4c2d121cd69cd4a2e49dff001fd9518d2e87b223504abc256b65271a7a025cd1988b7749ab5a448827f457acf1a1d5da4243c3593a7b8dcab9434527d81907fc42b8abd36fa858648bb4dcf84d63da5cdbf93ee80d0f6878cda18e90567aa324b490e09ee70d49b9d948a22ee7c4940656532d107499f2a2a3886cb490568aad04098cc07e0925a4804b6db940279737837b12a2a308bc9b27f496c492372a1f4c3a987349840258c883b1bc1d935a403207bab358011132a1d2449b201f4aa815441906c9ed7b5cf81a0b95ce64668922db27d3a995a7b940777817a9311e9ec58af449349c7fbb449b387f2bec5c3f1d47896028e370e49a55981cd9ecbf3b62abe525cefc97db3ecef0a70de8ac012f2e35d9cdbed3b2e5e74bb3a385be8f4c8421731b82108400842100210bcbfacfd6347d3983346811571f507f6e9eb97c952936e910dd6d91eaff005850e0748e07095a9bb8a556ff006a9b8fcbe4ff000be47571589c663b362dede6b8e6a959e6733964c6625fc4ab3eb635e6b55a8eccea8e3794a6d70e230d8f712c9fedd6efff008974fc3c17d4c54f27f43a34abb398054ae1d49a203f5972a3a9bf34939a4fe0b3d2c4ff004da2fc33f0f9cb8ea4dbe89d42abe9d0636ab7fb2feaceedbc2d232afc14946ff251e49740d41b956934db2eb93dd5aad1e4cbe641164910f04912775a991359c2bd322a0ccd9d0ae7d22785e21a65cec1ba43c37eeceeb63e2400eb2a3a9b5f2d71963b655946cb45b4c0d1f87687527f3283ccb2a0d084b19b53720ec9742a56e1550d8d7c138f5d3edecbaaea342bd0f8ac0bf9b44fcc23a98a13f0c96bc98830174c1063dd151a5d49b2e864f50dddfc292f6b9d6111f456ccd921b041d5a7753256a888ba76743841a4c71e869af3d398d80ec3b15d5c46169f10a392a087dee3eef85e61e0b07318e246860dda3f85d3e1dc59b5bfb15df153e50f22438795e5ce0e0e99e9c66a4b28981f46bf0bac5977d31ab3f7098436bb456a0e05bfa2ece258caa7958a01a1df25406e1716b60f1181aed7e1c0caed87cb53f82ba38b9eb5239f93872dc7b2c2cdcc75f2a469112760a29d5662da72187837676519b2085dc9d9c55454c83a84643965d046e87343c071124a86b835a731d7f2405e9831d4001b1571332c16d6ca8d39dbd06c9925a2220202c0b246b23595574cdb7b74eea0cc4837d4f60ac0e7236117280ab752263bc6c984c125da4f7566b436276d80d554901e03dbd07508061824e511daeaa1d9090d171654ca019613ad95cb4069813dda50101ae363001d49567b402002606aa07559c0582a39d98e9f86880ab89ccd244822c3baa3c348cb9afe36f64c363945d558329108056101151d49ceca3b95a451c254ac29b6a39aecb04cfe6866199549cc4b4c5cc68b139eea4725305a49819cd82ce5bd1a4535b36d0c261d9890dc3625edc9d4f79fbaa5afc390ef8733489e827b24e25af187a5832d2d7d439eaf70dd87eaa594c3486b0586c14c13db226fa45ea41710db11aa53dad0039bf41dd38dc89dbb6ea030971712331161b2b943265ca7ac91ee804326e08d931f4cb5f79807729155a6733489424d34ea326676df65af3b00cc758b785cacc1912220ebb2b8aee608d7c1420d8e707389df494ce502d01864ef659e9d40e1610e9fc569638c07116dc8dd0142c8b1169d141a79dd131e3b14ccc1cfb36ddb52a33c5a2dbca0115000080600d4aab5ed702445f4577343d9ac855700c7491948da1019eb453126c46d0aadaaee58802eaf58f32447fbacae706362609fc14125314e05849895fa13d214461fd25c3290321987685f9e1e33b9a05f3b8003bafd3585a4ca184a54a930318c6001a340b97999d1c48721085ce6c0842100210b8dea5f52613d37c35d89c41cd51d6a5481bbcff0a52bd20dd09f577a9a97a73859a8d2d762aa74d2a64dcf9f60be218ec5d7c6e2aa62b1550d5af50f53c9d53b8af15c571cc6d4c6e32a975579b7668ec06c1622ed660782576f1c314724e793112ecc40faa735c5ed2daad05ae9d525cdcae9758f64ea60399274eeb42a5a9d56e1f2e1b1873e1bfe5553ab3c1f0adcfab87731b8f239512da6dba53b2d469a244b4b608855a2f0d6fc1e39fd2eb51ac7eef82b1946b68d232bd337d17914a2b31c79a3331e746855a81c037291075ec90d38a7566d0aefe5d18ca1c7609a2a87d36d22e1cb048a71fba984ab5e04a2defc947089d842ab847565309f5a83e99eb6f544c0d00496e60e8bde67cad4c8886bac6f65848c4f0ac41c460c9c8ef99bb15d275da4081ec96f24b72bc749d943564a7432956c3f11a3cfc365153efd2dda7c24546ec6cef2b0d5c2be93fe230672bc5e01d56ec3e3a9712610f68a7896eadff2509f864b5e5053aa5aebda37eea2ae1839e2bd0686c0ea6eff004515d85b24a8a159e1c3313316f012515254c98c9c5da3a3c3f8982d186c475d3130776adc5c4cd2c47f729116bfe61726b938967fc3c36a83371a9f099c2f8abe83f918aa65cdcd05a756f90bcfe4e2943f077439233fc97c670cab86ac2be1dc4c891562c7c154c3d66e27a2a02daff79a57a2a389a7cb73b982a513f2bb5fa2e2f16e1f86a4fa7529bf232a3ba0b4f5309eddc2b71733869f45393894f7e45551ca30d111bf65949ea07595a68bdd530e695583569982468550b32936d2ebd04d3568e169a74c8a63280186fe764d902c27ca535cd8cfff0092acd7cd9a083e765240d804d899ed1faab168619b76b6c92eaa018d86e815337b201edaa72c1bf9da147fd4043824b40b00226e41dd34388240dc2025ae21d0c224efb299194c9120da12dae86c930076519c9bb5a2e35ec806546e53301a48d8aa9cd00342a35f701c3303dd5daf8bb448ee764059a5c3343baa22159a329150e5b99be9f5505c1c0662606db950e79739d4dce2c317efec5564fc2ecb45797d102ad42462a93dad8301ba994ca7505107175da0b89fedd2fbaf3e478fdd26953a2e0ec4562452689240b1f03ca82e7e26a9aef606408a6cff0016aa257a5d176eb6fb06cddee766aaf32e25303af94c49f0a41a640747e0ad4d99ce71f29d96a64195cd25b16d821c0be04927c27483a09da3b2a17b5cde964388ba01750034f296c46c1647b0b65b90dfcadaf6ee474ca554a65ed98bfe880e6d5740e91307450c783d42e7bad1568924022c354834452330a0918da85a63b8fc13e9bc9b35dd235bae797ba47547b2bd2ab97a4a58a37bea969cd98653b851f159c99b46fdd20416401237948a9d0e10eb6c25051d263c38824099b22abc875ee7bf75ce189c9b8f016ba75d8f6e627452288a8c21a0f7d962ae20440006ab7933763ae752b0e2eb53634b0082143086701c2b789faa386608b88e7621a090340bf4b3465681d842f80fd95e16963fd7b45d51a48c3d27d56c6ce110befeb8791db3ae0b408421665c10859389712c3709c0d4c662ea0653a624f9f01014e2fc5f05c1702ec5e36b3693272b64fcced80f2be15ea1e3b8ae35c52a55c6e66d669b5326c06d0b5faa3d4b89f53638d5c434d3c3d33fdaa60ce51dfdd71deea559829541cbe509a7589bcf63e0ae9845f1ed9849a9e9087b83019b770aad79ddb71a22b5773892e6e4aa0750fdc2ccc7d7a8d7be95325adf98ec1745a32a3672cb802620aa839496003595ac60ce2c329619a18f6b2412f9e677d965a061cf6b9a5b598620f7558cd4b689941c5d31c2986c13a2a9a34ab35cdac330567021a66098dd20bfb82ae50a53ae585981c4bc164c52a8e1a0dc1fc969a58966130eec354a479bf76a6991667526566e5abd40dedb2af38501f0d8c0e7d017655025cdf07c2c651ada368caf4ce8b72b690cd51d528fff0074ea87d2804b5c1c3ba5b6ad6c2d2653ca2a52719611f2c2730ba8e21cfa4e15f30198ec14c675f8fe1128dfe7fa24b464102ea84071836f2b41c951b9e9125a125cd245d6c64272c8ff00a3b859b11806d68a943a2a8d2375b5d3302d654d3dfbaab49929d09c2e39b5dedc3e2da29d76da4e853aad134dc4931fba4e27094f18dbcb5e3e529543883f0e461b1d240f91eab75a64d5f46d60398385ac9988c30c631b008aad121c3754ab2cca41e83a1f74ca356658646c15da4d5321369da238763f1184a8ea06195da2cc7986bfca562f155b138879a641ada3ab8d183b356b79a5886b5b89a2daa40d5db25bd94b280d6c0ec345ccbd3252bf0743f52dc6ab64e1031ac3468c77717d8a9c5b4486b0cf7f2ac5b4eb318cacd20b01c8e6ead49ac5d999cd76471101c7e57ff0574f473099731f2eb9d3d826b1dd000881aa8aa5ac607bfb4c46ab5d2c1ba960a8e331914e856716b49371e63b2872517b64a8b6b420ec2006f7416e539820c0a85a2083b853d45a5b30c9912ac54af30b8c9d375717b930d1a4a5656cc7fe4a926401acea80b97ccc45fbeea5ae926663c258c8d893af857639a66e50166c1b196850f7490d985398b41cb9a77850f2d176dc9d5c06fd8a893a564c55ba02fca40cc088d1c363bcf757a6d6e2eb329536c91f319bfbacd50b0b5cd65319b584eace34699c2d371e73c4b9c7fe5b7fc7ebfb2c9df5e59aaaefc22f887b3115c328bb361696862398eef0af9624419ff10b3d221a32c5858a648738b64c6fbad52a5464ddb194da5ee2d163375730d69041106d0a85d94000d8690a0971ebbc052417e6bc4b6e4ee7b29065d10401794971304b46a2e97cc26a5e408d101bb387349209034f2a0b980c340cdaf80b38af272dee2f3b20d514e660f790807646c0d2fbac95a98b7f8f955c4639ac1943acb06238887583b550da44a4c6d46b58e076edd962ab5c53766988d966ab8d24438fe09bc3b0f83e215c371fc4860e96ee2ccc7f090b29727d0d543ea3198e225b3aef2a95313d464c806cbd1f0fe1bf67f8671fea5c6f1b8b076a54453fdcaf5de9be19f65dc4b18ca38526a560406d2c5b87f70fb6eb37cacbe08f937c4b649cfbab8c7116049f2bf4733d09e9369ccce03821e453573e89f4c1ff00e8783fff008d53e2b2d823f393789b9a000e13b949a95ce26a452a6e7b8d8002657e9077a0fd26e32ee018227ffd35af877a5f81709abcde1fc2b0d86a9119a9b20c23e56c2e348f1ff64de8ec4f01c057e23c4a89a58bc5101b4ded875368fe67f25f4542162dd9a0210a1ce0d69738c01a92805e27134707877e231151b4e953199ce718002f8c7abbd543d49c4cf2ea3db81a76a2c2753fe442d3f683eae3c6f16786f0fac4e0291ea737fe63bf70bc696e465c82575f171d6d9cfc93bd2343dad61ea3ae8468b256ab4cb609cc7b2555aef314db33b01ba6d2a3470cd6d4c4379d54c06b1b70cf27f85aca545231b2c290acd388c7557089e5b40b91d919aad47e4a605363742d1652d24d635314eb1dceeaa5cead3fdd14f0ed241a84c65595577fa34bbebf65f0f89751acc6539191d0e7017f70a6be2309531546997b9f89926ad63a39bb7d755c9ad8fa951a6960a99008cafa83570fd92e8518a50e1d73755516e568b392c699d6acecd5ee74d214864e963bcec914608eb12749ecb4b402d8161a4ae939c5bc00d83af757e92c2d379170558b481949b4ea1406904ce9b590833d27d4c087300e6612a19730dcb3c84eaa6a61f0c4e12b07619f0246eac00f99da8d56235ea602be6634bf0cff009e94c2ca51ada358caf4cead1ff87653abcccc08ff00485e55aa556d52d2d6647384961105ab251686b998ec181598f3f213241ec7ca6d073b14c7e2df51b49c0ded72a232aebf5fe89946fbfd96753736498322de121c08b8165b5b51b5d8d193254d208f9877096ea65c089820ecb64d3568c5a69d3321bc004dbcaad6a54f1548d37b6477ec9d5a9b9a20c49efa2cf7167016dd09466a18aadc348c3e29b9a87dd745c2e9c0780fa2e0f638492121eda55e972ea5dbe5739b5311c22ae664ba83ce8a9f2fe0b7cdf93b25c1b04137b414c0d6d5b4c023f059b0f89a58b6f3295fc764d6d4735d95b0677574eca50c82c6861320e852ab625d4e8be88635cd7ead2267d939af3264fb85d1c152e1785cdc431b9eb1609a7480913e5566e9593056e838770ce450a5c478eb01c2318794c2f87bbb036b858b8ae3711c5eab7135a9b45168fed3583a5adec1571fc4b19c6718dc4d77d996634583476439c1a39d8773587ef52a8fe97f91d8aca30779cbb3594d7cb13354cd446622db05a68d1f8bc3676c38819b28d6169e17c2ff00aad67e3f15d380a17a8d9827c04bc771218cc7b5d83a430d87a20b69b5a2242b7c4b96312bf0ea39331d4765105a64155376c826e531e6664dfb24101a6675d02d8ccb3416939bbe8873dc0d8007ca80f0eb0067ba96c975c98dcee1401ad7e579a809194498d82ad5e6670f20663f296880ff002aad753a84b039a5d121f3a8ec55f0e0e2096bea86d3a426a4fdd1dc2c9bbf77e8d52af6fec6532dc3e1ce32ae5cc4c328bac4bfc781fba5526b9ce2faaeccf71cce76e553fef5579cf30d68cb4dbfe2d5724408bf956846b6ca4a564b8f4164413a152cb1873bde0aafcc6403dd43e40d6fd96850787b5c2c63b2b87193117593334103bee55c5704c6ad4035c331890dbc154aae03e502c12aa621b4a43ae0eeb0627880bf5193fa286d22526c6d4c5e53deeb2d6e204990481eeb154a8face9a771dd0cc3cc38cbb793a2c5cdbe8d5452ec1d8aa8f98d529cd73ceb7f75b99862e073cebd93a9e15b94cb483edba8c5bec9c9239630ee75ccabb3099a334dd75390ccadcb220de14b690220131ba9f8688cce63709ff4edbab8c2e5707365875046aba229b58436f3790abc9a60741260775382191f64fb27f50e278bf03ad82c63dd52b609c0731c64969d3f42bdeaf937d8d54653c7f14a2dcbfdc6d3265d7b66d07d57d6572cd548de0ed02108542c08421002f9afda0fabeb1c41e09c36a4307fde6ab4ff00fd57d0b1dcff0081adf0d979d90e4cda4afcf38ce2470d4aa53b8a9988799993badb8a29bd99f2369682b53a401731e011b2cf98d677269c39c371a0f75939671949b5a9e29b9262a1362c4f7d46328368e11a792757c497fbae873fa18a87d473b97843970e43eb38106bc48f60b38a6688e7380ce0c06b46a9ce753c252ce0cbe260ecb3621e30cd156bb8bb10ebd360dc79546ebf2592bfc0cab5db95b88c7bc96381c81bacac755f8ae28eceff00ed6181e9a6344329736af3f10e05e6f6d07b2dd9da04c7d14a85ed90e55a4637d0148736909800bda05a135a69ba967698eca4562da99d8d9ca6409804adb81e1df1154d500370efbb9bd8f8f0aae6b8d7b8bc60f91ac518e932a552723498eda2d033160105a46b2bbacc1d16526d26d311f7562afc3cb29730ddd245b41d9610f5772dad1d53f4551f6bb6616921b241f72ac0016fc15497b480e041eca6465300195de9d9e7355d87dd2d17ec92e1616b8d2c9a019b594119209df508419866c154188c31d4f5d23a396a34e863b0e31183273b4f552dc7ba511d472c8293518fe69ab857f26ac4183f30f2b2942f68d632ad33a46b1e218b73594c52c820ba7443710430b481cb072f33fc8acd4b958ba6693cfc3629b6c83fe67b7f0ab46ad3c3517d2c430bea032d9360aaa4efeffd2ce2abedfc37d6a0e6bbfb800de1667d0993267cad141cfa2dfee75d27b7339c44e5f6553d6c15019a7f76362b58c948ca5171310cd984fca0c426641569963da23b4689a5ad90489034492c2d7075c8da158a9c8c4e1ab602bf3e8486f6ecba9c3f1b4b1ad0d1d1580bb3fc95dc43d85ae120eb2b978ae1efa0f15f0a7e53200d9674e2ed1a5a92a676da46624c82364e6d400411d1faae5e078a0c5b852ae7975f40eff25d078731f92ab4fb4aba927d19b4d7659f44670f60ca0e8256be1fc27e31c7138f270f8161eba91f3780b18acf6996906fff00909d57889c4d0e5be32ea5be544d49aa45a0d276c7f1ce30de2d569e0f0cc14f074cc5223a4fb9588d4632b7c2e2994e999e8ad4f47ff0a323441111b8d150b79e62b1772ceb0a23051e8994f2ecbba9961235f276497b4824113e635534abfc1bcd3ab53361c8e8713761ec551d52b07035343f2c6ead656888869ca2dac233b9ac0e37bcb1c0e847752f07249f94e8f68d0f628655acc754a6ea21c5d7803f35493bd782f155bf2572d3ad55869b1c64f501a84faefe611840f0f0cbd5a8dfbc7b7b0fdd1969e0a8b5d4dc4e22b5e938082d6ee4feca28b053600c26424564f21278ac50c68e5197653e559b4e4820413b2871cc4e6f7ba66686968bde2c56a6450b40f98117d4a5546c9b9cdec9ce2dc939aed58ab62836763faa128a567e4740d3bf6599f8b0cbccc689388c5874911dbdd6139ab3a5c618b194fc23551fa8fad8c35890d99d804a6d32fbb8c937857a4c6e805bd968a749a0824c81dd5526fb26eba294a9973b20d1696526b5b71707f2435cc6b41027bcabbaa374d40b586ab44a8a365e1cd04445e60a9249300198d07755e603246674db5506a0710d8758e92ac40d8734492009fc504cb4c4cea6525d5201395c1bda55f9adce43811bc4a58a2ee17e9ca6fb2ab800c03383e425f3bacde0779525eccc4019a0f7500f7ff644dffe21c53e3fe48d02fb0af977d8d759e2b532913cbb9dfe65f515c9cafdc74f1fca08421645c10842005f29fb51f41babbea71fe1fd2c68cd89a2c1af770f2beaca080e0438483a829740fcb8691357251a6d6b1ad1cbca7e6ee7dd3f0d8ae5b0d1a74cbdee20123eef95eefed1fd17fd2f12de25c3595060eb13cc6531fe8b8e847837fc17cea963a9e1eab41cdce008a8f6efd96d19b2928aefc1ab138ac3f0e696b5a2ae34fd5adf7f2b9f458f738d7aa4b9eed49d9530f49ad7173e1c4adad60ca4eddc2da11f2cca52258e13fdc6f4c2b82734b4fd114d80bc0b193611a95d5c160c532c7d46873f48d9472f3478d6cbf0f04b95eba2b81e1c1ce0fa8d86ecd85d86b43440d151a5ae1a92d75ae9588c59a6fe553a6e7d4cb30179539cb9656cf6a1c70e18e8bd563ac41b7de317514dfce6ba9bda446e7759e9e2ea0ad96a0be592d1dbb84e7b0380ab4ccb40b3468555a7d321497713362b08c8825cd23e43332b9adcec7165510e06f217a0690f696553048b2c98bc2f3410f0337dd70d4fbae9f4fcef8de32e8e6f53e9d72aca1d9cc2601b9fe559bf293abb63d9400f63cb6ab72395e9de40365eaa77d1e3b55d88a80ec2fbaccf78cc06a02d354004bb41bacae1267650c22ef78ae0523acd9c356a7b710c6d2386c716971bb6b9d0f82b0b5a1a7dd6b664ab4f9751a1cdf2aae2a5d975271e8762ebe2d9cba25c3e1da60341d0775a002cc43797543f36ad9b058f3bf06dc8f69ab85d01065d4ffd94d36b30d5e9d7a479943c3be659535dfecd134fafd1b2ab18fa62b52398030e1b82a8d96883175386a8718ea8e63037940e560f2a6b3d96a6c1d6df986cb58cf74fb3294356ba3339a0881d337850d36b9b0edbab3fa5e371b90aae68a82d66feaae50c18ec00aade752195fdbba66038bb4d3f85c7cdacca9b83e56b0d9209d3b05971fc3d959a5d4e3303af759b8f945d4bc337d4e652666b386ce69b2ce6a104b86df9ac1c3f8955e1d53918905d41d623b790bab89c2b5d4f9b8578ab49db8d14c6561c68a1ac1de07652daee6892608d8ec901a72dad0140738f4999d88dd5b65690f354ce6635af91a382ad2e63d829979b1b003fd34b151d4dc66e60d96dc351756a66a748eeeefe4aa49f845e2bcb21a4507075563793504666e855c52a78761a95ea16b0196d323a89ec3c28a05b53356c6d3c986a6d2647caeff759e9bea636a8c456272811481fbad555bd2e8b375b7d8c19eb3dd88ad19aa19f1ec148273e82342ad9491d2447eaa85e0381d276d96c9518f659ce11948e9d4c2a3ab10096bad0b3d7ab90c0311aac188c6364fb58f75572a2ca366dc4e30b66f78d06cb955b18e7becefaa539f52acb8d80556e1def3005d6329366aa291535093275d95daeb492240dca73306e9fa48298dc28cc0804850a2c96d0a6d60d9d2e549c4c03d43e89bf0805a7f25070dac0b68ad522ba2831102019beaa4624804932ac70a6f1a7ba8f86009fca13dc3441af246be4850dae645c91656f870058446f2a3e1b5d3d936344fc4bb7322f654189faf92aeca02245ff0065230d7195a4dd3dc3440ae5b25b3f50ba7c0b82715f51639b87e1b40bf3101cf3f2b07725734e1003a8b2ec700f51718f4ce2054e1d8b2d69bba8baec77d143c89d1f7cf4a7a670de97e10cc1d17732abbaab55220bddfc2edae27a53d4d86f54708663288e5d51d35a94c963bf85db5cceef66c810842824108420042108056270d4719877e1f114db52954195cd70b10be05ebcf4056f4af1138cc282fe1559d0c79b9a6e3f75dfcafd04b1716e1584e35c36ae031b4f9946a8823b790a53a643567e61a74b33b75d1a54985a29eb50e9feeba3ea5f4ae33d29c64e1aab4d4c354bd0ae44078edeeb3d0606127ef9b1fe16dc9cf18475d91c5e9df24a9f4330d876d1106efdcad749d9491244f94a6b81124ef0acbcb949c9db3dc842318d44d2d31a1dbf256ab459598592e691605b62124132644b85b29ee9ad73a00cdaf6dfdd553a25a4d5330d46622882da6cc8c61bbc9b9f65a79acc3550c6540e9bbd937f709988a431348d3cc729b82362b938aab470d57e12975624887557eab64f3d1c928fc277e0ecb003483dd5398d17690aeccb88672ea0ea89e9310b9fc3ebd0c3615b443f3381b8171f45d0c8090f0f227be8a8d6e8d13b49a3262e83328a72e044657386be256275334c96b816c7e6bb6d7b6ad27662499d563c561aad57dd8039ba381f99757a7e7c1e32e8e4f53e9d72ace1dff4e654607037d468b0d4696d8812b6542e6bc97332b86a3b2cd5c07c762bd3ecf27ad19a4b1c674ec98d792075586e92f04ba4a8e6465137ed2ab65a8e90aa6403241ec8a548d079ad8701ec997507685616d72d71f3bad742b43b3079b6b7d94e9f646d7468350d6654c4606ae57eb55a4dd9eeafc3835f86af571354749df525677839cd5c3b8d2adb386e3b208a78e2ca4e068629a2324d9fe42c9c5c75da3552cbeccd15053a94835c72cfc8e9d7dd672c73402ed0691ba661b9c7114f0a434b808322c9cf34e89761dadcd4e9824b95a33faf5f52b28fd3bfa192490411e2db2904c11680a6a61edcd6389074854b830e242d4ccad7c2d3c4b487b402162c355c5f097c3a5f8627ad9b15d16b8eb109995b5299639b20ed1b2ab8d92a5429e2957a631585eaa66c5bb8f759ab12c032933b00ae701530755b5f03532bc5f29d0a650c653c4638fc56169b2b98b1b0f70a9294a2bad97828ca5dd2269b1f4cb5b8ae9b6a3e600f74da42a730d263cd4a263a9bfba755c1b310c2f6d4323e67387537cf94a7547601870b41ee6e2ab341cc0400cee7caca3252d2efc9ace0e3b7d782bc4f11f178bf84c3f4e0e94670d367382bd390cca3f14ba54396396d369b9eea6a5419226076ee574a54733765cd6816372165af8a6b0483aa455c46407be913a2e6d4a8eaef21866faaaca745a31b195b16e79e9f9a7655187797667b75d1328e1c34773a995b28d088924dd5145becbda5d19e9e12a3e5d22d75a9d842c735a61c662765a608a64306576a8cb9da0c9306e568a2919b931230ce0e0730ead148c2ce692627b27380106d02daa8a825e4e6397bc58a9a22c51c3b25a08021b255ce1da5c3a2db90acfda401332654996d80074364020618c4000c0913ba1d4099801c41d026b1ad0dc8601b89fd1519ff004771b213655b41b908d4c692a5d8568a9909826c6eaf960e97b89400e195c0c7ff00b74422c51a22c034445802a792d6e6869ef29ae2e6ddc359d47752487323aa22f03709489b33e46961b092105a4b6ce1e13b341163dcdb59522c3344902dd1a9dd2859f46fb19e87f1664ed48e5ec7a97d4d7c87ec94c7a83142089a20afaf2e3e55523a78dfb410842c8b82108400842100210840733d41c0f09ea1e115787e2e9b5cd789639c2723b6217c2b8b70ac6701e2353038d6163e9ddae8e970ee0afd10bcf7ac7d2f47d4fc24d0cac188a47352791a1eca938da35e39e2cf8ab1f6316fd0260226264a56270d88e1f8ca982c533975e9b8b4ab35f98d8c7bae56a8f4e13b439a4cc00095769868b004da4e852819120ab0b410e82154d07b1f0201d048f0a5cda6f879635e468e3aa5037001ded0ae1c32c0317981b2068e455c5d6c3bdecc5b8493d3483608ec5a57470dc558dc3b4e2886bc8d378eeb2f19f8a753a7528c3a98f99c07537d95b05c2b08fc287baa735f507ced5bfb5c6d9c55353718ff0093a1518d75215699ccd689006e9b483eb533cc196f620aa6168d3a0c2c639c46b04a6b190e25c7376f0b26fc1ba8b4ed1cfc5e098e686033522d3f79729cc9395d208f982f5158671a104dc12b9988c23eb173dcc6b5e0d8ff0092ebf4fea31f6cba38fd57a5cd670ecf3ee1d5a41f0a1ed112b5d6a4438c8beeb1386cbd23ca160024b8ea9d46a0160a900dff00250c2d6fcdaf82aab44bd9bc7543a6c146228f3c30805af65c3c6ca986ac34235de56c774b66c5a3f357eca742e9634b1830f8d190bbff009969d7dd3c9f816557340a94ead98ecd3216577f78169901d682a6953c46040340f31baf29c7f30b27069dc4d54d355235b1cfad4f9ec39eb1b649b422b5265525ac8ccdf99aa94abe6a6f181aa5bbd56bb51f45349ec6611b51f5492e77ca35951175d7ebfd13257b7fbff6436916be1c2fa47753ca003a16926ad5a6d7571fea1e8ef1e5454a51d794383af216d192662e2d7628400dcc2f3a14ac470f6e35a43fe6fba46c9a244168bbaf1d93e9c5b771d55aacadd08e1f5f1f82a2ec357e1eeab5dbfe9558b1f7599d4312c7b9f51c1d5aa1ea83f905d9f8870a36a994e913a2e73de1a0971122e4aa2824ecbb9b6a8ceeaa5a3297904eab9d88c5e51674908c5e2802487485cc73f3ba5d71afbaa4e75a45e3118e73abb810613e9b1a1d0d658d9229eb006fa42d14dd95c359d1523f52ccd9472b4491a774fe737669045bcac62b9654ccd77d5579f989eafa95ae48ce8e80acdd053d373baaf333d32d6b05f7588e22e25c23c1502b0cc413b774c90c4e817b080081984c9076f6552f00b481a88202c5ce126083ec7b23e220413006c99218b37d47817b11a8506ad9b97588d35588e2489119a458955f8a3da23b29c90c4e80ac09399a1a226612dce0241f9bb2c7f12604d943b10799703dd464862740d46e5300c58cce9f455cd6718363dd62f8825e25d7235f2a4e21b0e8998b1ee992189b4bdd198ba4403aee86ba5c1c2409bdd6138804824937d0ee818901b066e992189d10e044871daea33b4c80e024c0bdd6018bd60c0222147c4c6521e64a64862cfa8fd8fe1f9bc4b8862b3472a9b1b11accff000beb0bc17d93f03c470ee05571f896b99531a416b1c221a260fe657bd5c9c8ee4744154410842ccb821084008421002108400842101e43d77e8ea1c7f01531787616710a4de97305ea0ff12be3b2685575178735cd3024447bafd22bc07da0fa31b8ca3538c60006d66366bd38f9c771e56538dece8e1e4a74cf9ad3713127bca608dc2c6ccd4886d5875a33693fc2d2c76c4f885ccd1e8c65630b89102745604ce68faf7540615819049373e541a0c040106e7420855a1468e143c301198924175bd94976a0496fbecac1c72c0032192965695d8c6b8c92d33689ee9ad71363f8acc5cfdc930260ab82475169245ee34424d2226f709756936ab61d2237054070110446bf44c1245f5420e463686724b69969063dd722ab6e46583f82f535e8f39901d94ec57138a51a60170245427a9a4466f2bbfd373bf924799eafd3affc91ff00e9cbb124efb2a40693985bca7b407dde488d92dd722d61a2ef68f309a44b44cc2d23105edeab8d96404b4c8360acd30d3981036529868d19cc48264a3e21c046e424e6b46fa5d11f7413e21081c63110e6134abb74a8d5a29e229d663598f6722a03d155a3a49f3d96305c1b0248eeb4d2736a332d5687b08b85128a916527137f32a8c787635ed0d6364968b10b3fc40a8f2cc3b9cc02606b9965152b6162901cfc21d5a6ee6fb2d787761dae38fc28cf4db0d6b08833e46cb27aeff668b7d7e8d4e2caa035a0b6b16cb987f54ae6169973888d0794a757a952abaa55606b8fca770975ab1a4e34ab3ccb44e788bad14eb523370bdc49c462796c82e9ec572715c40ba59b44120acf8ac5b9ce20199486d22f199ce33d8aaca6de91318d6d957d4350c011e155b4dced02db4f0d98dcecb4fc2b04c5fb0855506cb6491cf34cb0c48b1db75391d121fae8ba1c93331a8d8297e1a0905ae2607d15b023239d90c905d3202914c9b971fc1741b426e0136d10ec3753606a34f2980c8e6e47cea47d15853201bbada05bc518b40b6851f0c330839a6d2026046473831e4dc983e54b5b508207e6ba3f0c1ae8235f0a5987063336490980c8e764716cb647baae5a99481dc15d4761c10eb4806f655f87325a1a49d2130191cec8fd66ca0b2a58989d42e9328b6329173175070e234d350981391cf8a841bdc77501b526c56f3872299e98ec86d02649223328c06473e1e46a6dd8290d78261c74bc2e88c292d360626e0a834c0821aa7019187254205c9b2f57e83e23e99e1bc44d4f50605f55da53aa7a98df76fef2b8469182001aa1d41a44e51712a30b191fa870b88a18ac2d3af867b6a517b41639ba109cbe6df639c4ab57e198de1b50cd3c23daea67c3a6df92fa4ae592a746e9dab04210a0904210801084200421080108420050402082241528407c47ed1f0182e11ea81469530da58867363fc5fe179e63deca869b8100e8e36057a8fb60a4da9ea4c3c816a1795e27058c36c2e29e21df23f58f755e5e1f6e48e8e0e7f762cea878224dbb7957111add66666a44d37d407b11ba735c0981bdecb8da3d28cafb1b9e63349bdee82e06f3263b2a874b6c6c50a0b972733498d2c158101c65c645efaa588dff000533613a6e021039a7201793dc764e659c5b75958e25d3abbf559788715f85230f432bf1077d98ad18b93a452738c165235f10e26cc100d60156bbbe5a7fb95c4e5e22ad5756c43f9956a7cc4fddf014d168aad96bc9c5004baabbeff84e61e73011d30608dc2f538386315f73c4f51ea2737f63381d2409b1fc522a37a8982411f82d9572df6777d8a4b9a5c61b0d2ba99c88cbcb24ebf556d7616ee9859d5d326557243b6f0a28b5950323b4170ae2224820f7ecac049976bda14e501901d28414305d02e3b84d690c1b02771baa861cd3042635ad7ed00683ba9035a4c4441efdd4620725ff0013863cbaecd4459fe0a8154d212753b6cb3d6c506d324992a1d56c2bb2063a96258e7369f2f10db969758fb2e7e371b53195c8d8e83ca4d4a8eaae01b774ea13e9d3ca3aa1ce9b95825e1746cdf96529512c749324efd96ba5464b4b818dd328526e6b80e306c16a0f6061269c0b40d56b18d19b9035ad6019419888952d6b7349804eb05579ae3d56203a6cac497119499cb10ae501c690ea2058c9b2814d860b5a048d5db23983aba753690afcccad03248369520a35cc03347d2159cc07504101599508639b96444ebd955ef73bee017d01fc90146da5a5a6fd82b9617107b78bdd43dc5ee04f51222558d47101a5c2019178404169170dfa9b2ae5734939458ccc2a97173baac2f74364c975a0690a016a6080e6932d8899fcd58b185d99d1060d9c96d6991113a4c2999a701f12341ba02c5b2fca40b48d75510c88220cc992a2465399d17df7504001d79316405c3693865bfd0eca1f4db9490f13966c529a61cd936d5434180731b823e884802649916ef79439ac2e0eb877602d0a81c417dcc405786b8696063dd401ac6b9a1c403b6daa8cc01690d2245c44aa64696b4c8cc45d0ea6c0dcd2237beca41f43fb1faeea7c5f1d419192a536b9d22f698fd57d717c7fec828bddc731759ac9632880f23404cff0bec0b8f97e63a38fe504210b234042108010842004210801084200421080f947db1f09accab84e32d6b9f45a0d2a96b34edf8dd7ca5ee6b9a06b3e17ea1e29c2f0bc6387d5c0e3698a946a8823b795f9efd65e8fade94c7e46e2a962283c9e580eeb03c85bc27aa329477660e19c45950370f8c05c0fc8f985d00e7527647b5c0012d79162bcb0aa0113769f982ef70fe205c1b83c555269b8453a9b1f0b93978ab713bf839efdb23a2d306352409f0a4444b6e6353ba5be93b0cf0da8e07704760acd2205c74ebe1729de98cb8d6f7d9403b6a772803736decb93c4789bb3fc2608973c8873fb2b420e6e911c9c91e359487710e2cea64e1b040bab7df7ecdff75cfa140b6ee399c6e494cc361db866099738dc95ad8c63c66cd33f9af5b878571afb9e173f3cb9656fa294a8f3225a491b15ab2f35e1f48ce300ea6e82a01fba4d6a991b941848cc6b0ca1c5a47de06e56928f95d99465aa668a715dbcd6c653adee14e4616c08b6ca792facd388a34c31ed30fa675a9e4794b273b055a6249fc95a324d15945a60ea526f1e6151cccb6222f601436bccc9be89a0820699b632ac40a20b48b4c77d428c85e400606a9994ef2efdd544389edb90a01620481a2996651368dd21cfbc8d164c462a1b20c46ca1ba252b1989c58169b05cc7d5755758c01baa54aa6a132a013331a76584a4d9b28d1aa90ca0003dcf75a29911b0dd62639cd166eeadcd933e2e14a9510d59d2e7099b4cea8159b16375cd354c18d4e90a79b78d655b32b89d115c476dcdd5862ac091a5a0ae58aeeb6a8354e5b0d533181d238a391c1c4779850dc55c38169bdfcae70ac6f2499b20563bce92998c4ea0c45acf04468a0e264482091b12b9a2b927751cfd0c10998c0e91c4480d33f4287623602cb9bcf8110611ceb891ef2998c0e91c4348fbcebf7502bc006224113d97379ae220cc9522b9b0c9aee999389d2188682d0ebfd140aec152ed0b9bce7e5f94e9aa9e741d0a66462744e200d4822370a5d8a27585cde7b8181266d0ac2b937831de133189b7e21d906921545720927bedb2c3ce3060c28e7b8da75ba8cc9c4e81ad702f011cd25920489833bae7babbc3a4ebeea0567010e170998c4e89ad1f2c403b0473e011688d560e73b2eebd6fa47d05c57d565b5daf661f041d95f55c649ef0374cc607bafb16c357185e278d7b0f2ab398d63f6716cc8fcc2fa82c1c178360f80f0ba3c3b02cc94690df571ee7cadeb9a4edd9ba54a810842a92084210021084008421002108400842101e23ed2fd5eef4ff000a6e0b035b2710c5186903e46ee7c1d217c22a53a956b39f52a39ef7192e75eebdb7da5d4ab8bf5b62b9aee9a2c6b1807612bca36882eca0dcb80b95d70868e794b66114445c01dd5e9ff6f353a80ba8b8891a107b85b8d16b481981b92aaea2c800b625aace04291b3038e0dc983c79cec37a5546e3b15bcb3955b96e195a64b4ec42e11a2723b0f584532641ff0002aadab8f7b7e0f1354b68b4dfbb87bae1e4f4feed1e8717aba8ef669c5e3df8973b0d81b5316755fe1187c17c337e5064492569a228e1a88cb4e04485538de64b48ea9b42ede2e28f1ad1c3cbcd3e576c87b4121d04781b2ab5ae6bad0e034522a39afb37f1504c8cc16c6249c3978b9f71dd5e961db4fadc06931d951b55d4dd69950eaae7fcbf594036ad66b6b32a536cbda65b3a24567b72fc4b0cbdd7af4c6fe5559489792ef97bab3de5950b98ec9220ace51ffd91a45dfb598ab556b5bcc699cdd95f046ae21e2229d306f51da05b6a70cc3340c43ea114dda51882efe02457c497c53606d36b34633e50b3726fa2ca296d9af174391841570d99e69802b0267ea3c2c0310d753ccc740ec9985c79a6f635af02ab6cd2ed08ec5737141ec7f39b4cd3a752f97b1eca23c8d6a5d969f1aee3d16af8a91132b212eaa4957651354973a62745a69e1e4781d94ee4575132370e5ce84fa786001b498bae8d1a34e2d07a87bab863339dfb01a2bae3455cce7fc393323412a7e1632da2e42dc29868225b206ca0d369a725d378055b1446473fe1c036d82b7240306755d0e5d26fde2332ab5b4c588da546286460387b47947227cf65d0c80e8c250288683f34c9d029c50c8c0da13032dca8143505a001e16f14fa6cdb83d9585101e45c83a593123239bc969886f8856e598b4882ba1ca020910ace635b0328b192a3044e47339048d098b1f75069476002e8b43038b626da040630b6c36d6531191ce14a5b2a0d268db45d2e54170dc151cb6fca087c8d930191cfe4b49d35b050685a234d0f65d21449709207ba834328102fde364c10c8e7fc3383a030d943a865b655d1752711245e248472e1c465197684c064739d40b9f6049d95791119bf45d2731b9c4ba24594728000cc381d54603239a68931d1f885230eecd948cab6727a48062da2037a85f69d54624e466185cc05ae6d2ba1c2788f11e058a18be1b8aa946a0890d759c3b10a1945a2334469641a792c0dcdc7853822323f457a5f8fd2f52702a1c469b0d32ee9a8c2672b86a2575d780fb20c4877a7311840d8e5621ce99ff2ff00d17bf5c9254e8e98bb5608421549042108010842004210801084200421080f80fda213ff006e31c3dbf75e71a041b92469ecbd27da435f4bd718d1501667682df20cdd798e6b03490e27dff55dd07ed472cbb1a1e017113008990a73976417ed94a51a80c9d029ccd21a4990240562a4d7731e5c209045a7b2661eb023e16ac023fd27f6f07c253aab5d1302ca9521edb0855925245a2e87b43e96665407a6c67ba900d52037e6f0af87c40c735b45e1a714c9e5977df1d95f0cf149e595043c8bceca212f0c9947ca1f4e8b4b48a821c122a45330db81bab54c43dc4b6d6ec9618ea8e81f31d602d4cca92df713a76502b3418736db42bbda6978d921eccc72b1a5c6600500bd4ae010c6824ec13b353e1ec152b3b998a77cad77cb4fdfb94b754a7c3865699c59041791d2cf03cac843834bdf21aed1a4efdd64e4e5a468925b635959ceab9ea9397724ea97887b1ef0ca32c9d0c6a92fa9509e58b00dcd1120acd88c4344d3a3a7f9011f82a3925a45e9bdb22b56caf736face59b02974e939e439d713a77534980438dcec16da3467a8dcf6848c6c4a54452c339c0920d8adada0584803dfc2ac880003a58f74c6d5804bc9efa2dd248c9b6c29d3218e3941913eca5b49b9faa4754c764bce0080d88b19ee8356083001cb652417cad6b8021d26672a921bcbb680003caafc4864c4101d2abce2e39400090744033234919ba81776560d63ace119811297f1048b6c2506bb8c02f163b8420692ccd2d1b7656b03736076f2922a88073474dacaa2bbcb6e60f841439aca6e00db4d54c00e26d363092dac4c836eafc547c439af073418d7ba58a1c329b006da99438026cd991d92856fee104de7ba8352e43498234403dc036a001b322d680a80430b408ee4a8359a1c33099bea966ab3993333b14b145f335b12db8dcab071044b772212b9ad01a409244d90710d739d969362c964d0d7b9edb31b014f4970b90901e399f2c81691f921955f06dd56012c50e0182c044899ecab7ca32cdc4193aaaf39a092e9999851ce1943498b6880bd4637a5e5bb9df554e9825e24f6eca1d53a673903c0d954d5696ba5e4970b185008743742449b7b2a010440748b02a4d4b8cd368d155ce8227507bf75048d6b880580c1ec994dd2f240246a2566151b06e0db54de68266237175299147d67ec6dd381e2001902a37f75f4a5f3efb1fc20a7e9bc462c11fdec416c476ffd57d0571727cccea87ca0842150b021084008421002108400842100210840781fb4ff004656e3f816711e1b4c3b1d85065805eab3b7b8dbdd7c31d55d4dee63c1639ba83685fa73d49ea0c27a6783d4e238b92d69cad6375738e817e76f54f1e7fa9f8ad4c71c151c2b5c7a5ac1d51e4eeb683746724ace5f3c93aeba10ac2b10201883659f93a0de2149a3246c1696ca521fcf73a0ccda148c49f9838802e0ca47c3d8785068188b668d12e4290c7557021cd24381906745dbc362d9c569f5ba314cf99a0dea01bfbae0fc3c5c9fcd148d6c2d56d7a2e2d7b2f2155a6593a3b994547921c7ea1388187a5cc76b096319471b87f8b600dae07f76983107b858ea1c462dc5d9e18d3d4f3a7b05ac7935b339437a18cacec7625b429c1738fcc4c01e4ad4fc4330745f430c73bde21f508f9fff000acc2ae5a4dc3d1a6d027a9b177792a5c69d1a41d1350d80516e5f826947f229cda54e997d59026cd9d3d964e73ea870d326a1c2c02b97179355e600f9b368df6f2b156ae6a014d821834f2a8dea91749ddb0ab59b9053a421a353bb925aeca66148638e825329e1dced9529b26d1663c66d93be247e733291c9748244c852ea6e124b85b4574da2948d1f107481310a39e499b831a4a40a36d458e92a05120820df7536c521e6b137cd27741ad31163095c98247e12a0d122c09dd2d8a43b9f2ef733a20568702749849340c00012614f262e6e12d8a437e21b020da3bab7c44b8667137eeb38a3b0d148a4e3052d8a4385607bdbb153f1169da3bacfc913a4a9148e6fd6e96c521ff1194d85ff00450711a4104cca48a2336d10a05091622dad92d8a469e78bdc5f750eada0912922844d957926d067c29b64521ff12235ba3e26f378d6523924b62f3dd0683a220ca8b9134870c411024ca815a7f04ae4b81813f8a392e903e9ee96c521fcf3323f32a05537d08f74a141c5a4928e4dc0374b6290ee7491706d3aa39c32992db1ee926896da62c814cc99363df74b6290c35ed25c2fe74502b830a9c9bc0768aa68db5dae96c52186adc41d54738754c47855e488906150d27091ac0d428b64d21c2b891260810b670bc0e2f8c62e9e130345f5ab3c81002e78a1a1cd1f45effecffed0687a67fe0f1dc3a99a151c03b1349b0f68ee7bfe4a2d8a47d7fd25c05be9cf4ee1f87032f68cd55ddde752bb49385c550c6e1a9e270d51b568d56e663da64109cb07d9b204210a00210840084210021084008421002108407c4bed738c54e21ea3a7c2c18a18364ded2e3acfe0bc272c5a435b06d2bd5fda43df53d738dccf2ecad6b403b01365e6498990e3f45d904b139a4f629b49b22c6e0c42834c44f7ff00a56803a8100856221a5cd06d17d15e8ad99cd1b36e419ea10aa30f7046bb485ae5ee804125a6c255402486cc024de54d0b119041701aaa72f34691bdf55a1d311205a6ea4ba333ad983ad25450b313a954a2fcf48807420e84795bf0d5c622800d635ad0db007e5212c869303be8b399c2d6cf4c8820660163c9c768d78f91a63b1351b41e0d1ca1e475076c926ad37506d5af17b907527c2456c6735ac7540d73da64469f559897d679275544db5b2ed24f45eb57a98aa84001ad3a3468a69d024418929b428816b9d26cb736886c34939a7585ac617d99b919e9e172b736668129bc8037100ec754c734318d373dc765701a4499ea8dd689233b339a32474d90686512ea6e3604fb27b83226753a4eaac32883941b5eea685896e1a5d76917d09baaf2e2064208dbbad4d3489061a27ca886669741bcc029445993944b6faf64369026481f55a61a6019d226100b09266dde365144d994d1000b36f2a5b48408823710b4069cd249d4eca236666822c942c41a572e876bd95852b189066c9c1c419cc46ead9dc635224895342c4368ee4121472cc410410b4176525bb1439ae2e205bcce8944599cd3d096f83011c8cc5c7946014f2d32413a1fc4a0b7a8f5003f34a26c5721d95a7228e41898911dd3e03440871de541074179b68942c43f0ee6888120dd0fc39172e064c27104b8b4449bab3a032ee31362942cce6908041b23e1c033bcdcc2d0dbc76da4a1a7a1c0c1ec7f54a42c4b30cc2209323c68a791a58d86e9d003dc440937b2261c0cc1f64a22c49c280e122dd82a9c38d5b37d442d61d94c82081790355590da864107d9290b33fc38ce3a4eb794ae4332c906616903312409f6dd4174921b209d0468a289b32ba9b5c200b76254f2da2f97de344d040641d4e8ac203c36e413db65144d999b4c06e8078562c6c105ba9053880c04440362aa0cb5dd8794a167dbfec8eb3eafa25ad7bf372b10f60f004405ee17cd3ec66a13c33885391d3541fc657d2d71cd5499d11e810842a96042108010842004210801084200421080fcfdf68ce6ff00db9c68cc369bdc6abcd3aa4120113369dd7d03ed7f8057c2f17a7c6e8d1030d5c06547b47caff3effb2f9c3aa49d60f85d9097b4e792d9a7990d04b88bc4659505e4030446e93ce22c5c6251cd041ea33db657b2b46865c12d3bda554e83f6dd285776577549de106b0917b029688a1ce71225e0cd899519880e2438831748350c8707198d15dd558e044de34f29628d05d54920071ed754735efbe426c966ab0999da10eae4fde8b6852c508ab861725bf829a54038968000f3a270a8c2d988b42b8ad4e4c0b4efd9569596b614e981ab2db2772c3a672c5bdd24d76ba4653e013a156f8901a406ec15f457630536802d9b690a0b7374c5b2c425bf101a074cc992128d6dcc68774b4299ae32990d0434ce9b20b9ceb4c133603759b9e729300686549ae636243a6c96286b44c122dec8be6b3bb68934ebda09991105473c8306dba5a1439c24fcd69bdd4e73972c436c754918802a18204bb451cf91675f6275516851ab4713a80648502437a6370202ca2b11f7e0f6523111b1f2654da143dc6418b9cb1a2630e5765883a69aac47111a686daa9e7c3a4dceea2d0a34fcce36246a4abbde0b9dac65b058fe2041b99edd941c48d8ec992146d2d8889241d6775571738026d63201fc9653880609274506b66320b45eca6d0a348399a49b827f15360d9cc08060ac9ce681aeda2b1ae0823ca8b428d20826c475362614101cc90769f74866200220906760a0551194cc4dee9628d4e7c30120eb330a1a08cc325fc948157334c0b769941aa60b6d3b79536287bcde72ce86e55a0804da01d3b2c82a92e0e317168577579997032252c50f8d218048d7321c65c480083e56535663a8800420548248813ba8b146a905a61a046e0f65578693669917012be2891949111aaa735d324b6fdb64b42866513d404cc20fcad39779ba50aad2e22409ee87542e6e573865f0964d0c75376713103b8504c340e9b8b7849755974e604c2a9aa5a043fc28b428fb27d8cb3ff76710abfe7540d3b4afa5af19f65582af83f44d1388616bf1155d5848fba6217b35c737723a22a902108552c084210021084008421002108400842101cdf5061f8662b826269f182c182c84d473cc068eebf32f176e0e9712aece1559f88c2030c7d46c1217d3fed938f567e268702a2e2da6d6f36b806ce9f947e457cbb96091d1a85bc22e8ca525665cd5224008cf506c16a34c1025b606f2102986925c3eb0af8b2b664352a8db408cd57fc7f25af973248dad6472866800811298b168cbcca80465d5407d4240cb33e16c34f6b13e14b683c890db1f2a71632463cf540f93f240ab5b50d1f82da28ba4170d7cab370af913a93098b232460cd5a3e591ec80faf321b73e16e66167e6777d91f0c4b4362fdd316324620fae346904a0beb11712616e6e160800499d50cc292262374c58c91833d6244f7dd19ab7f8fe4b7fc296b09991690adf0ed20d8d9ddee1306324734bea81303dd4875689cbf92ddc81111b140a00b0c0d930632461cd5b66ea82fafb8fc96d187824002365228c869b49f09831923066aa0996f9faa9cf5263269aadfc824f500046883444988b7e898b19239e5d5488caa73568d16df87040b8d0dd4729b1f44c59392311755ff1fa4226acfc97f65b8d2eada7728341c1c5b7bf7098323230f32ae997f2522a562d04334de16cf87fcf553c970119484c593923166adbb3f2539ebdec60de16e7517003334dedaaa0a61d31060693aa62c8b321e701f2d86e8cf56f0dbc4185bb9443890d101c2c4a05025c018378b262c648c06ad70748bf641a95f45b0d2006c6d650ea223313d8e898b2724620fa90202335537cbf92dbca01c479dd40a6d36b477518b19232e7ab1204429152ac019256b140169ca2eae280800c6baa9c591923097d62dbb7eb0a33d688cab6f204585f7472440b09dcca62c648c5ccad3a1467ada1056ce488896fe28e480eca60c1ee98b272461e6d5060eaa43eb104098dc2d9ca123a7653c969886dc5d462c648c39eaeb1aaf61f67381f4e6378d37fafe2b239ae9a541e229bddd89fd979a340651304a0d28dae0ca87164e48fd5ac0d0c0180068168d159791fb30e2b88e2de8bc3d4c53b354a0f750cc75706c5cfe2bd72e76a99b204210a00210840084210021084008421002108407c07ed1a4fae31c2e748fcd798821b3023c95e97ed103bfedbe3ae419117f75e6f2d9ae9cd20e86ebba3d2395f60e9827240b5c956fbf02983b4076aa9d45b720f8566361c088066cac40171b9732d974550e371945c6c135ae21c01220760a264483323b210540cb0728241d215f2e663498132a0bc38417127bfeeacd7b7289171bce88024160608ef7099cb7012e24c18f62901e0b46506d7466ccd902c0a905e0b5c7a4efa7644001b730068a045c35b2ab99c4cb5b034f64034b2939e4ce8635bfba8616800b5a241d0dc2a12fcee904cee86b1f9cb4cc13dd00c2e1cbe960faa8963a6d3a587650d6bc889981b191eea6264c6580809cac912cb4c68aad61635ce73406c4011bab969741871bf7d12cb1ce7653adf7404d3f98c480e1d94c8990d3d27b2535824131110af97a4652227ba80588fedb5d79880365576ae00133f92b64606004c5fba87087107e847652087068ca2220cc15520002c4c885670970260cf8505ae90035a0891a6a1402480098690601ea372873c345c5a6d0650e6986981e245d14f592487016b29046600025a348955394b5c4448f09a65a7fd43731109733673883074dfc28041bb7366046698856ca5c4087004116dd50652c266f1792a408832483e50120365dd2eb0eeaf2d11671833aaab4073ec200eea5b063a62011a2900729bc782528e4c8773174e73438820e9e3650e800c025ba1b68a00973db9843046cac7e680d0466b1852608680208d7dd4c49cc01bdf5dd092d4ee32c13deca447cf944b4aa025aeb9822e2426343dc5c3378ba10501b168b13e1465b69730aed9611d264dc2bb0b9cf20bceaa40a022c5ae3752e86de05f510a4e6d4991121018e7383b35b4f6500a1610e3d13be9a27318f736098b653ec94f696c755a3b29a65cd10d82610065e886c80d32d93dd55c1c4836122130b48975ae3b59562f04349d34b2127d67ec6eb39dc1b1b433b8b29d6ccd0769ff00d17d1d7cd3ec6985b82e24ed8d46816f75f4b5c5c9f333a61f282108542c084210021084008421002108400842101f0afb56e195f87faadf8c78268e31a1d4df1b8d47e61789154340249fc57e8ef567a5b07eabe10fc1e23a2ab6f46b01269bbf85f9f3d43e9de29e99c4f2388512d0490ca8dbb2a4762ba21c9aa31943666e706b26e554d587113f9ac9cff26106b3499bad332b89b4561945cc9108156c20cc9ecb10ae2458c040adb4c266313733110e8d644e8ac2b1969bebd9738d6046970148c418dbba66313a06b90048d2f747361ae9d2762b9e2b9cf36853f10430806c6364cd1189d0e64be73de759556d502e5d7160b073e4c9327bc2835811bfe0999389d138868302248b98526a82e24911de1738622e099b6ca7e222d263c26688c4e8b6a6a2601b48522a66800975a0ae68c45f572915ed198a9cc62744d403aaf132abcc02a071117beeb9e7112d7751121473e7426677519a189d015ac2f074895615c6575e64493a2e6f3ee4feaa0551b8d4a66313a7cd01b7b4772835da40b5f60b9bcf10759f28e788922f2998c0e936bc800da0ca0d6d4e717237dd73b9e2f3bf651cd824c94cc62743e21a72b8b86b740ac08124749d21738d791373756f893b4ea998c4e83ab08f9818d24259a8d73fac107db5590e2369990838973a1c4c9d533189b1b5440264c69656351ad65c6a2d75cf1549d5d0a5b5ac24dd33189bc55925c1a1a27ba9ce40b013f2dcae78ad137d54bab02e3d46094cc626e6d67803436efa28a951ef7192066b9f2b17380112a39ad3066e998c4ddcc200eb1add417c86c3869b2c42b0ee502b00043884cd0c4dc6a1064be6d32a79cd0f12e3e6560e7d846c818875e5334313a26bc9f9a48d82195fadb0f21d3f8ae7f3c0982abf1045a133189d3350de1da0d147c48fbaf8bcae773c77dd473844266313a0fac0b5b0f33717514ebb4169326573dd58c40bc1522b16c1d23ca664e27479cd0e74b9d1a00a33b62ce2607e0b0fc513ac9b775ec7d29f673c67d49529e22b53384e1e61dcd7eaf07fc46ea1f224141b3e93f6454033d1dcf34e1f5abbce63ab85a17ba59786f0fc3f0ae1d4301856e5a341818c1e02d4b964edd9ba54a8108428241084200421080108420042108010850e30d27b0407cf3ed07d618bc1e2470ae1758d3a804d5a94cdc78f0be59570556bbb3d62faae3725ce95eb3895338ee2389c55521d52ad52496880b37f4f023335c27432ba1468c723ccff004e969fed90a0f0d766032eda12bd3b78789300e9bab9c082e920ccebdd4e2323cb0e1e5d90e5b5eea3fa70689b1b1d97a83806060306275561c3c024e4b1137ec988c8f2a300003d111af752386b8b4f49365ea0604434e417556f0e6b9aecb63dd462323cc8e1d20f45e77b23fa7b729969000b895e9ffa76d0d70368d533fa736f99ad1acc29c464795fe9e039bfdbd444a81c3dba64f61bd97a976041fbb32211fd3b239dd21df44c4647983c34874860b19b0507878020b458e817a83810d61b798f0ac300d1ad316d6db2624667951c3e40310235d94ff4f23ee88b6a17a87603a5ad0d9fa5c21d81bc96033706131199e606024c0628fe9a4824360db65ea3e10eb9058f657f82233086902c531199e50e01ac93927df550787998ca6e6c765ea060be586813747c264261b197b794c49c8f33fd3e5a01a7af840e1e0873b26a2cbd38c1b9cf692353655f80192728ea921312323cdb7868160cd44dd1fd3cba464b05e98e00122c3e591eca3fa7dc82d02f1f54c464798fe99720b23337528fe9b624360dbeabd2b70224581b5fc29f8268d5b045aea312723ccff4d81723f153fd365ba34c58af4a7002ed0d0e3a40d554e09a581d07530d0531191e73e00e7b35b13d91fd3c07380008d3d97a2384648245e2627652306d24c366e2531191e73e046580dd66e37503019f41b05e8fe19ad7464b9d957e1da400059a0a8a26cf3c3871cc011e26143b87d80c87bcaf4230f4c01224a390d93d20764a1679e1c3a2f95c7c283808be42000bd03a831d2440b4823b2afc3e56ce593e7f351a276707e040702593fb28f8106c01cdd82ee3b0e1a4916124a8f8620933b5d3436717e03b099d141c006b64832bb9f0ce33f928f867803dae4a686ce2fc08980c27bdf451f02d7080dfa770bb9f0cf0dcc63df655341db81d374d0d9c3f830041993a5955d841035823b2eefc29f13987b28f82876d611054689d9c538404180617a1f4b7ab78b7a6b17498310faf80cd0fc3b8d803b8ecb38c1b624b419b924a1f8074105a018df59407e80a15e9e26832bd270732a3439a4684262e47a4c47a57868927fe1dbaaebac8b82108400842101fffd9, '2024-09-06 04:55:52', 126, 'defaultValue', NULL);
INSERT INTO `masters` (`masterid`, `mastername`, `category`, `status`, `addmaster`, `view`, `image`, `createdon`, `createdby`, `lastmodifiedby`, `lastmodifieddate`) VALUES
(191, 'Formal Pant', 190, 1, 0, 0, NULL, '2024-09-06 04:56:16', 126, 'defaultValue', NULL),
(192, 'Half Pant', 190, 1, 0, 0, NULL, '2024-09-06 04:56:30', 126, 'defaultValue', NULL),
(193, 'Track Pant', 190, 1, 0, 0, NULL, '2024-09-06 04:56:49', 126, 'defaultValue', NULL),
(194, 'Grade', 9998, 1, 0, 0, NULL, '2024-09-06 04:56:49', 126, 'defaultValue', NULL),
(195, 'Frock', 0, 1, 0, 0, NULL, '2024-09-06 04:44:12', 126, 'defaultValue', NULL),
(196, 'Skirt', 0, 1, 0, 0, NULL, '2024-09-06 04:44:12', 126, 'defaultValue', NULL),
(197, 'Pinafore', 0, 1, 0, 0, NULL, '2024-09-06 04:44:12', 126, 'defaultValue', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mastersdata`
--

CREATE TABLE `mastersdata` (
  `dataid` bigint NOT NULL,
  `name` varchar(50) NOT NULL,
  `masterid` bigint NOT NULL,
  `status` int NOT NULL,
  `createdon` datetime NOT NULL DEFAULT (convert_tz(now(),_utf8mb4'+00:00',_utf8mb4'+05:30')),
  `lastmodifieddate` datetime DEFAULT (convert_tz(now(),_utf8mb4'+00:00',_utf8mb4'+05:30')),
  `lastmodifiedby` bigint DEFAULT NULL,
  `createdby` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `mastersdata`
--

INSERT INTO `mastersdata` (`dataid`, `name`, `masterid`, `status`, `createdon`, `lastmodifieddate`, `lastmodifiedby`, `createdby`) VALUES
(66, 'ankle', 96, 1, '2024-01-12 08:44:58', '2024-03-26 16:58:58', 85, 21),
(72, 'medium', 99, 1, '2024-01-19 05:18:20', NULL, NULL, 21),
(76, 'red', 98, 1, '2024-01-29 06:49:18', NULL, NULL, 21),
(77, 'blue', 98, 1, '2024-01-29 06:49:18', NULL, NULL, 21),
(78, 'large', 99, 1, '2024-01-29 06:52:16', NULL, NULL, 21),
(90, 'Store1', 113, 1, '2024-02-26 09:48:07', NULL, NULL, 44),
(91, 'Store2', 113, 1, '2024-02-26 09:48:07', NULL, NULL, 44),
(92, 'Online', 113, 1, '2024-02-26 09:48:07', NULL, NULL, 44),
(93, 'stripes', 114, 1, '2024-02-26 09:53:00', NULL, NULL, 44),
(94, 'plain', 114, 1, '2024-02-26 09:53:00', NULL, NULL, 44),
(95, 'checked', 114, 1, '2024-02-26 09:53:00', NULL, NULL, 44),
(96, 'curves', 114, 1, '2024-02-26 09:53:00', NULL, NULL, 44),
(109, 'green', 98, 1, '2024-03-11 04:59:31', NULL, NULL, 82),
(110, 'small', 99, 1, '2024-03-11 05:00:16', NULL, NULL, 82),
(111, 'orange', 98, 1, '2024-03-11 05:03:53', NULL, NULL, 82),
(115, 'Full', 124, 1, '2024-03-13 06:28:52', NULL, NULL, 93),
(116, 'Half', 124, 1, '2024-03-13 06:28:52', NULL, NULL, 93),
(117, 'Quarter', 124, 1, '2024-03-13 06:28:52', NULL, NULL, 93),
(135, 'extra large', 99, 1, '2024-03-19 06:37:52', NULL, NULL, 85),
(141, 'small', 99, 1, '2024-03-23 11:33:23', NULL, NULL, 85),
(147, 'klhasdcf;', 113, 1, '2024-03-23 11:35:54', NULL, NULL, 85),
(148, 'max', 135, 1, '2024-03-23 11:37:28', NULL, NULL, 85),
(149, 'max', 135, 1, '2024-03-23 11:37:37', NULL, NULL, 85),
(152, 'boys', 103, 1, '2024-03-26 16:44:02', NULL, NULL, 85),
(154, 'girls', 103, 1, '2024-03-26 16:44:20', NULL, NULL, 85),
(155, 'Baby clothings', 137, 1, '2024-03-26 16:45:24', NULL, NULL, 85),
(156, 'Extra small', 99, 1, '2024-03-26 16:46:39', NULL, NULL, 85),
(157, 'Cotton', 139, 1, '2024-03-26 16:54:34', NULL, NULL, 85),
(158, 'Lenin cotton', 139, 1, '2024-03-26 16:54:44', NULL, NULL, 85),
(159, 'Cotton blend', 139, 1, '2024-03-26 16:54:55', NULL, NULL, 85),
(160, 'cargo', 137, 1, '2024-03-26 17:01:55', NULL, NULL, 85),
(161, 'classic pants', 137, 1, '2024-03-26 17:02:13', NULL, NULL, 85),
(162, 'slim', 137, 1, '2024-03-26 17:02:19', NULL, NULL, 85),
(163, 'Trousers & pants', 137, 1, '2024-03-26 17:02:38', NULL, NULL, 85),
(164, 'Joggers', 137, 1, '2024-03-26 17:02:51', NULL, NULL, 85),
(165, 'Full length', 96, 1, '2024-03-26 17:03:48', NULL, NULL, 85),
(166, 'High rise', 140, 1, '2024-03-26 17:04:57', NULL, NULL, 85),
(167, 'Mid rise', 140, 1, '2024-03-26 17:05:06', NULL, NULL, 85),
(168, 'Low rise', 140, 1, '2024-03-26 17:05:16', NULL, NULL, 85),
(169, 'Wool', 141, 1, '2024-03-26 17:06:37', NULL, NULL, 85),
(170, 'Rayon', 141, 1, '2024-03-26 17:06:45', NULL, NULL, 85),
(171, 'Cotton', 141, 1, '2024-03-26 17:06:58', NULL, NULL, 85),
(172, 'Cotton blend', 141, 1, '2024-03-26 17:07:07', NULL, NULL, 85),
(173, 'Linen blend', 141, 1, '2024-03-26 17:07:21', NULL, NULL, 85),
(176, 'Georgette', 139, 1, '2024-04-11 10:06:29', NULL, NULL, 116),
(177, 'Organza', 139, 1, '2024-04-11 10:06:45', NULL, NULL, 116),
(178, 'Organza', 139, 1, '2024-04-11 10:06:53', NULL, NULL, 116),
(179, 'Floor touch', 154, 1, '2024-04-11 10:16:24', NULL, NULL, 116),
(187, 'Full sleeves', 186, 1, '2024-09-05 11:36:26', NULL, NULL, 126),
(188, 'Half Sleeves', 186, 1, '2024-09-05 11:51:19', NULL, NULL, 126),
(189, 'Half Sleeve', 189, 1, '2024-09-06 04:45:51', NULL, NULL, 126),
(190, 'Full Sleeve', 189, 1, '2024-09-06 04:46:05', NULL, NULL, 126),
(191, 'Cotton Pant', 191, 1, '2024-09-06 04:57:12', NULL, NULL, 126),
(192, 'Cotton Pant', 192, 1, '2024-09-06 04:57:42', NULL, NULL, 126),
(193, 'Fabric Pant', 193, 1, '2024-09-06 04:58:02', NULL, NULL, 126),
(194, 'Black', 98, 1, '2024-09-07 05:20:07', NULL, NULL, 126),
(195, 'grade 1 - grade 2', 194, 1, '2024-09-07 05:20:07', NULL, NULL, 126),
(196, 'grade 3 - grade 4', 194, 1, '2024-09-07 05:20:07', NULL, NULL, 126),
(197, 'grade 3', 194, 1, '2024-09-07 05:20:07', NULL, NULL, 126);

-- --------------------------------------------------------

--
-- Table structure for table `module`
--

CREATE TABLE `module` (
  `moduleid` bigint NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `status` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `createdAt` bigint DEFAULT NULL,
  `createdon` datetime DEFAULT (convert_tz(now(),_utf8mb4'+00:00',_utf8mb4'+05:30')),
  `createdby` varchar(100) NOT NULL,
  `lastmodifiedby` bigint DEFAULT NULL,
  `lastmodifiedate` datetime DEFAULT (convert_tz(now(),_utf8mb4'+00:00',_utf8mb4'+05:30'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `module`
--

INSERT INTO `module` (`moduleid`, `name`, `status`, `createdAt`, `createdon`, `createdby`, `lastmodifiedby`, `lastmodifiedate`) VALUES
(1, 'sidebar', NULL, NULL, '2024-04-01 16:49:10', '', NULL, '2024-04-01 16:49:10'),
(2, 'staffmasters', NULL, NULL, '2024-04-01 16:49:10', '', NULL, '2024-04-01 16:49:10'),
(3, 'productmasters', NULL, NULL, '2024-04-01 16:49:10', '', NULL, '2024-04-01 16:49:10'),
(4, 'generalmasters', NULL, NULL, '2024-04-01 16:49:10', '', NULL, '2024-04-01 16:49:10'),
(5, 'schoolmasters', NULL, NULL, '2024-04-01 16:49:10', '', NULL, '2024-04-01 16:49:10'),
(6, 'rolesmasters', NULL, NULL, '2024-04-01 16:49:10', '', NULL, '2024-04-01 16:49:10'),
(7, 'addproduct', NULL, NULL, '2024-04-01 16:49:10', '', NULL, '2024-04-01 16:49:10'),
(8, 'onlineview', NULL, NULL, '2024-04-01 16:49:10', '', NULL, '2024-04-01 16:49:10'),
(9, 'dashboard', NULL, NULL, '2024-04-01 16:49:10', '', NULL, '2024-04-01 16:49:10'),
(18, 'modulemasters', NULL, NULL, '2024-04-04 00:02:27', '', NULL, '2024-04-04 00:02:27'),
(24, 'schooladmindashboard', NULL, NULL, '2024-09-04 22:36:27', '0', NULL, '2024-09-04 22:36:27');

-- --------------------------------------------------------

--
-- Table structure for table `otpsmslog`
--

CREATE TABLE `otpsmslog` (
  `logid` bigint NOT NULL,
  `mobileno` varchar(10) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `otpcode` varchar(6) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `senttime` datetime DEFAULT (convert_tz(now(),_utf8mb4'+00:00',_utf8mb4'+05:30')),
  `status` bit(1) DEFAULT b'0'
) ;

--
-- Dumping data for table `otpsmslog`
--

INSERT INTO `otpsmslog` (`logid`, `mobileno`, `email`, `otpcode`, `senttime`, `status`) VALUES
(10, '9361621891', '', '365449', '2024-01-04 13:51:57', b'0'),
(11, '9361621891', '', '', '2024-01-04 13:54:51', b'0'),
(12, '8940900292', '', '444745', '2024-01-05 15:32:46', b'0'),
(13, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(14, '8903061357', '', '122801', '2024-01-06 21:27:28', b'0'),
(15, '8903061357', '', '', '2024-01-06 21:27:28', b'0'),
(16, '8903061357', '', '493628', '2024-01-06 22:56:42', b'0'),
(17, '8903061357', '', '', '2024-01-06 22:56:42', b'0'),
(18, '8940900292', '', '739557', '2024-01-06 22:56:42', b'0'),
(19, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(20, '8903061357', '', '281146', '2024-01-06 22:56:42', b'0'),
(21, '8903061357', '', '', '2024-01-06 22:56:42', b'0'),
(22, '8940900292', '', '420124', '2024-01-06 22:56:42', b'0'),
(23, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(24, '8903061357', '', '683231', '2024-01-06 22:56:42', b'0'),
(25, '8903061357', '', '', '2024-01-06 22:56:42', b'0'),
(26, '8940900292', '', '873682', '2024-01-07 14:24:39', b'0'),
(27, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(28, '8940900292', '', '925913', '2024-01-07 14:24:39', b'0'),
(29, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(30, '8940900292', '', '869572', '2024-01-07 14:36:32', b'0'),
(31, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(32, '8940900292', '', '881588', '2024-01-07 14:37:54', b'0'),
(33, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(34, '8940900292', '', '997956', '2024-01-07 14:38:36', b'0'),
(35, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(36, '8940900292', '', '441847', '2024-01-07 15:11:46', b'0'),
(37, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(38, '8940900292', '', '811184', '2024-01-07 15:11:46', b'0'),
(39, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(40, '8940900292', '', '268891', '2024-01-08 11:01:49', b'0'),
(41, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(42, '8940900292', '', '951304', '2024-01-08 11:01:49', b'0'),
(43, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(44, '8940900292', '', '895723', '2024-01-08 11:01:49', b'0'),
(45, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(46, '8940900292', '', '523832', '2024-01-08 11:01:49', b'0'),
(47, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(48, '8940900292', '', '509560', '2024-01-08 11:01:49', b'0'),
(49, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(50, '8940900292', '', '840871', '2024-01-08 11:01:49', b'0'),
(51, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(52, '8940900292', '', '572804', '2024-01-08 11:01:49', b'0'),
(53, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(54, '8940900292', '', '384417', '2024-01-08 11:01:49', b'0'),
(55, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(56, '8940900292', '', '642238', '2024-01-08 11:01:49', b'0'),
(57, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(58, '8940900292', '', '229883', '2024-01-08 11:01:49', b'0'),
(59, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(60, '8940900292', '', '792796', '2024-01-08 11:01:49', b'0'),
(61, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(62, '8940900292', '', '235549', '2024-01-08 11:01:49', b'0'),
(63, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(64, '8940900292', '', '436645', '2024-01-08 11:01:49', b'0'),
(65, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(66, '8940900292', '', '181538', '2024-01-08 11:01:49', b'0'),
(67, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(68, '8940900292', '', '324743', '2024-01-08 11:01:49', b'0'),
(69, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(70, '8940900292', '', '203163', '2024-01-08 11:01:49', b'0'),
(71, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(72, '8940900292', '', '849048', '2024-01-08 11:01:49', b'0'),
(73, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(74, '8940900292', '', '547179', '2024-01-08 11:01:49', b'0'),
(75, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(76, '9361621891', '', '963135', '2024-01-11 12:07:51', b'0'),
(77, '9361621891', '', '', '2024-01-11 12:07:51', b'0'),
(78, '9600724179', '', '540510', '2024-01-11 19:20:29', b'0'),
(79, '9600724179', '', '', '2024-01-11 19:20:29', b'0'),
(80, '8903061357', '', '767805', '2024-01-11 19:20:29', b'0'),
(81, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(82, '8903061357', '', '182015', '2024-01-11 19:20:29', b'0'),
(83, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(84, '8903061357', '', '620825', '2024-01-11 19:20:29', b'0'),
(85, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(86, '8903061357', '', '780764', '2024-01-11 19:20:29', b'0'),
(87, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(88, '8903061357', '', '817658', '2024-01-11 19:20:29', b'0'),
(89, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(90, '8903061357', '', '460704', '2024-01-11 19:20:29', b'0'),
(91, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(92, '8903061357', '', '223603', '2024-01-11 19:20:29', b'0'),
(93, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(94, '8903061357', '', '565029', '2024-01-11 19:20:29', b'0'),
(95, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(96, '8903061357', '', '432428', '2024-01-11 19:20:29', b'0'),
(97, '8903061357', '', '937948', '2024-01-11 19:20:29', b'0'),
(98, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(99, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(100, '8903061357', '', '789093', '2024-01-11 19:20:29', b'0'),
(101, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(102, '8903061357', '', '223311', '2024-01-11 19:20:29', b'0'),
(103, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(104, '8903061357', '', '670282', '2024-01-11 19:20:29', b'0'),
(105, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(106, '8903061357', '', '157943', '2024-01-11 19:20:29', b'0'),
(107, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(108, '8903061357', '', '755599', '2024-01-11 19:20:29', b'0'),
(109, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(110, '8903061357', '', '343797', '2024-01-11 19:20:29', b'0'),
(111, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(112, '8903061357', '', '237766', '2024-01-11 19:20:29', b'0'),
(113, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(114, '8903061357', '', '632046', '2024-01-11 19:20:29', b'0'),
(115, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(116, '8903061357', '', '744983', '2024-01-11 19:20:29', b'0'),
(117, '8903061357', '', '922186', '2024-01-11 19:20:29', b'0'),
(118, '8903061357', '', '789534', '2024-01-11 19:20:29', b'0'),
(119, '8903061357', '', '607694', '2024-01-11 19:20:29', b'0'),
(120, '8903061357', '', '874540', '2024-01-11 19:20:29', b'0'),
(121, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(122, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(123, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(124, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(125, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(126, '8903061357', '', '825502', '2024-01-11 19:20:29', b'0'),
(127, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(128, '8903061357', '', '282348', '2024-01-11 19:20:29', b'0'),
(129, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(130, '8903061357', '', '314277', '2024-01-11 19:20:29', b'0'),
(131, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(132, '8903061357', '', '221902', '2024-01-11 19:20:29', b'0'),
(133, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(134, '8903061357', '', '162002', '2024-01-11 19:20:29', b'0'),
(135, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(136, '8903061357', '', '734791', '2024-01-11 19:20:29', b'0'),
(137, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(138, '8903061357', '', '795435', '2024-01-11 19:20:29', b'0'),
(139, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(140, '8903061357', '', '398009', '2024-01-11 19:20:29', b'0'),
(141, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(142, '8903061357', '', '869427', '2024-01-11 19:20:29', b'0'),
(143, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(144, '8903061357', '', '914165', '2024-01-11 19:20:29', b'0'),
(145, '8903061357', '', '265740', '2024-01-11 19:20:29', b'0'),
(146, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(147, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(148, '8903061357', '', '713193', '2024-01-11 19:20:29', b'0'),
(149, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(150, '8903061357', '', '958774', '2024-01-11 19:20:29', b'0'),
(151, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(152, '8903061357', '', '103823', '2024-01-11 19:20:29', b'0'),
(153, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(154, '8903061357', '', '419287', '2024-01-11 19:20:29', b'0'),
(155, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(156, '8903061357', '', '808878', '2024-01-11 19:20:29', b'0'),
(157, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(158, '8903061357', '', '277123', '2024-01-11 19:20:29', b'0'),
(159, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(160, '8903061357', '', '503298', '2024-01-11 19:20:29', b'0'),
(161, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(162, '8903061357', '', '743649', '2024-01-11 19:20:29', b'0'),
(163, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(164, '8903061357', '', '791307', '2024-01-11 19:20:29', b'0'),
(165, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(166, '8903061357', '', '682532', '2024-01-11 19:20:29', b'0'),
(167, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(168, '8903061357', '', '521445', '2024-01-11 19:20:29', b'0'),
(169, '8903061357', '', '982608', '2024-01-11 19:20:29', b'0'),
(170, '8903061357', '', '527909', '2024-01-11 19:20:29', b'0'),
(171, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(172, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(173, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(174, '8903061357', '', '198744', '2024-01-11 19:20:29', b'0'),
(175, '8903061357', '', '571517', '2024-01-11 19:20:29', b'0'),
(176, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(177, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(178, '8903061357', '', '858531', '2024-01-11 19:20:29', b'0'),
(179, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(180, '8903061357', '', '695744', '2024-01-11 19:20:29', b'0'),
(181, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(182, '8903061357', '', '634138', '2024-01-11 19:20:29', b'0'),
(183, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(184, '8903061357', '', '440405', '2024-01-11 19:20:29', b'0'),
(185, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(186, '8903061357', '', '236721', '2024-01-11 19:20:29', b'0'),
(187, '8903061357', '', '138886', '2024-01-11 19:20:29', b'0'),
(188, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(189, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(190, '8903061357', '', '923730', '2024-01-11 19:20:29', b'0'),
(191, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(192, '8903061357', '', '750843', '2024-01-11 19:20:29', b'0'),
(193, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(194, '8903061357', '', '418981', '2024-01-11 19:20:29', b'0'),
(195, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(196, '8903061357', '', '704939', '2024-01-11 19:20:29', b'0'),
(197, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(198, '8903061357', '', '894278', '2024-01-11 19:20:29', b'0'),
(199, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(200, '8903061357', '', '691361', '2024-01-11 19:20:29', b'0'),
(201, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(202, '8903061357', '', '745540', '2024-01-11 19:20:29', b'0'),
(203, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(204, '8903061357', '', '882668', '2024-01-11 19:20:29', b'0'),
(205, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(206, '8903061357', '', '352612', '2024-01-11 19:20:29', b'0'),
(207, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(208, '8903061357', '', '251170', '2024-01-11 19:20:29', b'0'),
(209, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(210, '8903061357', '', '977541', '2024-01-11 19:20:29', b'0'),
(211, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(212, '8903061357', '', '465505', '2024-01-11 19:20:29', b'0'),
(213, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(214, '8903061357', '', '813370', '2024-01-11 19:20:29', b'0'),
(215, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(216, '8903061357', '', '750613', '2024-01-11 19:20:29', b'0'),
(217, '8903061357', '', '874692', '2024-01-11 19:20:29', b'0'),
(218, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(219, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(220, '8903061357', '', '291979', '2024-01-11 19:20:29', b'0'),
(221, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(222, '8903061357', '', '595374', '2024-01-11 19:20:29', b'0'),
(223, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(224, '8903061357', '', '239059', '2024-01-11 19:20:29', b'0'),
(225, '8903061357', '', '', '2024-01-11 19:20:29', b'0'),
(226, '9884302002', '', '111182', '2024-01-12 12:46:43', b'0'),
(227, '9884302002', '', '', '2024-01-12 12:46:43', b'0'),
(228, '9884302002', '', '325719', '2024-01-12 12:46:43', b'0'),
(229, '9884302002', '', '', '2024-01-12 12:46:43', b'0'),
(230, '9884302002', '', '506708', '2024-01-12 12:46:43', b'0'),
(231, '9884302002', '', '', '2024-01-12 12:46:43', b'0'),
(232, '9884302002', '', '711580', '2024-01-12 12:46:43', b'0'),
(233, '9884302002', '', '', '2024-01-12 12:46:43', b'0'),
(234, '9884302002', '', '214745', '2024-01-12 12:46:43', b'0'),
(235, '9884302002', '', '', '2024-01-12 12:46:43', b'0'),
(236, '9600420101', '', '833805', '2024-01-12 12:46:43', b'0'),
(237, '9600420101', '', '', '2024-01-12 12:46:43', b'0'),
(238, '9600420101', '', '903050', '2024-01-12 12:46:43', b'0'),
(239, '9600420101', '', '', '2024-01-12 12:46:43', b'0'),
(240, '9600420101', '', '730586', '2024-01-12 12:46:43', b'0'),
(241, '9600420101', '', '', '2024-01-12 12:46:43', b'0'),
(242, '9884302002', '', '428950', '2024-01-12 12:46:43', b'0'),
(243, '9884302002', '', '', '2024-01-12 12:46:43', b'0'),
(244, '9884302002', '', '741983', '2024-01-12 12:46:43', b'0'),
(245, '9884302002', '', '', '2024-01-12 12:46:43', b'0'),
(246, '9884302002', '', '481181', '2024-01-12 12:46:43', b'0'),
(247, '9884302002', '', '', '2024-01-12 12:46:43', b'0'),
(248, '9600420101', '', '724837', '2024-01-12 12:46:43', b'0'),
(249, '9600420101', '', '', '2024-01-12 12:46:43', b'0'),
(250, '9600420101', '', '340420', '2024-01-12 12:46:43', b'0'),
(251, '9600420101', '', '212428', '2024-01-12 12:46:43', b'0'),
(252, '9600420101', '', '', '2024-01-12 12:46:43', b'0'),
(253, '9600420101', '', '', '2024-01-12 12:46:43', b'0'),
(300, '9361621891', 'arav@gmail.com', '555555', '2024-01-12 16:53:41', b'0'),
(301, '8903061357', '', '547511', '2024-01-12 16:37:12', b'0'),
(302, '8903061357', '', '', '2024-01-12 16:37:12', b'0'),
(303, '8903061357', '', '862617', '2024-01-12 16:37:12', b'0'),
(304, '8903061357', '', '', '2024-01-12 16:37:12', b'0'),
(305, '8903061357', '', '203083', '2024-01-12 16:37:12', b'0'),
(306, '8903061357', '', '', '2024-01-12 16:37:12', b'0'),
(307, '8903061357', '', '814179', '2024-01-12 16:37:12', b'0'),
(308, '8903061357', '', '', '2024-01-12 16:37:12', b'0'),
(309, '8903061357', '', '650142', '2024-01-12 16:37:12', b'0'),
(310, '8903061357', '', '', '2024-01-12 16:37:12', b'0'),
(311, '9600420101', '', '380691', '2024-01-18 07:41:18', b'0'),
(312, '9600420101', '', '', '2024-01-18 07:41:18', b'0'),
(313, '9600420101', '', '526479', '2024-01-18 07:41:18', b'0'),
(314, '9600420101', '', '', '2024-01-18 07:41:18', b'0'),
(315, '8940900292', '', '761389', '2024-01-19 10:03:34', b'0'),
(316, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(317, '8940900292', '', '203392', '2024-01-19 10:03:34', b'0'),
(318, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(319, '8940900292', '', '728492', '2024-01-19 10:03:34', b'0'),
(320, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(321, '8940900292', '', '224964', '2024-01-19 10:03:34', b'0'),
(322, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(323, '8940900292', '', '844531', '2024-01-19 10:03:34', b'0'),
(324, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(325, '8940900292', '', '623842', '2024-01-19 10:03:34', b'0'),
(326, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(327, '8940900292', '', '990582', '2024-01-19 10:03:34', b'0'),
(328, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(329, '8940900292', '', '429994', '2024-01-19 10:03:34', b'0'),
(330, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(331, '8940900292', '', '781943', '2024-01-19 10:03:34', b'0'),
(332, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(333, '8940900292', '', '699212', '2024-01-19 10:03:34', b'0'),
(334, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(335, '8940900292', '', '152647', '2024-01-19 10:03:34', b'0'),
(336, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(337, '8940900292', '', '535556', '2024-01-19 10:03:34', b'0'),
(338, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(339, '8940900292', '', '951344', '2024-01-19 10:03:34', b'0'),
(340, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(341, '8903061357', '', '995244', '2024-01-19 10:03:34', b'0'),
(342, '8903061357', '', '', '2024-01-19 10:03:34', b'0'),
(343, '8903061357', '', '716067', '2024-01-19 10:03:34', b'0'),
(344, '8903061357', '', '', '2024-01-19 10:03:34', b'0'),
(345, '8903061357', '', '507473', '2024-01-19 10:03:34', b'0'),
(346, '8903061357', '', '', '2024-01-19 10:03:34', b'0'),
(347, '8903061357', '', '995734', '2024-01-19 10:03:34', b'0'),
(348, '8903061357', '', '', '2024-01-19 10:03:34', b'0'),
(349, '8940900292', '', '134842', '2024-01-19 10:03:34', b'0'),
(350, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(351, '8940900292', '', '785848', '2024-01-19 10:03:34', b'0'),
(352, '8940900292', '', '193508', '2024-01-19 10:03:34', b'0'),
(353, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(354, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(355, '8940900292', '', '237485', '2024-01-19 10:03:34', b'0'),
(356, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(357, '8940900292', '', '236875', '2024-01-19 10:03:34', b'0'),
(358, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(359, '8940900292', '', '426133', '2024-01-19 10:03:34', b'0'),
(360, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(361, '8940900292', '', '910811', '2024-01-19 10:03:34', b'0'),
(362, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(363, '8940900292', '', '288310', '2024-01-19 10:03:34', b'0'),
(364, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(365, '8940900292', '', '643948', '2024-01-19 10:03:34', b'0'),
(366, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(367, '8940900292', '', '751981', '2024-01-19 10:03:34', b'0'),
(368, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(369, '8940900292', '', '157191', '2024-01-19 10:03:34', b'0'),
(370, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(371, '8940900292', '', '561054', '2024-01-19 10:03:34', b'0'),
(372, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(373, '8940900292', '', '616483', '2024-01-19 10:03:34', b'0'),
(374, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(375, '8940900292', '', '122058', '2024-01-19 10:03:34', b'0'),
(376, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(377, '8940900292', '', '890314', '2024-01-19 10:03:34', b'0'),
(378, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(379, '8940900292', '', '517731', '2024-01-19 10:03:34', b'0'),
(380, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(381, '8940900292', '', '417193', '2024-01-19 10:03:34', b'0'),
(382, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(383, '8940900292', '', '479169', '2024-01-19 10:03:34', b'0'),
(384, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(385, '8940900292', '', '571708', '2024-01-19 10:03:34', b'0'),
(386, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(387, '8940900292', '', '903198', '2024-01-19 10:03:34', b'0'),
(388, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(389, '8940900292', '', '915190', '2024-01-19 10:03:34', b'0'),
(390, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(391, '8940900292', '', '235050', '2024-01-19 10:03:34', b'0'),
(392, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(393, '8940900292', '', '442967', '2024-01-19 10:03:34', b'0'),
(394, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(395, '8940900292', '', '569096', '2024-01-19 10:03:34', b'0'),
(396, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(397, '8940900292', '', '115367', '2024-01-19 10:03:34', b'0'),
(398, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(399, '8940900292', '', '576558', '2024-01-19 10:03:34', b'0'),
(400, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(401, '8940900292', '', '700161', '2024-01-19 10:03:34', b'0'),
(402, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(403, '8940900292', '', '568299', '2024-01-19 10:03:34', b'0'),
(404, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(405, '8940900292', '', '439566', '2024-01-19 10:03:34', b'0'),
(406, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(407, '8940900291', '', '689956', '2024-01-19 10:03:34', b'0'),
(408, '8940900291', '', '', '2024-01-19 10:03:34', b'0'),
(409, '8940900291', '', '253195', '2024-01-19 10:03:34', b'0'),
(410, '8940900291', '', '', '2024-01-19 10:03:34', b'0'),
(411, '8940900298', '', '205502', '2024-01-19 10:03:34', b'0'),
(412, '8940900298', '', '', '2024-01-19 10:03:34', b'0'),
(413, '8940900298', '', '963441', '2024-01-19 10:03:34', b'0'),
(414, '8940900298', '', '', '2024-01-19 10:03:34', b'0'),
(415, '8940900292', '', '811240', '2024-01-19 10:03:34', b'0'),
(416, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(417, '8940900292', '', '956561', '2024-01-19 10:03:34', b'0'),
(418, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(419, '8940900292', '', '180646', '2024-01-19 10:03:34', b'0'),
(420, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(421, '8940900292', '', '720591', '2024-01-19 10:03:34', b'0'),
(422, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(423, '8940900292', '', '377776', '2024-01-19 10:03:34', b'0'),
(424, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(425, '8940900292', '', '359410', '2024-01-19 10:03:34', b'0'),
(426, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(427, '8940900292', '', '905363', '2024-01-19 10:03:34', b'0'),
(428, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(429, '8940900292', '', '622062', '2024-01-19 10:03:34', b'0'),
(430, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(431, '8940900292', '', '439355', '2024-01-19 10:03:34', b'0'),
(432, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(433, '2343243242', '', '546754', '2024-01-19 10:03:34', b'0'),
(434, '8940900292', '', '318718', '2024-01-19 10:03:34', b'0'),
(435, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(436, '8940900292', '', '950954', '2024-01-19 10:03:34', b'0'),
(437, '8940900292', '', '922548', '2024-01-19 10:03:34', b'0'),
(438, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(439, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(440, '8940900292', '', '803069', '2024-01-19 10:03:34', b'0'),
(441, '8940900292', '', '737694', '2024-01-19 10:03:34', b'0'),
(442, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(443, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(444, '8940900292', '', '856016', '2024-01-19 10:03:34', b'0'),
(445, '8940900292', '', '559575', '2024-01-19 10:03:34', b'0'),
(446, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(447, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(448, '8903061357', '', '370645', '2024-01-19 10:03:34', b'0'),
(449, '8903061357', '', '', '2024-01-19 10:03:34', b'0'),
(450, '8903061357', '', '676476', '2024-01-19 10:03:34', b'0'),
(451, '8903061357', '', '', '2024-01-19 10:03:34', b'0'),
(452, '8940900292', '', '143248', '2024-01-19 10:03:34', b'0'),
(453, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(454, '8940900292', '', '597658', '2024-01-19 10:03:34', b'0'),
(455, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(456, '8903061357', '', '347231', '2024-01-19 10:03:34', b'0'),
(457, '8903061357', '', '', '2024-01-19 10:03:34', b'0'),
(458, '8903061357', '', '535741', '2024-01-19 10:03:34', b'0'),
(459, '8903061357', '', '', '2024-01-19 10:03:34', b'0'),
(460, '8903061357', '', '163142', '2024-01-19 10:03:34', b'0'),
(461, '8903061357', '', '', '2024-01-19 10:03:34', b'0'),
(462, '8903061357', '', '950154', '2024-01-19 10:03:34', b'0'),
(463, '8903061357', '', '', '2024-01-19 10:03:34', b'0'),
(464, '8940900292', '', '757363', '2024-01-19 10:03:34', b'0'),
(465, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(466, '8903061357', '', '580397', '2024-01-19 10:03:34', b'0'),
(467, '8903061357', '', '', '2024-01-19 10:03:34', b'0'),
(468, '8940900292', '', '789026', '2024-01-19 10:03:34', b'0'),
(469, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(470, '8940900292', '', '778068', '2024-01-19 10:03:34', b'0'),
(471, '8940900292', '', '374923', '2024-01-19 10:03:34', b'0'),
(472, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(473, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(474, '8940900292', '', '832597', '2024-01-19 10:03:34', b'0'),
(475, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(476, '8940900292', '', '498854', '2024-01-19 10:03:34', b'0'),
(477, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(478, '8903061357', '', '328277', '2024-01-19 10:03:34', b'0'),
(479, '8903061357', '', '', '2024-01-19 10:03:34', b'0'),
(480, '8940900292', '', '454443', '2024-01-19 10:03:34', b'0'),
(481, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(482, '8903061357', '', '475979', '2024-01-19 10:03:34', b'0'),
(483, '8903061357', '', '', '2024-01-19 10:03:34', b'0'),
(484, '8940900292', '', '774776', '2024-01-19 10:03:34', b'0'),
(485, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(486, '8940900292', '', '972719', '2024-01-19 10:03:34', b'0'),
(487, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(488, '8940900292', '', '931879', '2024-01-19 10:03:34', b'0'),
(489, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(490, '8940900292', '', '207320', '2024-01-19 10:03:34', b'0'),
(491, '8940900292', '', '705405', '2024-01-19 10:03:34', b'0'),
(492, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(493, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(494, '8940900292', '', '862008', '2024-01-19 10:03:34', b'0'),
(495, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(496, '8940900292', '', '298537', '2024-01-19 10:03:34', b'0'),
(497, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(498, '8940900292', '', '716907', '2024-01-19 10:03:34', b'0'),
(499, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(500, '8940900292', '', '745029', '2024-01-19 10:03:34', b'0'),
(501, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(502, '8940900292', '', '108607', '2024-01-19 10:03:34', b'0'),
(503, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(504, '8940900292', '', '533079', '2024-01-19 10:03:34', b'0'),
(505, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(506, '8940900292', '', '569574', '2024-01-19 10:03:34', b'0'),
(507, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(508, '8940900292', '', '607675', '2024-01-19 10:03:34', b'0'),
(509, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(510, '8940900293', '', '528621', '2024-01-19 10:03:34', b'0'),
(511, '8940900293', '', '', '2024-01-19 10:03:34', b'0'),
(512, '8940900292', '', '921718', '2024-01-19 10:03:34', b'0'),
(513, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(514, '8940900292', '', '459502', '2024-01-19 10:03:34', b'0'),
(515, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(516, '8940900292', '', '601299', '2024-01-19 10:03:34', b'0'),
(517, '8940900292', '', '871261', '2024-01-19 10:03:34', b'0'),
(518, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(519, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(520, '8903061357', '', '710884', '2024-01-19 10:03:34', b'0'),
(521, '8903061357', '', '', '2024-01-19 10:03:34', b'0'),
(522, '8940900292', '', '513052', '2024-01-19 10:03:34', b'0'),
(523, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(524, '8903061357', '', '459600', '2024-01-19 10:03:34', b'0'),
(525, '8903061357', '', '', '2024-01-19 10:03:34', b'0'),
(526, '8903061357', '', '541991', '2024-01-19 10:03:34', b'0'),
(527, '8903061357', '', '', '2024-01-19 10:03:34', b'0'),
(528, '8903061357', '', '356459', '2024-01-19 10:03:34', b'0'),
(529, '8903061357', '', '', '2024-01-19 10:03:34', b'0'),
(530, '8940900292', '', '322435', '2024-01-19 10:03:34', b'0'),
(531, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(532, '8940900292', '', '956292', '2024-01-19 10:03:34', b'0'),
(533, '8940900292', '', '764264', '2024-01-19 10:03:34', b'0'),
(534, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(535, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(536, '8903061357', '', '522877', '2024-01-19 10:03:34', b'0'),
(537, '8903061357', '', '', '2024-01-19 10:03:34', b'0'),
(538, '8940900292', '', '277535', '2024-01-19 10:03:34', b'0'),
(539, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(540, '8903061357', '', '254872', '2024-01-19 10:03:34', b'0'),
(541, '8903061357', '', '', '2024-01-19 10:03:34', b'0'),
(542, '8940900292', '', '758129', '2024-01-19 10:03:34', b'0'),
(543, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(544, '8903061357', '', '734170', '2024-01-19 10:03:34', b'0'),
(545, '8903061357', '', '', '2024-01-19 10:03:34', b'0'),
(546, '8940900292', '', '799304', '2024-01-19 10:03:34', b'0'),
(547, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(548, '8903061357', '', '387054', '2024-01-19 10:03:34', b'0'),
(549, '8903061357', '', '', '2024-01-19 10:03:34', b'0'),
(550, '8940900292', '', '570543', '2024-01-19 10:03:34', b'0'),
(551, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(552, '8940900292', '', '915658', '2024-01-19 10:03:34', b'0'),
(553, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(554, '8940900292', '', '368557', '2024-01-19 10:03:34', b'0'),
(555, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(556, '8903061357', '', '689144', '2024-01-19 10:03:34', b'0'),
(557, '8903061357', '', '', '2024-01-19 10:03:34', b'0'),
(558, '8940900292', '', '542038', '2024-01-19 10:03:34', b'0'),
(559, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(560, '8940900292', '', '915924', '2024-01-19 10:03:34', b'0'),
(561, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(562, '8940900292', '', '432484', '2024-01-19 10:03:34', b'0'),
(563, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(564, '8903061357', '', '236751', '2024-01-19 10:03:34', b'0'),
(565, '8903061357', '', '', '2024-01-19 10:03:34', b'0'),
(566, '8940900292', '', '899144', '2024-01-19 10:03:34', b'0'),
(567, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(568, '8903061357', '', '643131', '2024-01-19 10:03:34', b'0'),
(569, '8903061357', '', '', '2024-01-19 10:03:34', b'0'),
(570, '8940900292', '', '881251', '2024-01-19 10:03:34', b'0'),
(571, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(572, '8903061357', '', '390244', '2024-01-19 10:03:34', b'0'),
(573, '8903061357', '', '', '2024-01-19 10:03:34', b'0'),
(574, '8903061357', '', '921284', '2024-01-19 10:03:34', b'0'),
(575, '8903061357', '', '', '2024-01-19 10:03:34', b'0'),
(576, '8940900292', '', '358379', '2024-01-19 10:03:34', b'0'),
(577, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(578, '8903061357', '', '501113', '2024-01-19 10:03:34', b'0'),
(579, '8903061357', '', '', '2024-01-19 10:03:34', b'0'),
(580, '8903061357', '', '706556', '2024-01-19 10:03:34', b'0'),
(581, '8903061357', '', '', '2024-01-19 10:03:34', b'0'),
(582, '8940900292', '', '804957', '2024-01-19 10:03:34', b'0'),
(583, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(584, '8940900292', '', '162778', '2024-01-19 10:03:34', b'0'),
(585, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(586, '8940900292', '', '512087', '2024-01-19 10:03:34', b'0'),
(587, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(588, '8989898989', '', '944004', '2024-01-21 17:48:33', b'0'),
(589, '8989898989', '', '', '2024-01-21 17:48:33', b'0'),
(590, '8989898989', '', '132021', '2024-01-21 17:48:33', b'0'),
(591, '8989898989', '', '', '2024-01-21 17:48:33', b'0'),
(592, '8989898989', '', '991832', '2024-01-21 17:48:33', b'0'),
(593, '8989898989', '', '', '2024-01-21 17:48:33', b'0'),
(594, '8989898989', '', '473093', '2024-01-21 17:48:33', b'0'),
(595, '8989898989', '', '', '2024-01-21 17:48:33', b'0'),
(596, '8940900292', '', '509930', '2024-01-21 17:48:33', b'0'),
(597, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(598, '8940900292', '', '892038', '2024-01-21 17:48:33', b'0'),
(599, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(600, '8940900292', '', '635956', '2024-01-21 17:48:33', b'0'),
(601, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(602, '8940900292', '', '482718', '2024-01-21 17:48:33', b'0'),
(603, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(604, '8903061357', '', '447061', '2024-01-21 17:48:33', b'0'),
(605, '8903061357', '', '', '2024-01-21 17:48:33', b'0'),
(606, '8903061357', '', '885516', '2024-01-21 17:48:33', b'0'),
(607, '8903061357', '', '', '2024-01-21 17:48:33', b'0'),
(608, '8903061357', '', '569956', '2024-01-21 17:48:33', b'0'),
(609, '8903061357', '', '', '2024-01-21 17:48:33', b'0'),
(610, '8940900292', '', '647226', '2024-01-21 17:48:33', b'0'),
(611, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(612, '8940900292', '', '444850', '2024-01-21 17:48:33', b'0'),
(613, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(614, '8903061357', '', '628665', '2024-01-21 17:48:33', b'0'),
(615, '8903061357', '', '', '2024-01-21 17:48:33', b'0'),
(616, '8940900292', '', '510661', '2024-01-21 17:48:33', b'0'),
(617, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(618, '8940900292', '', '658825', '2024-01-21 17:48:33', b'0'),
(619, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(620, '8940900292', '', '291769', '2024-01-21 17:48:33', b'0'),
(621, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(622, '8940900292', '', '487824', '2024-01-21 17:48:33', b'0'),
(623, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(624, '8940900292', '', '496384', '2024-01-21 17:48:33', b'0'),
(625, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(626, '8940900292', '', '645071', '2024-01-21 17:48:33', b'0'),
(627, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(628, '8940900292', '', '281079', '2024-01-21 17:48:33', b'0'),
(629, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(630, '8940900292', '', '325689', '2024-01-21 17:48:33', b'0'),
(631, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(632, '8940900292', '', '545192', '2024-01-21 17:48:33', b'0'),
(633, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(634, '8940900292', '', '192927', '2024-01-21 17:48:33', b'0'),
(635, '8940900292', '', '510719', '2024-01-21 17:48:33', b'0'),
(636, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(637, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(638, '8940900292', '', '290216', '2024-01-21 17:48:33', b'0'),
(639, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(640, '8940900292', '', '119455', '2024-01-21 17:48:33', b'0'),
(641, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(642, '8940900292', '', '873276', '2024-01-21 17:48:33', b'0'),
(643, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(644, '8940900292', '', '410244', '2024-01-21 17:48:33', b'0'),
(645, '8940900292', '', '437754', '2024-01-21 17:48:33', b'0'),
(646, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(647, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(648, '8940900292', '', '907075', '2024-01-21 17:48:33', b'0'),
(649, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(650, '8940900292', '', '190728', '2024-01-21 17:48:33', b'0'),
(651, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(652, '8940900292', '', '619003', '2024-01-21 17:48:33', b'0'),
(653, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(654, '8940900292', '', '823799', '2024-01-21 17:48:33', b'0'),
(655, '8940900292', '', '540639', '2024-01-21 17:48:33', b'0'),
(656, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(657, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(658, '8940900292', '', '626801', '2024-01-21 17:48:33', b'0'),
(659, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(660, '8940900292', '', '788099', '2024-01-21 17:48:33', b'0'),
(661, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(662, '9361621891', '', '876949', '2024-01-18 07:41:18', b'0'),
(663, '9361621891', '', '', '2024-01-18 07:41:18', b'0'),
(664, '9361621891', '', '595964', '2024-01-18 07:41:18', b'0'),
(665, '9361621891', '', '', '2024-01-18 07:41:18', b'0'),
(666, '6374573725', '', '920773', '2024-01-18 07:41:18', b'0'),
(667, '6374573725', '', '', '2024-01-18 07:41:18', b'0'),
(668, '6374573725', '', '497510', '2024-01-18 07:41:18', b'0'),
(669, '6374573725', '', '', '2024-01-18 07:41:18', b'0'),
(670, '6374573725', '', '262769', '2024-01-18 07:41:18', b'0'),
(671, '6374573725', '', '', '2024-01-18 07:41:18', b'0'),
(672, '8248498874', '', '600834', '2024-01-24 07:10:36', b'0'),
(673, '8248498874', '', '', '2024-01-24 07:10:36', b'0'),
(674, '8248498874', '', '177184', '2024-01-24 10:20:53', b'0'),
(675, '8248498874', '', '', '2024-01-24 10:20:53', b'0'),
(676, '8903061357', '', '757203', '2024-01-24 10:20:53', b'0'),
(677, '8903061357', '', '', '2024-01-24 10:20:53', b'0'),
(678, '8940900292', '', '870316', '2024-01-24 10:20:53', b'0'),
(679, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(680, '6374573725', '', '295295', '2024-01-24 07:10:36', b'0'),
(681, '6374573725', '', '', '2024-01-24 07:10:36', b'0'),
(682, '6374573725', '', '802319', '2024-01-24 07:10:36', b'0'),
(683, '6374573725', '', '370391', '2024-01-24 07:10:36', b'0'),
(684, '6374573725', '', '', '2024-01-24 07:10:36', b'0'),
(685, '6374573725', '', '', '2024-01-24 07:10:36', b'0'),
(686, '8940900292', '', '662664', '2024-01-24 10:20:53', b'0'),
(687, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(688, '6374573725', '', '152648', '2024-01-24 07:10:36', b'0'),
(689, '6374573725', '', '', '2024-01-24 07:10:36', b'0'),
(690, '6374573725', '', '968100', '2024-01-24 07:10:36', b'0'),
(691, '6374573725', '', '', '2024-01-24 07:10:36', b'0'),
(692, '6374573725', '', '495330', '2024-01-24 07:10:36', b'0'),
(693, '6374573725', '', '', '2024-01-24 07:10:36', b'0'),
(694, '8903061357', '', '641927', '2024-01-24 13:21:23', b'0'),
(695, '8903061357', '', '', '2024-01-24 13:21:23', b'0'),
(696, '8940900292', '', '536317', '2024-01-24 13:21:23', b'0'),
(697, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(698, '8940900292', '', '940857', '2024-01-24 13:21:23', b'0'),
(699, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(700, '8940900292', '', '794937', '2024-01-24 13:21:23', b'0'),
(701, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(702, '8940900292', '', '122251', '2024-01-24 13:21:23', b'0'),
(703, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(704, '8940900292', '', '227238', '2024-01-24 17:03:35', b'0'),
(705, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(706, '9361621891', '', '346052', '2024-01-24 07:10:36', b'0'),
(707, '9361621891', '', '', '2024-01-24 07:10:36', b'0'),
(708, '9361621891', '', '914647', '2024-01-29 21:05:38', b'0'),
(709, '9361621891', '', '426271', '2024-01-29 21:07:40', b'0'),
(710, '9361621891', '', '191390', '2024-01-29 21:07:59', b'0'),
(711, '9361621891', '', '322122', '2024-01-29 21:10:06', b'0'),
(712, '9361621891', '', '710536', '2024-01-29 21:11:00', b'0'),
(713, '9361621891', '', '479357', '2024-01-29 21:11:56', b'0'),
(714, '9361621891', '', '230964', '2024-01-29 21:13:46', b'0'),
(715, '9361621891', '', '851071', '2024-01-29 21:14:57', b'0'),
(716, '9361621891', '', '221869', '2024-01-29 21:15:10', b'0'),
(717, '9361621891', '', '974272', '2024-01-29 21:16:44', b'0'),
(718, '9361621891', '', '930494', '2024-01-29 21:17:08', b'0'),
(719, '9361621891', '', '960390', '2024-01-29 21:17:35', b'0'),
(720, '9361621891', '', '349543', '2024-01-29 21:18:07', b'0'),
(721, '9361621891', '', '881973', '2024-01-29 21:18:13', b'0'),
(722, '9361621891', '', '720506', '2024-01-29 21:18:29', b'0'),
(723, '9361621891', '', '321829', '2024-01-29 21:19:16', b'0'),
(724, '9361621891', '', '792737', '2024-01-29 21:19:32', b'0'),
(725, '9361621891', '', '170855', '2024-01-29 21:20:16', b'0'),
(726, '9361621891', '', '153372', '2024-01-29 21:21:26', b'0'),
(727, '9361621891', '', '850873', '2024-01-29 21:25:07', b'0'),
(728, '9361621891', '', '726918', '2024-01-29 21:25:42', b'0'),
(729, '9361621891', '', '185970', '2024-01-29 21:21:08', b'0'),
(730, '9361621891', '', '965565', '2024-01-29 21:21:59', b'0'),
(731, '9361621891', '', '564591', '2024-01-29 21:22:58', b'0'),
(732, '9361621891', '', '987542', '2024-01-29 21:23:04', b'0'),
(733, '9361621891', '', '539368', '2024-01-29 21:24:40', b'0'),
(734, '9361621891', '', '817910', '2024-01-29 21:26:07', b'0'),
(735, '9361621891', '', '345331', '2024-01-29 21:29:46', b'0'),
(736, '9361621891', '', '772363', '2024-01-29 21:30:34', b'0'),
(737, '9361621891', '', '438549', '2024-01-29 21:31:00', b'0'),
(738, '8940900292', '', '672573', '2024-01-30 11:07:02', b'0'),
(739, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(740, '8940900292', '', '556813', '2024-01-31 10:16:39', b'0'),
(741, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(742, '9344002002', '', '840588', '2024-01-31 10:29:31', b'0'),
(743, '9344002002', '', '', '2024-01-31 10:29:31', b'0'),
(744, '9344002002', '', '275211', '2024-01-31 10:29:31', b'0'),
(745, '9344002002', '', '', '2024-01-31 10:29:31', b'0'),
(746, '8903061357', '', '183006', '2024-01-31 10:29:31', b'0'),
(747, '8903061357', '', '', '2024-01-31 10:29:31', b'0'),
(748, '8903061357', '', '957584', '2024-01-31 10:29:31', b'0'),
(749, '8903061357', '', '', '2024-01-31 10:29:31', b'0'),
(750, '9884302002', '', '167044', '2024-01-31 10:29:31', b'0'),
(751, '9884302002', '', '', '2024-01-31 10:29:31', b'0'),
(752, '9884302002', '', '125446', '2024-01-31 10:29:31', b'0'),
(753, '9884302002', '', '', '2024-01-31 10:29:31', b'0'),
(754, '8903061357', '', '442399', '2024-01-31 10:29:31', b'0'),
(755, '8903061357', '', '', '2024-01-31 10:29:31', b'0'),
(756, '8903061357', '', '547250', '2024-01-31 10:29:31', b'0'),
(757, '8903061357', '', '', '2024-01-31 10:29:31', b'0'),
(758, '8903061357', '', '513902', '2024-01-31 10:29:31', b'0'),
(759, '8903061357', '', '', '2024-01-31 10:29:31', b'0'),
(760, '8903061357', '', '389211', '2024-01-31 10:29:31', b'0'),
(761, '8903061357', '', '', '2024-01-31 10:29:31', b'0'),
(762, '8903061357', '', '218555', '2024-01-31 10:29:31', b'0'),
(763, '8903061357', '', '', '2024-01-31 10:29:31', b'0'),
(764, '8940900292', '', '745164', '2024-02-05 10:09:03', b'0'),
(765, '8940900292', '', '778613', '2024-02-05 10:09:03', b'0'),
(766, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(767, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(768, '8940900292', '', '830804', '2024-02-05 10:09:03', b'0'),
(769, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(770, '8940900292', '', '164784', '2024-02-05 10:09:03', b'0'),
(771, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(772, '8940900292', '', '258198', '2024-02-06 10:15:27', b'0'),
(773, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(774, '8940900292', '', '101271', '2024-02-06 17:35:21', b'0'),
(775, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(776, '9361621891', '', '760606', '2024-02-06 17:39:54', b'0'),
(777, '9361621891', '', '', '2024-02-06 17:39:54', b'0'),
(778, '9361621891', '', '622223', '2024-02-06 17:53:45', b'0'),
(779, '9361621891', '', '', '2024-02-06 17:53:45', b'0'),
(780, '8940900292', '', '869479', '2024-02-06 17:58:53', b'0'),
(781, '8940900292', '', '768737', '2024-02-06 17:58:53', b'0'),
(782, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(783, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(784, '8940900292', '', '661501', '2024-02-06 17:58:53', b'0'),
(785, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(786, '8940900292', '', '120564', '2024-02-06 17:58:53', b'0'),
(787, '8940900292', '', '', '1970-01-01 05:34:43', b'0'),
(788, '9361621891', '', '566810', '2024-02-06 18:09:09', b'0'),
(789, '9361621891', '', '', '2024-02-06 18:09:08', b'0'),
(790, '8056246381', '', '281643', '2024-02-06 17:58:53', b'0'),
(791, '8056246381', '', '', '2024-02-06 17:58:53', b'0'),
(792, '9361621891', '', '608788', '2024-02-06 18:27:10', b'0'),
(793, '9361621891', '', '474945', '2024-02-06 18:47:35', b'0'),
(794, '8940900292', '', '256981', '2024-02-06 20:31:54', b'0'),
(795, '8940900292', '', '306566', '2024-02-06 20:31:54', b'0'),
(796, '8940900292', '', '798996', '2024-02-06 20:31:54', b'0'),
(797, '8940900292', '', '325137', '2024-02-06 20:31:54', b'0'),
(798, '8940900292', '', '556034', '2024-02-07 10:41:00', b'0'),
(799, '8940900292', '', '936214', '2024-02-07 23:47:38', b'0'),
(800, '8940900292', '', '213185', '2024-02-07 23:47:38', b'0'),
(801, '8940900292', '', '929798', '2024-02-07 23:47:38', b'0'),
(802, '8940900292', '', '540594', '2024-02-07 23:47:38', b'0'),
(803, '8940900292', '', '167637', '2024-02-08 11:32:11', b'0'),
(804, '8940900292', '', '848614', '2024-02-08 11:32:11', b'0'),
(805, '8903061357', '', '443173', '2024-02-12 13:10:30', b'0'),
(806, '8903061357', '', '750096', '2024-02-12 13:10:30', b'0'),
(807, '8903061357', '', '878671', '2024-02-12 13:10:30', b'0'),
(808, '8940900292', '', '233172', '2024-02-12 13:10:30', b'0'),
(809, '8940900292', '', '971461', '2024-02-12 14:54:22', b'0'),
(810, '8940900292', '', '744614', '2024-02-12 14:54:22', b'0'),
(811, '8940900292', '', '564228', '2024-02-12 14:54:22', b'0'),
(812, '8940900292', '', '247442', '2024-02-12 14:54:22', b'0'),
(813, '8940900292', '', '685929', '2024-02-12 14:54:22', b'0'),
(814, '8940900292', '', '796701', '2024-02-12 14:54:22', b'0'),
(815, '8940900292', '', '215922', '2024-02-12 14:54:22', b'0'),
(816, '8940900292', '', '595580', '2024-02-12 14:54:22', b'0'),
(817, '8940900292', '', '851242', '2024-02-12 14:54:22', b'0'),
(818, '8940900292', '', '986658', '2024-02-12 14:54:22', b'0'),
(819, '8940900292', '', '936391', '2024-02-12 14:54:22', b'0'),
(820, '8940900292', '', '771525', '2024-02-12 14:54:22', b'0'),
(821, '8940900292', '', '420810', '2024-02-12 14:54:22', b'0'),
(822, '8940900292', '', '839163', '2024-02-12 14:54:22', b'0'),
(823, '9791344113', '', '142186', '2024-02-12 14:54:22', b'0'),
(824, '8903061357', '', '297530', '2024-02-12 14:54:22', b'0'),
(825, '8903061357', '', '637459', '2024-02-12 14:54:22', b'0'),
(826, '9600420101', '', '914827', '2024-02-12 05:30:10', b'0'),
(827, '9600420101', '', '620758', '2024-02-12 05:30:10', b'0'),
(828, '9600420101', '', '550742', '2024-02-12 05:30:10', b'0'),
(829, '9600420101', '', '765909', '2024-02-12 05:30:10', b'0'),
(830, '9600420101', '', '855654', '2024-02-12 05:30:10', b'0'),
(831, '8940900292', '', '696508', '2024-02-12 14:54:22', b'0'),
(832, '8940900292', '', '612551', '2024-02-13 09:14:28', b'0'),
(833, '8940900291', '', '836323', '2024-02-13 09:14:28', b'0'),
(834, '9361621891', '', '111116', '2024-02-13 17:47:05', b'0'),
(835, '8940900292', '', '740667', '2024-02-15 10:43:57', b'0'),
(836, '8940900292', '', '189057', '2024-02-15 10:43:57', b'0'),
(837, '8940900292', '', '666469', '2024-02-15 10:43:57', b'0'),
(838, '8940900292', '', '271149', '2024-02-15 10:43:57', b'0'),
(839, '8940900292', '', '176640', '2024-02-15 10:43:57', b'0'),
(840, '8940900292', '', '874726', '2024-02-15 10:43:57', b'0'),
(841, '8940900292', '', '974705', '2024-02-15 10:43:57', b'0'),
(842, '8940900292', '', '137782', '2024-02-15 10:43:57', b'0'),
(843, '8940900292', '', '129474', '2024-02-15 10:43:57', b'0'),
(844, '9361621891', '', '567143', '2024-02-15 15:34:27', b'0'),
(845, '8940900292', '', '252554', '2024-02-15 11:54:17', b'0'),
(846, '9600724179', '', '355723', '2024-02-15 11:54:17', b'0'),
(847, '9600724179', '', '799207', '2024-02-15 11:54:17', b'0'),
(848, '9600724179', '', '843837', '2024-02-15 11:54:17', b'0'),
(849, '9600724179', '', '680486', '2024-02-15 11:54:17', b'0'),
(850, '8940900292', '', '985702', '2024-02-15 11:54:17', b'0'),
(851, '8940900292', '', '192975', '2024-02-15 11:54:17', b'0'),
(852, '8940900292', '', '998282', '2024-02-15 11:54:17', b'0'),
(853, '8940900292', '', '578051', '2024-02-15 11:54:17', b'0'),
(854, '6374573725', '', '864831', '2024-02-15 10:32:33', b'0'),
(855, '6374573725', '', '398008', '2024-02-15 10:32:33', b'0'),
(856, '6374573725', '', '807099', '2024-02-15 10:32:33', b'0'),
(857, '6374573725', '', '960746', '2024-02-15 10:32:33', b'0'),
(858, '6374573725', '', '879325', '2024-02-15 10:32:33', b'0'),
(859, '6374573725', '', '942265', '2024-02-15 10:32:33', b'0'),
(860, '8248498874', '', '534553', '2024-02-15 10:32:33', b'0'),
(861, '8940900292', '', '121926', '2024-02-15 11:54:17', b'0'),
(862, '8940900292', '', '655132', '2024-02-15 11:54:17', b'0'),
(863, '8248498874', '', '493419', '2024-02-15 10:32:33', b'0'),
(864, '8248498874', '', '580229', '2024-02-15 10:32:33', b'0'),
(865, '8248498874', '', '469545', '2024-02-15 10:32:33', b'0'),
(866, '6374573725', '', '252735', '2024-02-15 10:32:33', b'0'),
(867, '6374573725', '', '300651', '2024-02-15 10:32:33', b'0'),
(868, '8940900292', '', '272374', '2024-02-15 11:54:17', b'0'),
(869, '8940900292', '', '595663', '2024-02-15 11:54:17', b'0'),
(870, '6374573725', '', '372209', '2024-02-15 10:32:33', b'0'),
(871, '6374573725', '', '497602', '2024-02-15 10:32:33', b'0'),
(872, '6374573725', '', '113256', '2024-02-15 10:32:33', b'0'),
(873, '8940900292', '', '245256', '2024-02-15 11:54:17', b'0'),
(874, '8940900292', '', '399906', '2024-02-15 11:54:17', b'0'),
(875, '8940900292', '', '385627', '2024-02-15 11:54:17', b'0'),
(876, '8940900292', '', '799817', '2024-02-15 17:02:01', b'0'),
(877, '8940900292', '', '202272', '2024-02-15 17:02:01', b'0'),
(878, '9361621891', '', '417388', '2024-02-15 16:49:54', b'0'),
(879, '9361621891', '', '375090', '2024-02-15 16:49:54', b'0'),
(880, '8940900292', '', '834595', '2024-02-15 17:02:01', b'0'),
(881, '8940900292', '', '131318', '2024-02-15 17:02:01', b'0'),
(882, '8940900292', '', '925386', '2024-02-16 09:39:23', b'0'),
(883, '8940900292', '', '235321', '2024-02-16 09:39:23', b'0'),
(884, '8940900292', '', '641984', '2024-02-16 09:39:23', b'0'),
(885, '8940900292', '', '812429', '2024-02-16 09:39:23', b'0'),
(886, '8940900292', '', '602548', '2024-02-16 09:39:23', b'0'),
(887, '8940900292', '', '465678', '2024-02-16 09:39:23', b'0'),
(888, '8940900292', '', '102761', '2024-02-16 09:39:23', b'0'),
(889, '8940900292', '', '415052', '2024-02-16 09:39:23', b'0'),
(890, '8940900292', '', '521373', '2024-02-16 09:39:23', b'0'),
(891, '8940900292', '', '810203', '2024-02-15 10:32:33', b'0'),
(892, '8903061357', '', '734011', '2024-02-15 10:32:33', b'0'),
(893, '6374573725', '', '315977', '2024-02-15 10:32:33', b'0'),
(894, '8903061357', '', '977362', '2024-02-15 10:32:33', b'0'),
(895, '6374573725', '', '198383', '2024-02-15 10:32:33', b'0');
INSERT INTO `otpsmslog` (`logid`, `mobileno`, `email`, `otpcode`, `senttime`, `status`) VALUES
(896, '6374573725', '', '603958', '2024-02-15 10:32:33', b'0'),
(897, '9894749740', '', '250958', '2024-02-15 10:32:33', b'0'),
(898, '8248498874', '', '789043', '2024-02-15 10:32:33', b'0'),
(899, '8248498874', '', '191239', '2024-02-15 10:32:33', b'0'),
(900, '8903061357', '', '213330', '2024-02-16 09:39:23', b'0'),
(901, '8903061357', '', '285843', '2024-02-16 09:39:23', b'0'),
(902, '8903061357', '', '540684', '2024-02-16 09:39:23', b'0'),
(903, '3424324324', '', '647433', '2024-02-16 09:39:23', b'0'),
(904, '3424324324', '', '323405', '2024-02-16 09:39:23', b'0'),
(905, '8903061357', '', '909409', '2024-02-16 09:39:23', b'0'),
(906, '8903061357', '', '704237', '2024-02-16 09:39:23', b'0'),
(907, '8903061357', '', '630422', '2024-02-16 09:39:23', b'0'),
(908, '8248498874', '', '254413', '2024-02-15 10:32:33', b'0'),
(909, '8248498874', '', '667820', '2024-02-15 10:32:33', b'0'),
(910, '8903061357', '', '145216', '2024-02-15 10:32:33', b'0'),
(911, '8903061357', '', '765103', '2024-02-15 10:32:33', b'0'),
(912, '8903061357', '', '541569', '2024-02-16 09:39:23', b'0'),
(913, '1111111111', '', '364778', '2024-02-15 10:32:33', b'0'),
(914, '1111111111', '', '976755', '2024-02-15 10:32:33', b'0'),
(915, '1111111111', '', '959414', '2024-02-15 10:32:33', b'0'),
(916, '1111111111', '', '148302', '2024-02-15 10:32:33', b'0'),
(917, '9894749740', '', '293273', '2024-02-15 10:32:33', b'0'),
(918, '8248498874', '', '957485', '2024-02-15 10:32:33', b'0'),
(919, '8248498874', '', '830291', '2024-02-15 10:32:33', b'0'),
(920, '8248498874', '', '731624', '2024-02-15 10:32:33', b'0'),
(921, '8248498874', '', '535246', '2024-02-15 10:32:33', b'0'),
(922, '8248498874', '', '847316', '2024-02-15 10:32:33', b'0'),
(923, '8903061357', '', '270376', '2024-02-16 09:39:23', b'0'),
(924, '8248498874', '', '153085', '2024-02-15 10:32:33', b'0'),
(925, '8248498874', '', '613857', '2024-02-15 10:32:33', b'0'),
(926, '8903061357', '', '741323', '2024-02-16 09:39:23', b'0'),
(927, '8903061357', '', '916323', '2024-02-15 10:32:33', b'0'),
(928, '8903061357', '', '991108', '2024-02-15 10:32:33', b'0'),
(929, '8248498874', '', '307482', '2024-02-15 10:32:33', b'0'),
(930, '8248498874', '', '681777', '2024-02-15 10:32:33', b'0'),
(931, '8248498874', '', '591278', '2024-02-15 10:32:33', b'0'),
(932, '8903061357', '', '561832', '2024-02-15 10:32:33', b'0'),
(933, '8903061357', '', '333591', '2024-02-15 10:32:33', b'0'),
(934, '8248498874', '', '470728', '2024-02-15 10:32:33', b'0'),
(935, '8248498874', '', '557976', '2024-02-15 10:32:33', b'0'),
(936, '8248498874', '', '849601', '2024-02-15 10:32:33', b'0'),
(937, '8248498874', '', '691811', '2024-02-15 10:32:33', b'0'),
(938, '8248498874', '', '496737', '2024-02-15 10:32:33', b'0'),
(939, '8248498874', '', '108081', '2024-02-15 10:32:33', b'0'),
(940, '8248498874', '', '194445', '2024-02-15 10:32:33', b'0'),
(941, '8248498874', '', '830268', '2024-02-15 10:32:33', b'0'),
(942, '9884302002', '', '767914', '2024-02-19 09:56:23', b'0'),
(943, '9884302002', '', '352928', '2024-02-19 11:44:50', b'0'),
(944, '9884302002', '', '670136', '2024-02-19 11:44:50', b'0'),
(945, '9884302002', '', '794088', '2024-02-19 11:44:50', b'0'),
(946, '8940900292', '', '562013', '2024-02-19 11:44:50', b'0'),
(947, '8903061357', '', '457703', '2024-02-19 11:44:50', b'0'),
(948, '8903061357', '', '249866', '2024-02-19 11:44:50', b'0'),
(949, '8903061357', '', '850408', '2024-02-19 11:44:50', b'0'),
(950, '8903061357', '', '976961', '2024-02-19 11:44:50', b'0'),
(951, '9600420101', '', '889939', '2024-02-26 08:16:19', b'0'),
(952, '8940900292', '', '289597', '2024-03-04 12:14:34', b'0'),
(953, '8940900292', '', '240339', '2024-03-04 12:14:34', b'0'),
(954, '8903061357', '', '772487', '2024-03-07 15:15:39', b'0'),
(955, '8903061357', '', '747620', '2024-03-07 15:15:39', b'0'),
(956, '6374573725', '', '561296', '2024-03-08 12:41:55', b'0'),
(957, '9600420101', '', '946102', '2024-03-10 17:39:02', b'0'),
(958, '9600420101', '', '696739', '2024-03-10 17:39:02', b'0'),
(959, '9600420101', '', '982729', '2024-03-10 17:39:02', b'0'),
(960, '8940900292', '', '853803', '2024-03-10 17:39:02', b'0'),
(961, '8940900292', '', '824944', '2024-03-10 17:39:02', b'0'),
(962, '8940900292', '', '974739', '2024-03-10 17:39:02', b'0'),
(963, '8940900292', '', '494543', '2024-03-10 17:39:02', b'0'),
(964, '8940900292', '', '498865', '2024-03-10 17:39:02', b'0'),
(965, '8940900292', '', '676046', '2024-03-10 17:39:02', b'0'),
(966, '8940900292', '', '521559', '2024-03-10 17:39:02', b'0'),
(967, '8940900292', '', '912838', '2024-03-10 17:39:02', b'0'),
(968, '8940900292', '', '761183', '2024-03-11 12:05:14', b'0'),
(969, '8940900292', '', '877164', '2024-03-11 12:05:14', b'0'),
(970, '8940900292', '', '429154', '2024-03-11 12:05:14', b'0'),
(971, '8940900292', '', '607774', '2024-03-11 12:05:14', b'0'),
(972, '8940900292', '', '861360', '2024-03-11 12:05:14', b'0'),
(973, '8940900292', '', '833614', '2024-03-11 12:05:14', b'0'),
(974, '8940900292', '', '255481', '2024-03-11 12:05:14', b'0'),
(975, '8940900292', '', '636590', '2024-03-11 12:05:14', b'0'),
(976, '8940900292', '', '545868', '2024-03-11 12:05:14', b'0'),
(977, '8940900292', '', '346224', '2024-03-11 12:05:14', b'0'),
(978, '8940900292', '', '196336', '2024-03-11 12:05:14', b'0'),
(979, '8940900292', '', '894682', '2024-03-11 12:05:14', b'0'),
(980, '8940900292', '', '576195', '2024-03-11 12:05:14', b'0'),
(981, '8940900292', '', '333499', '2024-03-11 12:05:14', b'0'),
(982, '8940900292', '', '592328', '2024-03-11 12:05:14', b'0'),
(983, '8940900292', '', '352054', '2024-03-11 17:00:11', b'0'),
(984, '8940900292', '', '174935', '2024-03-11 17:00:11', b'0'),
(985, '8940900292', '', '693522', '2024-03-11 17:00:11', b'0'),
(986, '6374573725', '', '609343', '2024-03-10 17:39:02', b'0'),
(987, '6374573725', '', '457659', '2024-03-10 17:39:02', b'0'),
(988, '8940900292', '', '620634', '2024-03-11 18:34:19', b'0'),
(989, '8940900292', '', '989149', '2024-03-11 18:34:19', b'0'),
(990, '8940900292', '', '132170', '2024-03-11 18:34:19', b'0'),
(991, '8940900292', '', '481821', '2024-03-11 18:34:19', b'0'),
(992, '8940900292', '', '496874', '2024-03-11 18:34:19', b'0'),
(993, '8940900292', '', '406274', '2024-03-11 18:34:19', b'0'),
(994, '8940900292', '', '121255', '2024-03-11 18:34:19', b'0'),
(995, '8940900292', '', '124123', '2024-03-11 18:34:19', b'0'),
(996, '8940900292', '', '252061', '2024-03-11 18:34:19', b'0'),
(997, '8940900292', '', '394147', '2024-03-11 18:34:19', b'0'),
(998, '8940900292', '', '594378', '2024-03-11 18:34:19', b'0'),
(999, '8940900292', '', '510838', '2024-03-11 18:34:19', b'0'),
(1000, '8940900292', '', '632573', '2024-03-11 18:34:19', b'0'),
(1001, '8940900292', '', '195719', '2024-03-11 18:34:19', b'0'),
(1002, '8940900292', '', '135423', '2024-03-11 18:34:19', b'0'),
(1003, '8940900292', '', '701224', '2024-03-11 18:34:19', b'0'),
(1004, '8940900292', '', '177786', '2024-03-11 18:34:19', b'0'),
(1005, '8940900292', '', '586341', '2024-03-11 18:34:19', b'0'),
(1006, '8940900292', '', '138381', '2024-03-11 18:34:19', b'0'),
(1007, '8940900292', '', '797697', '2024-03-11 18:34:19', b'0'),
(1008, '8940900292', '', '362420', '2024-03-11 18:34:19', b'0'),
(1009, '8940900292', '', '373355', '2024-03-11 18:34:19', b'0'),
(1010, '8940900292', '', '381927', '2024-03-11 18:34:19', b'0'),
(1011, '8940900292', '', '374765', '2024-03-11 18:34:19', b'0'),
(1012, '8940900292', '', '774739', '2024-03-11 18:34:19', b'0'),
(1013, '8940900292', '', '986157', '2024-03-11 18:34:19', b'0'),
(1014, '8940900292', '', '153482', '2024-03-11 18:34:19', b'0'),
(1015, '8940900292', '', '362566', '2024-03-11 18:34:19', b'0'),
(1016, '8940900292', '', '565773', '2024-03-11 18:34:19', b'0'),
(1017, '8940900292', '', '746741', '2024-03-11 18:34:19', b'0'),
(1018, '8940900292', '', '973446', '2024-03-11 18:34:19', b'0'),
(1019, '8940900292', '', '927802', '2024-03-11 18:34:19', b'0'),
(1020, '8940900292', '', '440337', '2024-03-11 18:34:19', b'0'),
(1021, '8940900292', '', '613347', '2024-03-11 18:34:19', b'0'),
(1022, '8940900292', '', '599351', '2024-03-11 18:34:19', b'0'),
(1023, '8940900292', '', '186739', '2024-03-11 18:34:19', b'0'),
(1024, '8940900292', '', '865505', '2024-03-11 18:34:19', b'0'),
(1025, '8940900292', '', '242137', '2024-03-11 18:34:19', b'0'),
(1026, '8940900292', '', '881557', '2024-03-11 18:34:19', b'0'),
(1027, '8940900292', '', '761370', '2024-03-11 18:34:19', b'0'),
(1028, '9600420101', '', '676436', '2024-03-10 17:39:02', b'0'),
(1029, '9600420101', '', '438886', '2024-03-10 17:39:02', b'0'),
(1030, '9600420101', '', '685947', '2024-03-10 17:39:02', b'0'),
(1031, '9600420101', '', '352800', '2024-03-12 11:04:02', b'0'),
(1032, '9600420101', '', '636312', '2024-03-10 17:39:02', b'0'),
(1033, '9361621891', '', '922113', '2024-03-10 17:39:02', b'0'),
(1034, '9894749740', '', '746453', '2024-03-10 17:39:02', b'0'),
(1035, '9894749740', '', '292268', '2024-03-10 17:39:02', b'0'),
(1036, '9894749740', '', '146966', '2024-03-10 17:39:02', b'0'),
(1037, '9894749740', '', '608224', '2024-03-10 17:39:02', b'0'),
(1038, '9894749740', '', '205748', '2024-03-10 17:39:02', b'0'),
(1039, '9894749740', '', '721197', '2024-03-10 17:39:02', b'0'),
(1040, '9894749740', '', '140632', '2024-03-10 17:39:02', b'0'),
(1041, '9894749740', '', '151140', '2024-03-10 17:39:02', b'0'),
(1042, '9894749740', '', '535104', '2024-03-10 17:39:02', b'0'),
(1043, '9894749740', '', '180776', '2024-03-10 17:39:02', b'0'),
(1044, '9894749740', '', '732570', '2024-03-10 17:39:02', b'0'),
(1045, '9894749740', '', '755701', '2024-03-10 17:39:02', b'0'),
(1046, '6374573725', '', '751116', '2024-03-10 17:39:02', b'0'),
(1047, '6374573725', '', '495765', '2024-03-10 17:39:02', b'0'),
(1048, '6374573725', '', '118946', '2024-03-10 17:39:02', b'0'),
(1049, '6374573725', '', '768124', '2024-03-10 17:39:02', b'0'),
(1050, '9894749740', '', '738262', '2024-03-10 17:39:02', b'0'),
(1051, '9894749740', '', '408977', '2024-03-10 17:39:02', b'0'),
(1052, '9894749740', '', '522981', '2024-03-10 17:39:02', b'0'),
(1053, '8248498874', '', '237277', '2024-03-10 17:39:02', b'0'),
(1054, '8248498874', '', '406656', '2024-03-10 17:39:02', b'0'),
(1055, '8248498874', '', '814544', '2024-03-10 17:39:02', b'0'),
(1056, '6379148114', '', '537394', '2024-03-10 17:39:02', b'0'),
(1057, '6379148114', '', '595334', '2024-03-10 17:39:02', b'0'),
(1058, '6379148114', '', '559617', '2024-03-10 17:39:02', b'0'),
(1059, '6379148114', '', '526278', '2024-03-10 17:39:02', b'0'),
(1060, '6379148114', '', '611905', '2024-03-10 17:39:02', b'0'),
(1061, '6379148114', '', '686358', '2024-03-10 17:39:02', b'0'),
(1062, '6379148114', '', '903803', '2024-03-10 17:39:02', b'0'),
(1063, '8940900292', '', '948214', '2024-03-20 18:50:49', b'0'),
(1064, '8940900292', '', '286835', '2024-03-20 18:50:49', b'0'),
(1065, '8940900292', '', '872313', '2024-03-20 20:16:20', b'0'),
(1066, '8940900292', '', '708462', '2024-03-20 20:16:20', b'0'),
(1067, '8940900292', '', '135683', '2024-03-25 14:00:18', b'0'),
(1068, '8940900292', '', '749371', '2024-03-25 14:00:18', b'0'),
(1069, '9600724179', '', '636319', '2024-03-25 14:33:10', b'0'),
(1070, '9600724179', '', '417203', '2024-03-26 19:44:20', b'0'),
(1071, '8940900292', '', '446334', '2024-03-26 20:03:23', b'0'),
(1072, '6374573725', '', '188499', '2024-03-26 21:02:29', b'0'),
(1073, '7708668443', '', '280796', '2024-03-27 09:50:29', b'0'),
(1074, '9791344113', '', '944036', '2024-03-27 11:06:04', b'0'),
(1075, '8940900292', '', '592845', '2024-03-27 11:06:04', b'0'),
(1076, '8940900292', '', '332458', '2024-03-27 11:06:04', b'0'),
(1077, '8940900292', '', '296575', '2024-03-27 11:06:04', b'0'),
(1078, '8940900292', '', '103171', '2024-03-27 11:06:04', b'0'),
(1079, '8940900292', '', '608087', '2024-03-27 11:06:04', b'0'),
(1080, '8940900292', '', '978011', '2024-03-27 11:06:04', b'0'),
(1081, '9600420101', '', '581459', '2024-03-28 11:38:01', b'0'),
(1082, '8940900292', '', '525157', '2024-03-28 14:59:50', b'0'),
(1083, '8940900292', '', '233538', '2024-03-28 14:59:50', b'0'),
(1084, '8940900292', '', '201520', '2024-03-28 14:59:50', b'0'),
(1085, '8940900292', '', '947654', '2024-03-30 14:21:29', b'0'),
(1086, '9600420101', '', '985090', '2024-03-29 14:58:53', b'0'),
(1087, '8903061357', '', '988230', '2024-03-29 14:58:53', b'0'),
(1088, '9884302002', '', '558654', '2024-03-29 14:58:53', b'0'),
(1089, '8940900292', '', '596110', '2024-04-12 01:30:41', b'0'),
(1090, '8940900292', '', '616008', '2024-04-12 01:30:41', b'0'),
(1091, '8940900292', '', '499919', '2024-04-12 01:30:41', b'0'),
(1092, '8940900292', '', '431516', '2024-04-12 01:30:41', b'0'),
(1093, '8940900292', '', '644069', '2024-04-12 01:30:41', b'0'),
(1094, '8940900292', '', '546672', '2024-04-12 01:30:41', b'0'),
(1095, '9361621891', '', '980387', '2024-04-12 11:27:51', b'0'),
(1096, '7708668443', '', '268178', '2024-04-12 12:29:48', b'0'),
(1097, '8940900292', '', '826477', '2024-04-30 10:26:43', b'0'),
(1098, '8940900292', '', '730758', '2024-04-30 10:26:43', b'0'),
(1099, '8940900292', '', '248403', '2024-04-30 10:26:43', b'0'),
(1100, '8940900292', '', '255152', '2024-04-30 10:26:43', b'0'),
(1101, '8940900292', '', '423939', '2024-04-30 10:26:43', b'0'),
(1102, '8940900292', '', '315455', '2024-04-30 10:26:43', b'0'),
(1103, '8940900292', '', '515075', '2024-04-30 10:26:43', b'0'),
(1104, '8940900292', '', '487770', '2024-04-30 10:26:43', b'0'),
(1105, '8940900292', '', '674959', '2024-04-30 10:26:43', b'0'),
(1106, '8940900292', '', '875729', '2024-04-30 10:26:43', b'0'),
(1107, '8940900292', '', '435692', '2024-04-30 10:26:43', b'0'),
(1108, '8940900292', '', '874794', '2024-04-12 12:29:48', b'0'),
(1109, '8940900292', '', '521899', '2024-04-30 10:26:43', b'0'),
(1110, '9361621891', '', '401636', '2024-04-30 12:00:06', b'0'),
(1111, '8940900292', '', '200820', '2024-04-30 12:00:06', b'0'),
(1112, '8940900292', '', '551177', '2024-04-30 12:00:06', b'0'),
(1113, '8940900292', '', '590118', '2024-04-30 12:05:02', b'0'),
(1114, '6374573725', '', '923741', '2024-05-24 10:20:02', b'0'),
(1115, '6374573725', '', '571226', '2024-05-24 10:20:01', b'0'),
(1116, '0637457372', '', '666862', '2024-05-24 10:20:01', b'0'),
(1117, '0637457372', '', '643282', '2024-05-24 10:20:01', b'0'),
(1118, '6374573725', '', '451924', '2024-05-24 10:20:01', b'0'),
(1119, '6374573725', '', '775447', '2024-05-24 10:20:01', b'0'),
(1120, '6374573725', '', '267536', '2024-05-24 10:20:02', b'0'),
(1121, '6374573725', '', '759367', '2024-05-24 10:20:01', b'0'),
(1122, '6374573725', '', '362743', '2024-05-24 10:20:01', b'0'),
(1123, '6374573725', '', '219537', '2024-05-24 10:20:02', b'0'),
(1124, '6374573725', '', '280841', '2024-05-24 10:20:01', b'0'),
(1125, '6374573725', '', '999079', '2024-05-24 10:20:02', b'0'),
(1126, '6374573725', '', '494988', '2024-05-24 10:20:01', b'0'),
(1127, '6374573725', '', '905121', '2024-05-24 10:20:01', b'0'),
(1128, '6374573725', '', '579499', '2024-05-24 10:20:02', b'0'),
(1129, '6374573725', '', '777532', '2024-05-24 10:20:01', b'0'),
(1130, '6374573725', '', '674805', '2024-05-24 10:20:01', b'0'),
(1131, '6374573725', '', '415694', '2024-05-24 10:20:01', b'0'),
(1132, '8940900293', '', '336365', '2024-05-24 10:20:01', b'0'),
(1133, '8940900292', '', '220930', '2024-05-24 10:20:01', b'0'),
(1134, '9361621891', '', '221376', '2024-05-24 10:20:01', b'0'),
(1135, '9361621891', '', '198982', '2024-06-07 11:22:40', b'0'),
(1136, '9361621891', '', '345691', '2024-06-07 11:32:02', b'0'),
(1137, '8940900292', '', '703471', '2024-06-07 11:39:52', b'0'),
(1138, '8940900292', '', '734951', '2024-06-11 09:45:56', b'0'),
(1139, '8940900292', '', '839818', '2024-06-11 09:45:56', b'0'),
(1140, '8940900292', '', '242882', '2024-06-11 09:45:56', b'0'),
(1141, '8940900292', '', '412370', '2024-06-11 09:45:56', b'0'),
(1142, '8940900292', '', '614039', '2024-06-11 09:45:56', b'0'),
(1143, '8940900292', '', '426030', '2024-06-11 09:45:56', b'0'),
(1144, '8940900292', '', '608294', '2024-06-11 09:45:56', b'0'),
(1145, '8940900292', '', '367759', '2024-06-11 09:45:56', b'0'),
(1146, '8940900292', '', '107383', '2024-06-11 09:45:56', b'0'),
(1147, '8940900292', '', '150290', '2024-06-11 09:45:56', b'0'),
(1148, '8940900292', '', '251929', '2024-06-11 09:45:56', b'0'),
(1149, '8940900292', '', '247001', '2024-06-11 11:42:21', b'0'),
(1150, '8940900292', '', '249652', '2024-06-11 11:42:21', b'0'),
(1151, '8940900292', '', '716403', '2024-06-11 11:42:21', b'0'),
(1152, '8940900292', '', '536406', '2024-06-11 11:42:21', b'0'),
(1153, '8940900292', '', '551182', '2024-06-11 11:42:21', b'0'),
(1154, '8940900292', '', '230840', '2024-06-11 11:42:21', b'0'),
(1155, '8940900292', '', '777224', '2024-06-11 11:42:21', b'0'),
(1156, '8940900292', '', '830711', '2024-06-11 11:42:21', b'0'),
(1157, '8940900292', '', '849910', '2024-06-11 11:42:21', b'0'),
(1158, '8940900292', '', '110645', '2024-06-11 11:42:21', b'0'),
(1159, '8940900292', '', '131517', '2024-06-11 11:42:21', b'0'),
(1160, '8940900292', '', '991889', '2024-06-11 11:42:21', b'0'),
(1161, '8940900292', '', '541074', '2024-06-11 11:42:21', b'0'),
(1162, '8940900292', '', '970993', '2024-06-11 11:42:21', b'0'),
(1163, '8940900292', '', '865564', '2024-06-11 11:42:21', b'0'),
(1164, '8940900292', '', '965731', '2024-06-11 11:42:21', b'0'),
(1165, '8940900292', '', '124489', '2024-06-11 11:42:21', b'0'),
(1166, '8940900292', '', '948327', '2024-06-11 11:42:21', b'0'),
(1167, '8940900292', '', '101039', '2024-06-11 11:42:21', b'0'),
(1168, '8940900292', '', '898324', '2024-06-11 11:42:21', b'0'),
(1169, '8940900292', '', '420842', '2024-06-11 11:42:21', b'0'),
(1170, '8940900292', '', '463958', '2024-06-11 11:42:21', b'0'),
(1171, '8903061357', '', '856966', '2024-06-11 11:42:21', b'0'),
(1172, '8940900292', '', '990054', '2024-06-12 12:55:33', b'0'),
(1173, '8940900292', '', '763248', '2024-06-12 12:55:33', b'0'),
(1174, '8940900292', '', '565274', '2024-06-12 12:55:33', b'0'),
(1175, '8903061357', '', '216576', '2024-06-12 12:55:33', b'0'),
(1176, '8940900292', '', '749956', '2024-06-12 12:55:33', b'0'),
(1177, '8940900292', '', '321702', '2024-06-12 12:55:33', b'0'),
(1178, '8940900292', '', '420411', '2024-06-12 12:55:33', b'0'),
(1179, '8903061357', '', '681578', '2024-06-12 12:55:33', b'0'),
(1180, '8903061357', '', '879876', '2024-06-12 12:55:33', b'0'),
(1181, '8903061357', '', '467127', '2024-06-12 12:55:33', b'0'),
(1182, '8903061357', '', '846965', '2024-06-12 12:55:33', b'0'),
(1183, '8903061357', '', '298085', '2024-06-12 12:55:33', b'0'),
(1184, '8940900292', '', '214255', '2024-05-24 10:20:01', b'0'),
(1185, '8940900292', '', '788081', '2024-05-24 10:20:01', b'0'),
(1186, '8903061357', '', '669355', '2024-05-24 10:20:02', b'0'),
(1187, '6374573725', '', '504469', '2024-05-24 10:20:01', b'0'),
(1188, '6374573725', '', '718024', '2024-05-24 10:20:02', b'0'),
(1189, '9894749740', '', '251425', '2024-05-24 10:20:01', b'0'),
(1190, '6374573725', '', '338019', '2024-05-24 10:20:02', b'0'),
(1191, '6374573725', '', '776999', '2024-05-24 10:20:01', b'0'),
(1192, '6374573725', '', '952039', '2024-05-24 10:20:02', b'0'),
(1193, '6374573725', '', '730618', '2024-05-24 10:20:02', b'0'),
(1194, '6374573725', '', '403675', '2024-05-24 10:20:02', b'0'),
(1195, '6374573725', '', '965665', '2024-05-24 10:20:01', b'0'),
(1196, '6374573725', '', '111564', '2024-05-24 10:20:01', b'0'),
(1197, '6374573725', '', '908164', '2024-05-24 10:20:02', b'0'),
(1198, '6374573725', '', '157354', '2024-05-24 10:20:02', b'0'),
(1199, '6374573725', '', '309045', '2024-05-24 10:20:01', b'0'),
(1200, '6374573725', '', '916280', '2024-05-24 10:20:01', b'0'),
(1201, '6374573725', '', '627205', '2024-05-24 10:20:01', b'0'),
(1202, '6374573725', '', '559995', '2024-05-24 10:20:01', b'0'),
(1203, '6374573725', '', '576808', '2024-05-24 10:20:02', b'0'),
(1204, '6374573725', '', '281432', '2024-05-24 10:20:01', b'0'),
(1205, '6374573725', '', '149842', '2024-05-24 10:20:01', b'0'),
(1206, '6374573725', '', '837599', '2024-05-24 10:20:01', b'0'),
(1207, '6374573725', '', '860243', '2024-05-24 10:20:01', b'0'),
(1208, '6374573725', '', '184242', '2024-05-24 10:20:01', b'0'),
(1209, '8940900292', '', '950389', '2024-06-22 19:55:20', b'0'),
(1210, '9361621891', '', '669941', '2024-06-22 19:55:20', b'0'),
(1211, '9361621891', '', '587075', '2024-06-22 19:55:20', b'0'),
(1212, '8940900292', '', '855686', '2024-09-03 14:53:24', b'0'),
(1213, '8940900292', '', '929809', '2024-09-03 14:53:24', b'0'),
(1214, '8940900292', '', '413730', '2024-09-03 15:00:01', b'0'),
(1215, '8940900292', '', '184673', '2024-09-03 15:00:01', b'0'),
(1216, '8940900292', '', '795718', '2024-09-03 15:00:01', b'0'),
(1217, '8940900292', '', '699851', '2024-09-04 12:06:47', b'0'),
(1218, '9361621891', '', '222035', '2024-09-04 17:19:01', b'0'),
(1219, '9361621891', '', '560719', '2024-09-04 17:19:01', b'0'),
(1220, '8940900292', '', '701360', '2024-09-04 23:47:36', b'0'),
(1221, '6369515090', '', '113003', '2024-09-05 10:56:15', b'0'),
(1222, '8940900292', '', '741779', '2024-09-06 10:29:25', b'0'),
(1223, '8940900292', '', '147064', '2024-09-06 10:29:25', b'0'),
(1224, '8940900292', '', '565147', '2024-09-06 18:34:06', b'0'),
(1225, '6369515090', '', '213135', '2024-09-07 07:42:17', b'0'),
(1226, '9900557609', '', '248440', '2024-09-07 07:29:43', b'0'),
(1227, '9600724189', '', '822563', '2024-09-23 17:20:32', b'0'),
(1228, '9600724189', '', '982998', '2024-09-23 17:20:32', b'0'),
(1229, '9600724189', '', '886937', '2024-09-23 17:20:32', b'0'),
(1230, '9600724189', '', '683006', '2024-09-23 17:20:32', b'0'),
(1231, '9600724189', '', '794363', '2024-09-23 17:20:32', b'0'),
(1232, '9600724189', '', '999080', '2024-09-23 17:20:32', b'0'),
(1233, '9600724189', '', '103075', '2024-09-23 17:20:32', b'0'),
(1234, '8940900297', '', '488207', '2024-09-23 17:20:32', b'0'),
(1235, '8989898989', '', '450638', '2024-09-23 17:20:32', b'0'),
(1236, '8989898989', '', '280347', '2024-09-23 17:20:32', b'0'),
(1237, '8940900292', '', '988805', '2024-09-23 17:20:32', b'0'),
(1238, '8940900292', '', '120167', '2024-09-23 17:20:32', b'0'),
(1239, '8940900292', '', '183044', '2024-09-23 17:20:32', b'0'),
(1240, '8940900292', '', '788845', '2024-09-23 17:20:32', b'0'),
(1241, '8940900292', '', '764024', '2024-09-23 17:20:32', b'0'),
(1242, '8940900292', '', '263134', '2024-09-23 17:20:32', b'0'),
(1243, '8940900292', '', '787087', '2024-09-26 11:57:10', b'0'),
(1244, '8940900292', '', '290970', '2024-09-26 11:59:41', b'0'),
(1245, '8940900292', '', '400885', '2024-09-26 11:59:41', b'0'),
(1246, '8940900292', '', '598155', '2024-09-26 11:59:41', b'0'),
(1247, '8940900292', '', '634653', '2024-09-26 11:59:41', b'0'),
(1248, '8940900292', '', '609679', '2024-09-26 11:59:41', b'0'),
(1249, '8940900292', '', '232308', '2024-09-26 11:59:41', b'0'),
(1250, '8940900292', '', '591459', '2024-09-26 11:59:41', b'0'),
(1251, '8940900292', '', '152446', '2024-09-26 11:59:41', b'0'),
(1252, '8940900292', '', '372872', '2024-09-26 11:59:41', b'0'),
(1253, '8940900292', '', '380528', '2024-09-26 11:59:41', b'0'),
(1254, '8940900292', '', '445123', '2024-09-26 11:59:41', b'0'),
(1255, '8940900292', '', '183957', '2024-09-26 11:59:41', b'0'),
(1256, '8940900292', '', '810766', '2024-09-26 11:59:41', b'0'),
(1257, '8940900292', '', '663226', '2024-09-26 11:59:41', b'0'),
(1258, '8940900292', '', '323731', '2024-09-26 11:59:41', b'0'),
(1259, '8940900292', '', '400915', '2024-09-26 11:59:41', b'0'),
(1260, '8940900292', '', '851139', '2024-09-26 11:59:41', b'0'),
(1261, '8940900292', '', '529680', '2024-09-26 11:59:41', b'0'),
(1262, '9361621891', '', '545082', '2024-09-27 13:25:30', b'0'),
(1263, '8940900292', '', '785379', '2024-09-27 14:39:26', b'0'),
(1264, '8940900292', '', '757179', '2024-09-27 16:38:59', b'0'),
(1265, '8903061357', '', '422451', '2024-09-27 16:38:59', b'0'),
(1266, '8903061357', '', '245678', '2024-09-27 16:38:59', b'0'),
(1267, '8940900292', '', '866577', '2024-09-30 18:48:52', b'0'),
(1268, '6374573725', '', '366690', '2024-09-30 18:48:52', b'0'),
(1269, '6374573725', '', '709385', '2024-09-30 18:48:52', b'0'),
(1270, '6379148114', '', '950597', '2024-09-30 18:48:52', b'0'),
(1271, '9345002002', '', '673179', '2024-09-30 18:48:52', b'0'),
(1272, '8940900292', '', '401810', '2024-09-30 18:48:52', b'0'),
(1273, '8940900292', '', '805177', '2024-09-30 18:48:52', b'0'),
(1274, '8940900292', '', '620983', '2024-10-24 14:12:43', b'0'),
(1275, '8903061357', '', '257189', '2024-10-26 11:27:03', b'0'),
(1276, '8903061357', '', '877149', '2024-10-26 11:27:03', b'0'),
(1277, '8940900292', '', '452346', '2024-10-26 11:27:03', b'0'),
(1278, '8903061357', '', '127955', '2024-10-28 10:30:58', b'0'),
(1279, '8903061357', '', '635493', '2024-10-28 10:30:58', b'0'),
(1280, '6374573725', '', '394848', '2024-10-28 12:28:09', b'0'),
(1281, '6374573725', '', '811552', '2024-10-28 12:28:09', b'0'),
(1282, '6374573725', '', '825988', '2024-10-28 12:28:09', b'0'),
(1283, '6374573725', '', '982749', '2024-10-28 12:28:09', b'0'),
(1284, '6374573725', '', '911681', '2024-10-28 12:28:09', b'0'),
(1285, '6374573725', '', '373478', '2024-10-28 12:28:09', b'0'),
(1286, '6374573725', '', '341387', '2024-10-28 12:28:09', b'0'),
(1287, '6374573725', '', '862497', '2024-10-28 12:28:09', b'0'),
(1288, '6374573725', '', '275194', '2024-10-28 12:28:09', b'0'),
(1289, '6374573725', '', '628226', '2024-10-28 12:28:09', b'0'),
(1290, '9894749740', '', '387599', '2024-10-28 12:28:09', b'0'),
(1291, '8248498874', '', '305784', '2024-10-28 12:28:09', b'0'),
(1292, '8940900292', '', '923742', '2024-11-04 17:19:33', b'0'),
(1293, '8940900292', '', '175356', '2024-11-04 17:19:33', b'0'),
(1294, '8903061357', '', '371178', '2024-11-06 13:25:01', b'0'),
(1295, '8903061357', '', '917209', '2024-11-06 13:48:50', b'0'),
(1296, '6374573725', '', '544246', '2024-11-06 18:47:19', b'0'),
(1297, '6374573725', '', '505236', '2024-11-08 16:29:55', b'0'),
(1298, '9600420101', '', '406578', '2024-11-11 11:22:14', b'0'),
(1299, '9600420101', '', '800880', '2024-11-11 14:10:44', b'0'),
(1300, '8940900292', '', '518275', '2024-11-14 15:49:54', b'0'),
(1301, '8940900292', '', '724086', '2024-11-14 15:49:54', b'0'),
(1302, '8940900292', '', '155599', '2024-11-14 17:19:42', b'0'),
(1303, '9894749740', '', '170951', '2024-11-13 14:58:38', b'0'),
(1304, '9894749740', '', '191822', '2024-11-13 14:58:38', b'0'),
(1305, '9894749740', '', '466986', '2024-11-13 14:58:38', b'0'),
(1306, '9894749740', '', '102016', '2024-11-13 14:58:38', b'0'),
(1307, '9894749740', '', '898150', '2024-11-13 14:58:38', b'0'),
(1308, '9894749740', '', '194918', '2024-11-13 14:58:38', b'0'),
(1309, '9894749740', '', '232676', '2024-11-13 14:58:38', b'0'),
(1310, '9909988968', '', '249369', '2024-11-13 14:58:38', b'0'),
(1311, '9894749740', '', '867158', '2024-11-13 14:58:38', b'0'),
(1312, '9894749740', '', '133678', '2024-11-13 14:58:38', b'0'),
(1313, '9894749740', '', '862772', '2024-11-13 14:58:38', b'0'),
(1314, '8940900292', '', '690997', '2024-11-15 12:09:35', b'0'),
(1315, '8940900292', '', '796192', '2024-11-15 12:09:35', b'0'),
(1316, '8940900292', '', '609694', '2024-11-15 12:09:35', b'0'),
(1317, '8940900292', '', '946324', '2024-11-13 14:58:38', b'0'),
(1318, '9894749740', '', '663661', '2024-11-13 14:58:38', b'0'),
(1319, '9894749740', '', '922710', '2024-11-13 14:58:38', b'0'),
(1320, '9894749740', '', '676267', '2024-11-13 14:58:38', b'0'),
(1321, '8940900293', '', '157375', '2024-11-19 12:02:45', b'0'),
(1322, '8940900293', '', '447459', '2024-11-19 12:02:45', b'0'),
(1323, '8940900293', '', '513907', '2024-11-19 12:02:45', b'0'),
(1324, '8248498874', '', '719345', '2024-11-19 13:50:40', b'0'),
(1325, '9894749740', '', '643432', '2024-11-19 18:47:03', b'0'),
(1326, '6374573725', '', '357889', '2024-11-20 16:21:08', b'0'),
(1327, '6374573725', '', '254427', '2024-11-20 16:21:08', b'0'),
(1328, '6374573725', '', '134668', '2024-11-20 16:21:08', b'0'),
(1329, '9894749740', '', '286331', '2024-11-20 16:21:08', b'0'),
(1330, '9894749740', '', '246195', '2024-11-20 16:21:08', b'0'),
(1331, '9894749740', '', '780988', '2024-11-20 16:21:08', b'0'),
(1332, '9894749740', '', '226060', '2024-11-20 16:21:08', b'0'),
(1333, '9894749740', '', '228443', '2024-11-20 16:21:08', b'0'),
(1334, '9894749740', '', '739432', '2024-11-20 16:21:08', b'0'),
(1335, '6374573725', '', '613977', '2024-11-20 16:21:08', b'0'),
(1336, '9894749740', '', '720476', '2024-11-20 16:21:08', b'0'),
(1337, '6374573725', '', '634841', '2024-11-20 16:21:08', b'0'),
(1338, '6374573725', '', '717834', '2024-11-20 16:21:08', b'0'),
(1339, '8565875648', '', '396610', '2024-11-20 16:21:08', b'0'),
(1340, '0000000000', '', '647445', '2024-11-20 16:21:08', b'0'),
(1341, '9999999000', '', '610003', '2024-11-20 16:21:08', b'0'),
(1342, '8940900296', '', '807205', '2024-11-21 16:43:18', b'0'),
(1343, '8940900296', '', '310205', '2024-11-21 16:43:18', b'0'),
(1344, '8940900296', '', '384684', '2024-11-21 16:43:18', b'0'),
(1345, '8940900296', '', '860227', '2024-11-21 16:43:18', b'0'),
(1346, '8903061357', '', '319005', '2024-11-21 16:43:18', b'0'),
(1347, '8940900292', '', '657189', '2024-11-21 16:43:18', b'0'),
(1348, '8940900292', '', '779460', '2024-11-21 16:43:18', b'0'),
(1349, '8940900292', '', '456559', '2024-11-21 16:43:18', b'0'),
(1350, '6374573725', '', '300617', '2024-11-22 10:09:13', b'0'),
(1351, '6374573725', '', '479517', '2024-11-22 10:09:13', b'0'),
(1352, '6374573725', '', '982762', '2024-11-22 10:09:13', b'0'),
(1353, '6374573725', '', '964357', '2024-11-22 10:09:13', b'0'),
(1354, '6374573725', '', '441859', '2024-11-22 10:09:13', b'0'),
(1355, '6374573725', '', '312773', '2024-11-22 10:09:13', b'0'),
(1356, '6374573725', '', '998473', '2024-11-22 10:09:13', b'0'),
(1357, '9894749740', '', '546162', '2024-11-22 10:09:13', b'0');

-- --------------------------------------------------------

--
-- Table structure for table `otptable`
--

CREATE TABLE `otptable` (
  `id` bigint NOT NULL,
  `mobileno` varchar(10) DEFAULT NULL,
  `otpcode` varchar(6) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `validity` datetime DEFAULT NULL,
  `status` bit(1) DEFAULT b'1',
  `transtime` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT (convert_tz(now(),_utf8mb4'+00:00',_utf8mb4'+05:30')),
  `userid` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `otptable`
--

INSERT INTO `otptable` (`id`, `mobileno`, `otpcode`, `validity`, `status`, `transtime`, `userid`) VALUES
(509, '9361621891', '545082', '2024-09-28 19:05:37', b'0', '2024-09-27 18:55:37', NULL),
(510, '9361621855', '111116', '2024-02-15 17:19:18', b'1', '2024-02-13 17:09:18', NULL),
(511, '8940900292', '456559', '2024-11-21 22:56:52', b'1', '2024-11-21 22:46:52', 230),
(512, '9600724179', '417203', '2024-03-27 01:24:27', b'1', '2024-03-27 01:14:27', 85),
(513, '6374573725', '998473', '2024-11-23 17:57:29', b'1', '2024-11-23 17:47:29', 205),
(514, '8248498874', '719345', '2024-11-19 21:11:22', b'0', '2024-11-19 21:01:22', NULL),
(515, '8903061357', '319005', '2024-11-21 22:32:44', b'0', '2024-11-21 22:22:44', NULL),
(516, '9894749740', '546162', '2024-11-23 17:58:08', b'1', '2024-11-23 17:48:08', 228),
(517, '3424324324', '323405', '2024-02-16 15:57:58', b'1', '2024-02-16 15:47:58', NULL),
(518, '1111111111', '148302', '2024-02-16 16:10:21', b'1', '2024-02-16 16:00:21', NULL),
(519, '4334343', '432592', '2024-02-17 15:04:24', b'1', '2024-02-17 14:54:24', NULL),
(520, '34343', '381526', '2024-02-17 15:09:51', b'1', '2024-02-17 14:59:51', NULL),
(521, '9884302002', '558654', '2024-04-03 16:29:14', b'0', '2024-04-03 16:19:14', NULL),
(522, '9600420101', '800880', '2024-11-11 21:34:34', b'0', '2024-11-11 21:24:34', NULL),
(523, '6379148114', '950597', '2024-10-02 05:43:47', b'0', '2024-10-02 05:33:47', NULL),
(524, '7708668443', '268178', '2024-04-12 18:11:51', b'0', '2024-04-12 18:01:51', NULL),
(525, '9791344113', '944036', '2024-03-27 22:08:07', b'0', '2024-03-27 21:58:07', NULL),
(526, '0637457372', '643282', '2024-06-06 19:17:47', b'1', '2024-06-06 19:07:47', NULL),
(527, '8940900293', '513907', '2024-11-19 19:07:14', b'1', '2024-11-19 18:57:14', NULL),
(528, '6369515090', '213135', '2024-09-07 16:24:20', b'0', '2024-09-07 16:14:20', NULL),
(529, '9900557609', '248440', '2024-09-07 17:08:23', b'0', '2024-09-07 16:58:23', NULL),
(530, '9600724189', '103075', '2024-09-24 23:17:56', b'1', '2024-09-24 23:07:56', NULL),
(531, '8940900297', '488207', '2024-09-25 17:45:47', b'1', '2024-09-25 17:35:47', NULL),
(532, '8989898989', '280347', '2024-09-25 17:50:32', b'1', '2024-09-25 17:40:32', NULL),
(533, '9345002002', '673179', '2024-10-02 06:03:39', b'0', '2024-10-02 05:53:39', NULL),
(534, '9909988968', '249369', '2024-11-15 21:17:47', b'1', '2024-11-15 21:07:47', NULL),
(535, '8565875648', '396610', '2024-11-21 22:12:43', b'1', '2024-11-21 22:02:43', NULL),
(536, '0000000000', '647445', '2024-11-21 22:13:00', b'1', '2024-11-21 22:03:00', NULL),
(537, '9999999000', '610003', '2024-11-21 22:16:26', b'1', '2024-11-21 22:06:26', NULL),
(538, '8940900296', '860227', '2024-11-21 22:26:17', b'1', '2024-11-21 22:16:17', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `productid` bigint NOT NULL,
  `masterid` bigint DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `price` decimal(10,2) DEFAULT NULL,
  `gst` int DEFAULT NULL,
  `gender` bigint DEFAULT NULL,
  `weight` float DEFAULT NULL,
  `productstatus` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'instock',
  `published` int DEFAULT '0',
  `quantity` int DEFAULT NULL,
  `createdon` datetime DEFAULT NULL,
  `lastmodifiedate` datetime DEFAULT NULL,
  `lastmodifiedby` bigint DEFAULT NULL,
  `createdby` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`productid`, `masterid`, `name`, `description`, `price`, `gst`, `gender`, `weight`, `productstatus`, `published`, `quantity`, `createdon`, `lastmodifiedate`, `lastmodifiedby`, `createdby`) VALUES
(305, 185, '23456', '2342dsf', '34.01', 2, 152, 3424560, 'outofstock', 0, 3345674, '2024-10-30 16:33:43', '2024-10-30 16:33:43', 0, 0),
(306, 185, 'kamala nikethon school shirt', 'shirt', '678.00', 1, 118, 67, 'instock', 1, 67, '2024-10-30 16:33:43', '2024-10-30 16:33:43', 0, 0),
(307, 185, 'shirt school', 'shirt', '567.00', 3, 154, 567, 'instock', 1, 678, '2024-11-04 10:09:17', '2024-11-04 10:09:17', 0, 0),
(308, 185, 'shirt shirt', 'shirt 2cqr', '678.00', 2, 118, 678, 'instock', 1, 7878, '2024-11-04 10:35:04', '2024-11-04 17:19:33', 0, 0),
(315, 185, 't shirt school', 'shirt ', '456.00', 2, 152, 455, 'instock', 1, 455, '2024-11-04 17:19:33', '2024-11-04 17:19:33', 0, 0),
(318, 185, 'Louise Philippe Men Regular Fit  All Day Comfort Cotton Effortless Ironing Formal Shirt', 'Additional Information\r\nManufacturerABFRL, Aditya Birla Fashion and Retail,M/S B. L. Retails,Poddar Building,P.W.D Point, Gar-Ali-785001,Jorhat,Assam,India\r\nPackerAditya Birla Fashion and Retail,M/S B. L. Retails,Poddar Building,P.W.D Point, Gar-Ali-785001,Jorhat,Assam,India\r\nItem Weight300 g\r\nItem Dimensions LxWxH27.5 x 22.5 x 2 Centimeters\r\nGeneric NameShirt\r\nSee less', '876.00', 2, 152, 1, 'instock', 1, 10, '2024-10-28 12:28:10', '2024-11-11 11:22:14', 0, 0),
(319, 188, 't shirt ', 'describe', '123.00', 2, 152, 123, 'instock', 0, 123, '2024-11-04 17:19:33', '2024-11-04 17:19:33', 0, 0),
(320, 185, 'kamala nikethon shirt for boys', 'kamala nikethon school shirt', '456.00', 1, 152, 45, 'instock', 0, 45, '2024-11-04 17:19:33', '2024-11-11 11:22:14', 0, 0),
(321, 185, 'xgdg', 'dsf', '3.00', 2, 154, 424, 'instock', 0, 3432, '2024-10-28 12:28:10', '2024-10-28 12:28:10', 0, 0),
(326, 185, 'KSM SHIRTS', 'VVPS Boys school uniform for Grade 1 and Grade 2', '405.00', 2, 152, 1, 'instock', 0, 5, '2024-11-06 18:47:19', '2024-11-06 18:47:19', 0, 0),
(327, 185, 'VVPS White shirt -1', 'VVPS Boys school uniform for Grade 1 and Grade 2', '405.00', 2, 152, 1, 'instock', 1, 5, '2024-11-06 18:47:19', '2024-11-06 18:47:19', 0, 0),
(329, 185, 'VVPS White Shirtt', 'VVPS School shirt', '876.00', 2, 152, 1, 'instock', 1, 5, '2024-11-07 13:57:04', '2024-11-07 13:57:04', 0, 0),
(331, 185, 'Shirt', 'Men\'s shirt', '876.00', 3, 152, 3, 'instock', 1, 10, '2024-11-08 16:29:56', '2024-11-08 16:29:56', 0, 0),
(332, 185, 'New Shirt Added', 'Men\'s uniform shirt', '564.00', 2, 152, 1, 'instock', 1, 30, '2024-11-11 11:22:14', '2024-11-11 11:22:14', 0, 0),
(333, 185, 'Men\'s Uniform shirt', 'Men\'s uniform shirt', '675.00', 2, 152, 2, 'instock', 1, 10, '2024-11-11 11:22:14', '2024-11-11 11:22:14', 0, 0),
(334, 185, 'school shirt ', 'shirt kamala nikethon', '56.00', 2, 152, 45, 'instock', 1, 45, '2024-11-11 11:22:14', '2024-11-11 11:22:14', 0, 0),
(335, 188, 'Tshirt sports', 'asdgaf', '12.00', 2, 154, 100, 'instock', 1, 122, '2024-11-11 14:10:45', '2024-11-11 14:10:45', 0, 0),
(336, 188, 'Tshirt sports test', 'asdgaf', '12.00', 2, 154, 100, 'instock', 1, 122, '2024-11-11 14:10:45', '2024-11-11 14:10:45', 0, 0),
(337, 185, 'Men\'s cotton shirt', 'Men\'s cotton shirt', '786.00', 2, 152, 1, 'instock', 1, 12, '2024-11-11 14:10:45', '2024-11-11 14:10:45', 0, 0),
(338, 185, 'shirt school shirt', 'shirt school shirt', '12.00', 4, 152, 12, 'instock', 1, 12, '2024-11-11 14:10:45', '2024-11-11 14:10:45', 0, 0),
(339, 188, 't shirt  psg college', 'psg college t shirt', '34.00', 2, 152, 34, 'instock', 1, 34, '2024-11-13 14:58:38', '2024-11-13 14:58:38', 0, 0),
(340, 188, 't shirt college', 't shirt college', '34.00', 2, 152, 34, 'instock', 1, 34, '2024-11-13 14:58:38', '2024-11-13 14:58:38', 0, 0),
(341, 188, 'fdsfsfds', 'fdsfds', '43.00', 2, 152, 34, 'instock', 1, 34, '2024-11-13 14:58:38', '2024-11-13 14:58:38', 0, 0),
(344, 185, 'dfsf', 'fdsf', '34.00', 2, 152, 324, 'instock', 1, 324, '2024-11-19 16:22:08', '2024-11-19 16:22:08', 0, 0),
(345, 188, 'sdfsfsfdsfesadfdsfds', 'fdesf', '34.00', 1, 152, 342, 'instock', 1, 43, '2024-11-19 16:22:08', '2024-11-19 16:22:08', 0, 0),
(346, 185, '34324', 'sdfdsa', '453.00', 2, 152, 45, 'instock', 1, 43, '2024-11-19 12:02:46', '2024-11-19 12:02:46', 0, 0),
(347, 188, 'psg college both shirt', 'fds', '34.00', 2, 152, 34, 'instock', 1, 34, '2024-11-19 16:22:08', '2024-11-19 16:22:08', 0, 0),
(348, 185, 'Glentree Girls White Shirt', 'Glentree Girls White Shirt - Grade 1 to Grade 2', '405.00', 2, 154, 1, 'instock', 1, 20, '2024-11-19 18:47:04', '2024-11-19 18:47:04', 0, 0),
(350, 185, 'jhfkl', 'hgjx', '566.00', 2, 152, 6, 'instock', 0, 67, '2024-11-19 18:47:04', '2024-11-19 18:47:04', 0, 0),
(351, 185, 'Glentree Navy Blue Pant', 'Glentree Navy Blue Pant', '490.00', 2, 152, 1, 'instock', 1, 20, '2024-11-19 18:47:04', '2024-11-19 18:47:04', 0, 0),
(352, 197, 'Glentree Pinafore', 'Glentree Pinafore', '550.00', 2, 154, 2, 'instock', 1, 20, '2024-11-19 18:47:04', '2024-11-22 10:09:14', 0, 0),
(354, 196, ' Glentree Skirt', 'Glentree Skirt', '555.00', 2, 154, 1, 'instock', 1, 20, '2024-11-19 18:47:04', '2024-11-19 18:47:04', 0, 0),
(355, 188, 'Glentree T-Shirt - Green Piping', 'Glentree T-Shirt - Green Piping', '500.00', 2, 152, 1, 'instock', 1, 20, '2024-11-19 18:47:04', '2024-11-19 18:47:04', 0, 0),
(356, 185, 'Liberty Black Shoes', 'Liberty - JOVE/JOY Black Unisex School Shoes', '899.00', 2, 152, 5, 'instock', 1, 25, '2024-11-19 18:47:04', '2024-11-19 18:47:04', 0, 0),
(357, 185, 'shirt01', 'shirt01', '765.00', 2, 152, 2, 'instock', 0, 10, '2024-11-19 18:47:04', '2024-11-19 18:47:04', 0, 0),
(359, 185, 'glentree shirt', 'school shirt', '56.00', 2, 152, 56, 'instock', 1, 78, '2024-11-19 18:47:04', '2024-11-19 18:47:04', 0, 0),
(360, 188, 'eqrwfd', 'dfssa', '324.00', 1, 152, 342, 'instock', 1, 234, '2024-11-19 18:47:04', '2024-11-26 13:14:28', 0, 0),
(361, 188, 'sejbg.', 'a,jbe J<ZA', '677.00', 2, 154, 8, 'instock', 0, 20, '2024-11-20 16:21:08', '2024-11-20 16:21:08', 0, 0),
(362, 185, 'TVK shirts', 'set the data', '34.00', 1, 152, 45, 'instock', 0, 7, '2024-12-02 15:47:29', '2024-12-02 15:47:29', 0, 0);

--
-- Triggers `product`
--
DELIMITER $$
CREATE TRIGGER `product_after_delete` AFTER DELETE ON `product` FOR EACH ROW BEGIN
    
    DELETE FROM productstatuslog WHERE productid = OLD.productid;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `product_after_insert` AFTER INSERT ON `product` FOR EACH ROW BEGIN
   INSERT INTO productstatuslog (productid, productstatus, modifiedby, modifiedate)
    VALUES (
        NEW.productid,
        NEW.productstatus,
        NEW.lastmodifiedby,
        NEW.lastmodifiedate
    );
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `product_after_update` AFTER UPDATE ON `product` FOR EACH ROW BEGIN

        UPDATE productstatuslog
        SET
            productstatus = NEW.productstatus,
            modifiedby = NEW.lastmodifiedby,
            modifiedate = NEW.lastmodifiedate
        WHERE productid = NEW.productid;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `productimage`
--

CREATE TABLE `productimage` (
  `autoid` int NOT NULL,
  `productid` bigint DEFAULT NULL,
  `imageseq` int DEFAULT NULL,
  `image` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `productimage`
--

INSERT INTO `productimage` (`autoid`, `productid`, `imageseq`, `image`) VALUES
(75, 305, 1, 'ee7588bc733929a841bfe4a196d13e50.png'),
(80, 306, 1, '542fb08e13176421f89143a9376bf597.png'),
(81, 307, 1, '28fae3d9454863b4adc6eb6859a0da46.jpeg'),
(116, 308, 1, 'c1561de8605749758df8ed7e4957cda9.jpeg'),
(117, 315, 1, '3e709b8f66241a4949301752819acb75.jpeg'),
(121, 319, 1, '01057d23d566c48e3426f7668da073da.jpeg'),
(127, 321, 1, '86dc466f6ec33fff6c2dafc12e33883e.jpeg'),
(128, 321, 2, '0c5099db1923b4425ae507a090b5cf3f.jpeg'),
(129, 321, 3, 'f65f38c6b32fe842cf9a05cec879a183.jpeg'),
(130, 321, 4, '54eb4db3049a0dc041e32b4c74d6be8f.png'),
(131, 321, 5, '47efc404ceced7b27d82e17864059960.jpeg'),
(139, 326, 1, 'a774162fa1dd4b5d19a77e63d1842f59.jpeg'),
(140, 326, 2, 'abf5fb84d2b961d51a9f304556ca1d36.jpeg'),
(141, 326, 3, '0158ebef1588c349ff57258bf8f9ff6d.jpeg'),
(142, 327, 1, '72a3b46aaa315cdd2b69984e909a7d84.jpeg'),
(143, 327, 2, 'ec7c2b84f30c961cd5aa08938678101f.jpeg'),
(144, 327, 3, '33bf0c1a4cd8e232d775fe69aff11ae8.jpeg'),
(146, 329, 1, 'ddfdf6fb7f9977f36636b9147bff62bf.jpeg'),
(148, 331, 1, 'b7df126b6d91f2441a182583ae5269c4.jpeg'),
(149, 320, 1, '5c353466cc35c2b86df3cd362b8fc288.jpeg'),
(150, 320, 2, '75951af3a624845cef719cf47c63b52e.jpeg'),
(151, 320, 3, '39a154d7fe1e2684409a6cbb59fe26d1.jpeg'),
(152, 320, 4, 'f1bee8c21aeb651c950d59f3b31695b5.jpeg'),
(153, 320, 5, '7613fff3a3a3ae7387d37f47ca46dc70.jpeg'),
(154, 320, 6, '7f822ce964781695ff1da4e8f213db87.jpeg'),
(155, 332, 1, '1e7345a11ed86a26ae4187c4dc0895d3.jpeg'),
(156, 332, 2, 'bea48f653df1529591cdb0535c5de0f5.jpeg'),
(157, 332, 3, '0924225520e647612fcf28fa7b481815.jpeg'),
(158, 332, 4, '9c2c4b6b55d3edc95a2677b5806b164d.jpeg'),
(159, 332, 5, 'c21512dfd6f2105f4f99dd2d89820ae0.jpeg'),
(160, 332, 6, 'd7712b93171feddd00b2145ea531aa73.jpeg'),
(161, 332, 7, '4dfa72e94ee2090f1332111b3395b911.jpeg'),
(162, 318, 1, 'e177e2d0536ef008c1c40eb9031f0942.jpeg'),
(163, 333, 1, '19bd9d7166443e6787af0e7596ec0b2c.jpeg'),
(164, 334, 1, 'b7de2d91ee9ac7e4d922ea1111ebf430.jpeg'),
(165, 334, 2, 'b36baf8cdd52cd5abc577b91a3abc05c.jpeg'),
(166, 334, 3, '358ce5232ab352c9472d95e414d74bbf.png'),
(167, 335, 1, '2c0f61df29980142554186d55f04a2f7.png'),
(168, 336, 1, 'aea14bac36bab34be2201be3f02f1fed.png'),
(169, 337, 1, '6058d34949f6269852659437fb2e7608.jpeg'),
(170, 338, 1, '1e968b89a201a462b3c49a304dcd7006.jpeg'),
(171, 339, 1, '75260edee398f2c19389028a330784d4.jpeg'),
(172, 339, 2, 'ec6606c4237a4587a4d8e2fe80f32a07.jpeg'),
(173, 340, 1, 'a5575fc38e20001698c3363186dac2bd.jpeg'),
(174, 341, 1, '8fbd5d062df2a0449a784bd826a1a6bc.jpeg'),
(176, 343, 1, 'a712ae16ff302137ba23d88ead962ce5.jpeg'),
(177, 344, 1, 'dcaa68a123cbd50171b4dabf736318c8.jpeg'),
(178, 345, 1, 'bad0c5155aef01e275d6887bac54f1ba.jpeg'),
(179, 346, 1, '9dd172508581f067e82f28570359a2fb.jpeg'),
(180, 347, 1, 'f319929f221460f598eb052bf4bbf236.jpeg'),
(181, 347, 2, 'a9bdab28c60991de19a3b849e104d5d6.jpeg'),
(182, 347, 3, 'f776844dc15b6e06adf466c00cf4e056.jpeg'),
(183, 348, 1, '60d2b8069e3180903c5e9c3e8dc9b032.png'),
(184, 349, 1, '179248c17d3869b47433851ef9d6ec16.png'),
(185, 350, 1, '9ee9a7cdda5fde678403ec6da8641734.png'),
(186, 351, 1, '1cf871315d4a10e9a0d2a44ac80b5839.png'),
(189, 354, 1, '5ede90c074b631688cb9908d1a7b764a.png'),
(190, 355, 1, 'c437a008559430a84f86f340b620e081.png'),
(191, 356, 1, '3ee032f3c37cc28af089c389a987639d.png'),
(192, 356, 2, 'a65cf9c3d91603a7d0ee42caefc47191.png'),
(193, 357, 1, '323f8595d8fd45a9e7eae4191d269099.png'),
(195, 359, 1, '6338f8b708def0b515c34e7ba9a8efad.jpeg'),
(197, 361, 1, 'd53204c428b19b4136ffa05a64df8b62.png'),
(200, 352, 1, '94b14ccc2aad39d310ab487fa104f271.png'),
(202, 360, 1, '8ca92feda61ebafaf3d3683644fc3418.jpeg'),
(203, 362, 1, '200.jpg'),
(204, 362, 2, '300.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `productschoolmap`
--

CREATE TABLE `productschoolmap` (
  `autoid` int NOT NULL,
  `productid` bigint DEFAULT NULL,
  `schoolid` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `productschoolmap`
--

INSERT INTO `productschoolmap` (`autoid`, `productid`, `schoolid`) VALUES
(78, 305, '19'),
(79, 305, '13'),
(84, 306, '21'),
(85, 307, '197'),
(113, 308, '19'),
(114, 315, '19'),
(127, 319, '21'),
(130, 321, '19'),
(136, 326, '21'),
(137, 327, '21'),
(139, 329, '2'),
(140, 329, '1'),
(143, 331, '8'),
(146, 320, '19'),
(147, 320, '21'),
(148, 332, '1'),
(150, 318, '21'),
(151, 333, '1'),
(152, 334, '6'),
(153, 335, '4'),
(154, 336, '4'),
(155, 336, '6'),
(156, 336, '7'),
(157, 337, '1'),
(158, 338, '5'),
(159, 339, '1'),
(160, 340, '1'),
(161, 341, '1'),
(165, 343, '1'),
(166, 344, '195'),
(167, 345, '195'),
(168, 346, '1'),
(169, 347, '1'),
(170, 348, '10'),
(171, 348, '1'),
(172, 349, '10'),
(173, 349, '1'),
(174, 349, '2'),
(175, 349, '6'),
(176, 350, '1'),
(177, 351, '10'),
(178, 351, '1'),
(179, 351, '2'),
(185, 354, '1'),
(186, 354, '2'),
(187, 354, '10'),
(188, 355, '10'),
(189, 355, '2'),
(190, 355, '1'),
(191, 356, '10'),
(192, 356, '1'),
(193, 356, '2'),
(194, 357, '10'),
(195, 357, '4'),
(197, 359, '10'),
(199, 361, '1'),
(205, 352, '215'),
(210, 360, '10'),
(211, 362, '13');

-- --------------------------------------------------------

--
-- Table structure for table `productstatuslog`
--

CREATE TABLE `productstatuslog` (
  `productid` bigint DEFAULT NULL,
  `productstatus` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modifiedby` bigint DEFAULT NULL,
  `modifiedate` datetime DEFAULT (convert_tz(now(),_utf8mb4'+00:00',_utf8mb4'+05:30'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `productstatuslog`
--

INSERT INTO `productstatuslog` (`productid`, `productstatus`, `modifiedby`, `modifiedate`) VALUES
(273, 'instock', NULL, NULL),
(305, 'outofstock', 0, '2024-10-30 16:33:43'),
(306, 'instock', 0, '2024-10-30 16:33:43'),
(307, 'instock', 0, '2024-11-04 10:09:17'),
(308, 'instock', 0, '2024-11-04 17:19:33'),
(315, 'instock', 0, '2024-11-04 17:19:33'),
(318, 'instock', 0, '2024-11-11 11:22:14'),
(319, 'instock', 0, '2024-11-04 17:19:33'),
(320, 'instock', 0, '2024-11-11 11:22:14'),
(321, 'instock', 0, '2024-10-28 12:28:10'),
(326, 'instock', 0, '2024-11-06 18:47:19'),
(327, 'instock', 0, '2024-11-06 18:47:19'),
(329, 'instock', 0, '2024-11-07 13:57:04'),
(331, 'instock', 0, '2024-11-08 16:29:56'),
(332, 'instock', 0, '2024-11-11 11:22:14'),
(333, 'instock', 0, '2024-11-11 11:22:14'),
(334, 'instock', 0, '2024-11-11 11:22:14'),
(335, 'instock', 0, '2024-11-11 14:10:45'),
(336, 'instock', 0, '2024-11-11 14:10:45'),
(337, 'instock', 0, '2024-11-11 14:10:45'),
(338, 'instock', 0, '2024-11-11 14:10:45'),
(339, 'instock', 0, '2024-11-13 14:58:38'),
(340, 'instock', 0, '2024-11-13 14:58:38'),
(341, 'instock', 0, '2024-11-13 14:58:38'),
(344, 'instock', 0, '2024-11-19 16:22:08'),
(345, 'instock', 0, '2024-11-19 16:22:08'),
(346, 'instock', 0, '2024-11-19 12:02:46'),
(347, 'instock', 0, '2024-11-19 16:22:08'),
(348, 'instock', 0, '2024-11-19 18:47:04'),
(350, 'instock', 0, '2024-11-19 18:47:04'),
(351, 'instock', 0, '2024-11-19 18:47:04'),
(352, 'instock', 0, '2024-11-22 10:09:14'),
(354, 'instock', 0, '2024-11-19 18:47:04'),
(355, 'instock', 0, '2024-11-19 18:47:04'),
(356, 'instock', 0, '2024-11-19 18:47:04'),
(357, 'instock', 0, '2024-11-19 18:47:04'),
(359, 'instock', 0, '2024-11-19 18:47:04'),
(360, 'instock', 0, '2024-11-26 13:14:28'),
(361, 'instock', 0, '2024-11-20 16:21:08'),
(362, 'instock', 0, '2024-12-02 15:47:29');

-- --------------------------------------------------------

--
-- Table structure for table `producttext`
--

CREATE TABLE `producttext` (
  `extautoid` bigint NOT NULL,
  `productid` bigint DEFAULT NULL,
  `submasterid` bigint DEFAULT NULL,
  `subdataid` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `producttext`
--

INSERT INTO `producttext` (`extautoid`, `productid`, `submasterid`, `subdataid`) VALUES
(874, 114, 95, 63),
(875, 114, 100, 73),
(876, 114, 181, 184),
(877, 114, 99, 72),
(878, 114, 98, 76),
(879, 114, 113, 90),
(880, 114, 103, 150),
(881, 114, 135, 148),
(882, 114, 139, 149),
(883, 114, 141, 157),
(924, 119, 99, 135),
(925, 119, 98, 111),
(926, 119, 113, 90),
(927, 119, 103, 118),
(928, 119, 135, 148),
(929, 119, 139, 149),
(930, 119, 141, 157),
(931, 120, 99, 78),
(932, 120, 98, 76),
(933, 120, 113, 90),
(934, 120, 103, 118),
(935, 120, 135, 148),
(936, 120, 139, 149),
(937, 120, 141, 157),
(938, 121, 191, 191),
(939, 121, 192, 192),
(940, 121, 99, 110),
(941, 121, 98, 141),
(942, 121, 113, 109),
(943, 121, 103, 91),
(944, 121, 135, 118),
(945, 121, 139, 148),
(946, 121, 141, 149),
(976, 118, 103, 118),
(985, 124, 186, 187),
(986, 124, 99, 72),
(987, 124, 98, 76),
(988, 124, 113, 90),
(989, 124, 103, 118),
(990, 124, 135, 148),
(991, 124, 139, 149),
(992, 124, 141, 157),
(1038, 132, 186, 187),
(1039, 132, 99, 78),
(1040, 132, 98, 77),
(1041, 132, 113, 90),
(1042, 132, 103, 150),
(1043, 132, 135, 148),
(1044, 133, 186, 187),
(1045, 133, 99, 78),
(1046, 133, 98, 77),
(1047, 133, 113, 90),
(1048, 133, 103, 150),
(1049, 133, 135, 148),
(1050, 133, 189, 149),
(1051, 134, 186, 187),
(1052, 134, 99, 78),
(1053, 134, 98, 76),
(1054, 134, 113, 90),
(1055, 134, 103, 150),
(1056, 134, 135, 148),
(1057, 134, 189, 149),
(1058, 134, 191, 190),
(1059, 134, 192, 191),
(1060, 134, 193, 192),
(1061, 135, 186, 188),
(1062, 135, 99, 78),
(1063, 135, 98, 76),
(1064, 135, 113, 90),
(1065, 135, 103, 118),
(1066, 135, 135, 148),
(1067, 136, 191, 191),
(1068, 136, 192, 192),
(1069, 136, 193, 191),
(1070, 136, 99, 192),
(1071, 136, 98, 193),
(1072, 136, 113, 72),
(1073, 136, 103, 76),
(1074, 136, 135, 90),
(1075, 137, 189, 189),
(1076, 137, 99, 78),
(1077, 137, 98, 77),
(1078, 137, 113, 90),
(1079, 137, 103, 150),
(1080, 137, 135, 148),
(1081, 138, 189, 189),
(1082, 138, 99, 78),
(1083, 138, 98, 77),
(1084, 138, 113, 90),
(1085, 138, 103, 150),
(1086, 138, 135, 148);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `rolesid` bigint NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `role` bit(64) DEFAULT NULL,
  `status` bit(1) DEFAULT b'1',
  `createdon` datetime DEFAULT (convert_tz(now(),_utf8mb4'+00:00',_utf8mb4'+05:30')),
  `lastmodifiedat` datetime DEFAULT (convert_tz(now(),_utf8mb4'+00:00',_utf8mb4'+05:30')),
  `lastmodifiedby` bigint DEFAULT NULL,
  `createdby` bigint DEFAULT NULL,
  `defaultmodule` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`rolesid`, `name`, `role`, `status`, `createdon`, `lastmodifiedat`, `lastmodifiedby`, `createdby`, `defaultmodule`) VALUES
(20, 'Admin', b'0000000000000000000000000000000000000000000000000000001101111111', b'1', NULL, NULL, 116, NULL, 9),
(41, 'Delivery', b'0000000000000000000000000000000000000000000000000000001111111111', b'1', '2024-06-11 22:17:55', '2024-06-11 22:17:55', NULL, NULL, 2),
(42, 'Packed', b'0000000000000000000000000000000000000000000000000000001111111111', b'1', '2024-06-11 22:19:41', '2024-06-11 22:19:41', NULL, NULL, 2),
(48, 'Return', b'0000000000000000000000000000000000000000000000000000011111111111', b'1', '2024-06-24 16:15:36', '2024-06-24 16:15:36', NULL, NULL, 2),
(49, 'Shipped', b'0000000000000000000000000000000000000000000000000000011111111111', b'1', '2024-06-24 16:26:37', '2024-06-24 16:26:37', NULL, NULL, 2),
(52, 'online', b'0000000000000000000000000000000000000000000000000000000110000000', b'1', '2024-09-06 17:21:39', '2024-09-06 17:21:39', NULL, NULL, 9);

-- --------------------------------------------------------

--
-- Table structure for table `school`
--

CREATE TABLE `school` (
  `schoolid` bigint NOT NULL,
  `schoolcode` varchar(200) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `mobileno` varchar(10) DEFAULT NULL,
  `createdAt` datetime DEFAULT (convert_tz(now(),_utf8mb4'+00:00',_utf8mb4'+05:30')),
  `createdby` bigint DEFAULT NULL,
  `updatedAt` datetime DEFAULT (convert_tz(now(),_utf8mb4'+00:00',_utf8mb4'+05:30')),
  `updatedby` bigint DEFAULT NULL,
  `status` bit(1) DEFAULT b'1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `school`
--

INSERT INTO `school` (`schoolid`, `schoolcode`, `name`, `address`, `email`, `mobileno`, `createdAt`, `createdby`, `updatedAt`, `updatedby`, `status`) VALUES
(13, 'school13', 'santhiram matric', 'chennai', 'school13@gmail.com', '8940900292', '2024-01-12 10:04:32', NULL, '2024-06-11 16:47:27', 126, b'1'),
(19, 'school 123', 'kamala nikethon school', 'chennai', 'kamal@gmail.com', '8940900292', '2024-02-05 06:39:16', 49, '2024-06-11 17:05:45', 126, b'1'),
(21, '9090', 'PSG college', 'CHennai', 'lkjhhij', '345678', '2024-02-22 06:19:41', 70, '2024-02-22 06:25:06', 70, b'1'),
(215, '9956', 'Glentree Academy', 'Chennai', 'glentreeacademy@gmail.com', '34899', '2024-11-20 11:19:41', 202, '2024-11-20 11:19:41', 202, b'1'),
(221, 'cms10', 'CMS', '', 'cms@gmail.com', '8903061357', '2024-11-29 10:38:31', 205, '2024-11-29 12:21:31', 205, b'1'),
(222, 'apg09', 'APG', 'cbe', 'apg@gmail.com', '8940900292', '2024-11-29 11:54:00', 205, '2024-11-29 12:21:31', 205, b'1'),
(223, 'hr19', 'The higher secondary school', '', 'hrsec@gmail.com', '9600724179', '2024-11-29 11:54:00', 205, '2024-11-29 17:21:59', 205, b'1'),
(225, 'kendra15', 'kendra vidyalaya', 'chennai', 'santhiram@gmail.com', '9791344113', '2024-11-29 13:52:45', 205, '2024-11-29 13:52:45', 205, b'1');

-- --------------------------------------------------------

--
-- Table structure for table `schoolgrademap`
--

CREATE TABLE `schoolgrademap` (
  `id` bigint NOT NULL,
  `schoolid` bigint DEFAULT NULL,
  `gradeid` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `schoolgrademap`
--

INSERT INTO `schoolgrademap` (`id`, `schoolid`, `gradeid`) VALUES
(1, 21, 195),
(2, 21, 196),
(3, 13, 195),
(4, 13, 196),
(5, 19, 197),
(6, 19, 195),
(7, 19, 196),
(8, 21, 195),
(9, 19, 196),
(10, 215, 196),
(11, 221, 2),
(12, 222, 3),
(16, 221, 3),
(17, 223, 3),
(18, 222, 2),
(20, 223, 3),
(24, 223, 3),
(29, 225, 2),
(33, 223, 196);

-- --------------------------------------------------------

--
-- Table structure for table `size`
--

CREATE TABLE `size` (
  `id` int NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `size`
--

INSERT INTO `size` (`id`, `name`) VALUES
(1, 'XL'),
(2, 'L'),
(4, 'M'),
(5, 'S'),
(6, 'XXXL'),
(7, 'XXL'),
(10, 'XS');

-- --------------------------------------------------------

--
-- Table structure for table `states_names`
--

CREATE TABLE `states_names` (
  `id` int NOT NULL,
  `state_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `states_names`
--

INSERT INTO `states_names` (`id`, `state_name`) VALUES
(1, 'Andhra Pradesh'),
(2, 'Arunachal Pradesh'),
(3, 'Assam'),
(4, 'Bihar'),
(5, 'Chhattisgarh'),
(6, 'Goa'),
(7, 'Gujarat'),
(8, 'Haryana'),
(9, 'Himachal Pradesh'),
(10, 'Jharkhand'),
(11, 'Karnataka'),
(12, 'Kerala'),
(13, 'Madhya Pradesh'),
(14, 'Maharashtra'),
(15, 'Manipur'),
(16, 'Meghalaya'),
(17, 'Mizoram'),
(18, 'Nagaland'),
(19, 'Odisha'),
(20, 'Punjab'),
(21, 'Rajasthan'),
(22, 'Sikkim'),
(23, 'Tamil Nadu'),
(24, 'Telangana'),
(25, 'Tripura'),
(26, 'Uttar Pradesh'),
(27, 'Uttarakhand'),
(28, 'West Bengal');

-- --------------------------------------------------------

--
-- Table structure for table `temp_register`
--

CREATE TABLE `temp_register` (
  `id` bigint NOT NULL,
  `mobileno` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `json_data` json NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `temp_register`
--

INSERT INTO `temp_register` (`id`, `mobileno`, `json_data`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '8940900292', '{\"city\": \"Tiruchirappalli\", \"name\": \"arun\", \"email\": \"raghul1a@mail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"undefined\", \"password\": \"$2b$10$kkdJO6Mi3sYWQKHdPXzb..PZ7mydapGiieEcydR5JYk2DB8Q4QE9u\", \"username\": \"arun\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"new\", \"schoolcodes\": [\"school13\", \"school12\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-09-26 15:43:47', '2024-09-26 15:46:14', '2024-09-26 15:46:14'),
(2, '8940900292', '{\"city\": \"Tiruchirappalli\", \"name\": \"arun\", \"email\": \"raghul1a@mail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"undefined\", \"password\": \"$2b$10$waNyOsMzQiAwGdBecK5Jo.RCoar1yNFHEiBNGfcboEsNIbNTAfEeq\", \"username\": \"arun\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"new\", \"schoolcodes\": [\"school13\", \"school12\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-09-26 15:43:52', '2024-09-26 15:46:14', '2024-09-26 15:46:14'),
(3, '8940900292', '{\"city\": \"Tiruchirappalli\", \"name\": \"arun\", \"email\": \"raghul1a@mail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"undefined\", \"password\": \"$2b$10$trv1DZ0.RozTFf5fzhuVk.o0my22Gc.KgutC.eMbRlU57mh/ycrgO\", \"username\": \"arun\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"new\", \"schoolcodes\": [\"school13\", \"school12\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-09-26 15:46:14', '2024-09-26 17:03:31', '2024-09-26 17:03:31'),
(4, '8940900292', '{\"city\": \"Tiruchirappalli\", \"name\": \"arun\", \"email\": \"raghul1a@mail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"new cub\", \"password\": \"$2b$10$N4s/vpOBLSTFEM5H6uPhQ.G2V5v0dqxTKOd10UtXCc6Id4F51BXG6\", \"username\": \"arun\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"new\", \"schoolcodes\": [], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-09-26 17:03:31', '2024-09-26 17:09:31', '2024-09-26 17:09:31'),
(5, '8940900292', '{\"city\": \"Tiruchirappalli\", \"name\": \"arun\", \"email\": \"raghul1a@mail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"new cub\", \"password\": \"$2b$10$odqpyOYR35lBiQvB.6y5cu1LHkxqU1LgaW1t8vfvwjEaMosCK.m6G\", \"username\": \"arun\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"new\", \"schoolcodes\": [\"school13\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-09-26 17:09:31', '2024-09-26 17:09:46', '2024-09-26 17:09:46'),
(6, '8940900292', '{\"city\": \"Tiruchirappalli\", \"name\": \"arun_REG\", \"email\": \"raghul1a@mail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"new cub\", \"password\": \"$2b$10$WyIxg8HwUVG6NLvj1R7wDOTi45Wdt0oNyDflihlQubEBKsGv8JbRi\", \"username\": \"arun_reg_1\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"new\", \"schoolcodes\": [\"school13\", \"school14\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-09-26 17:09:46', '2024-09-26 18:10:52', '2024-09-26 18:10:52'),
(7, '8940900292', '{\"city\": \"Tiruchirappalli\", \"name\": \"arun\", \"email\": \"raghul1a@mail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"undefined\", \"password\": \"$2b$10$.dpfNouv7CKxo8n61MiDueFa.mFKXnLtxmwuJqso3SdcQ.BHyiS5K\", \"username\": \"arun\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"new\", \"schoolcodes\": [], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-09-27 12:42:43', '2024-09-27 12:46:35', '2024-09-27 12:46:35'),
(8, '8940900292', '{\"city\": \"Tiruchirappalli\", \"name\": \"arun\", \"email\": \"raghul1a@mail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"undefined\", \"password\": \"$2b$10$LzPsW3m72rrTpu0dEZx/3u4Ea78N0OKOIcDi87p8qc7k24zDPbCPG\", \"username\": \"arun\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"new\", \"schoolcodes\": [\"school13\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-09-27 12:46:35', '2024-09-27 12:47:02', '2024-09-27 12:47:02'),
(9, '8940900292', '{\"city\": \"Tiruchirappalli\", \"name\": \"arun\", \"email\": \"raghul1a@mail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"undefined\", \"password\": \"$2b$10$skUVTa9XnzrhSAjuYXOjJu4kCXNxLzzUf1gmL3YwACG7qCAi6LYYy\", \"username\": \"arun\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"new\", \"schoolcodes\": [\"school13\", \"9090\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-09-27 12:47:02', '2024-09-27 12:49:40', '2024-09-27 12:49:40'),
(10, '8940900292', '{\"city\": \"Tiruchirappalli\", \"name\": \"arun\", \"email\": \"raghul1a@mail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"undefined\", \"password\": \"$2b$10$4EJH0ScPJF108CPj/.d7xO9H17WE039T8KFOtV35AKZk89CGnoHxK\", \"username\": \"arun\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"new\", \"schoolcodes\": [\"school13\", \"9090\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-09-27 12:49:40', '2024-09-27 12:50:16', '2024-09-27 12:50:16'),
(11, '8940900292', '{\"city\": \"Tiruchirappalli\", \"name\": \"arun\", \"email\": \"raghul1a@mail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"undefined\", \"password\": \"$2b$10$7d.gjy3WDiuRll1beA.Fj..oCF94Fh1ROX9NpqKLaaPh58yHS5R.q\", \"username\": \"arun\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"new\", \"schoolcodes\": [\"school13\", \"9090\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-09-27 12:50:16', '2024-09-27 12:50:25', '2024-09-27 12:50:25'),
(12, '8940900292', '{\"city\": \"Tiruchirappalli\", \"name\": \"arun\", \"email\": \"raghul1a@mail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"undefined\", \"password\": \"$2b$10$6fH9ey7QQsYUC7Z5F8hv.O.qXUceoGCLTttYNhv51lTMi/L3RHwCC\", \"username\": \"arun\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"new\", \"schoolcodes\": [\"school13\", \"9090\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-09-27 12:50:25', '2024-09-27 12:50:39', '2024-09-27 12:50:39'),
(13, '8940900292', '{\"city\": \"Tiruchirappalli\", \"name\": \"arun\", \"email\": \"raghul1a@mail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"undefined\", \"password\": \"$2b$10$YiOpo4JDnu368FpLmGirq.XEfzB4hW9Ht24JG2nR2JFaEs7htEw1O\", \"username\": \"arun\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"new\", \"schoolcodes\": [\"school13\", \"9090\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-09-27 12:50:39', '2024-09-27 12:51:08', '2024-09-27 12:51:08'),
(14, '8940900292', '{\"city\": \"Tiruchirappalli\", \"name\": \"arun\", \"email\": \"raghul1a@mail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"undefined\", \"password\": \"$2b$10$W.3HpnaSBUikeD.6HzVMYu2yqNQ.kBhIs6m0uFJ2o.mIjXGEEEPCy\", \"username\": \"arun\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"new\", \"schoolcodes\": [\"school13\", \"9090\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-09-27 12:51:08', '2024-09-27 12:51:25', '2024-09-27 12:51:25'),
(15, '8940900292', '{\"city\": \"Tiruchirappalli\", \"name\": \"arun\", \"email\": \"raghul1a@mail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"undefined\", \"password\": \"$2b$10$f5DS5XoH7K3wVzMmQu8g0uzQcuMPE9t6Kn7A.4zRdbTHBXoF3ErqS\", \"username\": \"arun\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"new\", \"schoolcodes\": [\"school13\", \"9090\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-09-27 12:51:25', '2024-09-27 14:44:05', '2024-09-27 14:44:05'),
(16, '9361621891', '{\"city\": \"Tiruchirappalli\", \"name\": \"aravindotp\", \"email\": \"aravindotp@mail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"undefined\", \"password\": \"$2b$10$WHngfWu59997wGDzH6yuGOD200CnDKi5PTfoU2VwScWbmgy8IweIG\", \"username\": \"aravindotp\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"new\", \"schoolcodes\": [\"school13\", \"school12\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-09-27 13:19:49', '2024-09-27 13:24:43', '2024-09-27 13:24:43'),
(17, '9361621891', '{\"city\": \"Tiruchirappalli\", \"name\": \"aravindotp\", \"email\": \"aravindotp@mail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"undefined\", \"password\": \"$2b$10$bYpCCnEay7UDOfi5/WRlWumoDvFxgXY/yhml0hhzS.Ulxtkfgxnvq\", \"username\": \"aravindotp\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"new\", \"schoolcodes\": [\"school13\", \"school12\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-09-27 13:24:43', '2024-09-27 13:25:36', '2024-09-27 13:25:36'),
(18, '9361621891', '{\"city\": \"Tiruchirappalli\", \"name\": \"aravindotp\", \"email\": \"aravindotp@mail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"undefined\", \"password\": \"$2b$10$rUN/fjv.hIpptPfIkk9ieuye5JBOn73j2HeI1AmHItlVW/8vLVsNa\", \"username\": \"aravindotp\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"new\", \"schoolcodes\": [\"school13\", \"school12\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-09-27 13:25:36', '2024-09-27 13:36:14', '2024-09-27 13:36:14'),
(19, '8940900292', '{\"city\": \"Tiruchirappalli\", \"name\": \"arun\", \"email\": \"raghul1a@mail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"undefined\", \"password\": \"$2b$10$RaBxIpjahCbYTYQFDbNwwuGtjUpMxcBq.2HGGRuaIiAmnQSfyPjKW\", \"username\": \"arun\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"new\", \"schoolcodes\": [\"school13\", \"9090\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-09-27 14:44:05', '2024-09-27 14:44:25', '2024-09-27 14:44:25'),
(20, '8940900292', '{\"city\": \"Tiruchirappalli\", \"name\": \"arun\", \"email\": \"msarun@gmail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"undefined\", \"password\": \"$2b$10$QKAJgu.WnmxjZzJ2iayoHODt05/g1bD003dZTaasHvzAwHkDGZZ8q\", \"username\": \"arun\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"new\", \"schoolcodes\": [\"school13\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-09-27 16:45:46', '2024-09-27 16:46:01', '2024-09-27 16:46:01'),
(21, '8903061357', '{\"city\": \"Tiruchirappalli\", \"name\": \"arun\", \"email\": \"dsfds@gmail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"undefined\", \"password\": \"$2b$10$02H1w5lXiU1/478kJajgaulmi4n2dnhhhH7fWX0idQSw7EB3qya0S\", \"username\": \"arfd\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"new\", \"schoolcodes\": [\"9090\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-09-27 16:48:44', '2024-09-27 16:49:05', '2024-09-27 16:49:05'),
(22, '8940900292', '{\"city\": \"Tiruchirappalli\", \"name\": \"ar\", \"email\": \"raghul1a@mail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"undefined\", \"password\": \"$2b$10$sdLYOt8P1xLRa5F06Gd5zOKVfaD1vbUN0EyQWg7mPZr7lknO6p3RK\", \"username\": \"arun\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"new\", \"schoolcodes\": [\"school13\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-10-01 09:22:42', '2024-10-01 09:22:59', '2024-10-01 09:22:59'),
(23, '6374573725', '{\"city\": \"Villupuram\", \"name\": \"admin\", \"email\": \"a@gmail.com\", \"state\": \"tamilnadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"604202\", \"landmark\": \"undefined\", \"password\": \"$2b$10$CZTNUpju.rSKx3LAtgAjjurFAeqZkydp8.dHBlU7Pbc9MEjUCSu5W\", \"username\": \"admin\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"2\", \"schoolcodes\": [\"9090\"], \"locationDetails\": \"kamaraj street\", \"alternatemobileno\": \"undefined\"}', '2024-10-01 17:30:21', '2024-10-01 17:31:29', '2024-10-01 17:31:29'),
(24, '6379148114', '{\"city\": \"Chennai\", \"name\": \"Test\", \"email\": \"b@gmail.com\", \"state\": \"Tamilnadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"600024\", \"landmark\": \"undefined\", \"password\": \"$2b$10$LFrhHwlkcrJsBsYm1oMnEeIxWVVAqWPJIClOMPeOPnpTXjMG4vVwa\", \"username\": \"Test\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"172/1\", \"schoolcodes\": [\"9090\"], \"locationDetails\": \"2cqr Automation Private limited ,shridevikuppam main road\", \"alternatemobileno\": \"undefined\"}', '2024-10-02 00:03:47', '2024-10-02 00:04:09', '2024-10-02 00:04:09'),
(25, '9345002002', '{\"city\": \"Chennai\", \"name\": \"Gomathi\", \"email\": \"h@gmail.com\", \"state\": \"Tamilnadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"600024\", \"landmark\": \"undefined\", \"password\": \"$2b$10$XsJpzCJ/FVeyOEGiSqRaGOml8mozhMyzngPRtfjIxnBip/R1XI2MG\", \"username\": \"hari\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"172\", \"schoolcodes\": [\"9090\", \"School13\"], \"locationDetails\": \"2cqr Automation Private limited ,shridevikuppam main road\", \"alternatemobileno\": \"undefined\"}', '2024-10-02 00:23:39', '2024-10-02 00:23:55', '2024-10-02 00:23:55'),
(26, '8940900292', '{\"city\": \"Tiruchirappalli\", \"name\": \"arun\", \"email\": \"santhiram@gmail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"undefined\", \"password\": \"$2b$10$U3OL1ZErAwnhNr2YKI34S.BRQdanFt/HWzU2uXp6zAwqV5NezwUuC\", \"username\": \"arun\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"new\", \"schoolcodes\": [\"school13\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-10-03 11:43:18', '2024-10-03 11:43:33', '2024-10-03 11:43:33'),
(27, '8940900292', '{\"city\": \"Tiruchirappalli\", \"name\": \"arun\", \"email\": \"arunmuthiah100699@gmail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"234234\", \"landmark\": \"undefined\", \"password\": \"$2b$10$O.ASOY5zeGvnDMRUdK.kuuhBgrnV/aiZ/8jEBbOSN1r0.DrPmcm0e\", \"username\": \"aruns\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"new\", \"schoolcodes\": [\"school13\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-10-03 12:02:41', '2024-10-24 14:16:41', '2024-10-24 14:16:41'),
(28, '8940900292', '{\"city\": \"Tiruchirappalli\", \"name\": \"arun\", \"email\": \"arunmuthiah100699@gmail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"undefined\", \"password\": \"$2b$10$UdsybOVBq7cNK.zUQZGN.uyh2SjYlC5aVDDYeoDfBQXMhkDEeMV2O\", \"username\": \"arun\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"78A/2 new no 93\", \"schoolcodes\": [\"school13\"], \"locationDetails\": \" south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-10-24 14:16:41', '2024-10-24 14:16:54', '2024-10-24 14:16:54'),
(29, '8903061357', '{\"city\": \"chennai\", \"name\": \"2cqr\", \"email\": \"2cqr2024@gmail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"600028\", \"landmark\": \"\", \"password\": \"$2b$10$Ojp/3yVR3k2RM0cbB7djkusGKUSOyEVQeaouUgqnyoU3KG1iQGJ7u\", \"username\": \"2cqr\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"new cub\", \"schoolcodes\": [\"school 123\"], \"locationDetails\": \"valarasaravakam\", \"alternatemobileno\": \"undefined\"}', '2024-10-26 12:31:54', '2024-10-28 10:38:06', '2024-10-28 10:38:06'),
(30, '8940900292', '{\"city\": \"chennai\", \"name\": \"2cqr\", \"email\": \"2cqr2024@gmail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"600028\", \"landmark\": \"\", \"password\": \"$2b$10$xPIhLpD3CfPMpEH0tXuSgemH.BxAZwROnhZPvtOkPY0JoIcqIEw4a\", \"username\": \"2cqr\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"new cub\", \"schoolcodes\": [\"school 123\"], \"locationDetails\": \"valarasaravakam\", \"alternatemobileno\": \"undefined\"}', '2024-10-26 12:33:32', '2024-10-26 12:34:15', '2024-10-26 12:34:15'),
(31, '8903061357', '{\"city\": \"Tiruchirappalli\", \"name\": \"arunMuthiah\", \"email\": \"abc@gmail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"undefined\", \"password\": \"$2b$10$of7Vyo22VZZdMH3Ksfk.8eHIsm4QBpLjx2ABO/Np8q8QtbzPrIz3a\", \"username\": \"arunMuthiah\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"78\", \"schoolcodes\": [\"School001\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-10-28 10:38:06', '2024-10-28 10:41:21', '2024-10-28 10:41:21'),
(32, '6374573725', '{\"city\": \"Chennai\", \"name\": \"Anitha\", \"email\": \"a@gmail.com\", \"state\": \"Tamilnadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"600024\", \"landmark\": \"\", \"password\": \"$2b$10$W9qc.qsYe/VseDf8GkXbWONIOls5hEMRJKbQNCnSjs3z5zriRri9e\", \"username\": \"admin06\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"No:20\", \"schoolcodes\": [\"school13\"], \"locationDetails\": \"2cqr Automation Private limited ,shridevikuppam main road\", \"alternatemobileno\": \"undefined\"}', '2024-10-28 13:17:08', '2024-10-28 13:17:33', '2024-10-28 13:17:33'),
(33, '6374573725', '{\"city\": \"Chennai\", \"name\": \"Anitha\", \"email\": \"a@gmail.com\", \"state\": \"Tamilnadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"600024\", \"landmark\": \"\", \"password\": \"$2b$10$G0lhtQVlTpRDkkpFYpQaaulHnk214K8jAsDyQ2H2cV2yV6aGTnPhm\", \"username\": \"admin06\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"20\", \"schoolcodes\": [\"school13\", \"school123\", \"9090\", \"school001\"], \"locationDetails\": \"2cqr Automation Private limited ,shridevikuppam main road\", \"alternatemobileno\": \"undefined\"}', '2024-10-28 13:28:21', '2024-10-28 13:28:23', '2024-10-28 13:28:23'),
(34, '6374573725', '{\"city\": \"Chennai\", \"name\": \"Anitha\", \"email\": \"a@gmail.com\", \"state\": \"Tamilnadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"600024\", \"landmark\": \"\", \"password\": \"$2b$10$/jvPDcJVljHoYqxe6A0tGOaANktm4esQVizSGtcug7p.76Pb8RdOu\", \"username\": \"admin06\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"20\", \"schoolcodes\": [\"school13\", \"school123\", \"9090\", \"school001\"], \"locationDetails\": \"2cqr Automation Private limited ,shridevikuppam main road\", \"alternatemobileno\": \"undefined\"}', '2024-10-28 13:28:23', '2024-10-28 13:28:24', '2024-10-28 13:28:24'),
(35, '6374573725', '{\"city\": \"Chennai\", \"name\": \"Anitha\", \"email\": \"a@gmail.com\", \"state\": \"Tamilnadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"600024\", \"landmark\": \"\", \"password\": \"$2b$10$UCG89P5iSre7f9ThT/qx6eOxjHtIyGcFTSc9mNqhWffS5CmPGFqnW\", \"username\": \"admin06\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"20\", \"schoolcodes\": [\"school13\", \"school123\", \"9090\", \"school001\"], \"locationDetails\": \"2cqr Automation Private limited ,shridevikuppam main road\", \"alternatemobileno\": \"undefined\"}', '2024-10-28 13:28:24', '2024-10-28 13:28:25', '2024-10-28 13:28:25'),
(36, '6374573725', '{\"city\": \"Chennai\", \"name\": \"Anitha\", \"email\": \"a@gmail.com\", \"state\": \"Tamilnadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"600024\", \"landmark\": \"\", \"password\": \"$2b$10$uF39XpNLvskBwT3yaBaLseMXAf93.ieFIxZ08wI/Ml0L89LGTjSn2\", \"username\": \"admin06\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"20\", \"schoolcodes\": [\"school13\", \"school123\", \"9090\", \"school001\"], \"locationDetails\": \"2cqr Automation Private limited ,shridevikuppam main road\", \"alternatemobileno\": \"undefined\"}', '2024-10-28 13:28:25', '2024-10-28 13:28:26', '2024-10-28 13:28:26'),
(37, '6374573725', '{\"city\": \"Chennai\", \"name\": \"Anitha\", \"email\": \"a@gmail.com\", \"state\": \"Tamilnadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"600024\", \"landmark\": \"\", \"password\": \"$2b$10$86rVhtikH9Ddf/YuZDRAMe9gMFVl7DiVTan4sY94/btN0ZfCaCVB.\", \"username\": \"admin06\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"20\", \"schoolcodes\": [\"school13\", \"school123\", \"9090\"], \"locationDetails\": \"2cqr Automation Private limited ,shridevikuppam main road\", \"alternatemobileno\": \"undefined\"}', '2024-10-28 13:28:26', '2024-10-28 13:28:27', '2024-10-28 13:28:27'),
(38, '6374573725', '{\"city\": \"Chennai\", \"name\": \"Anitha\", \"email\": \"a@gmail.com\", \"state\": \"Tamilnadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"600024\", \"landmark\": \"\", \"password\": \"$2b$10$Z.kaVxb/wWK9uxaSjTesK.rawuvSUU9zgbs2WQpJZ/Bfnr/qouGn6\", \"username\": \"admin06\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"20\", \"schoolcodes\": [\"school13\", \"school123\", \"9090\"], \"locationDetails\": \"2cqr Automation Private limited ,shridevikuppam main road\", \"alternatemobileno\": \"undefined\"}', '2024-10-28 13:28:27', '2024-10-28 13:28:28', '2024-10-28 13:28:28'),
(39, '6374573725', '{\"city\": \"Chennai\", \"name\": \"Anitha\", \"email\": \"a@gmail.com\", \"state\": \"Tamilnadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"600024\", \"landmark\": \"\", \"password\": \"$2b$10$MJifIG.BrZ6/JYzntzpCPu7YP.E.s8g7OgPv7p5t6w8hTmoiCFy0.\", \"username\": \"admin06\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"20\", \"schoolcodes\": [\"school13\", \"school123\", \"9090\"], \"locationDetails\": \"2cqr Automation Private limited ,shridevikuppam main road\", \"alternatemobileno\": \"undefined\"}', '2024-10-28 13:28:28', '2024-10-28 13:28:28', '2024-10-28 13:28:28'),
(40, '6374573725', '{\"city\": \"Chennai\", \"name\": \"Anitha\", \"email\": \"a@gmail.com\", \"state\": \"Tamilnadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"600024\", \"landmark\": \"\", \"password\": \"$2b$10$rNnATx4HqLVfwxCoaDCLHul7qTTtwkF1ZyWK8rLEMi/.Nuol5z5BG\", \"username\": \"admin06\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"20\", \"schoolcodes\": [\"school13\", \"school123\", \"9090\"], \"locationDetails\": \"2cqr Automation Private limited ,shridevikuppam main road\", \"alternatemobileno\": \"undefined\"}', '2024-10-28 13:28:28', '2024-10-28 13:31:36', '2024-10-28 13:31:36'),
(41, '6374573725', '{\"city\": \"Chennai\", \"name\": \"Anitha\", \"email\": \"a@gmail.com\", \"state\": \"Tamilnadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"600024\", \"landmark\": \"\", \"password\": \"$2b$10$UFbabxbBrSriNH70AYrLZuuSW98S6JPsFBtCsgGwHN7E0qcicOwwm\", \"username\": \"admin06\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"20\", \"schoolcodes\": [\"school13\", \"school123\", \"9090\"], \"locationDetails\": \"2cqr Automation Private limited ,shridevikuppam main road\", \"alternatemobileno\": \"undefined\"}', '2024-10-28 13:31:36', '2024-10-28 13:35:52', '2024-10-28 13:35:52'),
(42, '9894749740', '{\"city\": \"Chennai\", \"name\": \"Anitha\", \"email\": \"n@gmail.com\", \"state\": \"Tamilnadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"600024\", \"landmark\": \"\", \"password\": \"$2b$10$iEu4Pu5b.qAIYkipqkvgaedIwUPzjnP.Yt7zMql5bF.nJonZtybSq\", \"username\": \"admin0612\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"32\", \"schoolcodes\": [\"9090\"], \"locationDetails\": \"2cqr Automation Private limited ,shridevikuppam main road\", \"alternatemobileno\": \"undefined\"}', '2024-10-28 14:10:59', '2024-10-28 14:11:15', '2024-10-28 14:11:15'),
(43, '8248498874', '{\"city\": \"Chennai\", \"name\": \"Gomathi\", \"email\": \"g@gmail.com\", \"state\": \"Tamilnadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"600024\", \"landmark\": \"\", \"password\": \"$2b$10$NgzLUWISBUhUzA.TfCJeKOa.KBAjbFMf0PcG.gAJV37LBickP/0Ry\", \"username\": \"admin01\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"2\", \"schoolcodes\": [\"9090\"], \"locationDetails\": \"2cqr Automation Private limited ,shridevikuppam main road\", \"alternatemobileno\": \"undefined\"}', '2024-11-05 11:17:55', '2024-11-05 11:18:09', '2024-11-05 11:18:09'),
(44, '8940900292', '{\"city\": \"trichy\", \"name\": \"2cqr\", \"email\": \"2cqr2024@gmail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"near cub\", \"password\": \"$2b$10$YGWT6TQcPT0KoKHco4esTeX.Jo3Bhtj8zV1rudd1VUCdiS2bHPKe6\", \"username\": \"msarun1999@gmail.com\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"78 a/2 south inside street\", \"schoolcodes\": [\"school 123\"], \"locationDetails\": \"thiruvanaikoil\", \"alternatemobileno\": \"undefined\"}', '2024-11-05 21:08:31', '2024-11-05 21:08:54', '2024-11-05 21:08:54'),
(45, '8903061357', '{\"city\": \"Tiruchirappalli\", \"name\": \"testing\", \"email\": \"testing@gmail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"near school\", \"password\": \"$2b$10$V5nhEDMmlTf4hNitktuqQO9aWm.NsKrSnfyWSxkenXqDzbc..bmea\", \"username\": \"testing\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"2448\", \"schoolcodes\": [\"School001\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-11-06 13:27:35', '2024-11-06 13:29:00', '2024-11-06 13:29:00'),
(46, '8903061357', '{\"city\": \"Tiruchirappalli\", \"name\": \"testing\", \"email\": \"testing@gmail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"near valasaravakam\", \"password\": \"$2b$10$TmYoB6Vh3s9Jftd6xNutfOBZHZHoLtVgMC1LXVihcdtOmAeP14Z3W\", \"username\": \"testing\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"789\", \"schoolcodes\": [\"9090\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-11-06 13:50:06', '2024-11-06 13:51:30', '2024-11-06 13:51:30'),
(47, '6374573725', '{\"city\": \"Chennai\", \"name\": \"Anitha\", \"email\": \"a@gmail.com\", \"state\": \"Tamilnadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"600024\", \"landmark\": \"\", \"password\": \"$2b$10$lcIZSBAzabVJQCDwGhoy/el4To9VVDW229/4fTzZM5AqQ463ZQsXe\", \"username\": \"admin06\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"21\", \"schoolcodes\": [\"9090\"], \"locationDetails\": \"2cqr Automation Private limited ,shridevikuppam main road\", \"alternatemobileno\": \"undefined\"}', '2024-11-07 13:25:50', '2024-11-07 13:26:04', '2024-11-07 13:26:04'),
(48, '9600420101', '{\"city\": \"Chennai\", \"name\": \"Test\", \"email\": \"bharathi@2cqr.in\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"641041\", \"landmark\": \"\", \"password\": \"$2b$10$Ef7LsLNuNclQHBN4P5goIuo4qSZBB1GiMhmGj6tEEzyE1pspe.PjW\", \"username\": \"test123\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"AO98, Elan\", \"schoolcodes\": [\"school13\"], \"locationDetails\": \"Thazambur\", \"alternatemobileno\": \"undefined\"}', '2024-11-11 11:40:37', '2024-11-11 11:43:56', '2024-11-11 11:43:56'),
(49, '9600420101', '{\"city\": \"adfa\", \"name\": \"test12\", \"email\": \"bharathi@2cqr.in\", \"state\": \"Tasd\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"idhsfg\", \"pincode\": \"641041\", \"landmark\": \"\", \"password\": \"$2b$10$Deq80.0m74yPs4V31o6V5enuLJD8c1fy1chq8ITz1eO89DX5b0F.G\", \"username\": \"test12\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"fadsf\", \"schoolcodes\": [\"school 123\"], \"locationDetails\": \"adfa\", \"alternatemobileno\": \"undefined\"}', '2024-11-11 15:54:34', '2024-11-11 15:54:48', '2024-11-11 15:54:48'),
(50, '8940900292', '{\"city\": \"Tiruchirappalli\", \"name\": \"arun\", \"email\": \"santhiram@gmail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"\", \"password\": \"$2b$10$FVWPUXpETpYkaLoFxmoq7OiqISkMVaAh52C.NuWPjE3oW/GO3RujS\", \"username\": \"arun\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"dfs\", \"schoolcodes\": [\"school13\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-11-14 17:15:09', '2024-11-14 17:15:46', '2024-11-14 17:15:46'),
(51, '8940900292', '{\"city\": \"Tiruchirappalli\", \"name\": \"arun\", \"email\": \"raghul1a@mail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"\", \"password\": \"$2b$10$L4KqmNIYmyrWWG1aNJDmBOAOP3HmV8q2smF67v9jdGldUgWtcCkjW\", \"username\": \"aru\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"34324\", \"schoolcodes\": [\"school13\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-11-14 17:17:18', '2024-11-14 17:17:33', '2024-11-14 17:17:33'),
(52, '8940900292', '{\"city\": \"Tiruchirappalli\", \"name\": \"fds\", \"email\": \"raghul1a@mail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"\", \"password\": \"$2b$10$cQrgb42G7AKc1hApQMHIH.6rWiG9etQqIs2lFXBYykVeefFoOPmFe\", \"username\": \"fds\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"fvsafde\", \"schoolcodes\": [\"school13\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-11-14 17:22:35', '2024-11-14 17:22:48', '2024-11-14 17:22:48'),
(53, '9894749740', '{\"city\": \"Chennai\", \"name\": \"Anitha\", \"email\": \"an@gmail.com\", \"state\": \"Tamilnadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"600024\", \"landmark\": \"\", \"password\": \"$2b$10$YAdtTFOGOi73xAwDV4r6tuzWpZq4LnAk7q6TjjdOoOCb6S6epYBHa\", \"username\": \"admin\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"4\", \"schoolcodes\": [\"9090\"], \"locationDetails\": \"2cqr Automation Private limited ,shridevikuppam main road\", \"alternatemobileno\": \"undefined\"}', '2024-11-15 15:22:44', '2024-11-15 15:23:01', '2024-11-15 15:23:01'),
(54, '9894749740', '{\"city\": \"Chennai\", \"name\": \"Anitha\", \"email\": \"an@gmail.com\", \"state\": \"Tamilnadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"600024\", \"landmark\": \"\", \"password\": \"$2b$10$Hu7uWppg0TY9CnM2dtTXKuInGCzEBuP7zghvtM8VGJQTKClLNYI6C\", \"username\": \"admin\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"4\", \"schoolcodes\": [\"9090\"], \"locationDetails\": \"2cqr Automation Private limited ,shridevikuppam main road\", \"alternatemobileno\": \"undefined\"}', '2024-11-15 15:23:01', '2024-11-15 15:23:24', '2024-11-15 15:23:24'),
(55, '9894749740', '{\"city\": \"Chennai\", \"name\": \"Anitha\", \"email\": \"an@gmail.com\", \"state\": \"Tamilnadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"600024\", \"landmark\": \"\", \"password\": \"$2b$10$VBVKDNHu71Oefjs.Yyr4QOVdb8fRXjpBngIuH2TtSxAjnPO5Dz7Gu\", \"username\": \"admin\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"4\", \"schoolcodes\": [\"9090\"], \"locationDetails\": \"2cqr Automation Private limited ,shridevikuppam main road\", \"alternatemobileno\": \"undefined\"}', '2024-11-15 15:23:24', '2024-11-15 15:23:34', '2024-11-15 15:23:34'),
(56, '9894749740', '{\"city\": \"Chennai\", \"name\": \"Anitha\", \"email\": \"an@gmail.com\", \"state\": \"Tamilnadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"600024\", \"landmark\": \"\", \"password\": \"$2b$10$6EeohpXI7diJaPtZi/HZ..hA5ryTrrZPShlL6MOOYy7UT7M5gQ7um\", \"username\": \"admin\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"4\", \"schoolcodes\": [\"9090\"], \"locationDetails\": \"2cqr Automation Private limited ,shridevikuppam main road\", \"alternatemobileno\": \"undefined\"}', '2024-11-15 15:23:34', '2024-11-15 15:23:59', '2024-11-15 15:23:59'),
(57, '9894749740', '{\"city\": \"Chennai\", \"name\": \"Anitha\", \"email\": \"an@gmail.com\", \"state\": \"Tamilnadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"600024\", \"landmark\": \"\", \"password\": \"$2b$10$2tVfgI33OSYowY/.6wsPvuFCBcqz8T8t7tY3yAwZwGBU1QxKmnM2G\", \"username\": \"admin\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"4\", \"schoolcodes\": [\"9090\"], \"locationDetails\": \"2cqr Automation Private limited ,shridevikuppam main road\", \"alternatemobileno\": \"undefined\"}', '2024-11-15 15:23:59', '2024-11-15 15:25:19', '2024-11-15 15:25:19'),
(58, '9894749740', '{\"city\": \"ftfuyhjvnbk\", \"name\": \"Anitha\", \"email\": \"an@gmail.com\", \"state\": \"ghfkjkh,\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"gfhjkl\", \"pincode\": \"768123\", \"landmark\": \"\", \"password\": \"$2b$10$4e9uvFQBht.qkDOXLTiSSukKp2/aiGh70T9zN5v/roEpkopLqVtaC\", \"username\": \"admin\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"9090\", \"schoolcodes\": [\"9090\"], \"locationDetails\": \"hiug\", \"alternatemobileno\": \"undefined\"}', '2024-11-15 15:32:50', '2024-11-15 15:33:35', '2024-11-15 15:33:35'),
(59, '9894749740', '{\"city\": \"ftfuyhjvnbk\", \"name\": \"Anitha\", \"email\": \"an@gmail.com\", \"state\": \"ghfkjkh,\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"gfhjkl\", \"pincode\": \"768123\", \"landmark\": \"\", \"password\": \"$2b$10$JcjvqzR.rGVpVibKdKE2S.akRebCLGb59WrUTABw.Oqc0PsX8Skfe\", \"username\": \"admin\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"9090\", \"schoolcodes\": [\"9090\"], \"locationDetails\": \"hiug\", \"alternatemobileno\": \"undefined\"}', '2024-11-15 15:33:35', '2024-11-15 15:38:25', '2024-11-15 15:38:25'),
(60, '9909988968', '{\"city\": \"ss\", \"name\": \"new\", \"email\": \"newentry@mail.in\", \"state\": \"ssss\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"india\", \"pincode\": \"980798\", \"landmark\": \"khkj\", \"password\": \"$2b$10$YHUploJ9LIOeRYc6LScrB.DgcFcqMDa.FLj4MoBK/5MA8FAyTrBX2\", \"username\": \"new user\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"addresss\", \"schoolcodes\": [\"school13\"], \"locationDetails\": \"ss\", \"alternatemobileno\": \"undefined\"}', '2024-11-15 15:37:47', NULL, NULL),
(61, '9894749740', '{\"city\": \"ftfuyhjvnbk\", \"name\": \"Anitha\", \"email\": \"an@gmail.com\", \"state\": \"ghfkjkh\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"gfhjkl\", \"pincode\": \"768123\", \"landmark\": \"\", \"password\": \"$2b$10$z.dsCKt7ervvUAEaDG5aSu3HoqM.WXySYd/zOnoSi8AVUFfAseHG2\", \"username\": \"admin\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"9090\", \"schoolcodes\": [\"9090\"], \"locationDetails\": \"hiug\", \"alternatemobileno\": \"undefined\"}', '2024-11-15 15:38:25', '2024-11-15 15:39:06', '2024-11-15 15:39:06'),
(62, '9894749740', '{\"city\": \"ftfuyhjvnbk\", \"name\": \"Anitha\", \"email\": \"an@gmail.com\", \"state\": \"ghfkjkh\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"gfhjkl\", \"pincode\": \"768123\", \"landmark\": \"\", \"password\": \"$2b$10$pAsL4ruWUc5xepSYOefOQeFKlnTNP1/D0CaNv.PN2DEATt2wVRddu\", \"username\": \"admin\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"9090\", \"schoolcodes\": [\"9090\"], \"locationDetails\": \"hiug\", \"alternatemobileno\": \"undefined\"}', '2024-11-15 15:39:06', '2024-11-15 15:41:26', '2024-11-15 15:41:26'),
(63, '8940900292', '{\"city\": \"Tiruchirappalli\", \"name\": \"arun\", \"email\": \"msarun@gmail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"\", \"password\": \"$2b$10$Fgh8kAQy3/RGIRkVAE2V5.HlTSguDwx5zv7hSKq76FrOzRnbVnWhy\", \"username\": \"arun\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"fds\", \"schoolcodes\": [\"school13\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-11-15 17:33:57', '2024-11-15 17:36:08', '2024-11-15 17:36:08'),
(64, '8940900292', '{\"city\": \"Tiruchirappalli\", \"name\": \"arun\", \"email\": \"msarun@gmail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"\", \"password\": \"$2b$10$Wm45YH1eM9HrnoziF1WnFecab922bSgkr/y9leO6/kN.WsYnk8JS.\", \"username\": \"arun\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"fds\", \"schoolcodes\": [\"school13\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-11-15 17:36:08', '2024-11-15 17:36:57', '2024-11-15 17:36:57'),
(65, '8940900292', '{\"city\": \"Tiruchirappalli\", \"name\": \"arun\", \"email\": \"arunmuthiah100699@gmail.com\", \"state\": \"Tamil Nadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"\", \"password\": \"$2b$10$TzNPqpIMO6B/pYkVGrfKDuNO3.eRw/ljlTtUrHY1eEXTPVkSsIjKy\", \"username\": \"aruns\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"fds\", \"schoolcodes\": [\"school13\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-11-15 17:37:53', '2024-11-15 17:38:07', '2024-11-15 17:38:07'),
(66, '9894749740', '{\"city\": \"Chennai\", \"name\": \"anitha\", \"email\": \"an@gmail.com\", \"state\": \"Tamilnadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"600024\", \"landmark\": \"\", \"password\": \"$2b$10$HmucmvMXF5Ud93dAtKjIpOL3ag1UTB5vJR7ihoLzdYSYsFVMTFJSu\", \"username\": \"admin\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"23\", \"schoolcodes\": [\"9090\"], \"locationDetails\": \"2cqr Automation Private limited ,shridevikuppam main road\", \"alternatemobileno\": \"undefined\"}', '2024-11-15 17:46:10', '2024-11-15 17:47:27', '2024-11-15 17:47:27'),
(67, '8940900293', '{\"city\": \"Tiruchirappalli\", \"name\": \"arun\", \"email\": \"raghul1ad@mail.com\", \"state\": \"17\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"\", \"password\": \"$2b$10$9ag2QfE25eqP6wbBPv4P..6aUhMQPpKK7DFoO0ptDo7EYLnxSsRFe\", \"username\": \"sdf@gmail.com\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"dfsed\", \"schoolcodes\": [\"school13\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-11-19 13:25:03', '2024-11-19 13:25:04', '2024-11-19 13:25:04'),
(68, '8940900293', '{\"city\": \"Tiruchirappalli\", \"name\": \"arun\", \"email\": \"raghul1ad@mail.com\", \"state\": \"17\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"\", \"password\": \"$2b$10$Weus79qK1lRD/TL9y54XLOmhvb86LMlKSEmGJsPJeB/ydpLLZ1KVG\", \"username\": \"sdf@gmail.com\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"dfsed\", \"schoolcodes\": [\"school13\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-11-19 13:25:04', '2024-11-19 13:27:13', '2024-11-19 13:27:13'),
(69, '8940900293', '{\"city\": \"Tiruchirappalli\", \"name\": \"arun\", \"email\": \"raghul1ad@mail.com\", \"state\": \"8\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"\", \"password\": \"$2b$10$kWQAlxOdX2FACDZCPgKUYediumrf7bU2dV0UOYAgiU.ohBZRJdmvu\", \"username\": \"sdf@gmail.com\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"dfsed\", \"schoolcodes\": [\"school13\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-11-19 13:27:13', NULL, NULL),
(70, '8248498874', '{\"city\": \"Chennai\", \"name\": \"Ahtina\", \"email\": \"anithaalex958@gmail.com\", \"state\": \"Tamilnadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"INDIA\", \"pincode\": \"600024\", \"landmark\": \"\", \"password\": \"$2b$10$6XzO1oH7dGm76Tl4iZksv.4P4Yr7.tomaqAm5AqWB00UC5QaHJrSK\", \"username\": \"admin12\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"1\", \"schoolcodes\": [\"9090\"], \"locationDetails\": \"3rd cross street\", \"alternatemobileno\": \"undefined\"}', '2024-11-19 15:31:22', '2024-11-19 15:31:53', '2024-11-19 15:31:53'),
(71, '9894749740', '{\"city\": \"Bangalore\", \"name\": \"Tiara\", \"email\": \"anithaalex958@gmail.com\", \"state\": \"Karanataka\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"INDIA\", \"pincode\": \"560066\", \"landmark\": \"\", \"password\": \"$2b$10$efYsZdLTDbVyYU75yfOAqOrv/xGHRBGe/I.xWySCIdtsl3eAK1Xq6\", \"username\": \"admin99\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"2\", \"schoolcodes\": [\"9956\"], \"locationDetails\": \"Whitefield\", \"alternatemobileno\": \"undefined\"}', '2024-11-20 13:13:25', '2024-11-20 13:13:44', '2024-11-20 13:13:44'),
(72, '8565875648', '{\"city\": \"Chennai\", \"name\": \"aaa\", \"email\": \"be@gmail.com\", \"state\": \"Tamilnadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"600234\", \"landmark\": \"\", \"password\": \"$2b$10$UlNb/PvVFZive9im/J1.XuwvSQvWpdFgfhK2gedZi9Si7uLwp49sK\", \"username\": \"admin97\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"2\", \"schoolcodes\": [\"9090\"], \"locationDetails\": \"2cqr Automation Private limited ,shridevikuppam main road\", \"alternatemobileno\": \"undefined\"}', '2024-11-21 16:32:43', NULL, NULL);
INSERT INTO `temp_register` (`id`, `mobileno`, `json_data`, `created_at`, `updated_at`, `deleted_at`) VALUES
(73, '0000000000', '{\"city\": \"Chennai\", \"name\": \"aaa\", \"email\": \"be@gmail.com\", \"state\": \"Tamilnadu\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"600234\", \"landmark\": \"\", \"password\": \"$2b$10$kh6vP55Bg9OpD0oRsTERteCJmqB9TXxO2Ls26bMk4syzvyyV0.9Sy\", \"username\": \"admin97\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"2\", \"schoolcodes\": [\"9090\"], \"locationDetails\": \"2cqr Automation Private limited ,shridevikuppam main road\", \"alternatemobileno\": \"undefined\"}', '2024-11-21 16:33:00', NULL, NULL),
(74, '9999999000', '{\"city\": \"Chennai\", \"name\": \"aaa\", \"email\": \"be@gmail.com\", \"state\": \"i576\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"600278\", \"landmark\": \"\", \"password\": \"$2b$10$hGKCO/N4uvK3NEEP9lXHRO6wgd6zsSADQi4PnlE72pdJJQrsnYVnu\", \"username\": \"admin97\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"2\", \"schoolcodes\": [\"9090\"], \"locationDetails\": \"2cqr Automation Private limited ,shridevikuppam main road\", \"alternatemobileno\": \"undefined\"}', '2024-11-21 16:36:26', NULL, NULL),
(75, '8940900296', '{\"city\": \"Tiruchirappalli\", \"name\": \"2cqr\", \"email\": \"msarun19949@gmail.com\", \"state\": \"23\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620006\", \"landmark\": \"near valasaravakam\", \"password\": \"$2b$10$85gPKoIl4lyF0yx8cPLeLe2lTuH.D9Oj5PJkiFAIqv69DfF/qFywK\", \"username\": \"abc@gmail.com\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"546\", \"schoolcodes\": [\"school13\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-11-21 16:45:59', '2024-11-21 16:46:07', '2024-11-21 16:46:07'),
(76, '8940900296', '{\"city\": \"Tiruchirappalli\", \"name\": \"2cqr\", \"email\": \"msarun19949@gmail.com\", \"state\": \"23\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620006\", \"landmark\": \"near valasaravakam\", \"password\": \"$2b$10$KbHCHjv2JoMuKQ5oKetIa.AL3gB5v9foKstnm5C5SP.BtF2naqK.m\", \"username\": \"abc@gmail.com\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"546\", \"schoolcodes\": [\"school13\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-11-21 16:46:07', '2024-11-21 16:46:13', '2024-11-21 16:46:13'),
(77, '8940900296', '{\"city\": \"Tiruchirappalli\", \"name\": \"2cqr\", \"email\": \"msarun19949@gmail.com\", \"state\": \"23\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620006\", \"landmark\": \"near valasaravakam\", \"password\": \"$2b$10$nTMVUbG6sdrM4ut65sjnouZh79cK7jSOfJM7zCt/Pcd4xkLfvjaRa\", \"username\": \"abc@gmail.com\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"546\", \"schoolcodes\": [\"school13\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-11-21 16:46:13', '2024-11-21 16:46:16', '2024-11-21 16:46:16'),
(78, '8940900296', '{\"city\": \"Tiruchirappalli\", \"name\": \"2cqr\", \"email\": \"msarun19949@gmail.com\", \"state\": \"23\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620006\", \"landmark\": \"near valasaravakam\", \"password\": \"$2b$10$a4HBiqX0xijJsAWjg/QiTeGQFc31xeY1f2mVnhKAOnyKZ4uuJ0VT2\", \"username\": \"abc@gmail.com\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"546\", \"schoolcodes\": [\"school13\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-11-21 16:46:16', NULL, NULL),
(79, '8903061357', '{\"city\": \"Tiruchirappalli\", \"name\": \"2cqr\", \"email\": \"msarun19949@gmail.com\", \"state\": \"23\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620006\", \"landmark\": \"near valasaravakam\", \"password\": \"$2b$10$nVUXJWHMS8hh5uZ7q4ncY.bk0rbQhzUZ.Q5G3QfkSYnSp1zkdfNby\", \"username\": \"abc@gmail.com\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"546\", \"schoolcodes\": [\"school13\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-11-21 16:52:44', '2024-11-21 16:52:58', '2024-11-21 16:52:58'),
(80, '8940900292', '{\"city\": \"Tiruchirappalli\", \"name\": \"arun\", \"email\": \"muthiah1006@gmail.com\", \"state\": \"23\", \"iswork\": \"base64:type16:AA==\", \"roleid\": 52, \"status\": \"base64:type16:AA==\", \"country\": \"India\", \"pincode\": \"620005\", \"landmark\": \"\", \"password\": \"$2b$10$QKW1gNbiawBNzMrB9ZsBkOUUKmOU/eYmxAoM.3NwYDyElU1uY/qc6\", \"username\": \"arun\", \"isprimary\": \"base64:type16:AA==\", \"fullAddress\": \"93\", \"schoolcodes\": [\"9956\"], \"locationDetails\": \"78A/2 south inside street Bramma thertham karai Thiruvanaikoil Trichy\", \"alternatemobileno\": \"undefined\"}', '2024-11-21 16:58:48', '2024-11-21 16:59:00', '2024-11-21 16:59:00');

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `roleblob` varbinary(100) NOT NULL,
  `checks` tinyint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`roleblob`, `checks`) VALUES
(0x11111111000000111110000001, 0),
(0x11111111000000111110000001, 0);

-- --------------------------------------------------------

--
-- Table structure for table `testbinary`
--

CREATE TABLE `testbinary` (
  `test2` bit(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `testbinary`
--

INSERT INTO `testbinary` (`test2`) VALUES
(b'0000000000000000000000000000000000000000000000000000000000000000'),
(b'0000000000000000000000000000000000000000000000000000000000000000'),
(b'0000000000000000000000000000000000000000000000000000000000000000'),
(b'0000000000000000000000000000000000000000000000000000000000000000'),
(b'0000000000000000000000000000000000000000000000000000000000000000'),
(b'0000000000000000000000000000000000000000000000000000000000000000'),
(b'0000000000000000000000000000000000000000000000000000000000000000'),
(b'0000000000000000000000000000000000000000000000000000000000000000'),
(b'0000000000000000000000000000000000000000000000000000000000000000'),
(b'0000000000000000000000000000000000000000000000000000000000000000'),
(b'0000000000000000000000000000000000000000000000000000000000000000'),
(b'0000000000000000000000000000000000000000000000000000000000000000'),
(b'0000000000000000000000000000000000000000000000000000000000000000'),
(b'0000000000000000000000000000000000000000000000000000000000000000'),
(b'0000000000000000000000000000000000000000000000000000000000000000'),
(b'0000000000000000000000000000000000000000000000000000000000000000'),
(b'0000000000000000000000000000000000000000000000000000000000000000'),
(b'0000000000000000000000000000000000000000000000000000000001100111'),
(b'0000000000000000000000000000000000000000000000000000000000111100'),
(b'0000000000000000000000000000000000000000000000000000000000001011'),
(b'0000000000000000000000000000000000000000111111111111111111111111'),
(b'0000000000000000000000000000000000000000000000000000000000000000'),
(b'0000000000000000000000000000000000000000000110011001100110011001'),
(b'0000000000000000000000000000000000000000000000000000111111110011'),
(b'0000000000000000000000000000000000000000000000000011111111001101'),
(b'0000000000000000000000000001100111011110101111010000000111000111'),
(b'0000000000000000000000000000000000000000000000000000000000000000'),
(b'0000000000000000000000000110001000100111000011111111001100100111'),
(b'0000000000000000000000000000000000110100001100000011100000110011'),
(b'0000000000000000000000000000000000000000001101010011000100110001');

-- --------------------------------------------------------

--
-- Table structure for table `test_timezone`
--

CREATE TABLE `test_timezone` (
  `id` int NOT NULL,
  `used` tinyint(1) DEFAULT NULL,
  `currentdatetime` datetime DEFAULT (convert_tz(now(),_utf8mb4'+00:00',_utf8mb4'+05:30'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `test_timezone`
--

INSERT INTO `test_timezone` (`id`, `used`, `currentdatetime`) VALUES
(1, 1, '2024-02-16 16:59:20'),
(2, 1, '2024-02-16 16:59:28');

-- --------------------------------------------------------

--
-- Table structure for table `transactionlog`
--

CREATE TABLE `transactionlog` (
  `logid` bigint NOT NULL,
  `transtableid` varchar(255) DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `createdon` datetime DEFAULT (convert_tz(now(),_utf8mb4'+00:00',_utf8mb4'+05:30')),
  `createdby` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `transactionlog`
--

INSERT INTO `transactionlog` (`logid`, `transtableid`, `status`, `createdon`, `createdby`) VALUES
(157, '43', 'Ordered', '2024-11-12 16:17:44', 202),
(158, '44', 'Ordered', '2024-11-12 16:24:02', 202),
(159, '45', 'Ordered', '2024-11-12 16:24:05', 202),
(160, '46', 'Ordered', '2024-11-12 16:25:58', 202),
(161, '47', 'Ordered', '2024-11-12 16:32:12', 202),
(162, '48', 'Ordered', '2024-11-12 16:33:34', 202),
(163, '49', 'Ordered', '2024-11-12 16:51:11', 202),
(164, '50', 'Ordered', '2024-11-12 16:51:12', 202),
(165, '51', 'Ordered', '2024-11-13 11:54:36', 202),
(166, '52', 'Ordered', '2024-11-13 11:54:37', 202),
(167, '53', 'Ordered', '2024-11-13 11:56:54', 202),
(168, '54', 'Ordered', '2024-11-13 12:48:47', 202),
(169, '55', 'Ordered', '2024-11-13 12:48:47', 202),
(170, '56', 'Ordered', '2024-11-13 12:48:47', 202),
(171, '57', 'Ordered', '2024-11-13 13:13:35', 202),
(172, '58', 'Ordered', '2024-11-13 13:18:58', 202),
(173, '59', 'Ordered', '2024-11-13 13:19:39', 202),
(174, '60', 'Ordered', '2024-11-13 13:33:59', 202),
(175, '61', 'Ordered', '2024-11-13 13:34:00', 202),
(176, '62', 'Ordered', '2024-11-13 13:41:18', 202),
(177, '63', 'Ordered', '2024-11-13 14:05:37', 202),
(178, '64', 'Ordered', '2024-11-13 14:44:02', 202),
(179, '65', 'Ordered', '2024-11-13 14:51:52', 202),
(180, '66', 'Ordered', '2024-11-13 14:51:53', 202),
(181, '67', 'Ordered', '2024-11-13 15:11:28', 205),
(182, '68', 'Ordered', '2024-11-13 15:11:29', 205),
(183, '69', 'Ordered', '2024-11-13 15:11:29', 205),
(184, '70', 'Ordered', '2024-11-13 15:12:04', 205),
(185, '71', 'Ordered', '2024-11-13 15:13:28', 205),
(186, '72', 'Ordered', '2024-11-13 15:15:28', 205),
(187, '73', 'Ordered', '2024-11-13 15:24:19', 205),
(188, '74', 'Ordered', '2024-11-13 15:25:37', 205),
(189, '75', 'Ordered', '2024-11-13 15:36:22', 205),
(190, '76', 'Ordered', '2024-11-13 15:36:22', 205),
(191, '77', 'Ordered', '2024-11-13 15:39:31', 202),
(192, '78', 'Ordered', '2024-11-13 15:39:32', 202),
(193, '79', 'Ordered', '2024-11-13 15:39:33', 202),
(194, '80', 'Ordered', '2024-11-13 15:53:05', 205),
(195, '81', 'Ordered', '2024-11-13 15:53:41', 205),
(196, '82', 'Ordered', '2024-11-13 18:01:16', 205),
(197, '83', 'Ordered', '2024-11-13 18:01:16', 205),
(198, '84', 'Ordered', '2024-11-14 11:23:47', 202),
(199, '85', 'Ordered', '2024-11-14 11:23:48', 202),
(200, '86', 'Ordered', '2024-11-14 11:30:52', 202),
(201, '87', 'Ordered', '2024-11-14 13:36:54', 202),
(202, '88', 'Ordered', '2024-11-14 15:39:11', 207),
(203, '89', 'Ordered', '2024-11-14 15:59:16', 202),
(204, '90', 'Ordered', '2024-11-14 16:17:41', 207),
(205, '91', 'Ordered', '2024-11-14 16:50:02', 202),
(206, '92', 'Ordered', '2024-11-14 16:54:21', 207),
(207, '93', 'Ordered', '2024-11-14 17:58:43', 202),
(208, '94', 'Ordered', '2024-11-14 18:02:47', 202),
(209, '95', 'Ordered', '2024-11-15 11:29:37', 202),
(210, '96', 'Ordered', '2024-11-15 11:42:25', 202),
(211, '97', 'Ordered', '2024-11-15 11:44:52', 202),
(212, '98', 'Ordered', '2024-11-15 12:54:25', 202),
(213, '99', 'Ordered', '2024-11-15 12:54:25', 202),
(214, '100', 'Ordered', '2024-11-15 12:54:26', 202),
(215, '101', 'Ordered', '2024-11-15 12:58:26', 202),
(216, '102', 'Ordered', '2024-11-15 13:01:30', 202),
(217, '103', 'Ordered', '2024-11-15 13:03:21', 202),
(218, '104', 'Ordered', '2024-11-15 13:03:22', 202),
(219, '105', 'Ordered', '2024-11-15 13:07:13', 202),
(220, '106', 'Ordered', '2024-11-15 13:07:57', 202),
(221, '107', 'Ordered', '2024-11-15 13:07:59', 202),
(222, '108', 'Ordered', '2024-11-15 13:28:49', 202),
(223, '109', 'Ordered', '2024-11-15 13:28:50', 202),
(224, '110', 'Ordered', '2024-11-15 16:23:24', 205),
(225, '111', 'Ordered', '2024-11-15 16:23:24', 205),
(226, '112', 'Ordered', '2024-11-15 17:29:26', 202),
(227, '113', 'Ordered', '2024-11-15 17:29:28', 202),
(228, '114', 'Ordered', '2024-11-18 11:20:29', 202),
(229, '115', 'Ordered', '2024-11-18 11:20:30', 202),
(230, '116', 'Ordered', '2024-11-18 11:27:42', 202),
(231, '117', 'Ordered', '2024-11-18 12:33:14', 202),
(232, '118', 'Ordered', '2024-11-18 12:43:31', 202),
(233, '119', 'Pending', '2024-11-18 13:48:00', 202),
(234, '120', 'Pending', '2024-11-18 13:48:01', 202),
(235, '121', 'Pending', '2024-11-18 13:53:23', 202),
(236, '122', 'Ordered', '2024-11-18 20:12:37', 202),
(237, '123', 'Ordered', '2024-11-19 15:47:55', 227),
(238, '124', 'Ordered', '2024-11-19 16:06:02', 227),
(239, '125', 'Ordered', '2024-11-19 16:08:17', 227),
(240, '126', 'Ordered', '2024-11-19 16:09:49', 227),
(241, '127', 'Ordered', '2024-11-19 16:11:05', 227),
(242, '128', 'Ordered', '2024-11-19 16:12:54', 227),
(243, '129', 'Ordered', '2024-11-19 16:14:58', 227),
(244, '130', 'Ordered', '2024-11-20 17:44:55', 202),
(245, '131', 'Ordered', '2024-11-20 17:46:32', 202),
(246, '132', 'Ordered', '2024-11-20 17:50:57', 202),
(247, '133', 'Ordered', '2024-11-20 17:53:29', 202),
(248, '134', 'Ordered', '2024-11-20 17:59:20', 202),
(249, '135', 'Ordered', '2024-11-20 18:03:42', 202),
(250, '136', 'Ordered', '2024-11-20 18:06:09', 202),
(251, '137', 'Ordered', '2024-11-20 18:10:46', 202),
(252, '138', 'Ordered', '2024-11-20 18:11:22', 202),
(253, '139', 'Ordered', '2024-11-20 18:13:16', 202),
(254, '140', 'Ordered', '2024-11-21 10:11:53', 202),
(255, '141', 'Ordered', '2024-11-21 12:42:48', 202),
(256, '142', 'Ordered', '2024-11-21 12:44:46', 202),
(257, '143', 'Ordered', '2024-11-21 12:55:22', 202),
(258, '144', 'Ordered', '2024-11-21 12:56:15', 202),
(259, '145', 'Ordered', '2024-11-21 12:58:34', 202),
(260, '146', 'Ordered', '2024-11-21 13:06:11', 202),
(261, '147', 'Ordered', '2024-11-21 13:06:54', 202),
(262, '148', 'Ordered', '2024-11-21 13:37:54', 202),
(263, '149', 'Ordered', '2024-11-21 13:37:54', 202),
(264, '150', 'Ordered', '2024-11-21 13:39:23', 202),
(265, '151', 'Ordered', '2024-11-21 13:39:24', 202),
(266, '152', 'Ordered', '2024-11-21 14:46:21', 202),
(267, '153', 'Ordered', '2024-11-21 15:21:39', 202),
(268, '154', 'Ordered', '2024-11-21 15:21:40', 202),
(269, '155', 'Ordered', '2024-11-21 15:23:17', 202),
(270, '156', 'Ordered', '2024-11-21 16:59:41', 230),
(271, '157', 'Ordered', '2024-11-21 17:04:19', 230),
(272, '158', 'Ordered', '2024-11-21 17:40:42', 230),
(273, '159', 'Ordered', '2024-11-21 17:40:43', 230),
(274, '160', 'Ordered', '2024-11-21 19:11:20', 230),
(275, '161', 'Ordered', '2024-11-22 10:38:26', 227),
(276, '162', 'Ordered', '2024-11-22 10:41:52', 227),
(277, '163', 'Ordered', '2024-11-22 10:42:33', 227),
(278, '164', 'Ordered', '2024-11-22 18:01:03', 227),
(279, '165', 'Ordered', '2024-11-22 18:03:26', 227),
(280, '166', 'Ordered', '2024-11-22 18:03:29', 228),
(281, '167', 'Ordered', '2024-11-23 11:18:53', 227),
(282, '168', 'Ordered', '2024-11-23 11:19:59', 227),
(283, '169', 'Ordered', '2024-11-23 11:39:55', 227),
(284, '170', 'Ordered', '2024-11-23 14:12:05', 227),
(285, '171', 'Ordered', '2024-11-23 14:12:05', 227),
(286, '172', 'Ordered', '2024-11-23 14:34:23', 227),
(287, '173', 'Ordered', '2024-11-23 14:34:23', 227),
(288, '174', 'Ordered', '2024-11-23 15:31:49', 227),
(289, '175', 'Ordered', '2024-11-23 15:31:49', 227),
(290, '176', 'Ordered', '2024-11-23 15:38:42', 227),
(291, '201', 'instock', '2024-11-26 15:26:23', 205),
(292, '202', 'instock', '2024-11-26 15:37:47', 205),
(293, '203', 'instock', '2024-11-26 15:37:55', 205),
(294, '204', 'instock', '2024-11-26 18:10:41', 205),
(295, '205', 'instock', '2024-11-26 18:12:13', 205),
(296, '206', 'instock', '2024-11-26 18:25:02', 205),
(297, '207', 'outofstock', '2024-11-26 18:31:18', 205),
(298, '208', 'instock', '2024-11-26 18:32:23', 205),
(299, '209', 'instock', '2024-11-26 18:46:26', 205),
(300, '210', 'instock', '2024-11-26 18:48:04', 205),
(301, '211', 'instock', '2024-11-26 18:50:44', 205),
(302, '212', 'instock', '2024-11-26 18:54:38', 205),
(303, '213', 'instock', '2024-11-26 18:55:28', 205),
(304, '214', 'instock', '2024-11-27 10:27:48', 205),
(305, '215', 'instock', '2024-11-27 10:27:48', 205),
(306, '216', 'instock', '2024-11-27 10:29:20', 205),
(307, '217', 'instock', '2024-11-27 10:29:21', 205),
(308, '218', 'instock', '2024-11-27 10:30:37', 205),
(309, '219', 'instock', '2024-11-27 10:30:38', 205),
(310, '220', 'instock', '2024-11-27 10:47:10', 205),
(311, '221', 'instock', '2024-11-27 10:48:33', 205),
(312, '222', 'instock', '2024-11-27 10:48:43', 205),
(315, '225', 'instock', '2024-11-27 13:01:38', 205),
(316, '226', 'instock', '2024-11-27 13:03:52', 205),
(317, '227', 'instock', '2024-11-27 13:05:55', 205),
(318, '228', 'instock', '2024-11-27 13:06:38', 205),
(319, '229', 'instock', '2024-11-27 13:16:41', 205),
(320, '230', 'instock', '2024-11-27 13:20:06', 205),
(321, '231', 'instock', '2024-11-27 13:24:09', 205),
(322, '232', 'instock', '2024-11-27 13:25:44', 205),
(323, '233', 'instock', '2024-11-27 13:35:32', 205),
(324, '234', 'instock', '2024-11-27 13:43:30', 205),
(325, '235', 'instock', '2024-11-27 13:58:12', 227),
(326, '236', 'outofstock', '2024-11-27 13:58:12', 227),
(327, '237', 'instock', '2024-11-27 13:58:36', 227),
(328, '238', 'outofstock', '2024-11-27 13:58:36', 227),
(329, '239', 'instock', '2024-11-27 14:00:05', 227),
(330, '240', 'outofstock', '2024-11-27 14:00:05', 227),
(331, '241', 'instock', '2024-11-27 15:31:32', 227),
(332, '242', 'instock', '2024-11-27 15:32:27', 227),
(333, '243', 'instock', '2024-11-27 15:38:34', 227),
(334, '244', 'instock', '2024-11-27 15:43:10', 227),
(335, '245', 'instock', '2024-11-27 15:48:40', 227),
(336, '246', 'instock', '2024-11-27 15:54:04', 227),
(337, '247', 'instock', '2024-11-27 15:55:57', 227),
(338, '248', 'instock', '2024-11-27 15:58:05', 227),
(339, '249', 'instock', '2024-11-27 16:01:38', 205),
(340, '250', 'instock', '2024-11-27 16:02:53', 205),
(341, '251', 'instock', '2024-11-27 16:02:54', 205),
(342, '252', 'instock', '2024-11-27 16:02:55', 205),
(343, '253', 'instock', '2024-11-27 16:06:32', 227),
(344, '254', 'instock', '2024-11-27 16:10:00', 205),
(345, '255', 'instock', '2024-11-27 16:10:48', 227),
(346, '256', 'instock', '2024-11-27 16:10:56', 227),
(347, '257', 'instock', '2024-11-27 16:11:56', 205),
(348, '258', 'instock', '2024-11-27 16:16:55', 205),
(349, '259', 'instock', '2024-11-27 17:33:23', 228),
(350, '260', 'instock', '2024-11-27 17:34:20', 228),
(351, '261', 'instock', '2024-11-27 17:35:37', 228),
(352, '262', 'instock', '2024-11-27 17:38:11', 227),
(353, '263', 'instock', '2024-11-27 17:39:35', 227),
(354, '264', 'instock', '2024-11-27 17:40:04', 227),
(355, '265', 'instock', '2024-11-27 17:41:37', 227),
(356, '266', 'instock', '2024-11-27 17:54:31', 227),
(357, '267', 'instock', '2024-11-27 17:54:54', 227),
(358, '268', 'instock', '2024-11-27 17:56:33', 227),
(361, '271', 'instock', '2024-11-27 18:20:09', 227);

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` bigint NOT NULL,
  `productid` varchar(255) DEFAULT NULL,
  `userid` bigint DEFAULT NULL,
  `transid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `addressid` bigint DEFAULT NULL,
  `ordernumber` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `variant` int DEFAULT NULL,
  `tpricegst` decimal(10,2) DEFAULT NULL,
  `tweight` int DEFAULT NULL,
  `childbillid` bigint DEFAULT NULL,
  `online` tinyint DEFAULT '0',
  `gst_id` int DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `createdon` datetime DEFAULT (convert_tz(now(),_utf8mb4'+00:00',_utf8mb4'+05:30')),
  `lastmodifiedat` datetime DEFAULT (convert_tz(now(),_utf8mb4'+00:00',_utf8mb4'+05:30')),
  `lastmodifiedby` bigint DEFAULT NULL,
  `createdby` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `productid`, `userid`, `transid`, `addressid`, `ordernumber`, `quantity`, `variant`, `tpricegst`, `tweight`, `childbillid`, `online`, `gst_id`, `status`, `createdon`, `lastmodifiedat`, `lastmodifiedby`, `createdby`) VALUES
(67, '329', 205, 'Trans-20241113-0017', 188, '2CQR-20241113-0017', 482, 493, NULL, NULL, NULL, 1, NULL, 'Ordered', '2024-11-13 15:11:28', '2024-11-13 15:11:28', NULL, NULL),
(68, '331', 205, 'Trans-20241113-0018', 188, '2CQR-20241113-0018', 1, 503, NULL, NULL, NULL, 1, NULL, 'Ordered', '2024-11-13 15:11:29', '2024-11-13 15:11:29', NULL, NULL),
(69, '329', 205, 'Trans-20241113-0019', 188, '2CQR-20241113-0019', 482, 493, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-13 15:11:29', '2024-11-13 15:11:29', NULL, NULL),
(70, '329', 205, 'Trans-20241113-0020', 188, '2CQR-20241113-0020', 1, 495, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-13 15:12:04', '2024-11-13 15:12:04', NULL, NULL),
(71, '332', 205, 'Trans-20241113-0021', 188, '2CQR-20241113-0021', 1, 516, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-13 15:13:28', '2024-11-13 15:13:28', NULL, NULL),
(72, '337', 205, 'Trans-20241113-0022', 188, '2CQR-20241113-0022', 1, 542, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-13 15:15:28', '2024-11-13 15:15:28', NULL, NULL),
(73, '337', 205, 'Trans-20241113-0023', 188, '2CQR-20241113-0023', 1, 542, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-13 15:24:19', '2024-11-13 15:24:19', NULL, NULL),
(74, '337', 205, 'Trans-20241113-0024', 188, '2CQR-20241113-0024', 1, 542, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-13 15:25:37', '2024-11-13 15:25:37', NULL, NULL),
(75, '329', 205, 'Trans-20241113-0025', 188, '2CQR-20241113-0025', 1, 493, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-13 15:36:22', '2024-11-13 15:36:22', NULL, NULL),
(76, '331', 205, 'Trans-20241113-0026', 188, '2CQR-20241113-0026', 9, 503, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-13 15:36:22', '2024-11-13 15:36:22', NULL, NULL),
(80, '331', 205, 'Trans-20241113-0030', 188, '2CQR-20241113-0030', 1, 503, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-13 15:53:05', '2024-11-13 15:53:05', NULL, NULL),
(81, '329', 205, 'Trans-20241113-0031', 188, '2CQR-20241113-0031', 1, 493, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-13 15:53:41', '2024-11-13 15:53:41', NULL, NULL),
(82, '339', 205, 'Trans-20241113-0032', 188, '2CQR-20241113-0032', 2, 546, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-13 18:01:16', '2024-11-13 18:01:16', NULL, NULL),
(83, '332', 205, 'Trans-20241113-0033', 188, '2CQR-20241113-0033', 1, 516, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-13 18:01:16', '2024-11-13 18:01:16', NULL, NULL),
(87, '334', 202, 'Trans-20241114-0004', 185, '2CQR-20241114-0004', 4, 534, NULL, NULL, NULL, 0, NULL, 'exchange', '2024-11-14 13:36:54', '2024-11-14 13:36:54', NULL, NULL),
(88, '334', 207, 'Trans-20241114-0005', 196, '2CQR-20241114-0005', 1, 534, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-14 15:39:11', '2024-11-14 15:39:11', NULL, NULL),
(89, '333', 202, 'Trans-20241114-0006', 114, '2CQR-20241114-0006', 2, 540, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-14 15:59:16', '2024-11-14 15:59:16', NULL, NULL),
(90, '334', 207, 'Trans-20241114-0007', 196, '2CQR-20241114-0007', 1, 534, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-14 16:17:41', '2024-11-14 16:17:41', NULL, NULL),
(91, '338', 202, 'Trans-20241114-0008', 185, '2CQR-20241114-0008', 2, 544, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-14 16:50:01', '2024-11-14 16:50:01', NULL, NULL),
(92, '338', 207, 'Trans-20241114-0009', 196, '2CQR-20241114-0009', 10, 544, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-14 16:54:21', '2024-11-14 16:54:21', NULL, NULL),
(93, '338', 202, 'Trans-20241114-0010', 185, '2CQR-20241114-0010', 2, 544, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-14 17:58:42', '2024-11-14 17:58:42', NULL, NULL),
(94, '336', 202, 'Trans-20241114-0011', 185, '2CQR-20241114-0011', 1, 539, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-14 18:02:46', '2024-11-14 18:02:46', NULL, NULL),
(95, '334', 202, 'Trans-20241115-0001', 185, '2CQR-20241115-0001', 1, 535, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-15 11:29:36', '2024-11-15 11:29:36', NULL, NULL),
(96, '334', 202, 'Trans-20241115-0002', 185, '2CQR-20241115-0002', 1, 534, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-15 11:42:25', '2024-11-15 11:42:25', NULL, NULL),
(97, '338', 202, 'Trans-20241115-0003', 185, '2CQR-20241115-0003', 1, 544, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-15 11:44:52', '2024-11-15 11:44:52', NULL, NULL),
(98, '334', 202, 'Trans-20241115-0004', 185, '2CQR-20241115-0004', 7, 534, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-15 12:54:24', '2024-11-15 12:54:24', NULL, NULL),
(99, '336', 202, 'Trans-20241115-0005', 185, '2CQR-20241115-0005', 7, 539, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-15 12:54:25', '2024-11-15 12:54:25', NULL, NULL),
(100, '338', 202, 'Trans-20241115-0006', 185, '2CQR-20241115-0006', 1, 544, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-15 12:54:26', '2024-11-15 12:54:26', NULL, NULL),
(101, '334', 202, 'Trans-20241115-0007', 185, '2CQR-20241115-0007', 1, 534, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-15 12:58:25', '2024-11-15 12:58:25', NULL, NULL),
(102, '334', 202, 'Trans-20241115-0008', 185, '2CQR-20241115-0008', 1, 534, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-15 13:01:30', '2024-11-15 13:01:30', NULL, NULL),
(103, '334', 202, 'Trans-20241115-0009', 185, '2CQR-20241115-0009', 1, 534, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-15 13:03:21', '2024-11-15 13:03:21', NULL, NULL),
(104, '338', 202, 'Trans-20241115-0010', 185, '2CQR-20241115-0010', 1, 544, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-15 13:03:22', '2024-11-15 13:03:22', NULL, NULL),
(105, '334', 202, 'Trans-20241115-0011', 185, '2CQR-20241115-0011', 1, 534, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-15 13:07:13', '2024-11-15 13:07:13', NULL, NULL),
(106, '334', 202, 'Trans-20241115-0012', 185, '2CQR-20241115-0012', 1, 534, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-15 13:07:57', '2024-11-15 13:07:57', NULL, NULL),
(107, '338', 202, 'Trans-20241115-0013', 185, '2CQR-20241115-0013', 1, 544, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-15 13:07:58', '2024-11-15 13:07:58', NULL, NULL),
(108, '334', 202, 'Trans-20241115-0014', 221, '2CQR-20241115-0014', 2, 534, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-15 13:28:49', '2024-11-15 13:28:49', NULL, NULL),
(109, '338', 202, 'Trans-20241115-0015', 221, '2CQR-20241115-0015', 2, 544, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-15 13:28:50', '2024-11-15 13:28:50', NULL, NULL),
(110, '340', 205, 'Trans-20241115-0016', 188, '2CQR-20241115-0016', 3, 548, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-15 16:23:24', '2024-11-15 16:23:24', NULL, NULL),
(111, '329', 205, 'Trans-20241115-0017', 188, '2CQR-20241115-0017', 2, 493, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-15 16:23:24', '2024-11-15 16:23:24', NULL, NULL),
(112, '333', 202, 'Trans-20241115-0018', 114, '2CQR-20241115-0018', 0, 0, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-15 17:29:26', '2024-11-15 17:29:26', NULL, NULL),
(113, '334', 202, 'Trans-20241115-0019', 114, '2CQR-20241115-0019', 1, 534, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-15 17:29:27', '2024-11-15 17:29:27', NULL, NULL),
(114, '334', 202, 'Trans-20241118-0001', 185, '2CQR-20241118-0001', 1, 534, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-18 11:20:29', '2024-11-18 11:20:29', NULL, NULL),
(115, '336', 202, 'Trans-20241118-0002', 185, '2CQR-20241118-0002', 1, 539, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-18 11:20:30', '2024-11-18 11:20:30', NULL, NULL),
(116, '336', 202, 'Trans-20241118-0003', 185, '2CQR-20241118-0003', 1, 539, NULL, NULL, NULL, 0, NULL, 'Ordered', '2024-11-18 11:27:42', '2024-11-18 11:27:42', NULL, NULL),
(117, '336', 202, 'Trans-20241118-0004', 114, '2CQR-20241118-0004', 7, 541, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-18 12:33:14', '2024-11-18 12:33:14', NULL, NULL),
(118, '336', 202, 'Trans-20241118-0005', 114, '2CQR-20241118-0005', 7, 539, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-18 12:43:30', '2024-11-18 12:43:30', NULL, NULL),
(119, '334', 202, 'Trans-20241118-0006', 185, '2CQR-20241118-0006', 3, 534, NULL, NULL, NULL, 0, 2, 'Pending', '2024-11-18 13:48:00', '2024-11-18 13:48:00', NULL, NULL),
(120, '338', 202, 'Trans-20241118-0007', 185, '2CQR-20241118-0007', 1, 544, NULL, NULL, NULL, 0, 4, 'Pending', '2024-11-18 13:48:01', '2024-11-18 13:48:01', NULL, NULL),
(121, '334', 202, 'Trans-20241118-0008', 185, '2CQR-20241118-0008', 1, 538, NULL, NULL, NULL, 0, 2, 'Pending', '2024-11-18 13:53:22', '2024-11-18 13:53:22', NULL, NULL),
(122, '334', 202, 'Trans-20241118-0009', 185, '2CQR-20241118-0009', 1, 544, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-18 20:12:36', '2024-11-18 20:12:36', NULL, NULL),
(123, '329', 227, 'Trans-20241119-0001', 230, '2CQR-20241119-0001', 1, 493, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-19 15:47:55', '2024-11-19 15:47:55', NULL, NULL),
(124, '329', 227, 'Trans-20241119-0002', 230, '2CQR-20241119-0002', 1, 493, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-19 16:06:01', '2024-11-19 16:06:01', NULL, NULL),
(125, '329', 227, 'Trans-20241119-0003', 230, '2CQR-20241119-0003', 1, 493, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-19 16:08:16', '2024-11-19 16:08:16', NULL, NULL),
(126, '329', 227, 'Trans-20241119-0004', 230, '2CQR-20241119-0004', 1, 493, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-19 16:09:49', '2024-11-19 16:09:49', NULL, NULL),
(127, '329', 227, 'Trans-20241119-0005', 230, '2CQR-20241119-0005', 1, 493, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-19 16:11:05', '2024-11-19 16:11:05', NULL, NULL),
(128, '329', 227, 'Trans-20241119-0006', 230, '2CQR-20241119-0006', 1, 493, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-19 16:12:54', '2024-11-19 16:12:54', NULL, NULL),
(129, '329', 227, 'Trans-20241119-0007', 230, '2CQR-20241119-0007', 1, 493, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-19 16:14:57', '2024-11-19 16:14:57', NULL, NULL),
(140, '334', 202, 'Trans-20241118-0009', 185, '2CQR-20241121-0002', 1, 544, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-21 10:11:53', '2024-11-21 10:11:53', NULL, NULL),
(141, '336', 202, 'Trans-20241121-0002', 221, '2CQR-20241121-0002', 0, 0, NULL, NULL, NULL, 0, 0, 'Ordered', '2024-11-21 12:42:48', '2024-11-21 12:42:48', NULL, NULL),
(142, '334', 202, 'Trans-20241121-0003', 221, '2CQR-20241121-0003', 1, 534, NULL, NULL, NULL, 0, 0, 'Ordered', '2024-11-21 12:44:46', '2024-11-21 12:44:46', NULL, NULL),
(143, '334', 202, 'Trans-20241121-0004', 221, '2CQR-20241121-0004', 1, 535, NULL, NULL, NULL, 0, 0, 'Ordered', '2024-11-21 12:55:22', '2024-11-21 12:55:22', NULL, NULL),
(144, '334', 202, 'Trans-20241121-0005', 221, '2CQR-20241121-0005', 1, 534, NULL, NULL, NULL, 0, 0, 'Ordered', '2024-11-21 12:56:15', '2024-11-21 12:56:15', NULL, NULL),
(145, '336', 202, 'Trans-20241121-0006', 221, '2CQR-20241121-0006', 1, 539, NULL, NULL, NULL, 0, 0, 'Ordered', '2024-11-21 12:58:34', '2024-11-21 12:58:34', NULL, NULL),
(146, '336', 202, 'Trans-20241121-0007', 221, '2CQR-20241121-0007', 1, 539, NULL, NULL, NULL, 0, 0, 'Ordered', '2024-11-21 13:06:10', '2024-11-21 13:06:10', NULL, NULL),
(147, '336', 202, 'Trans-20241121-0008', 221, '2CQR-20241121-0008', 1, 539, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-21 13:06:54', '2024-11-21 13:06:54', NULL, NULL),
(148, '334', 202, 'Trans-20241121-0009', 221, '2CQR-20241121-0009', 1, 534, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-21 13:37:53', '2024-11-21 13:37:53', NULL, NULL),
(149, '338', 202, 'Trans-20241121-0010', 221, '2CQR-20241121-0010', 1, 544, NULL, NULL, NULL, 0, 0, 'Ordered', '2024-11-21 13:37:54', '2024-11-21 13:37:54', NULL, NULL),
(150, '334', 202, 'Trans-20241121-0011', 221, '2CQR-20241121-0011', 1, 534, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-21 13:39:23', '2024-11-21 13:39:23', NULL, NULL),
(151, '338', 202, 'Trans-20241121-0012', 221, '2CQR-20241121-0012', 1, 544, NULL, NULL, NULL, 0, 4, 'Ordered', '2024-11-21 13:39:24', '2024-11-21 13:39:24', NULL, NULL),
(152, '336', 202, 'Trans-20241121-0013', 221, '2CQR-20241121-0013', 1, 539, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-21 14:46:21', '2024-11-21 14:46:21', NULL, NULL),
(153, '334', 202, 'Trans-20241121-0014', 221, '2CQR-20241121-0014', 1, 534, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-21 15:21:39', '2024-11-21 15:21:39', NULL, NULL),
(154, '338', 202, 'Trans-20241121-0015', 221, '2CQR-20241121-0015', 1, 544, NULL, NULL, NULL, 0, 4, 'Ordered', '2024-11-21 15:21:40', '2024-11-21 15:21:40', NULL, NULL),
(155, '334', 202, 'Trans-20241121-0016', 221, '2CQR-20241121-0016', 1, 536, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-21 15:23:17', '2024-11-21 15:23:17', NULL, NULL),
(156, '348', 230, 'Trans-20241121-0017', 233, '2CQR-20241121-0017', 1, 585, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-21 16:59:41', '2024-11-21 16:59:41', NULL, NULL),
(157, '349', 230, 'Trans-20241121-0018', 233, '2CQR-20241121-0018', 1, 590, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-21 17:04:19', '2024-11-21 17:04:19', NULL, NULL),
(158, '348', 230, 'Trans-20241121-0019', 233, '2CQR-20241121-0019', 2, 585, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-21 17:40:42', '2024-11-21 17:40:42', NULL, NULL),
(159, '349', 230, 'Trans-20241121-0020', 233, '2CQR-20241121-0020', 1, 590, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-21 17:40:43', '2024-11-21 17:40:43', NULL, NULL),
(160, '348', 230, 'Trans-20241121-0021', 233, '2CQR-20241121-0021', 1, 587, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-21 19:11:19', '2024-11-21 19:11:19', NULL, NULL),
(161, '351', 227, 'Trans-20241122-0001', 230, '2CQR-20241122-0001', 2, 600, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-22 10:38:26', '2024-11-22 10:38:26', NULL, NULL),
(162, '356', 227, 'Trans-20241122-0002', 230, '2CQR-20241122-0002', 4, 628, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-22 10:41:52', '2024-11-22 10:41:52', NULL, NULL),
(163, '359', 227, 'Trans-20241122-0003', 230, '2CQR-20241122-0003', 1, 638, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-22 10:42:33', '2024-11-22 10:42:33', NULL, NULL),
(164, '348', 227, 'Trans-20241122-0004', 230, '2CQR-20241122-0004', 1, 585, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-22 18:01:03', '2024-11-22 18:01:03', NULL, NULL),
(165, '359', 227, 'Trans-20241122-0005', 230, '2CQR-20241122-0005', 1, 637, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-22 18:03:26', '2024-11-22 18:03:26', NULL, NULL),
(166, '348', 228, 'Trans-20241122-0006', 231, '2CQR-20241122-0006', 1, 585, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-22 18:03:29', '2024-11-22 18:03:29', NULL, NULL),
(167, '348', 227, 'Trans-20241123-0001', 230, '2CQR-20241123-0001', 2, 585, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-23 11:18:53', '2024-11-23 11:18:53', NULL, NULL),
(168, '348', 227, 'Trans-20241123-0002', 230, '2CQR-20241123-0002', 1, 585, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-23 11:19:59', '2024-11-23 11:19:59', NULL, NULL),
(169, '360', 227, 'Trans-20241123-0003', 230, '2CQR-20241123-0003', 234, 639, NULL, NULL, NULL, 0, 1, 'Ordered', '2024-11-23 11:39:55', '2024-11-23 11:39:55', NULL, NULL),
(170, '348', 227, 'Trans-20241123-0004', 230, '2CQR-20241123-0004', 1, 585, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-23 14:12:05', '2024-11-23 14:12:05', NULL, NULL),
(171, '348', 227, 'Trans-20241123-0005', 230, '2CQR-20241123-0005', 1, 585, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-23 14:12:05', '2024-11-23 14:12:05', NULL, NULL),
(172, '354', 227, 'Trans-20241123-0006', 230, '2CQR-20241123-0006', 1, 615, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-23 14:34:23', '2024-11-23 14:34:23', NULL, NULL),
(173, '348', 227, 'Trans-20241123-0007', 230, '2CQR-20241123-0007', 1, 585, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-23 14:34:23', '2024-11-23 14:34:23', NULL, NULL),
(174, '351', 227, 'Trans-20241123-0008', 230, '2CQR-20241123-0008', 99, 600, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-23 15:31:49', '2024-11-23 15:31:49', NULL, NULL),
(175, '348', 227, 'Trans-20241123-0009', 230, '2CQR-20241123-0009', 1, 585, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-23 15:31:49', '2024-11-23 15:31:49', NULL, NULL),
(176, '348', 227, 'Trans-20241123-0010', 230, '2CQR-20241123-0010', 1, 585, NULL, NULL, NULL, 0, 2, 'Ordered', '2024-11-23 15:38:42', '2024-11-23 15:38:42', NULL, NULL),
(192, '329', 205, 'Trans-20241125-0001', 188, '2CQR-20241125-0001', 117, 493, '102492.00', 117, 68, 0, 1, 'instock', '2024-11-25 16:35:38', '2024-11-25 16:35:38', NULL, NULL),
(193, '329', 205, 'Trans-20241125-0002', 188, '2CQR-20241125-0002', 365, 493, '319740.00', 365, 68, 0, 1, 'outofstock', '2024-11-25 16:35:39', '2024-11-25 16:35:39', NULL, NULL),
(194, '332', 205, 'Trans-20241125-0003', 188, '2CQR-20241125-0003', 1, 516, '564.00', 1, 68, 0, 1, 'instock', '2024-11-25 16:35:40', '2024-11-25 16:35:40', NULL, NULL),
(198, '329', 205, 'Trans-20241125-0004', 188, '2CQR-20241125-0004', 117, 493, '102492.00', 117, 70, 0, 1, 'instock', '2024-11-25 16:38:27', '2024-11-25 16:38:27', NULL, NULL),
(199, '329', 205, 'Trans-20241125-0005', 188, '2CQR-20241125-0005', 365, 493, '319740.00', 365, 70, 0, 1, 'outofstock', '2024-11-25 16:38:28', '2024-11-25 16:38:28', NULL, NULL),
(200, '332', 205, 'Trans-20241125-0006', 188, '2CQR-20241125-0006', 1, 516, '564.00', 1, 70, 0, 1, 'instock', '2024-11-25 16:38:29', '2024-11-25 16:38:29', NULL, NULL),
(201, '329', 205, 'Trans-20241126-0001', 188, '2CQR-20241126-0001', 1, 493, '876.00', 1, 71, 0, 0, 'Ordered', '2024-11-26 15:26:23', '2024-11-26 15:26:23', NULL, NULL),
(202, '329', 205, 'Trans-20241126-0002', 188, '2CQR-20241126-0002', 1, 493, '876.00', 1, 72, 0, 0, 'instock', '2024-11-26 15:37:47', '2024-11-26 15:37:47', NULL, NULL),
(203, '329', 205, 'Trans-20241126-0003', 188, '2CQR-20241126-0003', 1, 493, '876.00', 1, 73, 0, 0, 'Ordered', '2024-11-26 15:37:55', '2024-11-26 15:37:55', NULL, NULL),
(204, '329', 205, 'Trans-20241126-0004', 188, '2CQR-20241126-0004', 1, 493, '876.00', 1, 74, 0, 0, 'instock', '2024-11-26 18:10:41', '2024-11-26 18:10:41', NULL, NULL),
(205, '329', 205, 'Trans-20241126-0005', 188, '2CQR-20241126-0005', 1, 493, '876.00', 1, 75, 0, 0, 'Ordered', '2024-11-26 18:12:13', '2024-11-26 18:12:13', NULL, NULL),
(206, '329', 205, 'Trans-20241126-0006', 188, '2CQR-20241126-0006', 1, 493, '876.00', 1, 76, 0, 0, 'Ordered', '2024-11-26 18:25:02', '2024-11-26 18:25:02', NULL, NULL),
(207, '331', 205, 'Trans-20241126-0007', 188, '2CQR-20241126-0007', 1, 503, '876.00', 1, 77, 0, 0, 'outofstock_o', '2024-11-26 18:31:18', '2024-11-26 18:31:18', NULL, NULL),
(208, '329', 205, 'Trans-20241126-0008', 188, '2CQR-20241126-0008', 1, 493, '876.00', 1, 78, 0, 0, 'Ordered', '2024-11-26 18:32:23', '2024-11-26 18:32:23', NULL, NULL),
(209, '329', 205, 'Trans-20241126-0009', 188, '2CQR-20241126-0009', 1, 493, '876.00', 1, 79, 0, 0, 'Ordered', '2024-11-26 18:46:26', '2024-11-26 18:46:26', NULL, NULL),
(210, '329', 205, 'Trans-20241126-0010', 188, '2CQR-20241126-0010', 1, 493, '876.00', 1, 80, 0, 0, 'Ordered', '2024-11-26 18:48:04', '2024-11-26 18:48:04', NULL, NULL),
(211, '329', 205, 'Trans-20241126-0011', 188, '2CQR-20241126-0011', 1, 493, '876.00', 1, 81, 0, 0, 'Ordered', '2024-11-26 18:50:44', '2024-11-26 18:50:44', NULL, NULL),
(212, '354', 205, 'Trans-20241126-0012', 188, '2CQR-20241126-0012', 1, 615, '555.00', 1, 82, 0, 0, 'instock', '2024-11-26 18:54:38', '2024-11-26 18:54:38', NULL, NULL),
(213, '354', 205, 'Trans-20241126-0013', 188, '2CQR-20241126-0013', 1, 615, '555.00', 1, 83, 0, 0, 'instock', '2024-11-26 18:55:28', '2024-11-26 18:55:28', NULL, NULL),
(214, '354', 205, 'Trans-20241127-0001', 188, '2CQR-20241127-0001', 1, 615, '555.00', 1, 84, 0, 0, 'instock', '2024-11-27 10:27:47', '2024-11-27 10:27:47', NULL, NULL),
(215, '329', 205, 'Trans-20241127-0002', 188, '2CQR-20241127-0002', 1, 493, '876.00', 1, 84, 0, 0, 'instock', '2024-11-27 10:27:48', '2024-11-27 10:27:48', NULL, NULL),
(216, '354', 205, 'Trans-20241127-0003', 188, '2CQR-20241127-0003', 1, 615, '555.00', 1, 85, 0, 0, 'instock', '2024-11-27 10:29:20', '2024-11-27 10:29:20', NULL, NULL),
(217, '329', 205, 'Trans-20241127-0004', 188, '2CQR-20241127-0004', 1, 493, '876.00', 1, 85, 0, 0, 'instock', '2024-11-27 10:29:21', '2024-11-27 10:29:21', NULL, NULL),
(218, '354', 205, 'Trans-20241127-0005', 188, '2CQR-20241127-0005', 1, 615, '555.00', 1, 86, 0, 0, 'Ordered', '2024-11-27 10:30:37', '2024-11-27 10:30:37', NULL, NULL),
(219, '329', 205, 'Trans-20241127-0006', 188, '2CQR-20241127-0006', 1, 493, '876.00', 1, 86, 0, 0, 'Ordered', '2024-11-27 10:30:38', '2024-11-27 10:30:38', NULL, NULL),
(220, '329', 205, 'Trans-20241127-0007', 188, '2CQR-20241127-0007', 11, 493, '9636.00', 11, 87, 0, 0, 'instock', '2024-11-27 10:47:10', '2024-11-27 10:47:10', NULL, NULL),
(221, '329', 205, 'Trans-20241127-0008', 188, '2CQR-20241127-0008', 11, 493, '9636.00', 11, 88, 0, 0, 'instock', '2024-11-27 10:48:33', '2024-11-27 10:48:33', NULL, NULL),
(222, '329', 205, 'Trans-20241127-0009', 188, '2CQR-20241127-0009', 11, 493, '9636.00', 11, 89, 0, 0, 'Ordered', '2024-11-27 10:48:43', '2024-11-27 10:48:43', NULL, NULL),
(225, '329', 205, 'Trans-20241127-0010', 188, '2CQR-20241127-0010', 1, 493, '876.00', 1, 92, 0, 2, 'instock', '2024-11-27 13:01:38', '2024-11-27 13:01:38', NULL, NULL),
(226, '329', 205, 'Trans-20241127-0011', 188, '2CQR-20241127-0011', 1, 493, '876.00', 1, 93, 0, 2, 'instock', '2024-11-27 13:03:52', '2024-11-27 13:03:52', NULL, NULL),
(227, '329', 205, 'Trans-20241127-0012', 188, '2CQR-20241127-0012', 1, 493, '876.00', 1, 94, 0, 2, 'instock', '2024-11-27 13:05:55', '2024-11-27 13:05:55', NULL, NULL),
(228, '329', 205, 'Trans-20241127-0013', 188, '2CQR-20241127-0013', 1, 493, '876.00', 1, 95, 0, 2, 'instock', '2024-11-27 13:06:38', '2024-11-27 13:06:38', NULL, NULL),
(229, '329', 205, 'Trans-20241127-0014', 188, '2CQR-20241127-0014', 2, 493, '1752.00', 2, 96, 0, 2, 'instock', '2024-11-27 13:16:41', '2024-11-27 13:16:41', NULL, NULL),
(230, '329', 205, 'Trans-20241127-0015', 188, '2CQR-20241127-0015', 2, 493, '1752.00', 2, 97, 0, 2, 'instock', '2024-11-27 13:20:06', '2024-11-27 13:20:06', NULL, NULL),
(231, '329', 205, 'Trans-20241127-0016', 188, '2CQR-20241127-0016', 2, 493, '1752.00', 2, 98, 0, 2, 'instock', '2024-11-27 13:24:09', '2024-11-27 13:24:09', NULL, NULL),
(232, '329', 205, 'Trans-20241127-0017', 188, '2CQR-20241127-0017', 2, 493, '1752.00', 2, 99, 0, 2, 'Ordered', '2024-11-27 13:25:44', '2024-11-27 13:25:44', NULL, NULL),
(233, '329', 205, 'Trans-20241127-0018', 188, '2CQR-20241127-0018', 20, 493, '17520.00', 20, 100, 0, 2, 'instock', '2024-11-27 13:35:32', '2024-11-27 13:35:32', NULL, NULL),
(234, '329', 205, 'Trans-20241127-0019', 188, '2CQR-20241127-0019', 20, 493, '17520.00', 20, 101, 0, 2, 'Ordered', '2024-11-27 13:43:29', '2024-11-27 13:43:29', NULL, NULL),
(235, '356', 227, 'Trans-20241127-0020', 230, '2CQR-20241127-0020', 1, 625, '899.00', 5, 102, 0, 2, 'instock', '2024-11-27 13:58:12', '2024-11-27 13:58:12', NULL, NULL),
(236, '351', 227, 'Trans-20241127-0021', 230, '2CQR-20241127-0021', 2, 600, '980.00', 2, 102, 0, 2, 'outofstock', '2024-11-27 13:58:12', '2024-11-27 13:58:12', NULL, NULL),
(237, '356', 227, 'Trans-20241127-0022', 230, '2CQR-20241127-0022', 1, 625, '899.00', 5, 103, 0, 2, 'instock', '2024-11-27 13:58:36', '2024-11-27 13:58:36', NULL, NULL),
(238, '351', 227, 'Trans-20241127-0023', 230, '2CQR-20241127-0023', 2, 600, '980.00', 2, 103, 0, 2, 'outofstock', '2024-11-27 13:58:36', '2024-11-27 13:58:36', NULL, NULL),
(239, '356', 227, 'Trans-20241127-0024', 230, '2CQR-20241127-0024', 1, 625, '899.00', 5, 104, 0, 2, 'instock', '2024-11-27 14:00:05', '2024-11-27 14:00:05', NULL, NULL),
(240, '351', 227, 'Trans-20241127-0025', 230, '2CQR-20241127-0025', 2, 600, '980.00', 2, 104, 0, 2, 'outofstock', '2024-11-27 14:00:05', '2024-11-27 14:00:05', NULL, NULL),
(241, '348', 227, 'Trans-20241127-0026', 230, '2CQR-20241127-0026', 1, 585, '405.00', 1, 105, 0, 2, 'instock', '2024-11-27 15:31:32', '2024-11-27 15:31:32', NULL, NULL),
(242, '348', 227, 'Trans-20241127-0027', 230, '2CQR-20241127-0027', 1, 585, '405.00', 1, 106, 0, 2, 'instock', '2024-11-27 15:32:27', '2024-11-27 15:32:27', NULL, NULL),
(243, '348', 227, 'Trans-20241127-0028', 230, '2CQR-20241127-0028', 1, 585, '405.00', 1, 107, 0, 2, 'instock', '2024-11-27 15:38:34', '2024-11-27 15:38:34', NULL, NULL),
(244, '348', 227, 'Trans-20241127-0029', 230, '2CQR-20241127-0029', 1, 585, '405.00', 1, 108, 0, 2, 'instock', '2024-11-27 15:43:10', '2024-11-27 15:43:10', NULL, NULL),
(245, '348', 227, 'Trans-20241127-0030', 230, '2CQR-20241127-0030', 1, 585, '405.00', 1, 109, 0, 2, 'instock', '2024-11-27 15:48:40', '2024-11-27 15:48:40', NULL, NULL),
(246, '348', 227, 'Trans-20241127-0031', 230, '2CQR-20241127-0031', 1, 585, '405.00', 1, 110, 0, 2, 'instock', '2024-11-27 15:54:04', '2024-11-27 15:54:04', NULL, NULL),
(247, '348', 227, 'Trans-20241127-0032', 230, '2CQR-20241127-0032', 1, 585, '405.00', 1, 111, 0, 2, 'instock', '2024-11-27 15:55:57', '2024-11-27 15:55:57', NULL, NULL),
(248, '348', 227, 'Trans-20241127-0033', 230, '2CQR-20241127-0033', 4, 585, '1620.00', 4, 112, 0, 2, 'instock', '2024-11-27 15:58:05', '2024-11-27 15:58:05', NULL, NULL),
(249, '329', 205, 'Trans-20241127-0034', 188, '2CQR-20241127-0034', 7, 493, '6132.00', 7, 113, 0, 2, 'Ordered', '2024-11-27 16:01:38', '2024-11-27 16:01:38', NULL, NULL),
(250, '329', 205, 'Trans-20241127-0035', 188, '2CQR-20241127-0035', 3, 493, '2628.00', 3, 114, 0, 2, 'Ordered', '2024-11-27 16:02:53', '2024-11-27 16:02:53', NULL, NULL),
(251, '332', 205, 'Trans-20241127-0036', 188, '2CQR-20241127-0036', 2, 516, '1128.00', 2, 114, 0, 2, 'Ordered', '2024-11-27 16:02:54', '2024-11-27 16:02:54', NULL, NULL),
(252, '346', 205, 'Trans-20241127-0037', 188, '2CQR-20241127-0037', 4, 579, '1812.00', 180, 114, 0, 2, 'Ordered', '2024-11-27 16:02:55', '2024-11-27 16:02:55', NULL, NULL),
(253, '354', 227, 'Trans-20241127-0038', 230, '2CQR-20241127-0038', 8, 615, '4440.00', 8, 115, 0, 2, 'Ordered', '2024-11-27 16:06:32', '2024-11-27 16:06:32', NULL, NULL),
(254, '332', 205, 'Trans-20241127-0039', 188, '2CQR-20241127-0039', 2, 516, '1128.00', 2, 116, 0, 2, 'Ordered', '2024-11-27 16:10:00', '2024-11-27 16:10:00', NULL, NULL),
(255, '354', 227, 'Trans-20241127-0040', 230, '2CQR-20241127-0040', 1, 615, '555.00', 1, 117, 0, 2, 'instock', '2024-11-27 16:10:48', '2024-11-27 16:10:48', NULL, NULL),
(256, '354', 227, 'Trans-20241127-0041', 230, '2CQR-20241127-0041', 1, 615, '555.00', 1, 118, 0, 2, 'instock', '2024-11-27 16:10:56', '2024-11-27 16:10:56', NULL, NULL),
(257, '329', 205, 'Trans-20241127-0042', 188, '2CQR-20241127-0042', 6, 493, '5256.00', 6, 119, 0, 2, 'Ordered', '2024-11-27 16:11:56', '2024-11-27 16:11:56', NULL, NULL),
(258, '329', 205, 'Trans-20241127-0043', 188, '2CQR-20241127-0043', 5, 493, '4380.00', 5, 120, 0, 2, 'Ordered', '2024-11-27 16:16:55', '2024-11-27 16:16:55', NULL, NULL),
(259, '348', 228, 'Trans-20241127-0044', 231, '2CQR-20241127-0044', 1, 585, '405.00', 1, 121, 0, 2, 'instock', '2024-11-27 17:33:23', '2024-11-27 17:33:23', NULL, NULL),
(260, '348', 228, 'Trans-20241127-0045', 231, '2CQR-20241127-0045', 1, 585, '405.00', 1, 122, 0, 2, 'instock', '2024-11-27 17:34:20', '2024-11-27 17:34:20', NULL, NULL),
(261, '348', 228, 'Trans-20241127-0046', 231, '2CQR-20241127-0046', 1, 585, '405.00', 1, 123, 0, 2, 'instock', '2024-11-27 17:35:37', '2024-11-27 17:35:37', NULL, NULL),
(262, '348', 227, 'Trans-20241127-0047', 230, '2CQR-20241127-0047', 2, 585, '810.00', 2, 124, 0, 2, 'Ordered', '2024-11-27 17:38:11', '2024-11-27 17:38:11', NULL, NULL),
(263, '348', 227, 'Trans-20241127-0048', 230, '2CQR-20241127-0048', 1, 585, '405.00', 1, 125, 0, 2, 'instock', '2024-11-27 17:39:35', '2024-11-27 17:39:35', NULL, NULL),
(264, '348', 227, 'Trans-20241127-0049', 230, '2CQR-20241127-0049', 1, 585, '405.00', 1, 126, 0, 2, 'instock', '2024-11-27 17:40:04', '2024-11-27 17:40:04', NULL, NULL),
(265, '348', 227, 'Trans-20241127-0050', 230, '2CQR-20241127-0050', 2, 585, '810.00', 2, 127, 0, 2, 'Ordered', '2024-11-27 17:41:37', '2024-11-27 17:41:37', NULL, NULL),
(266, '354', 227, 'Trans-20241127-0051', 230, '2CQR-20241127-0051', 2, 615, '1110.00', 2, 128, 0, 2, 'instock', '2024-11-27 17:54:31', '2024-11-27 17:54:31', NULL, NULL),
(267, '354', 227, 'Trans-20241127-0052', 230, '2CQR-20241127-0052', 2, 615, '1110.00', 2, 129, 0, 2, 'Ordered', '2024-11-27 17:54:54', '2024-11-27 17:54:54', NULL, NULL),
(268, '348', 227, 'Trans-20241127-0053', 230, '2CQR-20241127-0053', 1, 585, '405.00', 1, 130, 0, 2, 'Ordered', '2024-11-27 17:56:33', '2024-11-27 17:56:33', NULL, NULL),
(271, '354', 227, 'Trans-20241127-0054', 188, '2CQR-20241127-0054', 1, 615, '555.00', 1, 133, 0, 2, 'instock', '2024-11-28 18:20:08', '2024-11-27 18:20:08', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `transaction_billing`
--

CREATE TABLE `transaction_billing` (
  `id` int NOT NULL,
  `ccavenue_transid` int DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `tpricegst` varchar(255) DEFAULT NULL,
  `tweight` int DEFAULT NULL,
  `shipping_charges` decimal(10,2) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `actual_price` decimal(10,2) DEFAULT NULL,
  `transaction_price` decimal(10,2) DEFAULT NULL,
  `payment_type` varchar(255) DEFAULT NULL,
  `parent_bill_id` bigint DEFAULT NULL,
  `createdon` datetime DEFAULT NULL,
  `lastmodifiedate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `transaction_billing`
--

INSERT INTO `transaction_billing` (`id`, `ccavenue_transid`, `status`, `tpricegst`, `tweight`, `shipping_charges`, `type`, `actual_price`, `transaction_price`, `payment_type`, `parent_bill_id`, `createdon`, `lastmodifiedate`) VALUES
(1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-18 12:33:05', '2024-11-18 12:33:05'),
(2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-18 12:42:33', '2024-11-18 12:42:33'),
(3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-18 13:37:01', '2024-11-18 13:37:01'),
(4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-18 13:37:01', '2024-11-18 13:37:01'),
(5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-18 13:37:01', '2024-11-18 13:37:01'),
(6, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-18 13:37:01', '2024-11-18 13:37:01'),
(7, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-19 13:50:41', '2024-11-19 13:50:41'),
(8, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-19 16:05:57', '2024-11-19 16:05:57'),
(9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-19 16:05:57', '2024-11-19 16:05:57'),
(10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-19 16:05:57', '2024-11-19 16:05:57'),
(11, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-19 16:10:33', '2024-11-19 16:10:33'),
(12, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-19 16:10:33', '2024-11-19 16:10:33'),
(13, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-19 16:10:33', '2024-11-19 16:10:33'),
(14, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-20 17:43:03', '2024-11-20 17:43:03'),
(15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-20 17:43:03', '2024-11-20 17:43:03'),
(16, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-20 17:43:03', '2024-11-20 17:43:03'),
(17, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-20 17:43:03', '2024-11-20 17:43:03'),
(18, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-20 17:43:03', '2024-11-20 17:43:03'),
(19, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-20 17:43:03', '2024-11-20 17:43:03'),
(20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-20 17:43:03', '2024-11-20 17:43:03'),
(21, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-20 17:43:03', '2024-11-20 17:43:03'),
(22, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-20 17:43:03', '2024-11-20 17:43:03'),
(23, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-20 17:43:03', '2024-11-20 17:43:03'),
(24, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-21 10:03:26', '2024-11-21 10:03:26'),
(25, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-21 12:17:41', '2024-11-21 12:17:41'),
(26, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-21 12:17:41', '2024-11-21 12:17:41'),
(27, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-21 12:17:41', '2024-11-21 12:17:41'),
(28, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-21 12:17:41', '2024-11-21 12:17:41'),
(29, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-21 12:17:41', '2024-11-21 12:17:41'),
(30, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-21 12:17:41', '2024-11-21 12:17:41'),
(31, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-21 12:17:41', '2024-11-21 12:17:41'),
(32, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-21 12:17:41', '2024-11-21 12:17:41'),
(33, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-21 12:17:41', '2024-11-21 12:17:41'),
(34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-21 12:17:41', '2024-11-21 12:17:41'),
(35, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-21 12:17:41', '2024-11-21 12:17:41'),
(36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-21 12:17:41', '2024-11-21 12:17:41'),
(37, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-21 12:17:41', '2024-11-21 12:17:41'),
(38, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-21 12:17:41', '2024-11-21 12:17:41'),
(39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-21 12:17:41', '2024-11-21 12:17:41'),
(40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-21 16:43:19', '2024-11-21 16:43:19'),
(41, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-21 16:43:19', '2024-11-21 16:43:19'),
(42, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-21 16:43:19', '2024-11-21 16:43:19'),
(43, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-21 16:43:19', '2024-11-21 16:43:19'),
(44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-21 16:43:19', '2024-11-21 16:43:19'),
(45, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-22 10:09:14', '2024-11-22 10:09:14'),
(46, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-22 10:09:14', '2024-11-22 10:09:14'),
(47, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-22 10:09:14', '2024-11-22 10:09:14'),
(48, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-22 10:09:14', '2024-11-22 10:09:14'),
(49, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-22 10:09:14', '2024-11-22 10:09:14'),
(50, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-22 10:09:14', '2024-11-22 10:09:14'),
(51, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-22 10:09:14', '2024-11-22 10:09:14'),
(52, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-22 10:09:14', '2024-11-22 10:09:14'),
(53, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-22 10:09:14', '2024-11-22 10:09:14'),
(54, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-22 10:09:14', '2024-11-22 10:09:14'),
(55, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-22 10:09:14', '2024-11-22 10:09:14'),
(56, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-22 10:09:14', '2024-11-22 10:09:14'),
(57, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-22 10:09:14', '2024-11-22 10:09:14'),
(58, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-22 10:09:14', '2024-11-22 10:09:14'),
(59, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-22 10:09:14', '2024-11-22 10:09:14'),
(60, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2024-11-22 10:09:14', '2024-11-22 10:09:14'),
(68, NULL, 'Initiated', '422796', 483, '20.00', NULL, '42279620.00', '42279620.00', 'ccavenue', NULL, '2024-11-25 16:35:36', '2024-11-25 16:35:36'),
(70, NULL, 'Initiated', '422796', 483, '20.00', NULL, '42279620.00', '42279620.00', 'ccavenue', NULL, '2024-11-25 16:37:20', '2024-11-25 16:37:20'),
(71, NULL, 'success', '876', 1, '0.00', NULL, '876.00', '876.00', 'ccavenue', NULL, '2024-11-26 15:24:41', '2024-11-26 15:24:41'),
(72, NULL, 'Initiated', '876', 1, '0.00', NULL, '876.00', '876.00', 'ccavenue', NULL, '2024-11-26 15:32:00', '2024-11-26 15:32:00'),
(73, NULL, 'success', '876', 1, '0.00', NULL, '876.00', '876.00', 'ccavenue', NULL, '2024-11-26 15:32:00', '2024-11-26 15:32:00'),
(74, NULL, 'Initiated', '876', 1, '0.00', NULL, '876.00', '876.00', 'ccavenue', NULL, '2024-11-26 17:59:46', '2024-11-26 17:59:46'),
(75, NULL, 'success', '876', 1, '0.00', NULL, '876.00', '876.00', 'ccavenue', NULL, '2024-11-26 17:59:46', '2024-11-26 17:59:46'),
(76, NULL, 'success', '876', 1, '0.00', NULL, '876.00', '876.00', 'ccavenue', NULL, '2024-11-26 17:59:46', '2024-11-26 17:59:46'),
(77, NULL, 'success', '876', 1, '0.00', NULL, '876.00', '876.00', 'ccavenue', NULL, '2024-11-26 17:59:46', '2024-11-26 17:59:46'),
(78, NULL, 'success', '876', 1, '0.00', NULL, '876.00', '876.00', 'ccavenue', NULL, '2024-11-26 17:59:46', '2024-11-26 17:59:46'),
(79, NULL, 'success', '876', 1, '0.00', NULL, '876.00', '876.00', 'ccavenue', NULL, '2024-11-26 17:59:46', '2024-11-26 17:59:46'),
(80, NULL, 'success', '876', 1, '0.00', NULL, '876.00', '876.00', 'ccavenue', NULL, '2024-11-26 17:59:46', '2024-11-26 17:59:46'),
(81, NULL, 'success', '876', 1, '0.00', NULL, '876.00', '876.00', 'ccavenue', NULL, '2024-11-26 17:59:46', '2024-11-26 17:59:46'),
(82, NULL, 'Initiated', '555', 1, '0.00', NULL, '555.00', '555.00', 'ccavenue', NULL, '2024-11-26 17:59:46', '2024-11-26 17:59:46'),
(83, NULL, 'Initiated', '555', 1, '0.00', NULL, '555.00', '555.00', 'ccavenue', NULL, '2024-11-26 17:59:46', '2024-11-26 17:59:46'),
(84, NULL, 'Initiated', '1431', 2, '0.00', NULL, '1431.00', '1431.00', 'ccavenue', NULL, '2024-11-27 10:25:23', '2024-11-27 10:25:23'),
(85, NULL, 'Initiated', '1431', 2, '0.00', NULL, '1431.00', '1431.00', 'ccavenue', NULL, '2024-11-27 10:25:23', '2024-11-27 10:25:23'),
(86, NULL, 'success', '1431', 2, '0.00', NULL, '1431.00', '1431.00', 'ccavenue', NULL, '2024-11-27 10:25:23', '2024-11-27 10:25:23'),
(87, NULL, 'Initiated', '9636', 11, '5.00', NULL, '96365.00', '96365.00', 'ccavenue', NULL, '2024-11-27 10:25:23', '2024-11-27 10:25:23'),
(88, NULL, 'Initiated', '9636', 11, '5.00', NULL, '96365.00', '96365.00', 'ccavenue', NULL, '2024-11-27 10:25:23', '2024-11-27 10:25:23'),
(89, NULL, 'success', '9636', 11, '5.00', NULL, '96365.00', '96365.00', 'ccavenue', NULL, '2024-11-27 10:25:23', '2024-11-27 10:25:23'),
(92, NULL, 'Initiated', '25', 1, '0.00', NULL, '876.00', '901.00', 'ccavenue', NULL, '2024-11-27 12:04:32', '2024-11-27 12:04:32'),
(93, NULL, 'Initiated', '25', 1, '0.00', NULL, '876.00', '901.00', 'ccavenue', NULL, '2024-11-27 12:04:32', '2024-11-27 12:04:32'),
(94, NULL, 'Initiated', '25', 1, '0.00', NULL, '876.00', '901.00', 'ccavenue', NULL, '2024-11-27 13:05:39', '2024-11-27 13:05:39'),
(95, NULL, 'Initiated', '25', 1, '0.00', NULL, '876.00', '901.00', 'ccavenue', NULL, '2024-11-27 13:05:39', '2024-11-27 13:05:39'),
(96, NULL, 'Initiated', '63072', 2, '10.00', NULL, '1752.00', '64834.00', 'ccavenue', NULL, '2024-11-27 13:16:18', '2024-11-27 13:16:18'),
(97, NULL, 'Initiated', '146', 2, '10.00', NULL, '1752.00', '1908.00', 'ccavenue', NULL, '2024-11-27 13:19:55', '2024-11-27 13:19:55'),
(98, NULL, 'Initiated', '211', 2, '10.00', NULL, '1752.00', '1973.00', 'ccavenue', NULL, '2024-11-27 13:23:52', '2024-11-27 13:23:52'),
(99, NULL, 'success', '211', 2, '10.00', NULL, '1752.00', '1973.00', 'ccavenue', NULL, '2024-11-27 13:23:52', '2024-11-27 13:23:52'),
(100, NULL, 'Initiated', '2103', 20, '0.00', NULL, '17520.00', '19623.00', 'ccavenue', NULL, '2024-11-27 13:32:12', '2024-11-27 13:32:12'),
(101, NULL, 'success', '2103', 20, '50.00', NULL, '17520.00', '19673.00', 'ccavenue', NULL, '2024-11-27 13:32:12', '2024-11-27 13:32:12'),
(102, NULL, 'Initiated', '451', 7, '50.00', NULL, '1879.00', '2380.00', 'ccavenue', NULL, '2024-11-27 13:57:48', '2024-11-27 13:57:48'),
(103, NULL, 'Initiated', '451', 7, '50.00', NULL, '1879.00', '2380.00', 'ccavenue', NULL, '2024-11-27 13:57:48', '2024-11-27 13:57:48'),
(104, NULL, 'Initiated', '451', 7, '50.00', NULL, '1879.00', '2380.00', 'ccavenue', NULL, '2024-11-27 13:57:48', '2024-11-27 13:57:48'),
(105, NULL, 'Initiated', '49', 1, '0.00', NULL, '405.00', '454.00', 'ccavenue', NULL, '2024-11-27 15:30:18', '2024-11-27 15:30:18'),
(106, NULL, 'Initiated', '49', 1, '0.00', NULL, '405.00', '454.00', 'ccavenue', NULL, '2024-11-27 15:30:18', '2024-11-27 15:30:18'),
(107, NULL, 'Initiated', '49', 1, '0.00', NULL, '405.00', '454.00', 'ccavenue', NULL, '2024-11-27 15:38:22', '2024-11-27 15:38:22'),
(108, NULL, 'Initiated', '49', 1, '0.00', NULL, '405.00', '454.00', 'ccavenue', NULL, '2024-11-27 15:38:22', '2024-11-27 15:38:22'),
(109, NULL, 'Initiated', '49', 1, '0.00', NULL, '405.00', '454.00', 'ccavenue', NULL, '2024-11-27 15:48:20', '2024-11-27 15:48:20'),
(110, NULL, 'Initiated', '49', 1, '0.00', NULL, '405.00', '454.00', 'ccavenue', NULL, '2024-11-27 15:48:20', '2024-11-27 15:48:20'),
(111, NULL, 'Initiated', '49', 1, '0.00', NULL, '405.00', '454.00', 'ccavenue', NULL, '2024-11-27 15:55:26', '2024-11-27 15:55:26'),
(112, NULL, 'Initiated', '195', 4, '50.00', NULL, '1620.00', '1865.00', 'ccavenue', NULL, '2024-11-27 15:58:01', '2024-11-27 15:58:01'),
(113, NULL, 'success', '736', 7, '50.00', NULL, '6132.00', '6918.00', 'ccavenue', NULL, '2024-11-27 16:01:12', '2024-11-27 16:01:12'),
(114, NULL, 'success', '669', 185, '50.00', NULL, '5568.00', '6287.00', 'ccavenue', NULL, '2024-11-27 16:01:12', '2024-11-27 16:01:12'),
(115, NULL, 'success', '533', 8, '50.00', NULL, '4440.00', '5023.00', 'ccavenue', NULL, '2024-11-27 16:05:38', '2024-11-27 16:05:38'),
(116, NULL, 'success', '136', 2, '50.00', NULL, '1128.00', '1314.00', 'ccavenue', NULL, '2024-11-27 16:04:35', '2024-11-27 16:04:35'),
(117, NULL, 'Initiated', '67', 1, '0.00', NULL, '555.00', '622.00', 'ccavenue', NULL, '2024-11-27 16:05:38', '2024-11-27 16:05:38'),
(118, NULL, 'Initiated', '67', 1, '0.00', NULL, '555.00', '622.00', 'ccavenue', NULL, '2024-11-27 16:05:38', '2024-11-27 16:05:38'),
(119, NULL, 'success', '631', 6, '50.00', NULL, '5256.00', '5937.00', 'ccavenue', NULL, '2024-11-27 16:05:38', '2024-11-27 16:05:38'),
(120, NULL, 'success', '526', 5, '50.00', NULL, '4380.00', '4956.00', 'ccavenue', NULL, '2024-11-27 16:16:38', '2024-11-27 16:16:38'),
(121, NULL, 'Initiated', '49', 1, '0.00', NULL, '405.00', '454.00', 'ccavenue', NULL, '2024-11-27 16:16:38', '2024-11-27 16:16:38'),
(122, NULL, 'Initiated', '49', 1, '0.00', NULL, '405.00', '454.00', 'ccavenue', NULL, '2024-11-27 16:16:38', '2024-11-27 16:16:38'),
(123, NULL, 'Initiated', '49', 1, '0.00', NULL, '405.00', '454.00', 'ccavenue', NULL, '2024-11-27 16:16:38', '2024-11-27 16:16:38'),
(124, NULL, 'success', '98', 2, '50.00', NULL, '810.00', '958.00', 'ccavenue', NULL, '2024-11-27 16:16:38', '2024-11-27 16:16:38'),
(125, NULL, 'Initiated', '49', 1, '0.00', NULL, '405.00', '454.00', 'ccavenue', NULL, '2024-11-27 16:16:38', '2024-11-27 16:16:38'),
(126, NULL, 'Initiated', '49', 1, '0.00', NULL, '405.00', '454.00', 'ccavenue', NULL, '2024-11-27 16:16:38', '2024-11-27 16:16:38'),
(127, NULL, 'success', '98', 2, '50.00', NULL, '810.00', '958.00', 'ccavenue', NULL, '2024-11-27 16:16:38', '2024-11-27 16:16:38'),
(128, NULL, 'Initiated', '134', 2, '50.00', NULL, '1110.00', '1294.00', 'ccavenue', NULL, '2024-11-27 16:16:38', '2024-11-27 16:16:38'),
(129, NULL, 'success', '134', 2, '50.00', NULL, '1110.00', '1294.00', 'ccavenue', NULL, '2024-11-27 16:16:38', '2024-11-27 16:16:38'),
(130, NULL, 'success', '49', 1, '0.00', NULL, '405.00', '454.00', 'ccavenue', NULL, '2024-11-27 16:16:38', '2024-11-27 16:16:38'),
(133, NULL, 'Initiated', '67', 1, '50.00', NULL, '555.00', '672.00', 'ccavenue', NULL, '2024-11-27 18:20:08', '2024-11-27 18:20:08');

-- --------------------------------------------------------

--
-- Table structure for table `transaction_error_logs`
--

CREATE TABLE `transaction_error_logs` (
  `id` bigint NOT NULL,
  `transactionid` bigint DEFAULT NULL,
  `trans_number` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `error_code` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `error_message` text COLLATE utf8mb4_general_ci,
  `userid` int DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `id` int NOT NULL,
  `userid` bigint DEFAULT NULL,
  `lastlogin` datetime DEFAULT NULL,
  `logout` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`id`, `userid`, `lastlogin`, `logout`) VALUES
(1, 98, '2024-03-27 14:49:09', NULL),
(2, 98, '2024-03-27 14:49:09', NULL),
(3, 85, '2024-03-27 10:10:25', NULL),
(4, 85, '2024-03-27 10:10:25', NULL),
(5, 85, '2024-03-26 21:02:29', NULL),
(6, 85, '2024-03-26 21:02:29', NULL),
(7, 85, '2024-03-27 11:06:04', NULL),
(8, 100, '2024-03-27 11:06:04', NULL),
(9, 85, '2024-03-27 11:06:04', NULL),
(10, 85, '2024-03-27 11:06:04', NULL),
(11, 85, '2024-03-27 11:06:04', NULL),
(12, 85, '2024-03-27 11:06:04', NULL),
(13, 85, '2024-03-27 11:06:04', NULL),
(14, 85, '2024-03-27 11:06:04', NULL),
(15, 85, '2024-03-27 11:06:04', NULL),
(16, 85, '2024-03-27 11:06:04', NULL),
(17, 85, '2024-03-27 11:06:04', NULL),
(18, 85, '2024-03-27 11:06:04', NULL),
(19, 85, '2024-03-27 11:06:04', NULL),
(20, 85, '2024-03-27 11:06:04', NULL),
(21, 85, '2024-03-27 11:06:04', NULL),
(22, 85, '2024-03-27 11:06:04', NULL),
(23, 85, '2024-03-27 11:06:04', NULL),
(24, 85, '2024-03-27 11:06:04', NULL),
(25, 85, '2024-03-27 11:06:04', NULL),
(26, 85, '2024-03-27 11:06:04', NULL),
(27, 85, '2024-03-27 11:06:04', NULL),
(28, 85, '2024-03-27 11:06:04', NULL),
(29, 85, '2024-03-27 11:06:04', NULL),
(30, 85, '2024-03-27 11:06:04', NULL),
(31, 85, '2024-03-27 11:06:04', NULL),
(32, 101, '2024-03-27 11:06:04', NULL),
(33, 101, '2024-03-27 11:06:04', NULL),
(34, 101, '2024-03-27 11:06:04', NULL),
(35, 85, '2024-03-27 11:06:04', NULL),
(36, 85, '2024-03-27 11:06:04', NULL),
(37, 85, '2024-03-27 11:06:04', NULL),
(38, 85, '2024-03-27 11:06:04', NULL),
(39, 85, '2024-03-27 11:06:04', NULL),
(40, 85, '2024-03-27 11:06:04', NULL),
(41, 85, '2024-03-27 11:06:04', NULL),
(42, 85, '2024-03-27 11:06:04', NULL),
(43, 85, '2024-03-27 11:06:04', NULL),
(44, 85, '2024-03-27 11:06:04', NULL),
(45, 85, '2024-03-27 11:06:04', NULL),
(46, 101, '2024-03-27 11:06:04', NULL),
(47, 102, '2024-03-27 11:06:04', NULL),
(48, 85, '2024-03-26 21:02:29', NULL),
(49, 85, '2024-03-26 21:02:29', NULL),
(50, 85, '2024-03-26 21:02:29', NULL),
(51, 85, '2024-03-26 21:02:29', NULL),
(52, 85, '2024-03-26 21:02:29', NULL),
(53, 85, '2024-03-26 21:02:29', NULL),
(54, 85, '2024-03-26 21:02:29', NULL),
(55, 104, '2024-03-27 11:06:04', NULL),
(56, 85, '2024-03-26 21:02:29', NULL),
(57, 85, '2024-03-26 21:02:29', NULL),
(58, 85, '2024-03-26 21:02:29', NULL),
(59, 85, '2024-03-26 21:02:29', NULL),
(60, 104, '2024-03-27 11:06:04', NULL),
(61, 85, '2024-03-27 11:06:04', NULL),
(62, 85, '2024-03-27 10:10:25', NULL),
(63, 85, '2024-03-27 11:06:04', NULL),
(64, 85, '2024-03-27 11:06:04', NULL),
(65, 104, '2024-03-27 11:06:04', NULL),
(66, 85, '2024-03-27 11:06:04', NULL),
(67, 85, '2024-03-27 11:06:04', NULL),
(68, 85, '2024-03-27 11:06:04', NULL),
(69, 85, '2024-03-27 11:06:04', NULL),
(70, 105, '2024-03-27 11:06:04', NULL),
(71, 105, '2024-03-27 11:06:04', NULL),
(72, 105, '2024-03-27 11:06:04', NULL),
(73, 105, '2024-03-27 11:06:04', NULL),
(74, 105, '2024-03-27 10:10:25', NULL),
(75, 105, '2024-03-27 11:06:04', NULL),
(76, 105, '2024-03-27 11:06:04', NULL),
(77, 105, '2024-03-27 11:06:04', NULL),
(78, 105, '2024-03-27 11:06:04', NULL),
(79, 105, '2024-03-27 22:22:49', NULL),
(80, 105, '2024-03-27 22:28:06', NULL),
(81, 105, '2024-03-27 22:28:30', NULL),
(82, 105, '2024-03-28 09:57:25', NULL),
(83, 105, '2024-03-28 09:57:25', NULL),
(84, 105, '2024-03-28 09:57:25', NULL),
(85, 105, '2024-03-28 09:57:25', NULL),
(86, 105, '2024-03-28 10:08:41', NULL),
(87, 105, '2024-03-28 10:08:41', NULL),
(88, 105, '2024-03-28 10:32:13', NULL),
(89, 105, '2024-03-28 10:44:37', NULL),
(90, 105, '2024-03-28 11:24:17', NULL),
(91, 105, '2024-03-28 11:24:17', NULL),
(92, 105, '2024-03-28 11:25:44', NULL),
(93, 105, '2024-03-28 11:27:58', NULL),
(94, 105, '2024-03-28 11:27:58', NULL),
(95, 105, '2024-03-28 11:38:01', NULL),
(96, 105, '2024-03-28 11:38:01', NULL),
(97, 105, '2024-03-28 11:38:01', NULL),
(98, 105, '2024-03-28 11:38:01', NULL),
(99, 105, '2024-03-28 11:27:58', NULL),
(100, 105, '2024-03-28 11:38:01', NULL),
(101, 105, '2024-03-28 11:38:01', NULL),
(102, 105, '2024-03-28 11:27:58', NULL),
(103, 105, '2024-03-28 11:38:01', NULL),
(104, 105, '2024-03-28 11:38:01', NULL),
(105, 105, '2024-03-28 11:27:58', NULL),
(106, 105, '2024-03-28 11:27:58', NULL),
(107, 105, '2024-03-28 11:38:01', NULL),
(108, 105, '2024-03-28 11:38:01', NULL),
(109, 105, '2024-03-28 11:38:01', NULL),
(110, 105, '2024-03-28 11:38:01', NULL),
(111, 105, '2024-03-28 11:38:01', NULL),
(112, 105, '2024-03-28 11:38:01', NULL),
(113, 105, '2024-03-28 11:38:01', NULL),
(114, 105, '2024-03-28 11:38:01', NULL),
(115, 105, '2024-03-28 11:27:58', NULL),
(116, 105, '2024-03-28 11:38:01', NULL),
(117, 105, '2024-03-28 11:27:58', NULL),
(118, 105, '2024-03-28 11:27:58', NULL),
(119, 105, '2024-03-28 11:27:58', NULL),
(120, 108, '2024-03-28 11:38:01', NULL),
(121, 105, '2024-03-28 11:38:01', NULL),
(122, 105, '2024-03-28 11:38:01', NULL),
(123, 105, '2024-03-28 11:38:01', NULL),
(124, 105, '2024-03-28 11:27:58', NULL),
(125, 105, '2024-03-28 11:27:58', NULL),
(126, 109, '2024-03-28 11:38:01', NULL),
(127, 109, '2024-03-28 11:27:58', NULL),
(128, 109, '2024-03-28 11:38:01', NULL),
(129, 109, '2024-03-28 11:38:01', NULL),
(130, 109, '2024-03-28 11:38:01', NULL),
(131, 109, '2024-03-28 11:38:01', NULL),
(132, 109, '2024-03-28 11:38:01', NULL),
(133, 109, '2024-03-28 11:38:01', NULL),
(134, 105, '2024-03-28 11:27:58', NULL),
(135, 109, '2024-03-28 11:38:01', NULL),
(136, 105, '2024-03-28 11:38:01', NULL),
(137, 109, '2024-03-28 11:38:01', NULL),
(138, 109, '2024-03-28 11:38:01', NULL),
(139, 109, '2024-03-28 11:38:01', NULL),
(140, 109, '2024-03-28 11:27:58', NULL),
(141, 108, '2024-03-28 11:38:01', NULL),
(142, 109, '2024-03-28 11:27:58', NULL),
(143, 105, '2024-03-28 11:38:01', NULL),
(144, 108, '2024-03-28 11:27:58', NULL),
(145, 105, '2024-03-28 11:27:58', NULL),
(146, 105, '2024-03-28 11:38:01', NULL),
(147, 105, '2024-03-28 11:38:01', NULL),
(148, 105, '2024-03-28 11:38:01', NULL),
(149, 105, '2024-03-28 11:38:01', NULL),
(150, 105, '2024-03-28 11:38:01', NULL),
(151, 105, '2024-03-28 11:27:58', NULL),
(152, 105, '2024-03-28 11:38:01', NULL),
(153, 105, '2024-03-28 11:38:01', NULL),
(154, 105, '2024-03-28 11:27:58', NULL),
(155, 105, '2024-03-28 11:38:01', NULL),
(156, 105, '2024-03-28 11:38:01', NULL),
(157, 105, '2024-03-28 11:38:01', NULL),
(158, 105, '2024-03-28 11:38:01', NULL),
(159, 105, '2024-03-28 11:38:01', NULL),
(160, 105, '2024-03-28 11:38:01', NULL),
(161, 105, '2024-03-28 11:38:01', NULL),
(162, 105, '2024-03-28 11:38:01', NULL),
(163, 105, '2024-03-28 11:38:01', NULL),
(164, 105, '2024-03-28 11:38:01', NULL),
(165, 105, '2024-03-28 11:25:44', NULL),
(166, 105, '2024-03-28 11:27:58', NULL),
(167, 110, '2024-03-28 11:38:01', NULL),
(168, 105, '2024-03-28 11:25:44', NULL),
(169, 105, '2024-03-28 11:38:01', NULL),
(170, 105, '2024-03-28 11:38:01', NULL),
(171, 105, '2024-03-28 11:38:01', NULL),
(172, 105, '2024-03-28 11:25:44', NULL),
(173, 105, '2024-03-28 11:38:01', NULL),
(174, 105, '2024-03-28 11:38:01', NULL),
(175, 105, '2024-03-28 11:38:01', NULL),
(176, 105, '2024-03-28 11:38:01', NULL),
(177, 105, '2024-03-28 14:59:50', NULL),
(178, 105, '2024-03-28 14:59:50', NULL),
(179, 105, '2024-03-28 14:59:50', NULL),
(180, 105, '2024-03-28 14:59:50', NULL),
(181, 105, '2024-03-28 14:59:50', NULL),
(182, 105, '2024-03-28 11:25:44', NULL),
(183, 105, '2024-03-28 14:59:50', NULL),
(184, 105, '2024-03-28 14:59:50', NULL),
(185, 105, '2024-03-28 14:59:50', NULL),
(186, 108, '2024-03-28 14:59:50', NULL),
(187, 111, '2024-03-28 14:59:50', NULL),
(188, 111, '2024-03-28 14:59:50', NULL),
(189, 105, '2024-03-28 14:59:50', NULL),
(190, 105, '2024-03-28 14:59:50', NULL),
(191, 111, '2024-03-28 14:59:50', NULL),
(192, 113, '2024-03-28 14:59:50', NULL),
(193, 113, '2024-03-28 14:59:50', NULL),
(194, 113, '2024-03-28 14:59:50', NULL),
(195, 105, '2024-03-28 11:25:44', NULL),
(196, 105, '2024-03-28 14:59:50', NULL),
(197, 113, '2024-03-28 14:59:50', NULL),
(198, 113, '2024-03-28 17:21:13', NULL),
(199, 105, '2024-03-28 17:21:13', NULL),
(200, 105, '2024-03-28 11:25:44', NULL),
(201, 113, '2024-03-28 17:21:13', NULL),
(202, 113, '2024-03-28 17:21:13', NULL),
(203, 105, '2024-03-28 11:25:44', NULL),
(204, 113, '2024-03-28 17:21:13', NULL),
(205, 113, '2024-03-28 17:21:13', NULL),
(206, 113, '2024-03-28 17:21:13', NULL),
(207, 113, '2024-03-28 17:21:13', NULL),
(208, 113, '2024-03-28 17:21:13', NULL),
(209, 113, '2024-03-28 17:21:13', NULL),
(210, 113, '2024-03-28 17:21:13', NULL),
(211, 113, '2024-03-28 17:21:13', NULL),
(212, 113, '2024-03-28 17:21:13', NULL),
(213, 113, '2024-03-28 17:21:13', NULL),
(214, 105, '2024-03-28 17:21:13', NULL),
(215, 105, '2024-03-28 17:21:13', NULL),
(216, 113, '2024-03-28 17:21:13', NULL),
(217, 113, '2024-03-28 17:21:13', NULL),
(218, 113, '2024-03-28 23:46:21', NULL),
(219, 105, '2024-03-28 23:46:21', NULL),
(220, 113, '2024-03-28 23:46:21', NULL),
(221, 113, '2024-03-28 23:46:21', NULL),
(222, 113, '2024-03-28 23:46:21', NULL),
(223, 113, '2024-03-28 23:46:21', NULL),
(224, 113, '2024-03-28 23:46:21', NULL),
(225, 105, '2024-03-28 23:46:21', NULL),
(226, 113, '2024-03-28 23:46:21', NULL),
(227, 113, '2024-03-28 23:46:21', NULL),
(228, 105, '2024-03-28 23:46:21', NULL),
(229, 113, '2024-03-28 23:46:21', NULL),
(230, 105, '2024-03-28 23:46:21', NULL),
(231, 105, '2024-03-29 09:54:02', NULL),
(232, 105, '2024-03-29 09:54:02', NULL),
(233, 105, '2024-03-29 09:54:02', NULL),
(234, 113, '2024-03-29 10:37:11', NULL),
(235, 105, '2024-03-29 10:37:11', NULL),
(236, 105, '2024-03-29 10:37:11', NULL),
(237, 105, '2024-03-29 11:06:10', NULL),
(238, 105, '2024-03-29 10:37:11', NULL),
(239, 105, '2024-03-29 10:37:11', NULL),
(240, 105, '2024-03-29 10:37:11', NULL),
(241, 105, '2024-03-29 10:37:11', NULL),
(242, 113, '2024-03-29 10:37:11', NULL),
(243, 105, '2024-03-29 10:37:11', NULL),
(244, 105, '2024-03-29 10:37:11', NULL),
(245, 105, '2024-03-29 10:37:11', NULL),
(246, 113, '2024-03-29 10:37:11', NULL),
(247, 113, '2024-03-29 10:37:11', NULL),
(248, 105, '2024-03-29 10:37:11', NULL),
(249, 105, '2024-03-29 10:37:11', NULL),
(250, 113, '2024-03-29 10:37:11', NULL),
(251, 113, '2024-03-29 10:37:11', NULL),
(252, 113, '2024-03-29 10:37:11', NULL),
(253, 113, '2024-03-29 10:37:11', NULL),
(254, 113, '2024-03-29 10:37:11', NULL),
(255, 105, '2024-03-29 10:37:11', NULL),
(256, 113, '2024-03-29 10:37:11', NULL),
(257, 105, '2024-03-29 11:06:10', NULL),
(258, 113, '2024-03-29 10:37:11', NULL),
(259, 105, '2024-03-29 10:37:11', NULL),
(260, 113, '2024-03-29 10:37:11', NULL),
(261, 105, '2024-03-29 10:37:11', NULL),
(262, 113, '2024-03-29 10:37:11', NULL),
(263, 113, '2024-03-29 10:37:11', NULL),
(264, 113, '2024-03-29 10:37:11', NULL),
(265, 105, '2024-03-29 10:37:11', NULL),
(266, 113, '2024-03-29 10:37:11', NULL),
(267, 109, '2024-03-29 10:37:11', NULL),
(268, 109, '2024-03-29 10:37:11', NULL),
(269, 109, '2024-03-29 10:37:11', NULL),
(270, 105, '2024-03-29 10:37:11', NULL),
(271, 113, '2024-03-29 10:37:11', NULL),
(272, 105, '2024-03-29 10:37:11', NULL),
(273, 105, '2024-03-29 10:37:11', NULL),
(274, 105, '2024-03-29 10:37:11', NULL),
(275, 113, '2024-03-29 10:37:11', NULL),
(276, 113, '2024-03-29 10:37:11', NULL),
(277, 105, '2024-03-29 11:06:10', NULL),
(278, 105, '2024-03-28 11:38:01', NULL),
(279, 105, '2024-03-29 10:37:11', NULL),
(280, 113, '2024-03-29 10:37:11', NULL),
(281, 105, '2024-03-29 10:37:11', NULL),
(282, 113, '2024-03-29 10:37:11', NULL),
(283, 105, '2024-03-29 10:37:11', NULL),
(284, 105, '2024-03-29 10:37:11', NULL),
(285, 113, '2024-03-29 14:58:53', NULL),
(286, 105, '2024-03-29 14:58:53', NULL),
(287, 113, '2024-03-29 14:58:53', NULL),
(288, 105, '2024-03-29 11:06:10', NULL),
(289, 105, '2024-03-29 11:06:10', NULL),
(290, 105, '2024-03-29 11:06:10', NULL),
(291, 105, '2024-03-29 11:06:10', NULL),
(292, 105, '2024-03-29 11:06:10', NULL),
(293, 105, '2024-03-29 11:06:10', NULL),
(294, 105, '2024-03-29 14:58:53', NULL),
(295, 105, '2024-03-29 14:58:53', NULL),
(296, 105, '2024-03-29 11:06:10', NULL),
(297, 105, '2024-03-29 14:58:53', NULL),
(298, 105, '2024-03-29 14:58:53', NULL),
(299, 105, '2024-03-29 14:38:46', NULL),
(300, 105, '2024-03-29 11:06:10', NULL),
(301, 113, '2024-03-29 14:38:46', NULL),
(302, 105, '2024-03-29 14:38:46', NULL),
(303, 105, '2024-03-29 11:06:10', NULL),
(304, 105, '2024-03-29 11:06:10', NULL),
(305, 105, '2024-03-29 11:06:10', NULL),
(306, 105, '2024-03-29 14:38:46', NULL),
(307, 105, '2024-03-29 14:38:46', NULL),
(308, 113, '2024-03-30 12:54:15', NULL),
(309, 105, '2024-03-30 12:57:29', NULL),
(310, 113, '2024-03-30 13:05:31', NULL),
(311, 105, '2024-03-30 13:05:31', NULL),
(312, 105, '2024-03-30 14:10:35', NULL),
(313, 105, '2024-03-30 14:21:29', NULL),
(314, 105, '2024-03-30 14:21:29', NULL),
(315, 105, '2024-03-30 14:21:29', NULL),
(316, 105, '2024-03-30 14:21:29', NULL),
(317, 105, '2024-03-29 14:58:53', NULL),
(318, 105, '2024-03-30 14:21:29', NULL),
(319, 105, '2024-03-30 14:21:29', NULL),
(320, 109, '2024-03-29 14:58:53', NULL),
(321, 109, '2024-03-29 14:58:53', NULL),
(322, 109, '2024-03-29 14:58:53', NULL),
(323, 105, '2024-03-29 14:58:53', NULL),
(324, 116, '2024-03-30 14:21:29', NULL),
(325, 116, '2024-03-30 14:21:29', NULL),
(326, 117, '2024-03-29 14:58:53', NULL),
(327, 116, '2024-04-01 12:14:26', NULL),
(328, 116, '2024-04-01 12:14:26', NULL),
(329, 116, '2024-04-01 12:21:29', NULL),
(330, 116, '2024-04-01 12:24:13', NULL),
(331, 116, '2024-04-01 12:24:13', NULL),
(332, 116, '2024-04-01 12:14:26', NULL),
(333, 116, '2024-04-01 12:14:26', NULL),
(334, 117, '2024-03-29 14:58:53', NULL),
(335, 116, '2024-04-01 12:24:13', NULL),
(336, 116, '2024-04-01 12:14:26', NULL),
(337, 116, '2024-04-01 12:24:13', NULL),
(338, 116, '2024-04-01 12:24:13', NULL),
(339, 116, '2024-04-01 12:14:26', NULL),
(340, 116, '2024-04-01 12:14:26', NULL),
(341, 116, '2024-04-01 12:24:13', NULL),
(342, 116, '2024-04-01 12:14:26', NULL),
(343, 116, '2024-04-01 16:05:59', NULL),
(344, 116, '2024-04-01 16:05:59', NULL),
(345, 116, '2024-04-01 16:05:59', NULL),
(346, 116, '2024-04-01 12:24:13', NULL),
(347, 116, '2024-04-01 12:24:13', NULL),
(348, 116, '2024-04-01 12:24:13', NULL),
(349, 116, '2024-04-01 12:24:13', NULL),
(350, 116, '2024-04-01 12:24:13', NULL),
(351, 116, '2024-04-01 16:05:59', NULL),
(352, 116, '2024-04-01 12:24:13', NULL),
(353, 116, '2024-04-01 12:24:13', NULL),
(354, 116, '2024-04-01 12:24:13', NULL),
(355, 116, '2024-04-01 12:24:13', NULL),
(356, 116, '2024-04-01 12:24:13', NULL),
(357, 116, '2024-04-01 12:24:13', NULL),
(358, 116, '2024-04-01 12:24:13', NULL),
(359, 116, '2024-04-01 12:24:13', NULL),
(360, 116, '2024-03-29 14:58:53', NULL),
(361, 116, '2024-04-01 21:38:05', NULL),
(362, 116, '2024-04-01 21:38:05', NULL),
(363, 116, '2024-04-02 10:00:15', NULL),
(364, 116, '2024-04-02 10:00:15', NULL),
(365, 116, '2024-04-02 10:00:15', NULL),
(366, 116, '2024-04-02 10:00:15', NULL),
(367, 116, '2024-04-02 10:00:15', NULL),
(368, 116, '2024-04-02 10:00:15', NULL),
(369, 116, '2024-04-02 10:30:55', NULL),
(370, 116, '2024-04-02 10:00:15', NULL),
(371, 116, '2024-04-02 10:00:15', NULL),
(372, 117, '2024-03-29 14:58:53', NULL),
(373, 116, '2024-04-02 10:00:15', NULL),
(374, 116, '2024-04-02 10:00:15', NULL),
(375, 116, '2024-04-02 11:40:53', NULL),
(376, 116, '2024-04-02 11:40:53', NULL),
(377, 116, '2024-04-02 11:40:53', NULL),
(378, 116, '2024-04-02 11:40:53', NULL),
(379, 116, '2024-04-02 11:40:53', NULL),
(380, 116, '2024-04-02 11:40:53', NULL),
(381, 116, '2024-04-02 11:40:53', NULL),
(382, 116, '2024-04-02 11:40:53', NULL),
(383, 116, '2024-03-29 14:58:53', NULL),
(384, 116, '2024-03-29 14:58:53', NULL),
(385, 116, '2024-03-29 14:58:53', NULL),
(386, 117, '2024-03-29 14:58:53', NULL),
(387, 116, '2024-04-02 10:39:48', NULL),
(388, 116, '2024-04-02 14:53:20', NULL),
(389, 116, '2024-04-02 14:53:20', NULL),
(390, 116, '2024-03-29 14:58:53', NULL),
(391, 116, '2024-04-02 14:53:20', NULL),
(392, 116, '2024-04-02 14:53:20', NULL),
(393, 116, '2024-03-29 14:58:53', NULL),
(394, 116, '2024-04-02 14:53:20', NULL),
(395, 116, '2024-04-02 14:53:20', NULL),
(396, 116, '2024-04-02 14:53:20', NULL),
(397, 116, '2024-03-29 14:58:53', NULL),
(398, 116, '2024-03-29 14:58:53', NULL),
(399, 116, '2024-03-29 14:58:53', NULL),
(400, 116, '2024-04-02 16:12:33', NULL),
(401, 116, '2024-04-02 16:12:33', NULL),
(402, 116, '2024-03-29 14:58:53', NULL),
(403, 116, '2024-04-02 16:18:10', NULL),
(404, 116, '2024-04-02 16:18:10', NULL),
(405, 116, '2024-04-02 16:22:10', NULL),
(406, 116, '2024-03-29 14:58:53', NULL),
(407, 116, '2024-03-29 14:58:53', NULL),
(408, 116, '2024-04-02 17:29:17', NULL),
(409, 116, '2024-04-02 17:32:05', NULL),
(410, 116, '2024-04-02 18:14:29', NULL),
(411, 116, '2024-04-02 18:15:45', NULL),
(412, 116, '2024-04-02 18:15:45', NULL),
(413, 116, '2024-04-02 18:41:37', NULL),
(414, 116, '2024-04-02 18:41:37', NULL),
(415, 116, '2024-04-02 18:43:47', NULL),
(416, 116, '2024-04-02 18:48:49', NULL),
(417, 116, '2024-03-29 14:58:53', NULL),
(418, 116, '2024-03-29 14:58:53', NULL),
(419, 116, '2024-03-29 14:58:53', NULL),
(420, 116, '2024-03-29 14:58:53', NULL),
(421, 116, '2024-03-29 14:58:53', NULL),
(422, 116, '2024-03-29 14:58:53', NULL),
(423, 116, '2024-03-29 14:58:53', NULL),
(424, 116, '2024-03-29 14:58:53', NULL),
(425, 116, '2024-03-29 14:58:53', NULL),
(426, 120, '2024-03-29 14:58:53', NULL),
(427, 120, '2024-03-29 14:58:53', NULL),
(428, 116, '2024-04-03 10:39:01', NULL),
(429, 116, '2024-03-29 14:58:53', NULL),
(430, 116, '2024-04-03 10:39:01', NULL),
(431, 116, '2024-04-03 10:49:45', NULL),
(432, 121, '2024-03-29 14:58:53', NULL),
(433, 116, '2024-03-29 14:58:53', NULL),
(434, 121, '2024-03-29 14:58:53', NULL),
(435, 117, '2024-03-29 14:58:53', NULL),
(436, 116, '2024-03-29 14:58:53', NULL),
(437, 116, '2024-03-29 14:58:53', NULL),
(438, 116, '2024-03-29 14:58:53', NULL),
(439, 116, '2024-04-03 10:49:45', NULL),
(440, 116, '2024-03-29 14:58:53', NULL),
(441, 116, '2024-04-03 11:04:55', NULL),
(442, 116, '2024-04-03 11:15:16', NULL),
(443, 116, '2024-04-03 11:15:16', NULL),
(444, 116, '2024-04-03 11:16:15', NULL),
(445, 116, '2024-04-03 11:16:15', NULL),
(446, 116, '2024-04-03 11:19:37', NULL),
(447, 116, '2024-04-03 10:49:45', NULL),
(448, 116, '2024-04-03 11:19:37', NULL),
(449, 116, '2024-04-03 11:22:37', NULL),
(450, 116, '2024-04-03 11:22:37', NULL),
(451, 116, '2024-04-03 11:22:37', NULL),
(452, 116, '2024-04-03 11:22:37', NULL),
(453, 116, '2024-04-03 11:24:25', NULL),
(454, 116, '2024-04-03 11:24:25', NULL),
(455, 116, '2024-04-03 11:24:25', NULL),
(456, 116, '2024-04-03 11:24:25', NULL),
(457, 116, '2024-04-03 11:24:25', NULL),
(458, 116, '2024-04-03 11:24:25', NULL),
(459, 116, '2024-04-03 11:24:25', NULL),
(460, 116, '2024-04-03 11:24:25', NULL),
(461, 121, '2024-04-03 11:41:32', NULL),
(462, 116, '2024-04-03 12:05:33', NULL),
(463, 116, '2024-04-03 12:05:33', NULL),
(464, 116, '2024-04-03 12:48:55', NULL),
(465, 116, '2024-04-03 13:01:19', NULL),
(466, 116, '2024-04-03 13:01:19', NULL),
(467, 116, '2024-04-03 13:02:47', NULL),
(468, 116, '2024-04-03 13:02:47', NULL),
(469, 116, '2024-04-03 13:02:47', NULL),
(470, 116, '2024-04-03 13:01:19', NULL),
(471, 116, '2024-04-03 13:01:19', NULL),
(472, 116, '2024-04-03 13:36:50', NULL),
(473, 116, '2024-04-03 14:29:52', NULL),
(474, 116, '2024-04-03 14:29:52', NULL),
(475, 116, '2024-04-03 14:29:52', NULL),
(476, 116, '2024-04-03 14:29:52', NULL),
(477, 116, '2024-04-03 14:29:52', NULL),
(478, 116, '2024-04-03 14:29:52', NULL),
(479, 116, '2024-04-03 14:29:52', NULL),
(480, 116, '2024-04-03 14:29:52', NULL),
(481, 116, '2024-04-03 14:53:15', NULL),
(482, 116, '2024-04-03 14:53:15', NULL),
(483, 116, '2024-04-03 14:53:15', NULL),
(484, 116, '2024-04-03 14:53:15', NULL),
(485, 116, '2024-04-03 14:53:15', NULL),
(486, 116, '2024-04-03 14:53:15', NULL),
(487, 116, '2024-04-03 14:53:15', NULL),
(488, 116, '2024-04-03 14:53:15', NULL),
(489, 116, '2024-04-03 14:53:15', NULL),
(490, 116, '2024-04-03 14:53:15', NULL),
(491, 116, '2024-04-03 14:53:15', NULL),
(492, 116, '2024-04-03 14:53:15', NULL),
(493, 116, '2024-04-03 14:53:15', NULL),
(494, 116, '2024-04-03 13:28:58', NULL),
(495, 116, '2024-04-03 14:53:15', NULL),
(496, 116, '2024-04-03 14:53:15', NULL),
(497, 116, '2024-04-03 14:53:15', NULL),
(498, 116, '2024-04-03 15:00:08', NULL),
(499, 116, '2024-04-03 15:04:42', NULL),
(500, 116, '2024-04-03 15:11:02', NULL),
(501, 116, '2024-04-03 15:13:09', NULL),
(502, 116, '2024-04-03 15:21:35', NULL),
(503, 116, '2024-04-03 15:25:47', NULL),
(504, 116, '2024-04-03 15:25:47', NULL),
(505, 116, '2024-04-03 15:25:47', NULL),
(506, 116, '2024-04-03 15:25:47', NULL),
(507, 116, '2024-04-03 15:25:47', NULL),
(508, 116, '2024-04-03 15:32:51', NULL),
(509, 116, '2024-04-03 15:33:12', NULL),
(510, 116, '2024-04-03 15:35:20', NULL),
(511, 116, '2024-04-03 15:35:20', NULL),
(512, 116, '2024-04-03 15:35:52', NULL),
(513, 116, '2024-04-03 15:35:52', NULL),
(514, 116, '2024-04-03 15:35:52', NULL),
(515, 116, '2024-04-03 15:35:52', NULL),
(516, 116, '2024-04-03 15:45:02', NULL),
(517, 116, '2024-04-03 15:45:02', NULL),
(518, 116, '2024-04-03 16:23:59', NULL),
(519, 116, '2024-04-03 15:45:02', NULL),
(520, 116, '2024-04-03 15:45:02', NULL),
(521, 116, '2024-04-03 16:31:49', NULL),
(522, 116, '2024-04-03 16:31:49', NULL),
(523, 116, '2024-04-03 16:31:49', NULL),
(524, 116, '2024-04-03 15:45:02', NULL),
(525, 116, '2024-04-03 15:45:02', NULL),
(526, 116, '2024-04-03 15:45:02', NULL),
(527, 116, '2024-04-03 15:45:02', NULL),
(528, 116, '2024-04-03 15:45:02', NULL),
(529, 116, '2024-04-03 15:45:02', NULL),
(530, 116, '2024-04-03 16:52:56', NULL),
(531, 116, '2024-04-03 16:52:56', NULL),
(532, 116, '2024-04-03 16:52:56', NULL),
(533, 116, '2024-04-03 16:52:56', NULL),
(534, 116, '2024-04-03 16:52:56', NULL),
(535, 116, '2024-04-03 16:52:56', NULL),
(536, 116, '2024-04-03 15:45:02', NULL),
(537, 116, '2024-04-03 18:28:26', NULL),
(538, 116, '2024-04-03 18:28:26', NULL),
(539, 116, '2024-04-03 18:28:26', NULL),
(540, 116, '2024-04-03 18:28:26', NULL),
(541, 116, '2024-04-03 18:28:26', NULL),
(542, 116, '2024-04-03 18:28:26', NULL),
(543, 116, '2024-04-03 18:28:26', NULL),
(544, 116, '2024-04-03 18:28:26', NULL),
(545, 116, '2024-04-03 18:28:26', NULL),
(546, 116, '2024-04-03 18:28:26', NULL),
(547, 116, '2024-04-03 18:28:26', NULL),
(548, 116, '2024-04-03 16:52:56', NULL),
(549, 116, '2024-04-03 18:28:26', NULL),
(550, 116, '2024-04-03 18:28:26', NULL),
(551, 116, '2024-04-03 18:28:26', NULL),
(552, 116, '2024-04-03 18:28:26', NULL),
(553, 116, '2024-04-04 10:36:06', NULL),
(554, 116, '2024-04-03 18:28:26', NULL),
(555, 116, '2024-04-03 18:28:26', NULL),
(556, 116, '2024-04-03 18:28:26', NULL),
(557, 116, '2024-04-03 16:52:56', NULL),
(558, 116, '2024-04-04 11:11:27', NULL),
(559, 116, '2024-04-04 10:36:06', NULL),
(560, 116, '2024-04-04 11:11:27', NULL),
(561, 116, '2024-04-04 11:29:14', NULL),
(562, 116, '2024-04-04 11:11:27', NULL),
(563, 116, '2024-04-04 11:11:27', NULL),
(564, 116, '2024-04-04 11:11:27', NULL),
(565, 116, '2024-04-04 11:51:26', NULL),
(566, 116, '2024-04-04 10:36:06', NULL),
(567, 116, '2024-04-04 10:36:06', NULL),
(568, 116, '2024-04-04 11:51:26', NULL),
(569, 116, '2024-04-04 10:36:06', NULL),
(570, 116, '2024-04-04 10:36:06', NULL),
(571, 116, '2024-04-04 13:02:59', NULL),
(572, 116, '2024-04-04 13:02:59', NULL),
(573, 116, '2024-04-04 10:36:06', NULL),
(574, 116, '2024-04-04 10:36:06', NULL),
(575, 116, '2024-04-04 13:02:59', NULL),
(576, 116, '2024-04-03 16:52:56', NULL),
(577, 116, '2024-04-04 13:02:59', NULL),
(578, 116, '2024-04-04 10:36:06', NULL),
(579, 116, '2024-04-04 13:02:59', NULL),
(580, 116, '2024-04-04 13:02:59', NULL),
(581, 116, '2024-04-04 13:02:59', NULL),
(582, 116, '2024-04-03 16:52:56', NULL),
(583, 116, '2024-04-05 10:46:52', NULL),
(584, 116, '2024-04-03 16:52:56', NULL),
(585, 116, '2024-04-05 10:46:52', NULL),
(586, 116, '2024-04-03 16:52:56', NULL),
(587, 116, '2024-04-05 10:46:52', NULL),
(588, 122, '2024-04-03 16:52:56', NULL),
(589, 116, '2024-04-03 16:52:56', NULL),
(590, 122, '2024-04-03 16:52:56', NULL),
(591, 116, '2024-04-03 16:52:56', NULL),
(592, 122, '2024-04-03 16:52:56', NULL),
(593, 116, '2024-04-03 16:52:56', NULL),
(594, 122, '2024-04-03 16:52:56', NULL),
(595, 116, '2024-04-03 16:52:56', NULL),
(596, 116, '2024-04-03 16:52:56', NULL),
(597, 116, '2024-04-03 16:52:56', NULL),
(598, 122, '2024-04-03 16:52:56', NULL),
(599, 116, '2024-04-03 16:52:56', NULL),
(600, 116, '2024-04-05 10:46:52', NULL),
(601, 116, '2024-04-03 16:52:56', NULL),
(602, 122, '2024-04-03 16:52:56', NULL),
(603, 122, '2024-04-03 16:52:56', NULL),
(604, 116, '2024-04-03 16:52:56', NULL),
(605, 122, '2024-04-03 16:52:56', NULL),
(606, 116, '2024-04-03 16:52:56', NULL),
(607, 117, '2024-04-03 16:52:56', NULL),
(608, 122, '2024-04-03 16:52:56', NULL),
(609, 116, '2024-04-03 16:52:56', NULL),
(610, 116, '2024-04-05 12:37:57', NULL),
(611, 116, '2024-04-05 10:46:52', NULL),
(612, 122, '2024-04-03 16:52:56', NULL),
(613, 116, '2024-04-03 16:52:56', NULL),
(614, 122, '2024-04-03 16:52:56', NULL),
(615, 116, '2024-04-03 16:52:56', NULL),
(616, 122, '2024-04-03 16:52:56', NULL),
(617, 122, '2024-04-03 16:52:56', NULL),
(618, 116, '2024-04-03 16:52:56', NULL),
(619, 116, '2024-04-03 16:52:56', NULL),
(620, 116, '2024-04-03 16:52:56', NULL),
(621, 116, '2024-04-03 16:52:56', NULL),
(622, 116, '2024-04-03 16:52:56', NULL),
(623, 116, '2024-04-05 12:37:57', NULL),
(624, 116, '2024-04-05 13:14:43', NULL),
(625, 117, '2024-04-03 16:52:56', NULL),
(626, 116, '2024-04-03 16:52:56', NULL),
(627, 117, '2024-04-03 16:52:56', NULL),
(628, 116, '2024-04-03 16:52:56', NULL),
(629, 117, '2024-04-03 16:52:56', NULL),
(630, 117, '2024-04-05 13:14:43', NULL),
(631, 116, '2024-04-03 16:52:56', NULL),
(632, 116, '2024-04-03 16:52:56', NULL),
(633, 116, '2024-04-05 13:14:43', NULL),
(634, 122, '2024-04-03 16:52:56', NULL),
(635, 122, '2024-04-03 16:52:56', NULL),
(636, 122, '2024-04-03 16:52:56', NULL),
(637, 116, '2024-04-05 13:14:43', NULL),
(638, 116, '2024-04-05 13:14:43', NULL),
(639, 116, '2024-04-03 16:52:56', NULL),
(640, 116, '2024-04-05 13:14:43', NULL),
(641, 116, '2024-04-05 13:14:43', NULL),
(642, 116, '2024-04-05 13:14:43', NULL),
(643, 116, '2024-04-05 13:14:43', NULL),
(644, 116, '2024-04-03 16:52:56', NULL),
(645, 116, '2024-04-05 13:14:43', NULL),
(646, 116, '2024-04-03 16:52:56', NULL),
(647, 116, '2024-04-03 16:52:56', NULL),
(648, 116, '2024-04-05 13:14:43', NULL),
(649, 116, '2024-04-05 13:14:43', NULL),
(650, 122, '2024-04-03 16:52:56', NULL),
(651, 122, '2024-04-03 16:52:56', NULL),
(652, 116, '2024-04-05 13:14:43', NULL),
(653, 122, '2024-04-03 16:52:56', NULL),
(654, 116, '2024-04-03 16:52:56', NULL),
(655, 116, '2024-04-05 13:14:43', NULL),
(656, 116, '2024-04-03 16:52:56', NULL),
(657, 116, '2024-04-03 16:52:56', NULL),
(658, 116, '2024-04-05 13:14:43', NULL),
(659, 116, '2024-04-03 16:52:56', NULL),
(660, 116, '2024-04-05 13:14:43', NULL),
(661, 116, '2024-04-03 16:52:56', NULL),
(662, 116, '2024-04-03 16:52:56', NULL),
(663, 116, '2024-04-06 10:50:19', NULL),
(664, 116, '2024-04-06 10:50:19', NULL),
(665, 116, '2024-04-06 10:50:19', NULL),
(666, 116, '2024-04-06 10:50:19', NULL),
(667, 122, '2024-04-06 10:50:19', NULL),
(668, 122, '2024-04-03 16:52:56', NULL),
(669, 116, '2024-04-06 10:50:19', NULL),
(670, 122, '2024-04-03 16:52:56', NULL),
(671, 116, '2024-04-06 10:50:19', NULL),
(672, 116, '2024-04-06 10:50:19', NULL),
(673, 116, '2024-04-06 10:50:19', NULL),
(674, 116, '2024-04-06 10:50:19', NULL),
(675, 116, '2024-04-06 10:50:19', NULL),
(676, 116, '2024-04-03 16:52:56', NULL),
(677, 116, '2024-04-06 10:50:19', NULL),
(678, 116, '2024-04-06 10:50:19', NULL),
(679, 116, '2024-04-06 10:50:19', NULL),
(680, 116, '2024-04-03 16:52:56', NULL),
(681, 116, '2024-04-06 10:50:19', NULL),
(682, 116, '2024-04-03 16:52:56', NULL),
(683, 116, '2024-04-03 16:52:56', NULL),
(684, 116, '2024-04-08 13:19:31', NULL),
(685, 116, '2024-04-08 13:19:31', NULL),
(686, 116, '2024-04-08 13:19:31', NULL),
(687, 116, '2024-04-08 13:19:31', NULL),
(688, 116, '2024-04-08 13:19:31', NULL),
(689, 116, '2024-04-08 13:19:31', NULL),
(690, 116, '2024-04-08 13:19:31', NULL),
(691, 116, '2024-04-08 13:19:31', NULL),
(692, 116, '2024-04-08 13:19:31', NULL),
(693, 116, '2024-04-08 13:19:31', NULL),
(694, 116, '2024-04-08 13:19:31', NULL),
(695, 116, '2024-04-08 13:19:31', NULL),
(696, 116, '2024-04-08 13:19:31', NULL),
(697, 116, '2024-04-08 13:19:31', NULL),
(698, 116, '2024-04-09 10:01:46', NULL),
(699, 116, '2024-04-09 10:01:46', NULL),
(700, 116, '2024-04-09 10:28:10', NULL),
(701, 116, '2024-04-09 10:28:10', NULL),
(702, 116, '2024-04-09 10:01:46', NULL),
(703, 116, '2024-04-09 10:28:10', NULL),
(704, 116, '2024-04-09 10:28:10', NULL),
(705, 116, '2024-04-09 10:28:10', NULL),
(706, 116, '2024-04-09 13:01:07', NULL),
(707, 116, '2024-04-09 10:28:10', NULL),
(708, 116, '2024-04-09 13:43:40', NULL),
(709, 116, '2024-04-09 13:43:40', NULL),
(710, 116, '2024-04-09 13:43:40', NULL),
(711, 116, '2024-04-09 13:43:40', NULL),
(712, 116, '2024-04-09 13:47:22', NULL),
(713, 116, '2024-04-09 13:48:56', NULL),
(714, 116, '2024-04-09 13:54:39', NULL),
(715, 116, '2024-04-09 13:55:55', NULL),
(716, 116, '2024-04-09 13:58:24', NULL),
(717, 116, '2024-04-09 13:58:24', NULL),
(718, 116, '2024-04-09 13:26:40', NULL),
(719, 116, '2024-04-09 13:26:40', NULL),
(720, 116, '2024-04-09 21:21:07', NULL),
(721, 116, '2024-04-09 21:44:08', NULL),
(722, 116, '2024-04-09 21:44:08', NULL),
(723, 116, '2024-04-09 22:33:32', NULL),
(724, 116, '2024-04-09 23:43:54', NULL),
(725, 116, '2024-04-09 23:43:54', NULL),
(726, 116, '2024-04-09 23:43:54', NULL),
(727, 116, '2024-04-09 23:43:54', NULL),
(728, 116, '2024-04-10 00:19:30', NULL),
(729, 116, '2024-04-10 09:26:14', NULL),
(730, 116, '2024-04-10 09:26:14', NULL),
(731, 116, '2024-04-10 10:09:04', NULL),
(732, 116, '2024-04-10 10:09:04', NULL),
(733, 116, '2024-04-10 10:09:04', NULL),
(734, 116, '2024-04-09 13:01:07', NULL),
(735, 116, '2024-04-10 10:09:04', NULL),
(736, 116, '2024-04-10 10:09:04', NULL),
(737, 116, '2024-04-10 10:09:04', NULL),
(738, 116, '2024-04-10 10:42:47', NULL),
(739, 116, '2024-04-10 11:02:42', NULL),
(740, 116, '2024-04-09 13:01:07', NULL),
(741, 116, '2024-04-10 11:02:42', NULL),
(742, 116, '2024-04-10 10:42:47', NULL),
(743, 116, '2024-04-10 11:02:42', NULL),
(744, 116, '2024-04-10 10:42:47', NULL),
(745, 116, '2024-04-10 11:02:42', NULL),
(746, 116, '2024-04-10 12:20:29', NULL),
(747, 116, '2024-04-10 11:02:42', NULL),
(748, 116, '2024-04-10 11:02:42', NULL),
(749, 116, '2024-04-10 11:02:42', NULL),
(750, 116, '2024-04-10 12:44:45', NULL),
(751, 116, '2024-04-10 11:02:42', NULL),
(752, 116, '2024-04-10 11:02:42', NULL),
(753, 116, '2024-04-10 12:44:45', NULL),
(754, 116, '2024-04-10 12:44:45', NULL),
(755, 116, '2024-04-10 14:28:59', NULL),
(756, 116, '2024-04-10 14:28:59', NULL),
(757, 116, '2024-04-10 14:28:59', NULL),
(758, 116, '2024-04-10 14:28:59', NULL),
(759, 116, '2024-04-10 14:28:59', NULL),
(760, 116, '2024-04-10 14:28:59', NULL),
(761, 116, '2024-04-10 17:13:35', NULL),
(762, 116, '2024-04-10 17:13:35', NULL),
(763, 116, '2024-04-10 21:32:11', NULL),
(764, 116, '2024-04-11 09:59:40', NULL),
(765, 116, '2024-04-10 17:13:35', NULL),
(766, 116, '2024-04-11 09:59:40', NULL),
(767, 116, '2024-04-11 09:59:40', NULL),
(768, 116, '2024-04-11 09:59:40', NULL),
(769, 116, '2024-04-11 10:58:12', NULL),
(770, 116, '2024-04-11 10:58:12', NULL),
(771, 116, '2024-04-11 10:58:12', NULL),
(772, 116, '2024-04-11 10:58:12', NULL),
(773, 116, '2024-04-10 17:13:35', NULL),
(774, 116, '2024-04-10 17:13:35', NULL),
(775, 116, '2024-04-11 14:26:50', NULL),
(776, 116, '2024-04-10 17:13:35', NULL),
(777, 116, '2024-04-10 17:13:35', NULL),
(778, 116, '2024-04-10 17:13:35', NULL),
(779, 116, '2024-04-10 17:13:35', NULL),
(780, 116, '2024-04-10 17:13:35', NULL),
(781, 116, '2024-04-10 17:13:35', NULL),
(782, 116, '2024-04-11 14:26:50', NULL),
(783, 116, '2024-04-10 17:13:35', NULL),
(784, 116, '2024-04-10 17:13:35', NULL),
(785, 116, '2024-04-11 15:47:19', NULL),
(786, 116, '2024-04-11 15:47:19', NULL),
(787, 116, '2024-04-11 15:47:19', NULL),
(788, 116, '2024-04-10 17:13:35', NULL),
(789, 116, '2024-04-10 17:13:35', NULL),
(790, 116, '2024-04-10 17:13:35', NULL),
(791, 116, '2024-04-10 17:13:35', NULL),
(792, 116, '2024-04-10 17:13:35', NULL),
(793, 116, '2024-04-10 17:13:35', NULL),
(794, 123, '2024-04-10 17:13:35', NULL),
(795, 116, '2024-04-10 17:13:35', NULL),
(796, 116, '2024-04-10 17:13:35', NULL),
(797, 116, '2024-04-11 14:26:50', NULL),
(798, 116, '2024-04-11 14:26:50', NULL),
(799, 116, '2024-04-11 14:26:50', NULL),
(800, 116, '2024-04-12 01:30:41', NULL),
(801, 116, '2024-04-12 01:30:41', NULL),
(802, 116, '2024-04-12 01:30:41', NULL),
(803, 116, '2024-04-12 01:30:41', NULL),
(804, 116, '2024-04-12 01:30:41', NULL),
(805, 116, '2024-04-12 01:30:41', NULL),
(806, 116, '2024-04-12 01:30:41', NULL),
(807, 116, '2024-04-12 01:30:41', NULL),
(808, 116, '2024-04-12 01:30:41', NULL),
(809, 116, '2024-04-12 01:30:41', NULL),
(810, 116, '2024-04-12 01:30:41', NULL),
(811, 116, '2024-04-12 01:30:41', NULL),
(812, 116, '2024-04-12 01:30:41', NULL),
(813, 116, '2024-04-12 09:58:58', NULL),
(814, 116, '2024-04-12 09:58:58', NULL),
(815, 116, '2024-04-12 09:58:58', NULL),
(816, 116, '2024-04-12 09:58:58', NULL),
(817, 116, '2024-04-12 09:58:58', NULL),
(818, 116, '2024-04-12 09:58:58', NULL),
(819, 116, '2024-04-12 09:58:58', NULL),
(820, 116, '2024-04-12 09:58:58', NULL),
(821, 116, '2024-04-12 09:58:58', NULL),
(822, 116, '2024-04-12 09:58:58', NULL),
(823, 116, '2024-04-12 09:58:58', NULL),
(824, 116, '2024-04-12 09:58:58', NULL),
(825, 116, '2024-04-12 09:58:58', NULL),
(826, 116, '2024-04-12 09:58:58', NULL),
(827, 116, '2024-04-12 09:58:58', NULL),
(828, 116, '2024-04-12 09:58:58', NULL),
(829, 116, '2024-04-12 09:58:58', NULL),
(830, 116, '2024-04-12 12:29:48', NULL),
(831, 124, '2024-04-12 12:29:48', NULL),
(832, 116, '2024-04-12 12:29:48', NULL),
(833, 125, '2024-04-12 12:29:48', NULL),
(834, 116, '2024-04-12 12:29:48', NULL),
(835, 116, '2024-04-12 12:29:48', NULL),
(836, 124, '2024-04-12 12:29:48', NULL),
(837, 116, '2024-04-12 12:29:48', NULL),
(838, 126, '2024-04-12 12:29:48', NULL),
(839, 126, '2024-04-12 12:29:48', NULL),
(840, 126, '2024-04-12 12:29:48', NULL),
(841, 116, '2024-04-12 12:29:48', NULL),
(842, 116, '2024-04-12 12:29:48', NULL),
(843, 116, '2024-04-12 12:29:48', NULL),
(844, 116, '2024-04-12 12:29:48', NULL),
(845, 116, '2024-04-12 12:29:48', NULL),
(846, 116, '2024-04-17 20:39:44', NULL),
(847, 116, '2024-04-17 20:39:44', NULL),
(848, 116, '2024-04-17 20:39:44', NULL),
(849, 116, '2024-04-12 12:29:48', NULL),
(850, 116, '2024-04-12 12:29:48', NULL),
(851, 126, '2024-04-12 12:29:48', NULL),
(852, 126, '2024-04-12 12:29:48', NULL),
(853, 126, '2024-04-12 12:29:48', NULL),
(854, 126, '2024-04-12 12:29:48', NULL),
(855, 116, '2024-04-12 12:29:48', NULL),
(856, 116, '2024-04-12 12:29:48', NULL),
(857, 116, '2024-04-12 12:29:48', NULL),
(858, 116, '2024-04-12 12:29:48', NULL),
(859, 116, '2024-04-12 12:29:48', NULL),
(860, 116, '2024-04-12 12:29:48', NULL),
(861, 126, '2024-04-12 12:29:48', NULL),
(862, 116, '2024-04-12 12:29:48', NULL),
(863, 116, '2024-04-12 12:29:48', NULL),
(864, 116, '2024-04-12 12:29:48', NULL),
(865, 116, '2024-04-12 12:29:48', NULL),
(866, 116, '2024-04-12 12:29:48', NULL),
(867, 116, '2024-04-12 12:29:48', NULL),
(868, 116, '2024-04-22 11:15:39', NULL),
(869, 116, '2024-04-22 11:15:39', NULL),
(870, 116, '2024-04-22 11:15:39', NULL),
(871, 116, '2024-04-22 11:15:39', NULL),
(872, 116, '2024-04-22 11:15:39', NULL),
(873, 116, '2024-04-22 11:15:39', NULL),
(874, 116, '2024-04-22 11:15:39', NULL),
(875, 116, '2024-04-22 11:15:39', NULL),
(876, 116, '2024-04-12 12:29:48', NULL),
(877, 116, '2024-04-22 11:15:39', NULL),
(878, 116, '2024-04-12 12:29:48', NULL),
(879, 116, '2024-04-12 12:29:48', NULL),
(880, 116, '2024-04-12 12:29:48', NULL),
(881, 116, '2024-04-12 12:29:48', NULL),
(882, 116, '2024-04-12 12:29:48', NULL),
(883, 116, '2024-04-25 11:25:37', NULL),
(884, 116, '2024-04-25 11:25:37', NULL),
(885, 116, '2024-04-25 11:25:37', NULL),
(886, 116, '2024-04-25 11:25:37', NULL),
(887, 116, '2024-04-25 11:25:37', NULL),
(888, 116, '2024-04-25 11:25:37', NULL),
(889, 116, '2024-04-25 11:25:37', NULL),
(890, 116, '2024-04-25 13:30:45', NULL),
(891, 116, '2024-04-25 13:30:45', NULL),
(892, 116, '2024-04-25 13:30:45', NULL),
(893, 116, '2024-04-25 13:30:45', NULL),
(894, 116, '2024-04-25 13:30:45', NULL),
(895, 116, '2024-04-25 13:30:45', NULL),
(896, 116, '2024-04-25 13:30:45', NULL),
(897, 116, '2024-04-25 13:30:45', NULL),
(898, 116, '2024-04-25 13:30:45', NULL),
(899, 116, '2024-04-25 13:30:45', NULL),
(900, 116, '2024-04-25 13:30:45', NULL),
(901, 116, '2024-04-25 13:30:45', NULL),
(902, 116, '2024-04-25 13:30:45', NULL),
(903, 116, '2024-04-25 13:30:45', NULL),
(904, 116, '2024-04-25 13:30:45', NULL),
(905, 116, '2024-04-25 13:30:45', NULL),
(906, 116, '2024-04-25 13:30:45', NULL),
(907, 116, '2024-04-25 13:30:45', NULL),
(908, 116, '2024-04-25 13:30:45', NULL),
(909, 116, '2024-04-25 13:30:45', NULL),
(910, 116, '2024-04-25 13:30:45', NULL),
(911, 116, '2024-04-25 13:30:45', NULL),
(912, 116, '2024-04-25 13:30:45', NULL),
(913, 116, '2024-04-25 13:30:45', NULL),
(914, 116, '2024-04-25 13:30:45', NULL),
(915, 116, '2024-04-12 12:29:48', NULL),
(916, 116, '2024-04-26 10:21:36', NULL),
(917, 116, '2024-04-26 10:40:29', NULL),
(918, 116, '2024-04-26 10:40:29', NULL),
(919, 116, '2024-04-26 10:40:29', NULL),
(920, 116, '2024-04-26 10:40:29', NULL),
(921, 116, '2024-04-26 10:40:29', NULL),
(922, 116, '2024-04-26 10:40:29', NULL),
(923, 116, '2024-04-26 10:40:29', NULL),
(924, 116, '2024-04-26 10:40:29', NULL),
(925, 116, '2024-04-26 10:40:29', NULL),
(926, 116, '2024-04-26 10:40:29', NULL),
(927, 116, '2024-04-26 10:40:29', NULL),
(928, 116, '2024-04-26 10:40:29', NULL),
(929, 116, '2024-04-26 10:40:29', NULL),
(930, 116, '2024-04-26 10:40:29', NULL),
(931, 116, '2024-04-26 10:40:29', NULL),
(932, 116, '2024-04-26 10:40:29', NULL),
(933, 116, '2024-04-26 10:40:29', NULL),
(934, 116, '2024-04-29 15:53:20', NULL),
(935, 116, '2024-04-29 15:53:20', NULL),
(936, 116, '2024-04-29 15:53:20', NULL),
(937, 116, '2024-04-29 15:53:20', NULL),
(938, 116, '2024-04-29 15:53:20', NULL),
(939, 116, '2024-04-29 15:53:20', NULL),
(940, 116, '2024-04-12 12:29:48', NULL),
(941, 116, '2024-04-30 10:26:43', NULL),
(942, 116, '2024-04-30 10:26:43', NULL),
(943, 116, '2024-04-30 10:26:43', NULL),
(944, 116, '2024-04-12 12:29:48', NULL),
(945, 116, '2024-04-30 10:26:43', NULL),
(946, 116, '2024-04-30 10:26:43', NULL),
(947, 116, '2024-04-30 10:26:43', NULL),
(948, 127, '2024-04-12 12:29:48', NULL),
(949, 128, '2024-04-30 12:05:02', NULL),
(950, 126, '2024-04-30 12:05:02', NULL),
(951, 116, '2024-04-12 12:29:48', NULL),
(952, 116, '2024-04-12 12:29:48', NULL),
(953, 116, '2024-04-12 12:29:48', NULL),
(954, 116, '2024-04-12 12:29:48', NULL),
(955, 126, '2024-04-12 12:29:48', NULL),
(956, 116, '2024-04-12 12:29:48', NULL),
(957, 116, '2024-04-12 12:29:48', NULL),
(958, 116, '2024-04-12 12:29:48', NULL),
(959, 116, '2024-04-12 12:29:48', NULL),
(960, 116, '2024-04-12 12:29:48', NULL),
(961, 116, '2024-04-12 12:29:48', NULL),
(962, 116, '2024-04-12 12:29:48', NULL),
(963, 116, '2024-04-12 12:29:48', NULL),
(964, 116, '2024-04-12 12:29:48', NULL),
(965, 116, '2024-04-12 12:29:48', NULL),
(966, 116, '2024-04-12 12:29:48', NULL),
(967, 116, '2024-04-12 12:29:48', NULL),
(968, 126, '2024-04-12 12:29:48', NULL),
(969, 116, '2024-04-12 12:29:48', NULL),
(970, 116, '2024-04-12 12:29:48', NULL),
(971, 116, '2024-04-12 12:29:48', NULL),
(972, 116, '2024-04-12 12:29:48', NULL),
(973, 116, '2024-04-12 12:29:48', NULL),
(974, 116, '2024-04-12 12:29:48', NULL),
(975, 116, '2024-04-12 12:29:48', NULL),
(976, 116, '2024-04-12 12:29:48', NULL),
(977, 116, '2024-05-24 10:20:01', NULL),
(978, 116, '2024-05-24 10:20:01', NULL),
(979, 126, '2024-05-24 10:20:01', NULL),
(980, 116, '2024-05-24 10:20:01', NULL),
(981, 126, '2024-05-24 10:20:01', NULL),
(982, 116, '2024-05-24 10:20:01', NULL),
(983, 116, '2024-05-24 10:20:01', NULL),
(984, 116, '2024-05-24 10:20:01', NULL),
(985, 116, '2024-05-24 10:20:01', NULL),
(986, 116, '2024-05-24 10:20:01', NULL),
(987, 116, '2024-05-24 10:20:01', NULL),
(988, 116, '2024-05-24 10:20:01', NULL),
(989, 116, '2024-05-24 10:20:01', NULL),
(990, 116, '2024-05-24 10:20:01', NULL),
(991, 116, '2024-05-24 10:20:01', NULL),
(992, 116, '2024-05-24 10:20:01', NULL),
(993, 116, '2024-05-24 10:20:01', NULL),
(994, 116, '2024-05-24 10:20:01', NULL),
(995, 124, '2024-05-24 10:20:01', NULL),
(996, 126, '2024-05-24 10:20:01', NULL),
(997, 124, '2024-05-24 10:20:01', NULL),
(998, 126, '2024-05-24 10:20:01', NULL),
(999, 126, '2024-05-24 10:20:01', NULL),
(1000, 126, '2024-05-24 10:20:01', NULL),
(1001, 126, '2024-05-24 10:20:01', NULL),
(1002, 126, '2024-05-24 10:20:01', NULL),
(1003, 126, '2024-05-24 10:20:01', NULL),
(1004, 116, '2024-05-24 10:20:01', NULL),
(1005, 116, '2024-05-24 10:20:01', NULL),
(1006, 116, '2024-05-24 10:20:01', NULL),
(1007, 126, '2024-05-24 10:20:01', NULL),
(1008, 126, '2024-05-24 10:20:01', NULL),
(1009, 126, '2024-05-24 10:20:01', NULL),
(1010, 129, '2024-05-24 10:20:01', NULL),
(1011, 129, '2024-05-24 10:20:01', NULL),
(1012, 129, '2024-05-24 10:20:01', NULL),
(1013, 116, '2024-05-24 10:20:01', NULL),
(1014, 116, '2024-05-24 10:20:01', NULL),
(1015, 126, '2024-05-24 10:20:01', NULL),
(1016, 126, '2024-05-24 10:20:01', NULL),
(1017, 126, '2024-06-06 17:31:24', NULL),
(1018, 126, '2024-06-06 17:31:24', NULL),
(1019, 126, '2024-06-06 17:32:59', NULL),
(1020, 126, '2024-06-06 17:32:59', NULL),
(1021, 126, '2024-06-06 17:32:59', NULL),
(1022, 126, '2024-06-06 17:32:59', NULL),
(1023, 126, '2024-06-06 17:32:59', NULL),
(1024, 116, '2024-05-24 10:20:01', NULL),
(1025, 126, '2024-06-06 17:32:59', NULL),
(1026, 126, '2024-06-06 17:32:59', NULL),
(1027, 126, '2024-06-06 17:32:59', NULL),
(1028, 126, '2024-06-06 17:32:59', NULL),
(1029, 116, '2024-05-24 10:20:01', NULL),
(1030, 126, '2024-06-06 17:32:59', NULL),
(1031, 126, '2024-06-07 10:00:16', NULL),
(1032, 126, '2024-06-07 10:00:16', NULL),
(1033, 126, '2024-06-07 10:16:20', NULL),
(1034, 126, '2024-06-07 10:29:02', NULL),
(1035, 126, '2024-06-07 10:30:42', NULL),
(1036, 126, '2024-06-07 10:30:42', NULL),
(1037, 126, '2024-06-07 11:36:08', NULL),
(1038, 126, '2024-06-07 11:39:52', NULL),
(1039, 126, '2024-06-07 11:39:52', NULL),
(1040, 126, '2024-06-07 11:56:44', NULL),
(1041, 131, '2024-06-07 12:21:43', NULL),
(1042, 126, '2024-06-07 11:56:44', NULL),
(1043, 126, '2024-06-07 13:32:03', NULL),
(1044, 126, '2024-06-07 13:32:03', NULL),
(1045, 126, '2024-06-07 13:32:03', NULL),
(1046, 126, '2024-06-07 14:34:50', NULL),
(1047, 132, '2024-05-24 10:20:01', NULL),
(1048, 132, '2024-06-07 15:38:26', NULL),
(1049, 126, '2024-06-10 16:16:46', NULL),
(1050, 126, '2024-06-10 20:18:54', NULL),
(1051, 126, '2024-06-11 09:45:56', NULL),
(1052, 126, '2024-06-11 09:45:56', NULL),
(1053, 116, '2024-05-24 10:20:01', NULL),
(1054, 126, '2024-06-11 09:45:56', NULL),
(1055, 126, '2024-06-11 09:45:56', NULL),
(1056, 126, '2024-05-24 10:20:01', NULL),
(1057, 126, '2024-06-11 11:36:25', NULL),
(1058, 126, '2024-06-11 11:42:20', NULL),
(1059, 133, '2024-05-24 10:20:01', NULL),
(1060, 134, '2024-05-24 10:20:01', NULL),
(1061, 134, '2024-05-24 10:20:01', NULL),
(1062, 134, '2024-05-24 10:20:01', NULL),
(1063, 134, '2024-05-24 10:20:01', NULL),
(1064, 134, '2024-05-24 10:20:01', NULL),
(1065, 134, '2024-05-24 10:20:01', NULL),
(1066, 135, '2024-05-24 10:20:01', NULL),
(1067, 136, '2024-05-24 10:20:01', NULL),
(1068, 135, '2024-05-24 10:20:01', NULL),
(1069, 136, '2024-05-24 10:20:01', NULL),
(1070, 136, '2024-05-24 10:20:01', NULL),
(1071, 135, '2024-05-24 10:20:01', NULL),
(1072, 135, '2024-05-24 10:20:01', NULL),
(1073, 135, '2024-05-24 10:20:01', NULL),
(1074, 136, '2024-05-24 10:20:01', NULL),
(1075, 136, '2024-05-24 10:20:01', NULL),
(1076, 135, '2024-05-24 10:20:01', NULL),
(1077, 134, '2024-05-24 10:20:01', NULL),
(1078, 133, '2024-05-24 10:20:01', NULL),
(1079, 137, '2024-05-24 10:20:01', NULL),
(1080, 137, '2024-05-24 10:20:01', NULL),
(1081, 137, '2024-05-24 10:20:01', NULL),
(1082, 137, '2024-05-24 10:20:01', NULL),
(1083, 137, '2024-05-24 10:20:01', NULL),
(1084, 126, '2024-05-24 10:20:01', NULL),
(1085, 126, '2024-05-24 10:20:01', NULL),
(1086, 126, '2024-05-24 10:20:01', NULL),
(1087, 126, '2024-05-24 10:20:01', NULL),
(1088, 126, '2024-05-24 10:20:01', NULL),
(1089, 126, '2024-06-11 11:42:20', NULL),
(1090, 116, '2024-05-24 10:20:01', NULL),
(1091, 126, '2024-06-11 11:42:20', NULL),
(1092, 126, '2024-05-24 10:20:01', NULL),
(1093, 126, '2024-05-24 10:20:01', NULL),
(1094, 139, '2024-06-11 11:42:20', NULL),
(1095, 139, '2024-06-11 11:42:20', NULL),
(1096, 139, '2024-06-11 11:42:20', NULL),
(1097, 139, '2024-06-11 11:42:20', NULL),
(1098, 139, '2024-06-11 11:42:20', NULL),
(1099, 139, '2024-06-11 11:42:20', NULL),
(1100, 139, '2024-06-11 11:42:20', NULL),
(1101, 139, '2024-06-11 11:42:20', NULL),
(1102, 139, '2024-06-11 11:42:20', NULL),
(1103, 139, '2024-06-11 11:42:20', NULL),
(1104, 139, '2024-06-11 11:42:20', NULL),
(1105, 139, '2024-06-11 11:42:20', NULL),
(1106, 139, '2024-06-11 11:42:20', NULL),
(1107, 139, '2024-06-11 11:42:20', NULL),
(1108, 139, '2024-06-11 11:42:20', NULL),
(1109, 139, '2024-06-11 11:42:20', NULL),
(1110, 139, '2024-06-11 11:42:20', NULL),
(1111, 140, '2024-06-11 11:42:20', NULL),
(1112, 140, '2024-06-11 11:42:20', NULL),
(1113, 139, '2024-06-12 11:10:45', NULL),
(1114, 139, '2024-06-12 11:10:45', NULL),
(1115, 126, '2024-06-12 11:10:45', NULL),
(1116, 139, '2024-06-12 12:26:32', NULL),
(1117, 116, '2024-05-24 10:20:01', NULL),
(1118, 116, '2024-05-24 10:20:01', NULL),
(1119, 133, '2024-05-24 10:20:01', NULL),
(1120, 126, '2024-05-24 10:20:01', NULL),
(1121, 139, '2024-06-12 12:55:33', NULL),
(1122, 140, '2024-06-12 12:55:33', NULL),
(1123, 139, '2024-06-12 12:55:33', NULL),
(1124, 126, '2024-06-12 12:55:33', NULL),
(1125, 139, '2024-06-12 12:55:33', NULL),
(1126, 139, '2024-06-12 12:55:33', NULL),
(1127, 139, '2024-06-12 20:03:42', NULL),
(1128, 139, '2024-06-12 20:03:42', NULL),
(1129, 126, '2024-05-24 10:20:01', NULL),
(1130, 139, '2024-06-12 20:03:42', NULL),
(1131, 139, '2024-05-24 10:20:01', NULL),
(1132, 129, '2024-05-24 10:20:01', NULL),
(1133, 129, '2024-05-24 10:20:01', NULL),
(1134, 139, '2024-06-13 13:27:46', NULL),
(1135, 139, '2024-06-13 13:27:46', NULL),
(1136, 139, '2024-06-13 13:27:46', NULL),
(1137, 139, '2024-06-13 13:27:46', NULL),
(1138, 139, '2024-06-13 13:27:46', NULL),
(1139, 116, '2024-05-24 10:20:01', NULL),
(1140, 139, '2024-06-14 10:35:21', NULL),
(1141, 126, '2024-05-24 10:20:01', NULL),
(1142, 126, '2024-05-24 10:20:01', NULL),
(1143, 126, '2024-05-24 10:20:01', NULL),
(1144, 139, '2024-05-24 10:20:01', NULL),
(1145, 126, '2024-05-24 10:20:01', NULL),
(1146, 139, '2024-06-14 10:35:21', NULL),
(1147, 126, '2024-05-24 10:20:01', NULL),
(1148, 126, '2024-05-24 10:20:01', NULL),
(1149, 126, '2024-05-24 10:20:01', NULL),
(1150, 126, '2024-05-24 10:20:01', NULL),
(1151, 126, '2024-05-24 10:20:01', NULL),
(1152, 139, '2024-06-14 10:35:21', NULL),
(1153, 139, '2024-06-14 10:35:21', NULL),
(1154, 139, '2024-06-14 16:39:38', NULL),
(1155, 126, '2024-06-14 16:39:38', NULL),
(1156, 140, '2024-06-14 16:39:38', NULL),
(1157, 139, '2024-06-14 16:39:38', NULL),
(1158, 139, '2024-06-14 16:39:38', NULL),
(1159, 139, '2024-06-14 16:39:38', NULL),
(1160, 139, '2024-06-14 16:39:38', NULL),
(1161, 139, '2024-06-14 16:39:38', NULL),
(1162, 139, '2024-06-14 16:39:38', NULL),
(1163, 139, '2024-06-14 16:39:38', NULL),
(1164, 139, '2024-06-14 16:39:38', NULL),
(1165, 139, '2024-06-14 16:39:38', NULL),
(1166, 139, '2024-06-14 16:39:38', NULL),
(1167, 139, '2024-06-14 16:39:38', NULL),
(1168, 139, '2024-06-14 16:39:38', NULL),
(1169, 139, '2024-06-14 16:39:38', NULL),
(1170, 139, '2024-06-14 16:39:38', NULL),
(1171, 139, '2024-06-14 16:39:38', NULL),
(1172, 139, '2024-06-14 16:39:38', NULL),
(1173, 126, '2024-05-24 10:20:01', NULL),
(1174, 126, '2024-05-24 10:20:01', NULL),
(1175, 139, '2024-06-14 16:39:38', NULL),
(1176, 131, '2024-05-24 10:20:01', NULL),
(1177, 126, '2024-05-24 10:20:01', NULL),
(1178, 126, '2024-05-24 10:20:01', NULL),
(1179, 133, '2024-05-24 10:20:01', NULL),
(1180, 133, '2024-05-24 10:20:01', NULL),
(1181, 133, '2024-05-24 10:20:01', NULL),
(1182, 139, '2024-06-17 16:17:06', NULL),
(1183, 139, '2024-05-24 10:20:01', NULL),
(1184, 139, '2024-06-17 16:17:06', NULL),
(1185, 133, '2024-05-24 10:20:01', NULL),
(1186, 139, '2024-06-17 16:17:06', NULL),
(1187, 139, '2024-05-24 10:20:01', NULL),
(1188, 139, '2024-06-17 16:17:06', NULL),
(1189, 139, '2024-06-17 16:17:06', NULL),
(1190, 139, '2024-06-17 17:50:15', NULL),
(1191, 139, '2024-06-17 18:08:45', NULL),
(1192, 139, '2024-06-17 18:08:45', NULL),
(1193, 140, '2024-06-17 18:08:45', NULL),
(1194, 139, '2024-06-17 18:14:11', NULL),
(1195, 133, '2024-05-24 10:20:01', NULL),
(1196, 126, '2024-05-24 10:20:01', NULL),
(1197, 133, '2024-05-24 10:20:01', NULL),
(1198, 133, '2024-05-24 10:20:01', NULL),
(1199, 133, '2024-05-24 10:20:01', NULL),
(1200, 126, '2024-05-24 10:20:01', NULL),
(1201, 133, '2024-05-24 10:20:01', NULL),
(1202, 133, '2024-05-24 10:20:01', NULL),
(1203, 126, '2024-05-24 10:20:01', NULL),
(1204, 126, '2024-06-18 16:35:08', NULL),
(1205, 139, '2024-06-18 16:35:08', NULL),
(1206, 126, '2024-06-18 16:35:08', NULL),
(1207, 126, '2024-06-18 16:35:08', NULL),
(1208, 126, '2024-06-18 16:35:08', NULL),
(1209, 126, '2024-06-18 16:35:08', NULL),
(1210, 126, '2024-06-18 16:35:08', NULL),
(1211, 139, '2024-06-18 16:35:08', NULL),
(1212, 126, '2024-06-18 16:35:08', NULL),
(1213, 139, '2024-06-18 16:35:08', NULL),
(1214, 139, '2024-06-18 16:35:08', NULL),
(1215, 139, '2024-06-19 11:02:27', NULL),
(1216, 126, '2024-06-19 11:02:27', NULL),
(1217, 139, '2024-06-19 11:30:41', NULL),
(1218, 139, '2024-06-19 12:52:11', NULL),
(1219, 126, '2024-06-19 12:52:11', NULL),
(1220, 126, '2024-05-24 10:20:01', NULL),
(1221, 126, '2024-06-19 12:52:11', NULL),
(1222, 126, '2024-06-19 12:52:11', NULL),
(1223, 126, '2024-06-19 12:52:11', NULL),
(1224, 126, '2024-06-19 12:52:11', NULL),
(1225, 126, '2024-06-19 12:52:11', NULL),
(1226, 139, '2024-06-19 12:52:11', NULL),
(1227, 126, '2024-06-19 12:52:11', NULL),
(1228, 139, '2024-06-19 12:52:11', NULL),
(1229, 126, '2024-06-19 12:52:11', NULL),
(1230, 126, '2024-06-20 10:38:41', NULL),
(1231, 126, '2024-06-20 10:38:41', NULL),
(1232, 126, '2024-06-20 10:38:41', NULL),
(1233, 126, '2024-06-20 10:38:41', NULL),
(1234, 139, '2024-06-20 10:38:41', NULL),
(1235, 139, '2024-06-20 10:38:41', NULL),
(1236, 126, '2024-06-20 10:38:41', NULL),
(1237, 139, '2024-06-20 10:38:41', NULL),
(1238, 139, '2024-06-20 10:38:41', NULL),
(1239, 139, '2024-06-20 10:38:41', NULL),
(1240, 139, '2024-06-20 10:38:41', NULL),
(1241, 139, '2024-06-20 10:38:41', NULL),
(1242, 139, '2024-06-20 10:38:41', NULL),
(1243, 126, '2024-06-20 10:38:41', NULL),
(1244, 139, '2024-06-20 10:38:41', NULL),
(1245, 126, '2024-06-20 10:38:41', NULL),
(1246, 116, '2024-05-24 10:20:01', NULL),
(1247, 139, '2024-06-20 10:38:41', NULL),
(1248, 139, '2024-06-20 10:38:41', NULL),
(1249, 139, '2024-06-20 10:38:41', NULL),
(1250, 139, '2024-06-20 10:38:41', NULL),
(1251, 126, '2024-05-24 10:20:01', NULL),
(1252, 139, '2024-06-20 20:24:53', NULL),
(1253, 124, '2024-06-20 20:24:53', NULL),
(1254, 126, '2024-06-20 20:24:53', NULL),
(1255, 126, '2024-06-20 20:24:53', NULL),
(1256, 126, '2024-06-20 20:24:53', NULL),
(1257, 139, '2024-06-20 20:24:53', NULL),
(1258, 139, '2024-06-20 20:23:39', NULL),
(1259, 126, '2024-06-20 20:23:39', NULL),
(1260, 139, '2024-06-20 20:23:39', NULL),
(1261, 139, '2024-06-20 20:23:39', NULL),
(1262, 139, '2024-06-20 20:23:39', NULL),
(1263, 126, '2024-06-20 20:23:39', NULL),
(1264, 126, '2024-06-20 20:23:39', NULL),
(1265, 139, '2024-06-20 20:23:39', NULL),
(1266, 139, '2024-06-20 20:23:39', NULL),
(1267, 139, '2024-06-20 20:23:39', NULL),
(1268, 139, '2024-06-20 20:23:39', NULL),
(1269, 139, '2024-06-20 20:23:39', NULL),
(1270, 139, '2024-06-20 20:23:39', NULL),
(1271, 139, '2024-06-20 20:23:39', NULL),
(1272, 139, '2024-06-20 20:23:39', NULL),
(1273, 139, '2024-06-20 20:23:39', NULL),
(1274, 126, '2024-06-20 20:23:39', NULL),
(1275, 140, '2024-06-20 20:23:39', NULL),
(1276, 139, '2024-06-20 20:23:39', NULL),
(1277, 126, '2024-06-20 20:23:39', NULL);
INSERT INTO `userlog` (`id`, `userid`, `lastlogin`, `logout`) VALUES
(1278, 139, '2024-06-20 20:23:39', NULL),
(1279, 126, '2024-06-20 20:23:39', NULL),
(1280, 140, '2024-06-21 15:09:14', NULL),
(1281, 139, '2024-06-20 20:24:53', NULL),
(1282, 139, '2024-06-20 20:24:53', NULL),
(1283, 140, '2024-06-20 20:24:53', NULL),
(1284, 126, '2024-06-20 20:24:53', NULL),
(1285, 139, '2024-06-20 20:24:53', NULL),
(1286, 139, '2024-06-20 20:24:53', NULL),
(1287, 126, '2024-06-20 20:24:53', NULL),
(1288, 140, '2024-06-20 20:24:53', NULL),
(1289, 139, '2024-06-20 20:24:53', NULL),
(1290, 126, '2024-06-20 20:24:53', NULL),
(1291, 139, '2024-06-20 20:24:53', NULL),
(1292, 126, '2024-06-20 20:24:53', NULL),
(1293, 126, '2024-06-20 20:24:53', NULL),
(1294, 139, '2024-06-21 17:02:12', NULL),
(1295, 126, '2024-06-21 17:02:12', NULL),
(1296, 126, '2024-06-21 17:11:00', NULL),
(1297, 139, '2024-06-21 17:11:00', NULL),
(1298, 139, '2024-06-21 17:11:00', NULL),
(1299, 126, '2024-06-21 17:02:12', NULL),
(1300, 139, '2024-06-21 17:02:12', NULL),
(1301, 126, '2024-06-21 17:02:12', NULL),
(1302, 126, '2024-06-21 17:02:12', NULL),
(1303, 139, '2024-06-21 17:02:12', NULL),
(1304, 126, '2024-06-21 17:02:12', NULL),
(1305, 139, '2024-06-21 17:02:12', NULL),
(1306, 139, '2024-06-21 17:02:12', NULL),
(1307, 139, '2024-06-21 17:02:12', NULL),
(1308, 139, '2024-06-21 18:59:47', NULL),
(1309, 139, '2024-06-21 17:11:00', NULL),
(1310, 126, '2024-06-21 17:11:00', NULL),
(1311, 139, '2024-06-21 17:11:00', NULL),
(1312, 139, '2024-06-21 18:59:47', NULL),
(1313, 139, '2024-06-21 17:11:00', NULL),
(1314, 139, '2024-06-21 17:11:00', NULL),
(1315, 126, '2024-06-21 17:11:00', NULL),
(1316, 139, '2024-06-22 10:56:20', NULL),
(1317, 126, '2024-06-22 10:56:20', NULL),
(1318, 139, '2024-06-21 17:11:00', NULL),
(1319, 126, '2024-06-22 10:56:20', NULL),
(1320, 139, '2024-06-22 10:56:20', NULL),
(1321, 139, '2024-06-21 17:11:00', NULL),
(1322, 126, '2024-06-21 17:11:00', NULL),
(1323, 126, '2024-06-21 17:11:00', NULL),
(1324, 139, '2024-06-22 10:56:20', NULL),
(1325, 126, '2024-06-22 12:29:33', NULL),
(1326, 126, '2024-06-22 12:27:32', NULL),
(1327, 126, '2024-06-22 12:29:33', NULL),
(1328, 126, '2024-06-22 12:29:33', NULL),
(1329, 126, '2024-06-22 12:29:33', NULL),
(1330, 139, '2024-06-22 12:29:33', NULL),
(1331, 139, '2024-06-22 12:27:32', NULL),
(1332, 139, '2024-06-22 12:29:33', NULL),
(1333, 126, '2024-06-22 12:29:33', NULL),
(1334, 126, '2024-06-22 12:29:33', NULL),
(1335, 140, '2024-06-22 12:29:33', NULL),
(1336, 139, '2024-06-22 12:29:33', NULL),
(1337, 126, '2024-06-22 12:29:33', NULL),
(1338, 139, '2024-06-22 12:29:33', NULL),
(1339, 126, '2024-06-22 12:29:33', NULL),
(1340, 140, '2024-06-22 12:29:33', NULL),
(1341, 139, '2024-06-22 12:29:33', NULL),
(1342, 139, '2024-06-22 12:29:33', NULL),
(1343, 126, '2024-06-22 12:29:33', NULL),
(1344, 140, '2024-06-22 12:29:33', NULL),
(1345, 126, '2024-06-22 12:29:33', NULL),
(1346, 140, '2024-06-22 12:29:33', NULL),
(1347, 126, '2024-06-22 12:29:33', NULL),
(1348, 140, '2024-06-22 12:29:33', NULL),
(1349, 139, '2024-06-22 12:29:33', NULL),
(1350, 139, '2024-06-22 12:27:32', NULL),
(1351, 139, '2024-06-22 12:29:33', NULL),
(1352, 139, '2024-06-22 12:29:33', NULL),
(1353, 126, '2024-06-22 19:55:20', NULL),
(1354, 139, '2024-06-22 19:55:20', NULL),
(1355, 140, '2024-06-22 19:55:20', NULL),
(1356, 126, '2024-06-22 19:55:20', NULL),
(1357, 126, '2024-06-22 19:55:20', NULL),
(1358, 139, '2024-06-22 19:55:20', NULL),
(1359, 140, '2024-06-22 19:55:20', NULL),
(1360, 126, '2024-06-22 19:55:20', NULL),
(1361, 139, '2024-06-22 19:55:20', NULL),
(1362, 140, '2024-06-22 19:55:20', NULL),
(1363, 126, '2024-06-22 19:55:20', NULL),
(1364, 139, '2024-06-22 19:55:20', NULL),
(1365, 139, '2024-06-22 19:55:20', NULL),
(1366, 139, '2024-06-22 19:55:20', NULL),
(1367, 139, '2024-06-22 19:55:20', NULL),
(1368, 126, '2024-06-22 19:55:20', NULL),
(1369, 126, '2024-06-22 19:55:20', NULL),
(1370, 126, '2024-06-22 19:55:20', NULL),
(1371, 126, '2024-06-22 12:27:32', NULL),
(1372, 139, '2024-06-22 19:55:20', NULL),
(1373, 126, '2024-06-22 19:55:20', NULL),
(1374, 139, '2024-06-22 19:55:20', NULL),
(1375, 126, '2024-06-22 19:55:20', NULL),
(1376, 126, '2024-06-22 19:55:20', NULL),
(1377, 139, '2024-06-22 19:55:20', NULL),
(1378, 126, '2024-06-22 12:27:32', NULL),
(1379, 126, '2024-06-22 19:55:20', NULL),
(1380, 140, '2024-06-22 19:55:20', NULL),
(1381, 126, '2024-06-22 19:55:20', NULL),
(1382, 139, '2024-06-22 12:27:32', NULL),
(1383, 139, '2024-06-22 12:27:32', NULL),
(1384, 139, '2024-06-22 12:27:32', NULL),
(1385, 149, '2024-06-22 12:27:32', NULL),
(1386, 139, '2024-06-22 12:27:32', NULL),
(1387, 150, '2024-06-22 12:27:32', NULL),
(1388, 151, '2024-06-22 12:27:32', NULL),
(1389, 126, '2024-06-22 19:55:20', NULL),
(1390, 126, '2024-06-22 19:55:20', NULL),
(1391, 126, '2024-06-22 12:27:32', NULL),
(1392, 139, '2024-06-22 12:27:32', NULL),
(1393, 139, '2024-06-22 12:27:32', NULL),
(1394, 140, '2024-06-22 12:27:32', NULL),
(1395, 140, '2024-06-22 12:27:32', NULL),
(1396, 126, '2024-06-22 12:27:32', NULL),
(1397, 140, '2024-06-22 19:55:20', NULL),
(1398, 126, '2024-06-22 12:27:32', NULL),
(1399, 126, '2024-06-22 12:27:32', NULL),
(1400, 152, '2024-06-22 12:27:32', NULL),
(1401, 116, '2024-06-22 19:55:20', NULL),
(1402, 126, '2024-06-22 19:55:20', NULL),
(1403, 126, '2024-06-25 12:50:03', NULL),
(1404, 154, '2024-06-25 12:50:03', NULL),
(1405, 116, '2024-06-22 19:55:20', NULL),
(1406, 154, '2024-06-25 12:50:03', NULL),
(1407, 154, '2024-06-25 13:31:51', NULL),
(1408, 154, '2024-06-25 13:31:51', NULL),
(1409, 154, '2024-06-25 13:31:51', NULL),
(1410, 153, '2024-06-25 13:31:51', NULL),
(1411, 154, '2024-06-25 13:31:51', NULL),
(1412, 154, '2024-06-25 13:31:51', NULL),
(1413, 154, '2024-06-25 13:31:51', NULL),
(1414, 155, '2024-06-25 13:31:51', NULL),
(1415, 154, '2024-06-25 13:31:51', NULL),
(1416, 154, '2024-06-25 13:31:51', NULL),
(1417, 154, '2024-06-25 13:31:51', NULL),
(1418, 155, '2024-06-25 13:31:51', NULL),
(1419, 154, '2024-06-25 13:31:51', NULL),
(1420, 155, '2024-06-25 13:31:51', NULL),
(1421, 154, '2024-06-25 13:31:51', NULL),
(1422, 154, '2024-06-25 13:31:51', NULL),
(1423, 154, '2024-06-25 13:31:51', NULL),
(1424, 154, '2024-06-25 13:31:51', NULL),
(1425, 154, '2024-06-25 13:31:51', NULL),
(1426, 154, '2024-06-25 13:31:51', NULL),
(1427, 154, '2024-06-25 13:31:51', NULL),
(1428, 154, '2024-06-25 13:31:51', NULL),
(1429, 154, '2024-06-25 13:31:51', NULL),
(1430, 154, '2024-06-25 13:31:51', NULL),
(1431, 116, '2024-06-22 19:55:20', NULL),
(1432, 154, '2024-06-27 13:07:14', NULL),
(1433, 154, '2024-06-27 13:07:14', NULL),
(1434, 154, '2024-06-27 13:07:14', NULL),
(1435, 154, '2024-06-27 13:07:14', NULL),
(1436, 155, '2024-06-27 13:07:14', NULL),
(1437, 155, '2024-06-27 13:07:14', NULL),
(1438, 154, '2024-06-27 13:07:14', NULL),
(1439, 155, '2024-06-27 13:07:14', NULL),
(1440, 155, '2024-06-27 13:07:14', NULL),
(1441, 155, '2024-06-27 13:07:14', NULL),
(1442, 155, '2024-06-27 13:07:14', NULL),
(1443, 155, '2024-06-27 13:07:14', NULL),
(1444, 155, '2024-06-27 13:07:14', NULL),
(1445, 156, '2024-06-27 13:07:14', NULL),
(1446, 155, '2024-06-27 13:07:14', NULL),
(1447, 156, '2024-06-27 13:07:14', NULL),
(1448, 156, '2024-06-27 13:07:14', NULL),
(1449, 155, '2024-06-27 13:07:14', NULL),
(1450, 156, '2024-06-27 13:07:14', NULL),
(1451, 155, '2024-06-27 13:07:14', NULL),
(1452, 155, '2024-06-27 13:07:14', NULL),
(1453, 155, '2024-06-28 08:12:20', NULL),
(1454, 155, '2024-06-28 08:12:20', NULL),
(1455, 154, '2024-06-28 08:12:20', NULL),
(1456, 153, '2024-06-28 08:12:20', NULL),
(1457, 157, '2024-06-28 08:12:20', NULL),
(1458, 153, '2024-06-28 08:12:20', NULL),
(1459, 155, '2024-06-28 08:12:20', NULL),
(1460, 155, '2024-06-28 08:12:20', NULL),
(1461, 153, '2024-06-28 08:12:20', NULL),
(1462, 155, '2024-06-28 08:12:20', NULL),
(1463, 153, '2024-06-28 08:12:20', NULL),
(1464, 155, '2024-06-28 08:12:20', NULL),
(1465, 155, '2024-06-28 08:12:20', NULL),
(1466, 155, '2024-06-28 08:12:20', NULL),
(1467, 155, '2024-06-28 08:12:20', NULL),
(1468, 155, '2024-06-28 08:12:20', NULL),
(1469, 155, '2024-06-28 08:12:20', NULL),
(1470, 155, '2024-06-28 08:12:20', NULL),
(1471, 155, '2024-06-28 08:12:20', NULL),
(1472, 155, '2024-06-28 08:12:20', NULL),
(1473, 153, '2024-06-22 19:55:20', NULL),
(1474, 116, '2024-06-22 19:55:20', NULL),
(1475, 116, '2024-06-22 19:55:20', NULL),
(1476, 154, '2024-06-30 19:47:53', NULL),
(1477, 154, '2024-07-01 09:59:21', NULL),
(1478, 154, '2024-07-01 09:59:21', NULL),
(1479, 154, '2024-06-22 19:55:20', NULL),
(1480, 154, '2024-07-01 09:59:21', NULL),
(1481, 154, '2024-07-01 09:59:21', NULL),
(1482, 154, '2024-07-01 09:59:21', NULL),
(1483, 154, '2024-07-01 09:59:21', NULL),
(1484, 154, '2024-07-01 09:59:21', NULL),
(1485, 154, '2024-07-01 09:59:21', NULL),
(1486, 154, '2024-07-01 09:59:21', NULL),
(1487, 154, '2024-07-01 09:59:21', NULL),
(1488, 154, '2024-07-01 09:59:21', NULL),
(1489, 116, '2024-06-22 19:55:20', NULL),
(1490, 116, '2024-06-22 19:55:20', NULL),
(1491, 116, '2024-06-22 19:55:20', NULL),
(1492, 116, '2024-06-22 19:55:20', NULL),
(1493, 116, '2024-06-22 19:55:20', NULL),
(1494, 154, '2024-07-01 09:59:21', NULL),
(1495, 154, '2024-07-01 09:59:21', NULL),
(1496, 154, '2024-07-01 09:59:21', NULL),
(1497, 154, '2024-07-01 09:59:21', NULL),
(1498, 153, '2024-07-01 09:59:21', NULL),
(1499, 154, '2024-07-01 09:59:21', NULL),
(1500, 153, '2024-07-01 09:59:21', NULL),
(1501, 154, '2024-07-01 09:59:21', NULL),
(1502, 154, '2024-06-22 19:55:20', NULL),
(1503, 153, '2024-06-22 19:55:20', NULL),
(1504, 154, '2024-06-22 19:55:20', NULL),
(1505, 154, '2024-06-22 19:55:20', NULL),
(1506, 154, '2024-07-02 09:53:20', NULL),
(1507, 153, '2024-07-02 09:53:20', NULL),
(1508, 153, '2024-07-02 10:21:01', NULL),
(1509, 153, '2024-07-02 10:21:01', NULL),
(1510, 116, '2024-06-22 19:55:20', NULL),
(1511, 153, '2024-07-02 10:21:01', NULL),
(1512, 153, '2024-07-02 10:21:01', NULL),
(1513, 153, '2024-07-02 10:21:01', NULL),
(1514, 153, '2024-07-02 10:21:01', NULL),
(1515, 153, '2024-07-02 10:21:01', NULL),
(1516, 153, '2024-07-02 10:21:01', NULL),
(1517, 154, '2024-07-02 10:21:01', NULL),
(1518, 153, '2024-07-02 10:21:01', NULL),
(1519, 153, '2024-07-02 10:21:01', NULL),
(1520, 153, '2024-07-02 10:21:01', NULL),
(1521, 153, '2024-07-02 10:21:01', NULL),
(1522, 153, '2024-07-02 10:21:01', NULL),
(1523, 153, '2024-07-02 10:21:01', NULL),
(1524, 153, '2024-07-02 10:21:01', NULL),
(1525, 153, '2024-07-02 10:21:01', NULL),
(1526, 126, '2024-06-22 19:55:20', NULL),
(1527, 153, '2024-07-02 10:21:01', NULL),
(1528, 153, '2024-07-02 10:21:01', NULL),
(1529, 153, '2024-07-02 10:21:01', NULL),
(1530, 153, '2024-07-02 10:21:01', NULL),
(1531, 153, '2024-07-02 10:21:01', NULL),
(1532, 153, '2024-07-02 10:21:01', NULL),
(1533, 153, '2024-07-02 10:21:01', NULL),
(1534, 153, '2024-07-02 10:21:01', NULL),
(1535, 153, '2024-07-02 10:21:01', NULL),
(1536, 153, '2024-07-02 10:21:01', NULL),
(1537, 153, '2024-07-02 10:21:01', NULL),
(1538, 153, '2024-07-02 10:21:01', NULL),
(1539, 153, '2024-07-02 10:21:01', NULL),
(1540, 153, '2024-07-02 10:21:01', NULL),
(1541, 153, '2024-07-02 10:21:01', NULL),
(1542, 153, '2024-07-02 10:21:01', NULL),
(1543, 153, '2024-07-02 10:21:01', NULL),
(1544, 153, '2024-07-02 10:21:01', NULL),
(1545, 153, '2024-07-02 10:21:01', NULL),
(1546, 153, '2024-07-02 10:21:01', NULL),
(1547, 153, '2024-07-02 10:21:01', NULL),
(1548, 153, '2024-07-02 10:21:01', NULL),
(1549, 153, '2024-07-02 10:21:01', NULL),
(1550, 133, '2024-06-22 19:55:20', NULL),
(1551, 153, '2024-07-02 10:21:01', NULL),
(1552, 153, '2024-07-02 10:21:01', NULL),
(1553, 153, '2024-07-02 10:21:01', NULL),
(1554, 153, '2024-07-02 10:21:01', NULL),
(1555, 153, '2024-07-02 10:21:01', NULL),
(1556, 153, '2024-07-02 10:21:01', NULL),
(1557, 153, '2024-07-04 23:55:43', NULL),
(1558, 153, '2024-07-04 23:55:43', NULL),
(1559, 153, '2024-06-22 19:55:20', NULL),
(1560, 153, '2024-07-05 09:57:20', NULL),
(1561, 153, '2024-07-05 09:57:20', NULL),
(1562, 153, '2024-07-05 09:57:20', NULL),
(1563, 116, '2024-06-22 19:55:20', NULL),
(1564, 153, '2024-07-05 09:57:20', NULL),
(1565, 153, '2024-07-05 09:57:20', NULL),
(1566, 133, '2024-06-22 19:55:20', NULL),
(1567, 153, '2024-07-05 09:57:20', NULL),
(1568, 153, '2024-07-05 09:57:20', NULL),
(1569, 153, '2024-07-05 09:57:20', NULL),
(1570, 133, '2024-06-22 19:55:20', NULL),
(1571, 153, '2024-07-05 09:57:20', NULL),
(1572, 153, '2024-07-05 09:57:20', NULL),
(1573, 153, '2024-07-05 09:57:20', NULL),
(1574, 153, '2024-07-05 09:57:20', NULL),
(1575, 153, '2024-07-05 09:57:20', NULL),
(1576, 153, '2024-07-05 09:57:20', NULL),
(1577, 116, '2024-06-22 19:55:20', NULL),
(1578, 116, '2024-06-22 19:55:20', NULL),
(1579, 153, '2024-07-05 09:57:20', NULL),
(1580, 154, '2024-07-05 09:57:20', NULL),
(1581, 154, '2024-07-05 09:57:20', NULL),
(1582, 155, '2024-07-05 09:57:20', NULL),
(1583, 153, '2024-07-05 09:57:20', NULL),
(1584, 153, '2024-07-05 09:57:20', NULL),
(1585, 153, '2024-07-05 09:57:20', NULL),
(1586, 153, '2024-06-22 19:55:20', NULL),
(1587, 153, '2024-06-22 19:55:20', NULL),
(1588, 153, '2024-06-22 19:55:20', NULL),
(1589, 153, '2024-06-22 19:55:20', NULL),
(1590, 153, '2024-06-22 19:55:20', NULL),
(1591, 153, '2024-06-22 19:55:20', NULL),
(1592, 116, '2024-06-22 19:55:20', NULL),
(1593, 116, '2024-06-22 19:55:20', NULL),
(1594, 116, '2024-06-22 19:55:20', NULL),
(1595, 116, '2024-06-22 19:55:20', NULL),
(1596, 116, '2024-06-22 19:55:20', NULL),
(1597, 116, '2024-06-22 19:55:20', NULL),
(1598, 116, '2024-06-22 19:55:20', NULL),
(1599, 116, '2024-08-06 15:57:53', NULL),
(1600, 116, '2024-08-06 15:57:53', NULL),
(1601, 116, '2024-08-06 15:57:53', NULL),
(1602, 116, '2024-08-06 15:57:53', NULL),
(1603, 116, '2024-08-07 10:21:13', NULL),
(1604, 116, '2024-08-07 10:21:13', NULL),
(1605, 116, '2024-08-07 10:21:13', NULL),
(1606, 116, '2024-08-07 16:44:09', NULL),
(1607, 116, '2024-08-07 16:44:09', NULL),
(1608, 116, '2024-08-07 16:44:09', NULL),
(1609, 116, '2024-08-07 16:44:09', NULL),
(1610, 116, '2024-08-07 16:44:09', NULL),
(1611, 116, '2024-08-08 18:10:39', NULL),
(1612, 116, '2024-08-08 18:10:39', NULL),
(1613, 116, '2024-08-10 10:39:52', NULL),
(1614, 116, '2024-08-10 10:39:52', NULL),
(1615, 116, '2024-08-10 10:39:52', NULL),
(1616, 116, '2024-08-10 10:39:52', NULL),
(1617, 116, '2024-08-10 10:39:52', NULL),
(1618, 116, '2024-08-10 10:39:52', NULL),
(1619, 116, '2024-08-10 10:39:52', NULL),
(1620, 116, '2024-08-12 11:37:48', NULL),
(1621, 116, '2024-08-12 11:37:48', NULL),
(1622, 116, '2024-08-12 16:58:19', NULL),
(1623, 116, '2024-08-12 16:58:19', NULL),
(1624, 116, '2024-06-22 19:55:20', NULL),
(1625, 116, '2024-06-22 19:55:20', NULL),
(1626, 116, '2024-08-12 16:58:19', NULL),
(1627, 116, '2024-06-22 19:55:20', NULL),
(1628, 116, '2024-08-13 11:07:21', NULL),
(1629, 116, '2024-08-13 11:07:21', NULL),
(1630, 116, '2024-08-13 11:07:21', NULL),
(1631, 116, '2024-08-13 11:07:21', NULL),
(1632, 116, '2024-08-13 11:07:21', NULL),
(1633, 116, '2024-08-13 11:07:21', NULL),
(1634, 116, '2024-08-13 11:07:21', NULL),
(1635, 116, '2024-08-13 11:07:21', NULL),
(1636, 116, '2024-08-13 11:07:21', NULL),
(1637, 116, '2024-08-13 11:07:21', NULL),
(1638, 116, '2024-08-13 11:07:21', NULL),
(1639, 116, '2024-08-14 11:41:51', NULL),
(1640, 116, '2024-08-14 11:41:51', NULL),
(1641, 116, '2024-08-14 11:41:51', NULL),
(1642, 116, '2024-08-14 11:41:51', NULL),
(1643, 116, '2024-08-14 11:41:51', NULL),
(1644, 116, '2024-08-14 11:41:51', NULL),
(1645, 116, '2024-08-14 11:41:51', NULL),
(1646, 116, '2024-08-14 11:41:51', NULL),
(1647, 116, '2024-08-14 11:41:51', NULL),
(1648, 116, '2024-08-14 11:41:51', NULL),
(1649, 116, '2024-08-14 11:41:51', NULL),
(1650, 116, '2024-08-14 11:41:51', NULL),
(1651, 116, '2024-08-15 10:25:23', NULL),
(1652, 116, '2024-08-15 10:25:23', NULL),
(1653, 116, '2024-08-15 10:25:23', NULL),
(1654, 116, '2024-08-15 10:25:23', NULL),
(1655, 116, '2024-08-15 10:25:23', NULL),
(1656, 116, '2024-08-15 10:25:23', NULL),
(1657, 116, '2024-08-15 10:25:23', NULL),
(1658, 116, '2024-08-15 10:25:23', NULL),
(1659, 116, '2024-08-15 10:25:23', NULL),
(1660, 116, '2024-08-23 15:37:49', NULL),
(1661, 116, '2024-08-23 15:37:49', NULL),
(1662, 126, '2024-06-22 19:55:20', NULL),
(1663, 126, '2024-06-22 19:55:20', NULL),
(1664, 116, '2024-08-26 10:14:33', NULL),
(1665, 116, '2024-08-26 10:14:33', NULL),
(1666, 126, '2024-06-22 19:55:20', NULL),
(1667, 116, '2024-08-26 10:14:33', NULL),
(1668, 116, '2024-08-26 10:14:33', NULL),
(1669, 116, '2024-08-26 10:14:33', NULL),
(1670, 116, '2024-08-26 10:14:33', NULL),
(1671, 116, '2024-08-26 10:14:33', NULL),
(1672, 116, '2024-08-26 10:14:33', NULL),
(1673, 116, '2024-08-26 10:14:33', NULL),
(1674, 116, '2024-08-26 10:14:33', NULL),
(1675, 116, '2024-08-26 10:14:33', NULL),
(1676, 126, '2024-08-26 10:14:33', NULL),
(1677, 116, '2024-08-26 10:14:33', NULL),
(1678, 116, '2024-06-22 19:55:20', NULL),
(1679, 116, '2024-08-26 10:14:33', NULL),
(1680, 116, '2024-08-26 10:14:33', NULL),
(1681, 116, '2024-08-26 10:14:33', NULL),
(1682, 116, '2024-08-26 10:14:33', NULL),
(1683, 116, '2024-08-26 10:14:33', NULL),
(1684, 116, '2024-08-26 10:14:33', NULL),
(1685, 116, '2024-08-26 17:03:50', NULL),
(1686, 116, '2024-08-26 17:03:50', NULL),
(1687, 116, '2024-08-26 17:03:50', NULL),
(1688, 116, '2024-08-26 17:03:50', NULL),
(1689, 116, '2024-08-26 18:37:58', NULL),
(1690, 116, '2024-08-26 18:37:58', NULL),
(1691, 116, '2024-08-27 10:18:32', NULL),
(1692, 116, '2024-08-27 10:18:32', NULL),
(1693, 116, '2024-08-27 10:18:32', NULL),
(1694, 126, '2024-06-22 19:55:20', NULL),
(1695, 116, '2024-08-27 10:18:32', NULL),
(1696, 126, '2024-06-22 19:55:20', NULL),
(1697, 116, '2024-08-27 13:01:31', NULL),
(1698, 116, '2024-08-28 13:00:08', NULL),
(1699, 126, '2024-06-22 19:55:20', NULL),
(1700, 126, '2024-06-22 19:55:20', NULL),
(1701, 126, '2024-06-22 19:55:20', NULL),
(1702, 126, '2024-08-29 09:37:34', NULL),
(1703, 126, '2024-08-29 09:56:32', NULL),
(1704, 126, '2024-08-29 09:59:33', NULL),
(1705, 116, '2024-06-22 19:55:20', NULL),
(1706, 126, '2024-06-22 19:55:20', NULL),
(1707, 126, '2024-08-29 09:59:33', NULL),
(1708, 126, '2024-08-29 09:59:33', NULL),
(1709, 126, '2024-08-29 09:59:33', NULL),
(1710, 126, '2024-08-29 09:59:33', NULL),
(1711, 126, '2024-08-29 09:59:33', NULL),
(1712, 126, '2024-08-29 09:59:33', NULL),
(1713, 116, '2024-08-29 14:01:34', NULL),
(1714, 126, '2024-08-29 14:01:34', NULL),
(1715, 116, '2024-08-29 14:01:34', NULL),
(1716, 116, '2024-08-29 14:01:34', NULL),
(1717, 116, '2024-08-29 14:01:34', NULL),
(1718, 126, '2024-06-22 19:55:20', NULL),
(1719, 126, '2024-08-29 14:01:34', NULL),
(1720, 126, '2024-08-29 14:01:34', NULL),
(1721, 116, '2024-08-30 11:14:11', NULL),
(1722, 126, '2024-08-30 11:14:06', NULL),
(1723, 126, '2024-08-30 11:14:06', NULL),
(1724, 116, '2024-08-30 11:14:11', NULL),
(1725, 126, '2024-08-30 11:14:06', NULL),
(1726, 126, '2024-06-22 19:55:20', NULL),
(1727, 126, '2024-06-22 19:55:20', NULL),
(1728, 126, '2024-06-22 19:55:20', NULL),
(1729, 116, '2024-08-30 11:14:11', NULL),
(1730, 116, '2024-08-30 11:14:11', NULL),
(1731, 116, '2024-08-30 11:14:11', NULL),
(1732, 116, '2024-08-30 11:14:11', NULL),
(1733, 126, '2024-06-22 19:55:20', NULL),
(1734, 126, '2024-06-22 19:55:20', NULL),
(1735, 126, '2024-06-22 19:55:20', NULL),
(1736, 126, '2024-06-22 19:55:20', NULL),
(1737, 126, '2024-06-22 19:55:20', NULL),
(1738, 126, '2024-06-22 19:55:20', NULL),
(1739, 126, '2024-06-22 19:55:20', NULL),
(1740, 126, '2024-08-30 11:14:06', NULL),
(1741, 126, '2024-06-22 19:55:20', NULL),
(1742, 126, '2024-09-02 11:05:55', NULL),
(1743, 126, '2024-09-02 11:05:55', NULL),
(1744, 126, '2024-09-02 11:36:10', NULL),
(1745, 126, '2024-06-22 19:55:20', NULL),
(1746, 126, '2024-09-02 12:40:05', NULL),
(1747, 126, '2024-09-02 12:53:53', NULL),
(1748, 126, '2024-06-22 19:55:20', NULL),
(1749, 126, '2024-09-02 12:57:48', NULL),
(1750, 126, '2024-09-02 12:57:48', NULL),
(1751, 126, '2024-09-02 12:57:48', NULL),
(1752, 126, '2024-09-02 17:43:02', NULL),
(1753, 126, '2024-06-22 19:55:20', NULL),
(1754, 126, '2024-09-03 10:43:47', NULL),
(1755, 126, '2024-09-03 10:43:47', NULL),
(1756, 126, '2024-09-03 10:43:47', NULL),
(1757, 126, '2024-09-03 10:43:47', NULL),
(1758, 126, '2024-09-03 10:43:47', NULL),
(1759, 126, '2024-09-03 10:43:47', NULL),
(1760, 126, '2024-09-03 10:43:47', NULL),
(1761, 126, '2024-09-03 10:43:47', NULL),
(1762, 126, '2024-09-03 10:43:47', NULL),
(1763, 126, '2024-06-22 19:55:20', NULL),
(1764, 126, '2024-06-22 19:55:20', NULL),
(1765, 126, '2024-06-22 19:55:20', NULL),
(1766, 126, '2024-06-22 19:55:20', NULL),
(1767, 126, '2024-06-22 19:55:20', NULL),
(1768, 126, '2024-06-22 19:55:20', NULL),
(1769, 160, '2024-06-22 19:55:20', NULL),
(1770, 126, '2024-06-22 19:55:20', NULL),
(1771, 161, '2024-09-04 12:06:47', NULL),
(1772, 161, '2024-09-04 12:06:47', NULL),
(1773, 126, '2024-09-04 12:06:47', NULL),
(1774, 126, '2024-06-22 19:55:20', NULL),
(1775, 161, '2024-09-04 12:06:47', NULL),
(1776, 126, '2024-09-04 12:06:47', NULL),
(1777, 162, '2024-09-04 12:06:47', NULL),
(1778, 162, '2024-09-04 12:06:47', NULL),
(1779, 162, '2024-09-04 12:06:47', NULL),
(1780, 126, '2024-09-04 12:06:47', NULL),
(1781, 162, '2024-06-22 19:55:20', NULL),
(1782, 161, '2024-09-04 16:35:20', NULL),
(1783, 126, '2024-09-04 16:35:20', NULL),
(1784, 163, '2024-09-04 16:35:20', NULL),
(1785, 126, '2024-06-22 19:55:20', NULL),
(1786, 126, '2024-09-04 16:35:20', NULL),
(1787, 140, '2024-09-04 16:35:20', NULL),
(1788, 126, '2024-09-04 16:35:20', NULL),
(1789, 126, '2024-09-04 16:35:20', NULL),
(1790, 126, '2024-09-04 17:53:19', NULL),
(1791, 126, '2024-09-04 18:01:57', NULL),
(1792, 164, '2024-09-04 23:47:35', NULL),
(1793, 126, '2024-09-04 23:47:35', NULL),
(1794, 126, '2024-09-04 23:47:35', NULL),
(1795, 126, '2024-09-04 23:47:35', NULL),
(1796, 126, '2024-09-04 23:47:35', NULL),
(1797, 126, '2024-06-22 19:55:20', NULL),
(1798, 126, '2024-09-04 23:47:35', NULL),
(1799, 126, '2024-06-22 19:55:20', NULL),
(1800, 126, '2024-06-22 19:55:20', NULL),
(1801, 165, '2024-09-05 10:56:15', NULL),
(1802, 165, '2024-09-05 10:56:15', NULL),
(1803, 165, '2024-06-22 19:55:20', NULL),
(1804, 126, '2024-09-05 10:56:15', NULL),
(1805, 126, '2024-09-05 11:23:10', NULL),
(1806, 126, '2024-09-05 12:29:28', NULL),
(1807, 165, '2024-09-05 12:29:28', NULL),
(1808, 126, '2024-09-05 12:29:28', NULL),
(1809, 126, '2024-06-22 19:55:20', NULL),
(1810, 126, '2024-09-05 12:29:28', NULL),
(1811, 126, '2024-09-05 12:29:28', NULL),
(1812, 126, '2024-09-05 12:29:28', NULL),
(1813, 126, '2024-09-05 12:29:28', NULL),
(1814, 126, '2024-09-05 15:51:24', NULL),
(1815, 126, '2024-09-05 15:51:24', NULL),
(1816, 165, '2024-09-05 15:51:24', NULL),
(1817, 126, '2024-09-05 17:02:40', NULL),
(1818, 126, '2024-09-05 17:02:40', NULL),
(1819, 126, '2024-09-05 15:51:24', NULL),
(1820, 126, '2024-09-05 15:51:24', NULL),
(1821, 126, '2024-09-05 17:20:30', NULL),
(1822, 126, '2024-09-05 17:20:30', NULL),
(1823, 126, '2024-09-05 17:02:40', NULL),
(1824, 166, '2024-09-05 17:02:40', NULL),
(1825, 126, '2024-09-05 17:02:40', NULL),
(1826, 126, '2024-09-05 17:02:40', NULL),
(1827, 126, '2024-09-05 17:20:30', NULL),
(1828, 126, '2024-06-22 19:55:20', NULL),
(1829, 126, '2024-09-06 10:06:57', NULL),
(1830, 126, '2024-06-22 19:55:20', NULL),
(1831, 126, '2024-09-06 10:06:57', NULL),
(1832, 126, '2024-09-06 10:25:50', NULL),
(1833, 126, '2024-06-22 19:55:20', NULL),
(1834, 126, '2024-09-06 10:06:57', NULL),
(1835, 126, '2024-09-06 10:06:57', NULL),
(1836, 126, '2024-09-06 10:06:57', NULL),
(1837, 126, '2024-09-06 10:06:57', NULL),
(1838, 126, '2024-09-06 10:29:25', NULL),
(1839, 126, '2024-09-06 10:06:57', NULL),
(1840, 126, '2024-06-22 19:55:20', NULL),
(1841, 126, '2024-09-06 10:06:57', NULL),
(1842, 126, '2024-09-06 10:29:25', NULL),
(1843, 126, '2024-09-06 10:06:57', NULL),
(1844, 165, '2024-09-06 10:06:57', NULL),
(1845, 126, '2024-09-06 10:06:57', NULL),
(1846, 126, '2024-09-06 10:29:25', NULL),
(1847, 126, '2024-09-06 10:06:57', NULL),
(1848, 126, '2024-06-22 19:55:20', NULL),
(1849, 126, '2024-06-22 19:55:20', NULL),
(1850, 126, '2024-09-06 10:29:25', NULL),
(1851, 126, '2024-06-22 19:55:20', NULL),
(1852, 126, '2024-09-06 10:06:57', NULL),
(1853, 126, '2024-09-06 10:06:57', NULL),
(1854, 126, '2024-09-06 10:06:57', NULL),
(1855, 126, '2024-09-06 10:29:25', NULL),
(1856, 126, '2024-09-06 10:29:25', NULL),
(1857, 168, '2024-09-06 10:29:25', NULL),
(1858, 139, '2024-09-06 10:29:25', NULL),
(1859, 126, '2024-09-06 10:29:25', NULL),
(1860, 126, '2024-06-22 19:55:20', NULL),
(1861, 169, '2024-09-06 10:29:25', NULL),
(1862, 168, '2024-06-22 19:55:20', NULL),
(1863, 169, '2024-09-06 10:29:25', NULL),
(1864, 139, '2024-06-22 19:55:20', NULL),
(1865, 168, '2024-06-22 19:55:20', NULL),
(1866, 170, '2024-06-22 19:55:20', NULL),
(1867, 139, '2024-06-22 19:55:20', NULL),
(1868, 126, '2024-06-22 19:55:20', NULL),
(1869, 126, '2024-06-22 19:55:20', NULL),
(1870, 126, '2024-06-22 19:55:20', NULL),
(1871, 171, '2024-06-22 19:55:20', NULL),
(1872, 126, '2024-06-22 19:55:20', NULL),
(1873, 126, '2024-09-06 10:29:25', NULL),
(1874, 126, '2024-09-06 17:12:32', NULL),
(1875, 126, '2024-09-06 17:22:09', NULL),
(1876, 126, '2024-09-06 17:22:09', NULL),
(1877, 126, '2024-09-06 17:22:09', NULL),
(1878, 126, '2024-09-06 18:34:06', NULL),
(1879, 126, '2024-09-06 18:34:06', NULL),
(1880, 171, '2024-09-06 18:34:06', NULL),
(1881, 126, '2024-09-06 18:34:06', NULL),
(1882, 126, '2024-09-06 18:34:06', NULL),
(1883, 126, '2024-09-06 18:34:06', NULL),
(1884, 171, '2024-09-06 18:34:06', NULL),
(1885, 171, '2024-09-06 18:34:06', NULL),
(1886, 126, '2024-09-06 18:34:06', NULL),
(1887, 171, '2024-09-06 18:34:06', NULL),
(1888, 126, '2024-09-06 18:34:06', NULL),
(1889, 171, '2024-09-06 18:34:06', NULL),
(1890, 171, '2024-09-06 18:34:06', NULL),
(1891, 171, '2024-09-06 18:34:06', NULL),
(1892, 126, '2024-09-06 18:34:06', NULL),
(1893, 171, '2024-09-06 18:34:06', NULL),
(1894, 171, '2024-09-06 18:34:06', NULL),
(1895, 126, '2024-09-07 07:29:43', NULL),
(1896, 126, '2024-09-06 18:34:06', NULL),
(1897, 126, '2024-09-07 07:39:12', NULL),
(1898, 126, '2024-09-07 07:39:12', NULL),
(1899, 126, '2024-09-07 07:39:12', NULL),
(1900, 126, '2024-09-07 07:42:17', NULL),
(1901, 126, '2024-09-07 07:42:17', NULL),
(1902, 126, '2024-09-07 07:42:17', NULL),
(1903, 126, '2024-09-07 07:42:17', NULL),
(1904, 169, '2024-09-07 07:42:17', NULL),
(1905, 139, '2024-09-07 07:42:17', NULL),
(1906, 168, '2024-09-07 07:42:17', NULL),
(1907, 170, '2024-09-07 07:42:17', NULL),
(1908, 126, '2024-09-07 07:42:17', NULL),
(1909, 169, '2024-09-07 07:42:17', NULL),
(1910, 126, '2024-09-07 07:42:17', NULL),
(1911, 126, '2024-09-07 07:42:17', NULL),
(1912, 126, '2024-09-07 07:42:17', NULL),
(1913, 126, '2024-09-07 07:29:43', NULL),
(1914, 126, '2024-09-07 07:29:43', NULL),
(1915, 126, '2024-09-07 07:29:43', NULL),
(1916, 172, '2024-09-07 07:29:43', NULL),
(1917, 126, '2024-09-07 07:29:43', NULL),
(1918, 172, '2024-09-07 07:29:43', NULL),
(1919, 126, '2024-09-07 07:29:43', NULL),
(1920, 169, '2024-09-07 07:29:43', NULL),
(1921, 173, '2024-09-07 07:29:43', NULL),
(1922, 173, '2024-09-07 07:29:43', NULL),
(1923, 173, '2024-09-07 07:29:43', NULL),
(1924, 126, '2024-09-07 07:29:43', NULL),
(1925, 126, '2024-09-07 07:42:17', NULL),
(1926, 126, '2024-09-07 07:42:17', NULL),
(1927, 126, '2024-09-07 07:42:17', NULL),
(1928, 126, '2024-09-07 07:42:17', NULL),
(1929, 126, '2024-09-07 07:42:17', NULL),
(1930, 126, '2024-09-07 07:42:17', NULL),
(1931, 126, '2024-09-07 07:42:17', NULL),
(1932, 126, '2024-09-07 07:42:17', NULL),
(1933, 126, '2024-09-07 07:42:17', NULL),
(1934, 126, '2024-09-07 07:42:17', NULL),
(1935, 126, '2024-09-07 07:42:17', NULL),
(1936, 126, '2024-09-07 07:42:17', NULL),
(1937, 126, '2024-09-07 07:42:17', NULL),
(1938, 126, '2024-09-07 07:42:17', NULL),
(1939, 126, '2024-09-07 07:42:17', NULL),
(1940, 126, '2024-09-07 07:42:17', NULL),
(1941, 126, '2024-09-07 07:42:17', NULL),
(1942, 126, '2024-09-07 07:42:17', NULL),
(1943, 126, '2024-09-07 07:42:17', NULL),
(1944, 126, '2024-09-07 07:42:17', NULL),
(1945, 126, '2024-09-07 07:42:17', NULL),
(1946, 126, '2024-09-07 07:42:17', NULL),
(1947, 126, '2024-09-07 07:42:17', NULL),
(1948, 126, '2024-09-07 07:42:17', NULL),
(1949, 126, '2024-09-07 07:42:17', NULL),
(1950, 126, '2024-09-23 17:20:32', NULL),
(1951, 126, '2024-09-23 17:20:32', NULL),
(1952, 126, '2024-09-07 07:42:17', NULL),
(1953, 168, '2024-09-23 17:20:32', NULL),
(1954, 168, '2024-09-23 17:20:32', NULL),
(1955, 126, '2024-09-23 17:20:32', NULL),
(1956, 126, '2024-09-23 17:20:32', NULL),
(1957, 126, '2024-09-23 17:20:32', NULL),
(1958, 126, '2024-09-23 17:20:32', NULL),
(1959, 126, '2024-09-23 17:20:32', NULL),
(1960, 126, '2024-09-23 17:20:32', NULL),
(1961, 126, '2024-09-23 17:20:32', NULL),
(1962, 126, '2024-09-23 17:20:32', NULL),
(1963, 126, '2024-09-07 07:42:17', NULL),
(1964, 126, '2024-09-07 07:42:17', NULL),
(1965, 126, '2024-09-07 07:42:17', NULL),
(1966, 126, '2024-09-07 07:42:17', NULL),
(1967, 126, '2024-09-07 07:42:17', NULL),
(1968, 126, '2024-09-07 07:42:17', NULL),
(1969, 126, '2024-09-07 07:42:17', NULL),
(1970, 126, '2024-09-07 07:42:17', NULL),
(1971, 126, '2024-09-26 14:08:18', NULL),
(1972, 126, '2024-09-26 14:08:18', NULL),
(1973, 126, '2024-09-07 07:42:17', NULL),
(1974, 126, '2024-09-07 07:42:17', NULL),
(1975, 126, '2024-09-07 07:42:17', NULL),
(1976, 188, '2024-09-27 16:38:59', NULL),
(1977, 188, '2024-09-27 16:38:59', NULL),
(1978, 186, '2024-09-27 17:16:20', NULL),
(1979, 186, '2024-09-27 17:16:20', NULL),
(1980, 126, '2024-09-07 07:42:17', NULL),
(1981, 126, '2024-09-07 07:42:17', NULL),
(1982, 186, '2024-09-07 07:42:17', NULL),
(1983, 126, '2024-09-07 07:42:17', NULL),
(1984, 126, '2024-09-27 16:38:59', NULL),
(1985, 126, '2024-09-27 16:38:59', NULL),
(1986, 126, '2024-09-27 16:38:59', NULL),
(1987, 126, '2024-09-30 16:09:54', NULL),
(1988, 126, '2024-09-30 16:09:54', NULL),
(1989, 126, '2024-09-30 16:09:54', NULL),
(1990, 190, '2024-09-30 18:48:52', NULL),
(1991, 126, '2024-09-30 18:48:52', NULL),
(1992, 191, '2024-09-30 18:48:52', NULL),
(1993, 126, '2024-10-01 18:12:18', NULL),
(1994, 126, '2024-10-01 18:12:18', NULL),
(1995, 193, '2024-09-30 18:48:52', NULL),
(1996, 192, '2024-09-30 18:48:52', NULL),
(1997, 193, '2024-09-30 18:48:52', NULL),
(1998, 191, '2024-09-30 18:48:52', NULL),
(1999, 126, '2024-09-30 18:48:52', NULL),
(2000, 126, '2024-10-02 14:22:43', NULL),
(2001, 126, '2024-09-30 18:48:52', NULL),
(2002, 126, '2024-09-30 18:48:52', NULL),
(2003, 126, '2024-09-30 18:48:52', NULL),
(2004, 126, '2024-09-30 18:48:52', NULL),
(2005, 126, '2024-09-30 18:48:52', NULL),
(2006, 126, '2024-09-30 18:48:52', NULL),
(2007, 126, '2024-09-30 18:48:52', NULL),
(2008, 126, '2024-10-14 10:00:53', NULL),
(2009, 126, '2024-10-21 18:02:27', NULL),
(2010, 126, '2024-10-21 18:02:27', NULL),
(2011, 126, '2024-10-21 18:02:27', NULL),
(2012, 126, '2024-10-21 18:02:27', NULL),
(2013, 126, '2024-10-24 13:36:16', NULL),
(2014, 126, '2024-10-24 13:38:09', NULL),
(2015, 126, '2024-10-24 14:01:30', NULL),
(2016, 126, '2024-10-24 14:12:43', NULL),
(2017, 126, '2024-10-24 14:12:43', NULL),
(2018, 195, '2024-10-24 14:12:43', NULL),
(2019, 195, '2024-10-24 14:12:43', NULL),
(2020, 126, '2024-10-24 15:29:31', NULL),
(2021, 126, '2024-10-24 15:29:31', NULL),
(2022, 126, '2024-10-24 15:29:31', NULL),
(2023, 126, '2024-10-24 15:29:31', NULL),
(2024, 195, '2024-10-24 15:29:31', NULL),
(2025, 195, '2024-10-24 17:17:08', NULL),
(2026, 195, '2024-10-25 11:19:32', NULL),
(2027, 195, '2024-10-25 11:19:32', NULL),
(2028, 195, '2024-10-25 11:19:32', NULL),
(2029, 195, '2024-10-25 11:19:32', NULL),
(2030, 195, '2024-10-25 11:19:32', NULL),
(2031, 195, '2024-10-25 11:19:32', NULL),
(2032, 126, '2024-10-24 15:29:31', NULL),
(2033, 126, '2024-10-25 11:19:32', NULL),
(2034, 126, '2024-10-25 11:19:32', NULL),
(2035, 126, '2024-10-25 11:19:32', NULL),
(2036, 195, '2024-10-25 11:19:32', NULL),
(2037, 195, '2024-10-25 11:19:32', NULL),
(2038, 195, '2024-10-25 17:27:21', NULL),
(2039, 195, '2024-10-26 10:47:42', NULL),
(2040, 195, '2024-10-26 10:47:42', NULL),
(2041, 195, '2024-10-26 10:47:42', NULL),
(2042, 196, '2024-10-26 11:27:03', NULL),
(2043, 195, '2024-10-26 11:27:03', NULL),
(2044, 196, '2024-10-26 11:27:03', NULL),
(2045, 196, '2024-10-26 11:27:03', NULL),
(2046, 196, '2024-10-26 11:27:03', NULL),
(2047, 196, '2024-10-26 11:27:03', NULL),
(2048, 196, '2024-10-24 15:29:31', NULL),
(2049, 196, '2024-10-26 11:27:03', NULL),
(2050, 196, '2024-10-24 15:29:31', NULL),
(2051, 197, '2024-10-28 10:30:58', NULL),
(2052, 197, '2024-10-28 10:46:11', NULL),
(2053, 197, '2024-10-28 10:46:11', NULL),
(2054, 195, '2024-10-28 10:46:11', NULL),
(2055, 196, '2024-10-28 12:28:09', NULL),
(2056, 196, '2024-10-28 12:28:09', NULL),
(2057, 198, '2024-10-28 12:28:09', NULL),
(2058, 199, '2024-10-28 12:28:09', NULL),
(2059, 199, '2024-10-28 12:28:09', NULL),
(2060, 200, '2024-10-28 12:28:09', NULL),
(2061, 195, '2024-10-28 12:28:09', NULL),
(2062, 199, '2024-10-28 12:28:09', NULL),
(2063, 199, '2024-10-28 12:28:09', NULL),
(2064, 200, '2024-10-28 12:28:09', NULL),
(2065, 196, '2024-10-28 12:28:09', NULL),
(2066, 196, '2024-10-29 10:36:13', NULL),
(2067, 195, '2024-10-28 12:28:09', NULL),
(2068, 196, '2024-10-28 12:28:09', NULL),
(2069, 126, '2024-10-28 12:28:09', NULL),
(2070, 197, '2024-10-28 12:28:09', NULL),
(2071, 195, '2024-10-28 12:28:09', NULL),
(2072, 195, '2024-10-29 14:23:17', NULL),
(2073, 196, '2024-10-29 14:23:17', NULL),
(2074, 196, '2024-10-29 14:23:17', NULL),
(2075, 195, '2024-10-29 14:23:17', NULL),
(2076, 196, '2024-10-28 12:28:09', NULL),
(2077, 126, '2024-10-28 12:28:09', NULL),
(2078, 197, '2024-10-28 12:28:09', NULL),
(2079, 197, '2024-10-28 12:28:09', NULL),
(2080, 195, '2024-10-28 12:28:09', NULL),
(2081, 195, '2024-10-29 18:39:23', NULL),
(2082, 195, '2024-10-29 18:39:23', NULL),
(2083, 196, '2024-10-29 18:39:23', NULL),
(2084, 195, '2024-10-29 18:39:23', NULL),
(2085, 196, '2024-10-29 18:39:23', NULL),
(2086, 196, '2024-10-29 18:39:23', NULL),
(2087, 126, '2024-10-30 11:56:54', NULL),
(2088, 200, '2024-10-28 12:28:09', NULL),
(2089, 126, '2024-11-02 14:39:10', NULL),
(2090, 126, '2024-11-02 14:39:10', NULL),
(2091, 197, '2024-11-02 14:39:10', NULL),
(2092, 197, '2024-11-02 14:39:10', NULL),
(2093, 195, '2024-11-02 14:39:10', NULL),
(2094, 197, '2024-11-02 14:39:10', NULL),
(2095, 197, '2024-11-04 10:06:23', NULL),
(2096, 197, '2024-11-04 10:06:23', NULL),
(2097, 197, '2024-11-04 10:09:16', NULL),
(2098, 197, '2024-10-28 12:28:09', NULL),
(2099, 197, '2024-11-04 10:20:16', NULL),
(2100, 126, '2024-11-04 13:01:19', NULL),
(2101, 126, '2024-11-04 13:02:48', NULL),
(2102, 126, '2024-11-04 13:12:08', NULL),
(2103, 126, '2024-11-04 13:13:21', NULL),
(2104, 126, '2024-11-04 13:14:11', NULL),
(2105, 126, '2024-11-04 13:16:05', NULL),
(2106, 126, '2024-11-04 13:16:19', NULL),
(2107, 126, '2024-11-04 13:17:12', NULL),
(2108, 126, '2024-11-04 13:18:05', NULL),
(2109, 126, '2024-10-28 12:28:09', NULL),
(2110, 200, '2024-10-28 12:28:09', NULL),
(2111, 199, '2024-10-28 12:28:09', NULL),
(2112, 200, '2024-10-28 12:28:09', NULL),
(2113, 201, '2024-10-28 12:28:09', NULL),
(2114, 201, '2024-10-28 12:28:09', NULL),
(2115, 201, '2024-10-28 12:28:09', NULL),
(2116, 126, '2024-10-28 12:28:09', NULL),
(2117, 126, '2024-11-05 15:37:46', NULL),
(2118, 126, '2024-11-05 15:37:46', NULL),
(2119, 126, '2024-10-28 12:28:09', NULL),
(2120, 202, '2024-11-04 17:19:33', NULL),
(2121, 202, '2024-11-04 17:19:33', NULL),
(2122, 202, '2024-11-04 17:19:33', NULL),
(2123, 202, '2024-11-04 17:19:33', NULL),
(2124, 202, '2024-11-04 17:19:33', NULL),
(2125, 202, '2024-11-04 17:19:33', NULL),
(2126, 202, '2024-11-04 17:19:33', NULL),
(2127, 202, '2024-11-04 17:19:33', NULL),
(2128, 202, '2024-11-04 17:19:33', NULL),
(2129, 202, '2024-11-04 17:19:33', NULL),
(2130, 202, '2024-11-04 17:19:33', NULL),
(2131, 202, '2024-10-28 12:28:09', NULL),
(2132, 202, '2024-11-04 17:19:33', NULL),
(2133, 126, '2024-11-06 09:36:19', NULL),
(2134, 202, '2024-11-06 10:04:39', NULL),
(2135, 202, '2024-11-06 10:04:39', NULL),
(2136, 202, '2024-11-06 10:04:39', NULL),
(2137, 202, '2024-11-06 10:04:39', NULL),
(2138, 202, '2024-11-06 10:04:39', NULL),
(2139, 202, '2024-11-06 11:07:48', NULL),
(2140, 202, '2024-11-06 11:07:48', NULL),
(2141, 202, '2024-11-06 11:07:48', NULL),
(2142, 202, '2024-11-06 11:07:48', NULL),
(2143, 202, '2024-11-06 11:07:48', NULL),
(2144, 202, '2024-11-06 11:07:48', NULL),
(2145, 202, '2024-11-06 11:07:48', NULL),
(2146, 202, '2024-11-06 11:07:48', NULL),
(2147, 202, '2024-11-06 11:07:48', NULL),
(2148, 202, '2024-11-06 11:07:48', NULL),
(2149, 202, '2024-11-06 11:18:05', NULL),
(2150, 202, '2024-11-06 11:18:05', NULL),
(2151, 202, '2024-11-06 11:18:05', NULL),
(2152, 202, '2024-11-06 11:18:05', NULL),
(2153, 202, '2024-11-06 11:20:35', NULL),
(2154, 202, '2024-11-06 11:22:00', NULL),
(2155, 202, '2024-11-06 11:22:00', NULL),
(2156, 202, '2024-11-06 11:22:00', NULL),
(2157, 202, '2024-10-28 12:28:09', NULL),
(2158, 202, '2024-10-28 12:28:09', NULL),
(2159, 126, '2024-10-28 12:28:09', NULL),
(2160, 126, '2024-11-06 11:37:20', NULL),
(2161, 202, '2024-10-28 12:28:09', NULL),
(2162, 203, '2024-11-06 13:25:01', NULL),
(2163, 204, '2024-11-06 13:48:50', NULL),
(2164, 202, '2024-11-06 13:48:50', NULL),
(2165, 204, '2024-11-06 13:48:50', NULL),
(2166, 202, '2024-11-06 15:33:59', NULL),
(2167, 202, '2024-11-06 15:33:59', NULL),
(2168, 202, '2024-11-06 15:33:59', NULL),
(2169, 202, '2024-11-06 15:33:59', NULL),
(2170, 202, '2024-11-06 15:33:59', NULL),
(2171, 202, '2024-11-06 15:33:59', NULL),
(2172, 202, '2024-11-06 15:33:59', NULL),
(2173, 202, '2024-11-06 15:33:59', NULL),
(2174, 202, '2024-11-06 15:33:59', NULL),
(2175, 126, '2024-10-28 12:28:09', NULL),
(2176, 197, '2024-10-28 12:28:09', NULL),
(2177, 126, '2024-10-28 12:28:09', NULL),
(2178, 202, '2024-11-06 15:33:59', NULL),
(2179, 202, '2024-11-06 22:34:21', NULL),
(2180, 202, '2024-11-07 09:53:32', NULL),
(2181, 202, '2024-11-07 09:59:51', NULL),
(2182, 202, '2024-11-07 10:10:07', NULL),
(2183, 202, '2024-11-07 11:06:00', NULL),
(2184, 202, '2024-11-07 11:27:00', NULL),
(2185, 202, '2024-11-07 11:27:00', NULL),
(2186, 202, '2024-11-07 11:29:13', NULL),
(2187, 201, '2024-11-06 18:47:19', NULL),
(2188, 202, '2024-11-07 11:29:13', NULL),
(2189, 202, '2024-11-07 11:29:13', NULL),
(2190, 202, '2024-11-07 11:29:13', NULL),
(2191, 202, '2024-11-07 11:29:13', NULL),
(2192, 201, '2024-11-06 18:47:19', NULL),
(2193, 202, '2024-11-07 11:29:13', NULL),
(2194, 201, '2024-11-06 18:47:19', NULL),
(2195, 202, '2024-11-07 11:29:13', NULL),
(2196, 200, '2024-11-06 18:47:19', NULL),
(2197, 205, '2024-11-06 18:47:19', NULL),
(2198, 202, '2024-11-07 13:57:03', NULL),
(2199, 202, '2024-11-07 14:10:02', NULL),
(2200, 202, '2024-11-07 14:10:02', NULL),
(2201, 202, '2024-11-07 14:10:02', NULL),
(2202, 202, '2024-11-07 13:57:03', NULL),
(2203, 202, '2024-11-07 13:57:03', NULL),
(2204, 205, '2024-11-07 13:57:03', NULL),
(2205, 202, '2024-11-07 14:10:02', NULL),
(2206, 202, '2024-11-07 14:10:02', NULL),
(2207, 202, '2024-11-07 13:57:03', NULL),
(2208, 202, '2024-11-07 14:10:02', NULL),
(2209, 202, '2024-11-07 13:57:03', NULL),
(2210, 202, '2024-11-07 14:10:02', NULL),
(2211, 202, '2024-11-07 14:10:02', NULL),
(2212, 202, '2024-11-07 14:10:02', NULL),
(2213, 202, '2024-11-07 14:10:02', NULL),
(2214, 202, '2024-11-07 14:10:02', NULL),
(2215, 202, '2024-11-07 14:10:02', NULL),
(2216, 202, '2024-11-07 13:57:03', NULL),
(2217, 202, '2024-11-07 13:57:03', NULL),
(2218, 202, '2024-11-07 13:57:03', NULL),
(2219, 202, '2024-11-07 13:57:03', NULL),
(2220, 202, '2024-11-07 14:10:02', NULL),
(2221, 202, '2024-11-07 13:57:03', NULL),
(2222, 202, '2024-11-07 14:10:02', NULL),
(2223, 202, '2024-11-07 13:57:03', NULL),
(2224, 202, '2024-11-07 13:57:03', NULL),
(2225, 202, '2024-11-07 13:57:03', NULL),
(2226, 202, '2024-11-07 13:57:03', NULL),
(2227, 202, '2024-11-07 13:57:03', NULL),
(2228, 202, '2024-11-07 13:57:03', NULL),
(2229, 202, '2024-11-07 13:57:03', NULL),
(2230, 205, '2024-11-07 13:57:03', NULL),
(2231, 205, '2024-11-07 13:57:03', NULL),
(2232, 126, '2024-11-07 13:57:03', NULL),
(2233, 205, '2024-11-07 13:57:03', NULL),
(2234, 126, '2024-11-07 13:57:03', NULL),
(2235, 205, '2024-11-07 13:57:03', NULL),
(2236, 202, '2024-11-07 13:57:03', NULL),
(2237, 202, '2024-11-07 13:57:03', NULL),
(2238, 202, '2024-11-07 13:57:03', NULL),
(2239, 202, '2024-11-07 13:57:03', NULL),
(2240, 205, '2024-11-07 13:57:03', NULL),
(2241, 205, '2024-11-07 13:57:03', NULL),
(2242, 126, '2024-11-07 13:57:03', NULL),
(2243, 205, '2024-11-07 13:57:03', NULL),
(2244, 126, '2024-11-07 13:57:03', NULL),
(2245, 126, '2024-11-07 13:57:03', NULL),
(2246, 202, '2024-11-07 13:57:03', NULL),
(2247, 202, '2024-11-07 13:57:03', NULL),
(2248, 205, '2024-11-07 13:57:03', NULL),
(2249, 205, '2024-11-07 13:57:03', NULL),
(2250, 202, '2024-11-07 13:57:03', NULL),
(2251, 202, '2024-11-07 13:57:03', NULL),
(2252, 202, '2024-11-07 13:57:03', NULL),
(2253, 202, '2024-11-07 13:57:03', NULL),
(2254, 202, '2024-11-07 13:57:03', NULL),
(2255, 202, '2024-11-07 13:57:03', NULL),
(2256, 202, '2024-11-07 13:57:03', NULL),
(2257, 202, '2024-11-07 13:57:03', NULL),
(2258, 205, '2024-11-07 13:57:03', NULL),
(2259, 126, '2024-11-07 13:57:03', NULL),
(2260, 201, '2024-11-07 13:57:03', NULL),
(2261, 202, '2024-11-07 13:57:03', NULL),
(2262, 202, '2024-11-07 17:05:53', NULL),
(2263, 201, '2024-11-07 13:57:03', NULL),
(2264, 201, '2024-11-07 13:57:03', NULL),
(2265, 201, '2024-11-07 13:57:03', NULL),
(2266, 126, '2024-11-07 13:57:03', NULL),
(2267, 205, '2024-11-07 13:57:03', NULL),
(2268, 201, '2024-11-07 13:57:03', NULL),
(2269, 205, '2024-11-07 13:57:03', NULL),
(2270, 202, '2024-11-07 13:57:03', NULL),
(2271, 202, '2024-11-07 13:57:03', NULL),
(2272, 202, '2024-11-07 13:57:03', NULL),
(2273, 202, '2024-11-07 13:57:03', NULL),
(2274, 205, '2024-11-07 13:57:03', NULL),
(2275, 205, '2024-11-07 13:57:03', NULL),
(2276, 202, '2024-11-07 13:57:03', NULL),
(2277, 202, '2024-11-07 13:57:03', NULL),
(2278, 202, '2024-11-07 13:57:03', NULL),
(2279, 202, '2024-11-07 13:57:03', NULL),
(2280, 202, '2024-11-07 13:57:03', NULL),
(2281, 202, '2024-11-07 13:57:03', NULL),
(2282, 202, '2024-11-07 17:17:47', NULL),
(2283, 202, '2024-11-07 13:57:03', NULL),
(2284, 202, '2024-11-07 17:17:47', NULL),
(2285, 202, '2024-11-07 17:17:47', NULL),
(2286, 202, '2024-11-07 17:17:47', NULL),
(2287, 202, '2024-11-07 17:17:47', NULL),
(2288, 202, '2024-11-07 17:17:47', NULL),
(2289, 202, '2024-11-08 09:53:30', NULL),
(2290, 202, '2024-11-07 13:57:03', NULL),
(2291, 202, '2024-11-07 13:57:03', NULL),
(2292, 202, '2024-11-07 13:57:03', NULL),
(2293, 202, '2024-11-07 13:57:03', NULL),
(2294, 202, '2024-11-07 13:57:03', NULL),
(2295, 202, '2024-11-07 13:57:03', NULL),
(2296, 202, '2024-11-07 13:57:03', NULL),
(2297, 202, '2024-11-07 13:57:03', NULL),
(2298, 202, '2024-11-07 13:57:03', NULL),
(2299, 202, '2024-11-07 13:57:03', NULL),
(2300, 202, '2024-11-07 13:57:03', NULL),
(2301, 202, '2024-11-07 13:57:03', NULL),
(2302, 202, '2024-11-08 10:58:00', NULL),
(2303, 202, '2024-11-08 11:03:20', NULL),
(2304, 202, '2024-11-08 11:03:20', NULL),
(2305, 202, '2024-11-08 11:03:20', NULL),
(2306, 202, '2024-11-08 11:03:20', NULL),
(2307, 126, '2024-11-07 13:57:03', NULL),
(2308, 126, '2024-11-07 13:57:03', NULL),
(2309, 201, '2024-11-07 13:57:03', NULL),
(2310, 201, '2024-11-07 13:57:03', NULL),
(2311, 202, '2024-11-08 11:03:20', NULL),
(2312, 202, '2024-11-08 12:21:36', NULL),
(2313, 202, '2024-11-08 12:21:36', NULL),
(2314, 202, '2024-11-08 12:21:36', NULL),
(2315, 202, '2024-11-08 12:21:36', NULL),
(2316, 202, '2024-11-08 12:21:36', NULL),
(2317, 202, '2024-11-08 12:21:36', NULL),
(2318, 202, '2024-11-08 12:21:36', NULL),
(2319, 202, '2024-11-08 15:58:26', NULL),
(2320, 202, '2024-11-08 15:58:26', NULL),
(2321, 202, '2024-11-08 15:58:26', NULL),
(2322, 202, '2024-11-08 16:29:55', NULL),
(2323, 205, '2024-11-08 16:29:55', NULL),
(2324, 205, '2024-11-08 16:29:55', NULL),
(2325, 205, '2024-11-08 16:29:55', NULL),
(2326, 202, '2024-11-08 16:29:55', NULL),
(2327, 202, '2024-11-08 16:29:55', NULL),
(2328, 205, '2024-11-08 16:29:55', NULL),
(2329, 197, '2024-11-11 09:49:20', NULL),
(2330, 202, '2024-11-08 16:29:55', NULL),
(2331, 202, '2024-11-11 09:49:20', NULL),
(2332, 202, '2024-11-08 16:29:55', NULL),
(2333, 202, '2024-11-11 09:49:20', NULL),
(2334, 202, '2024-11-11 09:49:20', NULL),
(2335, 202, '2024-11-11 09:49:20', NULL),
(2336, 202, '2024-11-11 09:49:20', NULL),
(2337, 202, '2024-11-08 16:29:55', NULL),
(2338, 126, '2024-11-08 16:29:55', NULL),
(2339, 205, '2024-11-08 16:29:55', NULL),
(2340, 205, '2024-11-08 16:29:55', NULL),
(2341, 205, '2024-11-08 16:29:55', NULL),
(2342, 205, '2024-11-11 11:22:14', NULL),
(2343, 205, '2024-11-11 11:22:14', NULL),
(2344, 205, '2024-11-11 11:22:14', NULL),
(2345, 205, '2024-11-11 11:22:14', NULL),
(2346, 205, '2024-11-11 11:22:14', NULL),
(2347, 202, '2024-11-11 11:11:38', NULL),
(2348, 206, '2024-11-11 11:22:14', NULL),
(2349, 205, '2024-11-11 11:22:14', NULL),
(2350, 205, '2024-11-11 11:22:14', NULL),
(2351, 205, '2024-11-11 11:22:14', NULL),
(2352, 205, '2024-11-11 11:22:14', NULL),
(2353, 205, '2024-11-11 11:22:14', NULL),
(2354, 202, '2024-11-11 13:19:30', NULL),
(2355, 202, '2024-11-11 13:19:30', NULL),
(2356, 205, '2024-11-11 11:22:14', NULL),
(2357, 205, '2024-11-11 11:22:14', NULL),
(2358, 205, '2024-11-11 11:22:14', NULL),
(2359, 205, '2024-11-11 11:22:14', NULL),
(2360, 205, '2024-11-11 14:10:44', NULL),
(2361, 205, '2024-11-11 14:10:44', NULL),
(2362, 205, '2024-11-11 14:10:44', NULL),
(2363, 205, '2024-11-11 14:10:44', NULL),
(2364, 206, '2024-11-11 14:10:44', NULL),
(2365, 206, '2024-11-11 14:10:44', NULL),
(2366, 205, '2024-11-11 14:10:44', NULL),
(2367, 205, '2024-11-11 14:10:44', NULL),
(2368, 207, '2024-11-11 14:10:44', NULL),
(2369, 205, '2024-11-11 14:10:44', NULL),
(2370, 207, '2024-11-11 14:10:44', NULL),
(2371, 207, '2024-11-11 14:10:44', NULL),
(2372, 207, '2024-11-11 14:10:44', NULL),
(2373, 207, '2024-11-11 14:10:44', NULL),
(2374, 205, '2024-11-11 14:10:44', NULL),
(2375, 205, '2024-11-11 14:10:44', NULL),
(2376, 207, '2024-11-11 14:10:44', NULL),
(2377, 205, '2024-11-11 14:10:44', NULL),
(2378, 202, '2024-11-11 14:09:25', NULL),
(2379, 202, '2024-11-11 14:09:25', NULL),
(2380, 202, '2024-11-11 14:09:25', NULL),
(2381, 202, '2024-11-11 14:09:25', NULL),
(2382, 202, '2024-11-11 14:09:25', NULL),
(2383, 202, '2024-11-12 10:14:47', NULL),
(2384, 205, '2024-11-11 14:10:44', NULL),
(2385, 205, '2024-11-11 14:10:44', NULL),
(2386, 202, '2024-11-11 14:10:44', NULL),
(2387, 205, '2024-11-11 14:10:44', NULL),
(2388, 202, '2024-11-11 14:10:44', NULL),
(2389, 202, '2024-11-11 14:10:44', NULL),
(2390, 202, '2024-11-11 14:10:44', NULL),
(2391, 205, '2024-11-11 14:10:44', NULL),
(2392, 205, '2024-11-11 14:10:44', NULL),
(2393, 205, '2024-11-11 14:10:44', NULL),
(2394, 202, '2024-11-12 12:40:01', NULL),
(2395, 202, '2024-11-12 13:19:44', NULL),
(2396, 202, '2024-11-12 13:32:05', NULL),
(2397, 202, '2024-11-12 13:32:05', NULL),
(2398, 202, '2024-11-12 13:32:05', NULL),
(2399, 126, '2024-11-11 14:10:44', NULL),
(2400, 202, '2024-11-12 16:06:21', NULL),
(2401, 202, '2024-11-12 16:06:21', NULL),
(2402, 202, '2024-11-12 16:06:21', NULL),
(2403, 202, '2024-11-11 14:10:44', NULL),
(2404, 205, '2024-11-12 16:50:48', NULL),
(2405, 202, '2024-11-12 16:50:48', NULL),
(2406, 202, '2024-11-12 16:50:48', NULL),
(2407, 202, '2024-11-12 16:50:48', NULL),
(2408, 202, '2024-11-12 16:50:48', NULL),
(2409, 202, '2024-11-12 16:50:48', NULL),
(2410, 202, '2024-11-12 22:54:01', NULL),
(2411, 202, '2024-11-12 22:54:55', NULL),
(2412, 202, '2024-11-12 22:54:55', NULL),
(2413, 202, '2024-11-12 22:54:55', NULL),
(2414, 202, '2024-11-12 22:54:55', NULL),
(2415, 202, '2024-11-12 22:54:55', NULL),
(2416, 202, '2024-11-13 10:13:13', NULL),
(2417, 202, '2024-11-13 10:57:32', NULL),
(2418, 202, '2024-11-13 10:57:32', NULL),
(2419, 202, '2024-11-13 11:44:34', NULL),
(2420, 202, '2024-11-13 11:44:34', NULL),
(2421, 202, '2024-11-13 12:46:01', NULL),
(2422, 202, '2024-11-13 12:39:01', NULL),
(2423, 202, '2024-11-13 13:32:14', NULL),
(2424, 202, '2024-11-13 13:32:14', NULL),
(2425, 202, '2024-11-13 13:32:14', NULL),
(2426, 205, '2024-11-13 12:46:01', NULL),
(2427, 202, '2024-11-13 14:58:38', NULL),
(2428, 205, '2024-11-13 14:58:38', NULL),
(2429, 202, '2024-11-13 14:58:38', NULL),
(2430, 205, '2024-11-13 14:58:38', NULL),
(2431, 202, '2024-11-13 14:58:38', NULL),
(2432, 205, '2024-11-13 14:58:38', NULL),
(2433, 202, '2024-11-13 14:58:38', NULL),
(2434, 205, '2024-11-13 14:58:38', NULL),
(2435, 202, '2024-11-13 14:58:38', NULL),
(2436, 202, '2024-11-13 14:58:38', NULL),
(2437, 202, '2024-11-13 14:58:38', NULL),
(2438, 205, '2024-11-13 14:58:38', NULL),
(2439, 205, '2024-11-13 14:58:38', NULL),
(2440, 205, '2024-11-13 13:32:14', NULL),
(2441, 205, '2024-11-13 14:58:38', NULL),
(2442, 205, '2024-11-13 14:58:38', NULL),
(2443, 202, '2024-11-13 13:32:14', NULL),
(2444, 205, '2024-11-13 14:58:38', NULL),
(2445, 205, '2024-11-13 14:58:38', NULL),
(2446, 205, '2024-11-13 14:58:38', NULL),
(2447, 205, '2024-11-13 14:58:38', NULL),
(2448, 205, '2024-11-13 14:58:38', NULL),
(2449, 202, '2024-11-13 14:58:38', NULL),
(2450, 202, '2024-11-13 14:58:38', NULL),
(2451, 205, '2024-11-13 14:58:38', NULL),
(2452, 202, '2024-11-13 14:58:38', NULL),
(2453, 205, '2024-11-13 14:58:38', NULL),
(2454, 205, '2024-11-13 14:58:38', NULL),
(2455, 205, '2024-11-13 14:58:38', NULL),
(2456, 205, '2024-11-13 14:58:38', NULL),
(2457, 205, '2024-11-13 14:58:38', NULL),
(2458, 205, '2024-11-13 14:58:38', NULL),
(2459, 202, '2024-11-13 13:32:14', NULL),
(2460, 202, '2024-11-13 14:58:38', NULL),
(2461, 202, '2024-11-13 14:58:38', NULL),
(2462, 205, '2024-11-13 14:58:38', NULL),
(2463, 205, '2024-11-13 14:58:38', NULL),
(2464, 205, '2024-11-13 14:58:38', NULL),
(2465, 126, '2024-11-13 14:58:38', NULL),
(2466, 205, '2024-11-13 14:58:38', NULL),
(2467, 126, '2024-11-13 14:58:38', NULL),
(2468, 202, '2024-11-13 14:58:38', NULL),
(2469, 205, '2024-11-13 14:58:38', NULL),
(2470, 205, '2024-11-13 14:58:38', NULL),
(2471, 205, '2024-11-13 14:58:38', NULL),
(2472, 126, '2024-11-13 14:58:38', NULL),
(2473, 205, '2024-11-13 14:58:38', NULL),
(2474, 205, '2024-11-13 14:58:38', NULL),
(2475, 202, '2024-11-13 13:32:14', NULL),
(2476, 205, '2024-11-13 14:58:38', NULL),
(2477, 205, '2024-11-13 14:58:38', NULL),
(2478, 205, '2024-11-13 14:58:38', NULL),
(2479, 205, '2024-11-13 14:58:38', NULL),
(2480, 205, '2024-11-13 14:58:38', NULL),
(2481, 202, '2024-11-13 13:32:14', NULL),
(2482, 202, '2024-11-13 13:32:14', NULL),
(2483, 202, '2024-11-13 14:58:38', NULL),
(2484, 202, '2024-11-14 10:20:34', NULL),
(2485, 205, '2024-11-13 14:58:38', NULL),
(2486, 202, '2024-11-14 10:20:34', NULL),
(2487, 202, '2024-11-14 10:20:34', NULL),
(2488, 202, '2024-11-14 10:20:34', NULL),
(2489, 202, '2024-11-14 10:20:34', NULL),
(2490, 202, '2024-11-14 12:21:40', NULL),
(2491, 202, '2024-11-14 14:20:27', NULL),
(2492, 202, '2024-11-14 14:20:27', NULL),
(2493, 202, '2024-11-14 14:20:27', NULL),
(2494, 207, '2024-11-13 14:58:38', NULL),
(2495, 207, '2024-11-13 14:58:38', NULL),
(2496, 202, '2024-11-14 15:49:54', NULL),
(2497, 207, '2024-11-13 14:58:38', NULL),
(2498, 207, '2024-11-13 14:58:38', NULL),
(2499, 207, '2024-11-13 14:58:38', NULL),
(2500, 205, '2024-11-13 14:58:38', NULL),
(2501, 202, '2024-11-14 17:19:42', NULL),
(2502, 202, '2024-11-15 10:18:39', NULL),
(2503, 202, '2024-11-15 10:18:39', NULL),
(2504, 202, '2024-11-15 10:18:39', NULL),
(2505, 202, '2024-11-15 10:18:39', NULL),
(2506, 202, '2024-11-15 12:09:35', NULL),
(2507, 207, '2024-11-13 14:58:38', NULL),
(2508, 202, '2024-11-13 14:58:38', NULL),
(2509, 126, '2024-11-13 14:58:38', NULL),
(2510, 202, '2024-11-13 14:58:38', NULL),
(2511, 207, '2024-11-13 14:58:38', NULL),
(2512, 205, '2024-11-13 14:58:38', NULL),
(2513, 202, '2024-11-13 14:58:38', NULL),
(2514, 202, '2024-11-13 14:58:38', NULL),
(2515, 202, '2024-11-15 12:09:35', NULL),
(2516, 202, '2024-11-15 12:09:35', NULL),
(2517, 211, '2024-11-13 14:58:38', NULL),
(2518, 126, '2024-11-13 14:58:38', NULL),
(2519, 205, '2024-11-13 14:58:38', NULL),
(2520, 205, '2024-11-13 14:58:38', NULL),
(2521, 205, '2024-11-13 14:58:38', NULL),
(2522, 207, '2024-11-13 14:58:38', NULL),
(2523, 202, '2024-11-15 12:09:35', NULL),
(2524, 202, '2024-11-15 12:09:35', NULL),
(2525, 202, '2024-11-15 12:09:35', NULL);
INSERT INTO `userlog` (`id`, `userid`, `lastlogin`, `logout`) VALUES
(2526, 202, '2024-11-13 14:58:38', NULL),
(2527, 205, '2024-11-13 14:58:38', NULL),
(2528, 205, '2024-11-13 14:58:38', NULL),
(2529, 205, '2024-11-13 14:58:38', NULL),
(2530, 205, '2024-11-13 14:58:38', NULL),
(2531, 202, '2024-11-15 12:09:35', NULL),
(2532, 202, '2024-11-15 12:09:35', NULL),
(2533, 202, '2024-11-18 12:53:58', NULL),
(2534, 205, '2024-11-13 14:58:38', NULL),
(2535, 205, '2024-11-13 14:58:38', NULL),
(2536, 205, '2024-11-13 14:58:38', NULL),
(2537, 202, '2024-11-18 13:37:00', NULL),
(2538, 202, '2024-11-18 13:37:00', NULL),
(2539, 205, '2024-11-18 14:03:45', NULL),
(2540, 205, '2024-11-18 14:03:45', NULL),
(2541, 205, '2024-11-18 14:03:45', NULL),
(2542, 202, '2024-11-18 14:03:45', NULL),
(2543, 205, '2024-11-18 14:17:09', NULL),
(2544, 205, '2024-11-18 14:17:09', NULL),
(2545, 205, '2024-11-18 14:17:09', NULL),
(2546, 205, '2024-11-18 14:17:09', NULL),
(2547, 205, '2024-11-18 14:17:09', NULL),
(2548, 205, '2024-11-18 14:17:09', NULL),
(2549, 205, '2024-11-18 14:17:09', NULL),
(2550, 205, '2024-11-18 14:17:09', NULL),
(2551, 205, '2024-11-18 14:17:09', NULL),
(2552, 205, '2024-11-18 14:17:09', NULL),
(2553, 205, '2024-11-18 14:17:09', NULL),
(2554, 205, '2024-11-18 14:17:09', NULL),
(2555, 205, '2024-11-18 14:17:09', NULL),
(2556, 205, '2024-11-18 14:17:09', NULL),
(2557, 205, '2024-11-18 14:17:09', NULL),
(2558, 202, '2024-11-18 13:37:00', NULL),
(2559, 202, '2024-11-18 13:37:00', NULL),
(2560, 202, '2024-11-18 13:37:00', NULL),
(2561, 202, '2024-11-18 13:37:00', NULL),
(2562, 202, '2024-11-18 13:37:00', NULL),
(2563, 202, '2024-11-18 13:37:00', NULL),
(2564, 202, '2024-11-18 13:37:00', NULL),
(2565, 207, '2024-11-18 19:13:52', NULL),
(2566, 202, '2024-11-19 10:05:12', NULL),
(2567, 205, '2024-11-18 19:13:52', NULL),
(2568, 205, '2024-11-18 19:13:52', NULL),
(2569, 205, '2024-11-19 10:31:41', NULL),
(2570, 205, '2024-11-19 10:31:41', NULL),
(2571, 205, '2024-11-19 10:31:41', NULL),
(2572, 202, '2024-11-19 10:05:12', NULL),
(2573, 205, '2024-11-19 11:25:00', NULL),
(2574, 205, '2024-11-19 11:25:00', NULL),
(2575, 205, '2024-11-19 11:25:00', NULL),
(2576, 205, '2024-11-19 11:25:00', NULL),
(2577, 202, '2024-11-19 11:56:44', NULL),
(2578, 207, '2024-11-19 12:07:22', NULL),
(2579, 205, '2024-11-19 12:07:22', NULL),
(2580, 205, '2024-11-19 12:07:22', NULL),
(2581, 205, '2024-11-19 12:07:22', NULL),
(2582, 205, '2024-11-19 12:07:22', NULL),
(2583, 205, '2024-11-19 12:07:22', NULL),
(2584, 205, '2024-11-19 12:07:22', NULL),
(2585, 205, '2024-11-19 12:07:22', NULL),
(2586, 205, '2024-11-19 12:07:22', NULL),
(2587, 205, '2024-11-19 12:07:22', NULL),
(2588, 205, '2024-11-19 12:07:22', NULL),
(2589, 205, '2024-11-19 12:07:22', NULL),
(2590, 205, '2024-11-19 12:07:22', NULL),
(2591, 205, '2024-11-19 13:50:40', NULL),
(2592, 202, '2024-11-19 12:02:46', NULL),
(2593, 202, '2024-11-19 12:02:46', NULL),
(2594, 205, '2024-11-19 13:50:40', NULL),
(2595, 202, '2024-11-19 12:02:46', NULL),
(2596, 205, '2024-11-19 13:50:40', NULL),
(2597, 227, '2024-11-19 13:50:40', NULL),
(2598, 202, '2024-11-19 12:02:46', NULL),
(2599, 205, '2024-11-19 13:50:40', NULL),
(2600, 205, '2024-11-19 16:15:35', NULL),
(2601, 205, '2024-11-19 16:17:26', NULL),
(2602, 205, '2024-11-19 16:17:26', NULL),
(2603, 202, '2024-11-19 12:02:46', NULL),
(2604, 205, '2024-11-19 16:22:07', NULL),
(2605, 202, '2024-11-19 12:02:46', NULL),
(2606, 205, '2024-11-19 16:22:07', NULL),
(2607, 205, '2024-11-19 16:22:07', NULL),
(2608, 202, '2024-11-19 12:02:46', NULL),
(2609, 205, '2024-11-19 12:02:46', NULL),
(2610, 205, '2024-11-19 12:02:46', NULL),
(2611, 202, '2024-11-19 12:02:46', NULL),
(2612, 205, '2024-11-19 16:22:07', NULL),
(2613, 205, '2024-11-19 16:22:07', NULL),
(2614, 205, '2024-11-19 16:22:07', NULL),
(2615, 205, '2024-11-19 16:22:07', NULL),
(2616, 202, '2024-11-19 12:02:46', NULL),
(2617, 202, '2024-11-19 21:18:03', NULL),
(2618, 202, '2024-11-19 21:18:03', NULL),
(2619, 202, '2024-11-19 21:18:03', NULL),
(2620, 202, '2024-11-19 21:18:03', NULL),
(2621, 202, '2024-11-19 21:18:03', NULL),
(2622, 202, '2024-11-19 21:18:03', NULL),
(2623, 205, '2024-11-19 18:47:03', NULL),
(2624, 205, '2024-11-19 18:47:03', NULL),
(2625, 205, '2024-11-19 18:47:03', NULL),
(2626, 205, '2024-11-19 18:47:03', NULL),
(2627, 205, '2024-11-19 18:47:03', NULL),
(2628, 205, '2024-11-19 18:47:03', NULL),
(2629, 205, '2024-11-19 18:47:03', NULL),
(2630, 205, '2024-11-19 18:47:03', NULL),
(2631, 205, '2024-11-19 18:47:03', NULL),
(2632, 205, '2024-11-19 18:47:03', NULL),
(2633, 205, '2024-11-19 18:47:03', NULL),
(2634, 202, '2024-11-19 18:47:03', NULL),
(2635, 205, '2024-11-19 18:47:03', NULL),
(2636, 126, '2024-11-19 18:47:03', NULL),
(2637, 205, '2024-11-19 18:47:03', NULL),
(2638, 126, '2024-11-19 18:47:03', NULL),
(2639, 205, '2024-11-19 18:47:03', NULL),
(2640, 227, '2024-11-19 18:47:03', NULL),
(2641, 227, '2024-11-19 18:47:03', NULL),
(2642, 202, '2024-11-19 18:47:03', NULL),
(2643, 228, '2024-11-19 18:47:03', NULL),
(2644, 227, '2024-11-19 18:47:03', NULL),
(2645, 205, '2024-11-19 18:47:03', NULL),
(2646, 202, '2024-11-19 21:18:03', NULL),
(2647, 205, '2024-11-19 18:47:03', NULL),
(2648, 205, '2024-11-19 18:47:03', NULL),
(2649, 205, '2024-11-19 18:47:03', NULL),
(2650, 202, '2024-11-19 18:47:03', NULL),
(2651, 202, '2024-11-19 21:18:03', NULL),
(2652, 227, '2024-11-19 18:47:03', NULL),
(2653, 227, '2024-11-19 18:47:03', NULL),
(2654, 205, '2024-11-19 18:47:03', NULL),
(2655, 227, '2024-11-19 18:47:03', NULL),
(2656, 227, '2024-11-19 18:47:03', NULL),
(2657, 227, '2024-11-19 18:47:03', NULL),
(2658, 227, '2024-11-19 18:47:03', NULL),
(2659, 227, '2024-11-19 18:47:03', NULL),
(2660, 227, '2024-11-19 18:47:03', NULL),
(2661, 202, '2024-11-19 21:18:03', NULL),
(2662, 227, '2024-11-19 21:18:03', NULL),
(2663, 227, '2024-11-19 18:47:03', NULL),
(2664, 227, '2024-11-19 18:47:03', NULL),
(2665, 205, '2024-11-19 18:47:03', NULL),
(2666, 205, '2024-11-19 18:47:03', NULL),
(2667, 205, '2024-11-19 21:18:03', NULL),
(2668, 126, '2024-11-19 18:47:03', NULL),
(2669, 202, '2024-11-19 21:18:03', NULL),
(2670, 227, '2024-11-19 21:18:03', NULL),
(2671, 202, '2024-11-19 21:18:03', NULL),
(2672, 227, '2024-11-19 21:18:03', NULL),
(2673, 202, '2024-11-19 21:18:03', NULL),
(2674, 227, '2024-11-19 21:18:03', NULL),
(2675, 202, '2024-11-19 21:18:03', NULL),
(2676, 227, '2024-11-19 18:47:03', NULL),
(2677, 205, '2024-11-19 18:47:03', NULL),
(2678, 227, '2024-11-20 15:53:56', NULL),
(2679, 227, '2024-11-19 18:47:03', NULL),
(2680, 227, '2024-11-19 18:47:03', NULL),
(2681, 227, '2024-11-19 18:47:03', NULL),
(2682, 227, '2024-11-20 16:19:45', NULL),
(2683, 227, '2024-11-20 16:21:08', NULL),
(2684, 227, '2024-11-20 15:53:56', NULL),
(2685, 227, '2024-11-20 16:21:08', NULL),
(2686, 227, '2024-11-20 16:21:08', NULL),
(2687, 202, '2024-11-20 15:53:56', NULL),
(2688, 202, '2024-11-20 15:53:56', NULL),
(2689, 202, '2024-11-20 17:43:02', NULL),
(2690, 202, '2024-11-20 17:43:02', NULL),
(2691, 202, '2024-11-21 10:03:25', NULL),
(2692, 202, '2024-11-21 11:28:05', NULL),
(2693, 205, '2024-11-20 16:21:08', NULL),
(2694, 227, '2024-11-20 16:21:08', NULL),
(2695, 205, '2024-11-20 16:21:08', NULL),
(2696, 227, '2024-11-20 16:21:08', NULL),
(2697, 126, '2024-11-20 16:21:08', NULL),
(2698, 227, '2024-11-20 16:21:08', NULL),
(2699, 126, '2024-11-20 16:21:08', NULL),
(2700, 227, '2024-11-20 16:21:08', NULL),
(2701, 227, '2024-11-20 16:21:08', NULL),
(2702, 227, '2024-11-20 16:21:08', NULL),
(2703, 205, '2024-11-20 16:21:08', NULL),
(2704, 126, '2024-11-20 16:21:08', NULL),
(2705, 205, '2024-11-20 16:21:08', NULL),
(2706, 205, '2024-11-20 16:21:08', NULL),
(2707, 227, '2024-11-20 16:21:08', NULL),
(2708, 205, '2024-11-20 16:21:08', NULL),
(2709, 227, '2024-11-20 16:21:08', NULL),
(2710, 205, '2024-11-20 16:21:08', NULL),
(2711, 205, '2024-11-20 16:21:08', NULL),
(2712, 205, '2024-11-20 16:21:08', NULL),
(2713, 227, '2024-11-20 16:21:08', NULL),
(2714, 228, '2024-11-20 16:21:08', NULL),
(2715, 205, '2024-11-20 16:21:08', NULL),
(2716, 207, '2024-11-20 16:21:08', NULL),
(2717, 205, '2024-11-20 16:21:08', NULL),
(2718, 205, '2024-11-20 16:21:08', NULL),
(2719, 228, '2024-11-20 16:21:08', NULL),
(2720, 202, '2024-11-21 16:43:18', NULL),
(2721, 202, '2024-11-21 16:43:18', NULL),
(2722, 230, '2024-11-21 16:43:18', NULL),
(2723, 230, '2024-11-21 16:43:18', NULL),
(2724, 230, '2024-11-21 16:43:18', NULL),
(2725, 230, '2024-11-20 16:21:08', NULL),
(2726, 205, '2024-11-20 16:21:08', NULL),
(2727, 230, '2024-11-21 16:43:18', NULL),
(2728, 230, '2024-11-21 16:43:18', NULL),
(2729, 230, '2024-11-21 16:43:18', NULL),
(2730, 205, '2024-11-21 16:43:18', NULL),
(2731, 205, '2024-11-22 10:09:13', NULL),
(2732, 227, '2024-11-22 10:09:13', NULL),
(2733, 227, '2024-11-22 10:09:13', NULL),
(2734, 227, '2024-11-22 10:09:13', NULL),
(2735, 205, '2024-11-22 10:09:13', NULL),
(2736, 227, '2024-11-22 10:09:13', NULL),
(2737, 205, '2024-11-22 10:09:13', NULL),
(2738, 205, '2024-11-22 10:09:13', NULL),
(2739, 205, '2024-11-22 10:09:13', NULL),
(2740, 205, '2024-11-22 10:09:13', NULL),
(2741, 205, '2024-11-22 10:09:13', NULL),
(2742, 205, '2024-11-22 10:09:13', NULL),
(2743, 227, '2024-11-22 16:28:44', NULL),
(2744, 205, '2024-11-22 10:09:13', NULL),
(2745, 126, '2024-11-22 10:09:13', NULL),
(2746, 227, '2024-11-22 10:09:13', NULL),
(2747, 227, '2024-11-22 10:09:13', NULL),
(2748, 227, '2024-11-22 10:09:13', NULL),
(2749, 228, '2024-11-22 10:09:13', NULL),
(2750, 227, '2024-11-22 10:09:13', NULL),
(2751, 227, '2024-11-22 10:09:13', NULL),
(2752, 227, '2024-11-22 10:09:13', NULL),
(2753, 227, '2024-11-22 10:09:13', NULL),
(2754, 205, '2024-11-22 10:09:13', NULL),
(2755, 227, '2024-11-22 10:09:13', NULL),
(2756, 227, '2024-11-22 10:09:13', NULL),
(2757, 227, '2024-11-23 10:10:16', NULL),
(2758, 227, '2024-11-22 10:09:13', NULL),
(2759, 227, '2024-11-22 10:09:13', NULL),
(2760, 205, '2024-11-22 10:09:13', NULL),
(2761, 227, '2024-11-22 10:09:13', NULL),
(2762, 205, '2024-11-22 10:09:13', NULL),
(2763, 227, '2024-11-22 10:09:13', NULL),
(2764, 227, '2024-11-22 10:09:13', NULL),
(2765, 205, '2024-11-22 10:09:13', NULL),
(2766, 205, '2024-11-22 10:09:13', NULL),
(2767, 205, '2024-11-22 10:09:13', NULL),
(2768, 227, '2024-11-22 10:09:13', NULL),
(2769, 227, '2024-11-22 10:09:13', NULL),
(2770, 227, '2024-11-22 10:09:13', NULL),
(2771, 227, '2024-11-22 10:09:13', NULL),
(2772, 230, '2024-11-23 10:10:16', NULL),
(2773, 205, '2024-11-23 10:10:16', NULL),
(2774, 230, '2024-11-23 10:10:16', NULL),
(2775, 227, '2024-11-22 10:09:13', NULL),
(2776, 227, '2024-11-22 10:09:13', NULL),
(2777, 227, '2024-11-22 10:09:13', NULL),
(2778, 227, '2024-11-22 10:09:13', NULL),
(2779, 227, '2024-11-24 20:24:03', NULL),
(2780, 205, '2024-11-24 20:24:03', NULL),
(2781, 205, '2024-11-24 20:24:03', NULL),
(2782, 205, '2024-11-24 20:24:03', NULL),
(2783, 205, '2024-11-24 20:24:03', NULL),
(2784, 205, '2024-11-24 20:24:03', NULL),
(2785, 205, '2024-11-22 10:09:13', NULL),
(2786, 205, '2024-11-22 10:09:13', NULL),
(2787, 205, '2024-11-22 10:09:13', NULL),
(2788, 205, '2024-11-24 20:24:03', NULL),
(2789, 205, '2024-11-24 20:24:03', NULL),
(2790, 205, '2024-11-24 20:24:03', NULL),
(2791, 126, '2024-11-25 11:56:16', NULL),
(2792, 126, '2024-11-25 11:57:03', NULL),
(2793, 126, '2024-11-25 12:18:17', NULL),
(2794, 126, '2024-11-25 12:18:17', NULL),
(2795, 205, '2024-11-22 10:09:13', NULL),
(2796, 205, '2024-11-22 10:09:13', NULL),
(2797, 205, '2024-11-25 16:31:05', NULL),
(2798, 205, '2024-11-25 16:31:05', NULL),
(2799, 205, '2024-11-24 20:24:03', NULL),
(2800, 205, '2024-11-24 20:24:03', NULL),
(2801, 205, '2024-11-26 10:12:42', NULL),
(2802, 126, '2024-11-22 10:09:13', NULL),
(2803, 205, '2024-11-22 10:09:13', NULL),
(2804, 205, '2024-11-22 10:09:13', NULL),
(2805, 205, '2024-11-22 10:09:13', NULL),
(2806, 205, '2024-11-22 10:09:13', NULL),
(2807, 205, '2024-11-26 15:24:41', NULL),
(2808, 205, '2024-11-26 15:31:59', NULL),
(2809, 205, '2024-11-26 15:31:59', NULL),
(2810, 205, '2024-11-26 15:31:59', NULL),
(2811, 205, '2024-11-26 15:31:59', NULL),
(2812, 205, '2024-11-22 10:09:13', NULL),
(2813, 205, '2024-11-22 10:09:13', NULL),
(2814, 227, '2024-11-22 10:09:13', NULL),
(2815, 230, '2024-11-22 10:09:13', NULL),
(2816, 126, '2024-11-22 10:09:13', NULL),
(2817, 205, '2024-11-26 17:59:46', NULL),
(2818, 205, '2024-11-26 17:59:46', NULL),
(2819, 205, '2024-11-27 10:25:22', NULL),
(2820, 205, '2024-11-27 10:25:22', NULL),
(2821, 205, '2024-11-27 10:25:22', NULL),
(2822, 205, '2024-11-27 12:04:32', NULL),
(2823, 205, '2024-11-27 12:04:32', NULL),
(2824, 227, '2024-11-27 13:57:47', NULL),
(2825, 227, '2024-11-27 15:30:17', NULL),
(2826, 205, '2024-11-27 15:48:19', NULL),
(2827, 227, '2024-11-27 16:05:37', NULL),
(2828, 205, '2024-11-27 16:05:37', NULL),
(2829, 227, '2024-11-27 16:16:37', NULL),
(2830, 227, '2024-11-27 16:16:37', NULL),
(2831, 228, '2024-11-27 16:16:37', NULL),
(2832, 228, '2024-11-27 16:16:37', NULL),
(2833, 227, '2024-11-27 16:16:37', NULL),
(2834, 227, '2024-11-27 16:16:37', NULL),
(2835, 227, '2024-11-27 16:16:37', NULL),
(2836, 227, '2024-11-27 16:16:37', NULL),
(2837, 227, '2024-11-27 16:16:37', NULL),
(2838, 227, '2024-11-27 16:16:37', NULL),
(2839, 227, '2024-11-27 18:17:26', NULL),
(2840, 227, '2024-11-27 18:17:26', NULL),
(2841, 205, '2024-11-27 16:16:37', NULL),
(2842, 205, '2024-11-28 15:48:25', NULL),
(2843, 205, '2024-11-28 15:48:25', NULL),
(2844, 205, '2024-11-28 17:42:12', NULL),
(2845, 205, '2024-11-29 10:15:02', NULL),
(2846, 205, '2024-11-29 13:52:44', NULL),
(2847, 205, '2024-11-29 13:52:44', NULL),
(2848, 205, '2024-11-29 13:27:45', NULL),
(2849, 205, '2024-11-29 13:52:44', NULL),
(2850, 126, '2024-11-29 13:52:44', NULL),
(2851, 126, '2024-11-29 13:52:44', NULL),
(2852, 205, '2024-11-29 13:52:44', NULL),
(2853, 205, '2024-11-29 13:52:44', NULL),
(2854, 205, '2024-11-29 13:52:44', NULL),
(2855, 205, '2024-11-29 13:52:44', NULL),
(2856, 126, '2024-11-29 17:17:00', NULL),
(2857, 205, '2024-11-29 17:17:00', NULL),
(2858, 205, '2024-11-29 17:17:00', NULL),
(2859, 205, '2024-11-29 17:23:30', NULL),
(2860, 126, '2024-11-29 17:23:30', NULL),
(2861, 205, '2024-11-29 17:23:30', NULL),
(2862, 205, '2024-12-02 10:04:57', NULL),
(2863, 205, '2024-12-02 10:07:47', NULL),
(2864, 205, '2024-12-02 10:07:47', NULL),
(2865, 205, '2024-12-02 10:07:47', NULL),
(2866, 227, '2024-11-29 17:23:30', NULL),
(2867, 126, '2024-11-29 17:23:30', NULL),
(2868, 205, '2024-11-29 17:23:30', NULL),
(2869, 205, '2024-11-29 17:23:30', NULL),
(2870, 205, '2024-11-29 17:23:30', NULL),
(2871, 205, '2024-11-29 17:23:30', NULL),
(2872, 205, '2024-11-29 17:23:30', NULL),
(2873, 205, '2024-11-29 17:23:30', NULL),
(2874, 126, '2024-11-29 17:23:30', NULL),
(2875, 126, '2024-11-29 17:23:30', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `usermodulemap`
--

CREATE TABLE `usermodulemap` (
  `userid` bigint NOT NULL,
  `moduleid` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `usermodulemap`
--

INSERT INTO `usermodulemap` (`userid`, `moduleid`) VALUES
(71, 1);

-- --------------------------------------------------------

--
-- Table structure for table `userrolemap`
--

CREATE TABLE `userrolemap` (
  `userid` bigint NOT NULL,
  `roleid` bigint NOT NULL,
  `status` bit(1) DEFAULT b'1',
  `createdon` datetime DEFAULT NULL,
  `createdby` bigint DEFAULT NULL,
  `lastmodifiedat` datetime DEFAULT NULL,
  `lastmodifiedby` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `userrolemap`
--

INSERT INTO `userrolemap` (`userid`, `roleid`, `status`, `createdon`, `createdby`, `lastmodifiedat`, `lastmodifiedby`) VALUES
(101, 22, b'1', '2024-03-27 16:35:16', 85, '2024-03-27 16:35:16', NULL),
(102, 22, b'1', NULL, NULL, NULL, NULL),
(103, 22, b'1', NULL, NULL, NULL, NULL),
(104, 22, b'1', NULL, NULL, NULL, NULL),
(105, 20, b'1', NULL, NULL, NULL, NULL),
(106, 21, b'1', NULL, NULL, NULL, NULL),
(108, 23, b'1', NULL, NULL, NULL, NULL),
(109, 22, b'1', NULL, NULL, NULL, NULL),
(110, 25, b'1', NULL, NULL, NULL, NULL),
(111, 20, b'1', NULL, NULL, NULL, NULL),
(112, 22, b'1', NULL, NULL, NULL, NULL),
(113, 27, b'1', NULL, NULL, NULL, NULL),
(114, 20, b'1', NULL, NULL, NULL, NULL),
(115, 20, b'1', NULL, NULL, NULL, NULL),
(116, 20, b'1', NULL, NULL, NULL, NULL),
(117, 26, b'1', NULL, NULL, NULL, NULL),
(118, 20, b'1', NULL, NULL, NULL, NULL),
(119, 20, b'1', NULL, NULL, NULL, NULL),
(120, 26, b'1', NULL, NULL, NULL, NULL),
(121, 26, b'1', NULL, NULL, NULL, NULL),
(122, 29, b'1', NULL, NULL, NULL, NULL),
(123, 37, b'1', NULL, NULL, NULL, NULL),
(126, 20, b'1', NULL, NULL, NULL, NULL),
(127, 26, b'1', NULL, NULL, NULL, NULL),
(128, 26, b'1', NULL, NULL, NULL, NULL),
(134, 26, b'1', NULL, NULL, NULL, NULL),
(138, 26, b'1', NULL, NULL, NULL, NULL),
(139, 41, b'1', NULL, NULL, NULL, NULL),
(159, 26, b'1', NULL, NULL, NULL, NULL),
(168, 42, b'1', NULL, NULL, NULL, NULL),
(169, 52, b'1', NULL, NULL, NULL, NULL),
(170, 49, b'1', NULL, NULL, NULL, NULL),
(172, 52, b'1', NULL, NULL, NULL, NULL),
(173, 52, b'1', NULL, NULL, NULL, NULL),
(174, 52, b'1', NULL, NULL, NULL, NULL),
(184, 52, b'1', NULL, NULL, NULL, NULL),
(186, 52, b'1', NULL, NULL, NULL, NULL),
(187, 52, b'1', NULL, NULL, NULL, NULL),
(188, 52, b'1', NULL, NULL, NULL, NULL),
(189, 52, b'1', NULL, NULL, NULL, NULL),
(190, 52, b'1', NULL, NULL, NULL, NULL),
(191, 52, b'1', NULL, NULL, NULL, NULL),
(192, 52, b'1', NULL, NULL, NULL, NULL),
(193, 52, b'1', NULL, NULL, NULL, NULL),
(194, 52, b'1', NULL, NULL, NULL, NULL),
(195, 52, b'1', NULL, NULL, NULL, NULL),
(196, 52, b'1', NULL, NULL, NULL, NULL),
(197, 52, b'1', NULL, NULL, NULL, NULL),
(198, 52, b'1', NULL, NULL, NULL, NULL),
(199, 52, b'1', NULL, NULL, NULL, NULL),
(200, 52, b'1', NULL, NULL, NULL, NULL),
(201, 52, b'1', NULL, NULL, NULL, NULL),
(202, 52, b'1', NULL, NULL, NULL, NULL),
(204, 52, b'1', NULL, NULL, NULL, NULL),
(205, 52, b'1', NULL, NULL, NULL, NULL),
(206, 52, b'1', NULL, NULL, NULL, NULL),
(207, 52, b'1', NULL, NULL, NULL, NULL),
(208, 52, b'1', NULL, NULL, NULL, NULL),
(209, 52, b'1', NULL, NULL, NULL, NULL),
(210, 52, b'1', NULL, NULL, NULL, NULL),
(211, 52, b'1', NULL, NULL, NULL, NULL),
(216, 52, b'1', NULL, NULL, NULL, NULL),
(222, 52, b'1', NULL, NULL, NULL, NULL),
(223, 52, b'1', NULL, NULL, NULL, NULL),
(224, 52, b'1', NULL, NULL, NULL, NULL),
(225, 52, b'1', NULL, NULL, NULL, NULL),
(226, 52, b'1', NULL, NULL, NULL, NULL),
(227, 52, b'1', NULL, NULL, NULL, NULL),
(228, 52, b'1', NULL, NULL, NULL, NULL),
(229, 52, b'1', NULL, NULL, NULL, NULL),
(230, 52, b'1', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` bigint NOT NULL,
  `username` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `password` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `mobileno` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `role` varchar(10) DEFAULT NULL,
  `isstaff` bit(1) DEFAULT b'0',
  `status` bit(1) DEFAULT b'1',
  `createdAt` datetime DEFAULT (convert_tz(now(),_utf8mb4'+00:00',_utf8mb4'+05:30')),
  `updatedAt` datetime DEFAULT (convert_tz(now(),_utf8mb4'+00:00',_utf8mb4'+05:30')),
  `createdby` bigint DEFAULT NULL,
  `updatedby` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `username`, `password`, `name`, `email`, `mobileno`, `role`, `isstaff`, `status`, `createdAt`, `updatedAt`, `createdby`, `updatedby`) VALUES
(126, 'tiaraadmin', '$2b$10$5PWTLmD/6eYKcRE.FNfAku/AWC7YT95mjTeMSDbrhEV2Pkf9CcnE.', 'tiaraadmin', 'tiaraadmin@gmail.com', '7845532002', NULL, b'1', b'1', '2024-04-12 18:26:35', '2024-04-12 18:26:35', 125, NULL),
(139, 'tiaradelivery', '$2b$10$6xy1wzuhVi2lBl7YUlfVyO.btfMulbhyWiyDISMstpWMBOSqfonWS', 'tiaradelivery', 'muthiah1007@gmail.com', '8903061356', NULL, b'1', b'1', '2024-06-11 22:35:08', '2024-06-12 14:08:08', 116, NULL),
(168, 'tiarapacked', '$2b$10$kp9hJmfP3jSbkTfWZrC9De4.EmRCW8psrdc1EwBvN/GguXLZj5d9i', 'tiarapacked', 'tiarapacked@gmail.com', '9600724178', NULL, b'1', b'1', '2024-09-06 18:29:26', '2024-09-06 18:29:26', 139, 168),
(170, 'tiarashipped', '$2b$10$mapDx1JRvDT8Vo7kmop.uOhlob3YDd5QfoUz/EHodSJ7wx/B5BxTm', 'tiarashipped', 'tiarashipped@gmail.com', '9600724179', NULL, b'1', b'1', '2024-09-06 19:04:09', '2024-09-06 19:04:09', 164, NULL),
(172, 'onlineschoolcustomer', '$2b$10$1/WwDdCV5AZOxFTT8le9Qu48.AN9XfSQTAtccpPwt63I4gUgbDDeu', 'onlineschoolcustomer', '2cqr2011@gmail.com', '6369515090', NULL, b'0', b'1', '2024-09-07 16:14:33', '2024-09-07 16:14:33', NULL, NULL),
(184, 'tiara', '$2b$10$ZVfAfGWrP4v0PuoKnDK/D.FR0F5Kyd3cJ3gBjDtk7mEkhppMg/Aoq', 'tiara', 'test123@gmail.com', '9900557609', NULL, b'0', b'1', '2024-09-07 16:58:38', '2024-09-07 16:58:38', NULL, NULL),
(186, 'aravindotp', '$2b$10$rUN/fjv.hIpptPfIkk9ieuye5JBOn73j2HeI1AmHItlVW/8vLVsNa', 'aravindotp', 'aravindotp@mail.com', '9361621891', NULL, b'0', b'1', '2024-09-27 19:06:14', '2024-09-27 19:06:14', NULL, NULL),
(192, 'Test', '$2b$10$LFrhHwlkcrJsBsYm1oMnEeIxWVVAqWPJIClOMPeOPnpTXjMG4vVwa', 'Test', 'b@gmail.com', '6379148114', NULL, b'0', b'1', '2024-10-02 05:34:09', '2024-10-02 05:34:09', NULL, NULL),
(193, 'hari', '$2b$10$XsJpzCJ/FVeyOEGiSqRaGOml8mozhMyzngPRtfjIxnBip/R1XI2MG', 'Gomathi', 'h@gmail.com', '9345002002', NULL, b'0', b'1', '2024-10-02 05:53:55', '2024-10-02 05:53:55', NULL, NULL),
(197, 'arunMuthiah', '$2b$10$of7Vyo22VZZdMH3Ksfk.8eHIsm4QBpLjx2ABO/Np8q8QtbzPrIz3a', 'arunMuthiah', 'abc@gmail.com', '8903061353', NULL, b'0', b'1', '2024-10-28 16:11:21', '2024-10-28 16:11:21', NULL, NULL),
(202, 'msarun199@gmail.com', '$2b$10$of7Vyo22VZZdMH3Ksfk.8eHIsm4QBpLjx2ABO/Np8q8QtbzPrIz3a', '2cqr', 'msarun199@gmail.com', '8940900293', NULL, b'0', b'1', '2024-11-06 02:38:54', '2024-11-06 02:38:54', NULL, NULL),
(204, 'testing', '$2b$10$TmYoB6Vh3s9Jftd6xNutfOBZHZHoLtVgMC1LXVihcdtOmAeP14Z3W', 'testing', 'testing@gmail.com', '8903061356', NULL, b'0', b'1', '2024-11-06 19:21:30', '2024-11-06 19:21:30', NULL, NULL),
(205, 'admin06', '$2b$10$lcIZSBAzabVJQCDwGhoy/el4To9VVDW229/4fTzZM5AqQ463ZQsXe', 'Anitha', 'a@gmail.com', '6374573725', NULL, b'0', b'1', '2024-11-07 18:56:04', '2024-11-07 18:56:04', NULL, NULL),
(207, 'test12', '$2b$10$Deq80.0m74yPs4V31o6V5enuLJD8c1fy1chq8ITz1eO89DX5b0F.G', 'test12', 'bharathi@2cqr.in', '9600420101', NULL, b'0', b'1', '2024-11-11 21:24:48', '2024-11-11 21:24:48', NULL, NULL),
(210, 'fds', '$2b$10$cQrgb42G7AKc1hApQMHIH.6rWiG9etQqIs2lFXBYykVeefFoOPmFe', 'fds', 'raghul1a@mail.com', '8940900245', NULL, b'0', b'1', '2024-11-14 22:52:48', '2024-11-14 22:52:48', NULL, NULL),
(226, 'admin', '$2b$10$HmucmvMXF5Ud93dAtKjIpOL3ag1UTB5vJR7ihoLzdYSYsFVMTFJSu', 'anitha', 'an@gmail.com', '9894749741', NULL, b'0', b'1', '2024-11-15 23:17:27', '2024-11-15 23:17:27', NULL, NULL),
(227, 'admin12', '$2b$10$6XzO1oH7dGm76Tl4iZksv.4P4Yr7.tomaqAm5AqWB00UC5QaHJrSK', 'Ahtina', 'arulkumaranramu@gmail.com', '8248498874', NULL, b'0', b'1', '2024-11-19 21:01:53', '2024-11-19 21:01:53', NULL, NULL),
(228, 'admin99', '$2b$10$efYsZdLTDbVyYU75yfOAqOrv/xGHRBGe/I.xWySCIdtsl3eAK1Xq6', 'Tiara', 'anithaalex958@gmail.com', '9894749740', NULL, b'0', b'1', '2024-11-20 18:43:44', '2024-11-20 18:43:44', NULL, NULL),
(229, 'abc@gmail.com', '$2b$10$nVUXJWHMS8hh5uZ7q4ncY.bk0rbQhzUZ.Q5G3QfkSYnSp1zkdfNby', '2cqr', 'msarun19949@gmail.com', '8903061357', NULL, b'0', b'1', '2024-11-21 22:22:58', '2024-11-21 22:22:58', NULL, NULL),
(230, 'arun', '$2b$10$QKW1gNbiawBNzMrB9ZsBkOUUKmOU/eYmxAoM.3NwYDyElU1uY/qc6', 'arun', 'muthiah1006@gmail.com', '8940900292', NULL, b'0', b'1', '2024-11-21 22:29:00', '2024-11-21 22:29:00', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `usersschoolmap`
--

CREATE TABLE `usersschoolmap` (
  `autoid` int NOT NULL,
  `userid` bigint NOT NULL,
  `schoolid` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `usersschoolmap`
--

INSERT INTO `usersschoolmap` (`autoid`, `userid`, `schoolid`) VALUES
(1, 172, 13),
(2, 173, 13),
(3, 174, 13),
(4, 184, 0),
(5, 184, 13),
(6, 186, 13),
(7, 187, 13),
(8, 187, 21),
(9, 188, 13),
(10, 189, 21),
(11, 190, 13),
(12, 191, 21),
(13, 192, 21),
(14, 193, 13),
(15, 193, 21),
(16, 194, 13),
(17, 195, 13),
(18, 196, 19),
(19, 197, 194),
(20, 198, 13),
(21, 199, 13),
(22, 199, 21),
(23, 200, 21),
(24, 201, 21),
(25, 202, 19),
(27, 204, 21),
(28, 205, 21),
(29, 206, 13),
(30, 207, 19),
(31, 208, 13),
(32, 209, 13),
(33, 210, 13),
(34, 211, 21),
(35, 213, 13),
(36, 216, 21),
(37, 224, 13),
(38, 225, 13),
(39, 226, 21),
(40, 227, 215),
(41, 228, 215),
(42, 229, 13),
(43, 230, 215);

-- --------------------------------------------------------

--
-- Table structure for table `user_status`
--

CREATE TABLE `user_status` (
  `id` bigint NOT NULL,
  `username` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `loginAttempts` bigint DEFAULT '0',
  `lockedAt` datetime DEFAULT NULL,
  `loginBlockedUntil` datetime DEFAULT NULL,
  `refresh_token` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `createdAt` datetime DEFAULT (convert_tz(now(),_utf8mb4'+00:00',_utf8mb4'+05:30')),
  `updatedAt` datetime DEFAULT (convert_tz(now(),_utf8mb4'+00:00',_utf8mb4'+05:30')),
  `createdby` bigint DEFAULT NULL,
  `updatedby` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user_status`
--

INSERT INTO `user_status` (`id`, `username`, `loginAttempts`, `lockedAt`, `loginBlockedUntil`, `refresh_token`, `createdAt`, `updatedAt`, `createdby`, `updatedby`) VALUES
(1, '2cqr2011', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjk4LCJFbWFpbCI6IjJjcXIyMDEzQGdtYWlsLmNvbSIsIklzc3RhZmYiOnRydWUsImlhdCI6MTcxMTUzMjgyMywiZXhwIjoxNzExNjE5MjIzfQ.gpwELdOs7hJqx4afWqSGktf1OVP-QVYVOnIypDQmaCg', '2024-03-27 09:45:49', '2024-03-27 09:47:03', NULL, NULL),
(2, 'kannan', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjg1LCJFbWFpbCI6Imthbm5hbkBnbWFpbC5jb20iLCJJc3N0YWZmIjp0cnVlLCJpYXQiOjE3MTE1NDM1NzMsImV4cCI6MTcxMTYyOTk3M30.tnwAQBMk2g1Ve7oJgRFO3rZzpqb5R_KI6jHwUbNhr7M', '2024-03-27 09:57:52', '2024-03-27 12:46:13', NULL, NULL),
(3, 'cqr', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEwMCwiRW1haWwiOiJjcXJAZ21haWwuY29tIiwiSXNzdGFmZiI6ZmFsc2UsImlhdCI6MTcxMTUzNzEzMCwiZXhwIjoxNzExNjIzNTMwfQ.8zJH25h7ds1BZjBjXG0_-0Tds3hGRj1KO_i6yrNmoYc', '2024-03-27 10:58:50', '2024-03-27 10:58:50', NULL, NULL),
(4, '2cqrcqr', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEwMSwiRW1haWwiOiJtdXRoaWFoMTAwNkBnbWFpbC5jb20iLCJJc3N0YWZmIjpmYWxzZSwiaWF0IjoxNzExNTQwNzAxLCJleHAiOjE3MTE2MjcxMDF9.6FLHEyXqB8jzBfZsrSQdIvE50VNEJoG-2RIyY5kXWhA', '2024-03-27 11:44:22', '2024-03-27 11:58:21', NULL, NULL),
(5, 'cqrcqr', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEwMiwiRW1haWwiOiJjcXIyMDExQGdtYWlsLmNvbSIsIklzc3RhZmYiOmZhbHNlLCJpYXQiOjE3MTE1NDEyMzYsImV4cCI6MTcxMTYyNzYzNn0.pw9kTDIVvFJD4mA4YLCnjP8dGf80QpXKx67NbOtG0GQ', '2024-03-27 12:07:17', '2024-03-27 12:07:17', NULL, NULL),
(6, 'karthikarthi', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEwNCwiRW1haWwiOiJrYXJ0aGlAZ21haWwuY29tIiwiSXNzdGFmZiI6ZmFsc2UsImlhdCI6MTcxMTU0MzIzNSwiZXhwIjoxNzExNjI5NjM1fQ.zsgrvdXyzDU6Cz-8-B3iRUzTHcjTMxaaTkA6HoDqb-c', '2024-03-27 12:13:15', '2024-03-27 12:40:35', NULL, NULL),
(8, 'storemanager', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEwOCwiRW1haWwiOiJiaGFyYXRoaUBnbWFpbC5jb20iLCJJc3N0YWZmIjp0cnVlLCJpYXQiOjE3MTE2MjExMzgsImV4cCI6MTcxMTcwNzUzOH0.EyBHJpUfE2pV5d3vJxjP_CGhICoU9nMV_p1lXpv6n6s', '2024-03-28 07:10:47', '2024-03-28 10:18:58', NULL, NULL),
(9, 'bharathi', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEwOSwiRW1haWwiOiJiaGFyYXRoaTEyM0BnbWFpbC5jb20iLCJJc3N0YWZmIjpmYWxzZSwiaWF0IjoxNzExOTQ5ODYzLCJleHAiOjE3MTIwMzYyNjN9.VG9_4EBDe399Dla-TNicN92Gul_E--tsBc6ZMpLcorw', '2024-03-28 07:42:01', '2024-04-01 05:37:43', NULL, NULL),
(10, 'ahtina06', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjExMCwiRW1haWwiOiJhQGdtYWlsLmNvbSIsIklzc3RhZmYiOnRydWUsImlhdCI6MTcxMTYxNTgzOSwiZXhwIjoxNzExNzAyMjM5fQ.MpBDzEZLXlkfPCf5o_LSNZlfwtT_3IMdR_N0mJJSFTQ', '2024-03-28 08:50:39', '2024-03-28 08:50:39', NULL, NULL),
(11, 'tiaradelivery', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEzOSwiRW1haWwiOiJtdXRoaWFoMTAwN0BnbWFpbC5jb20iLCJJc3N0YWZmIjp0cnVlLCJpYXQiOjE3MjU2ODQ0NjksImV4cCI6MTcyNTc3MDg2OX0.SSvv0o5ArFDxcLCxvJN3kp2--EHEw5iv9ACr2en8K88', '2024-03-28 10:43:31', '2024-09-07 04:47:49', NULL, NULL),
(12, 'bharathiTest', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjExNywiRW1haWwiOiJiaGFyYXRoaUAyY3FyLmluIiwiSXNzdGFmZiI6ZmFsc2UsImlhdCI6MTcxMjMwMzUyNSwiZXhwIjoxNzEyMzg5OTI1fQ.ACyxGpuMdXF3vvC3K5x_ycPiCPBH_sX7cscx14ViEK8', '2024-04-01 06:13:59', '2024-04-05 07:52:05', NULL, NULL),
(13, 'bharathi2', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMSwiRW1haWwiOiIxMjNzb211QGdtYWlsLmNvbSIsIklzc3RhZmYiOmZhbHNlLCJpYXQiOjE3MTIxMjQ3NDIsImV4cCI6MTcxMjIxMTE0Mn0.pz9URS6f8Pd4GZD_KMrPP0CqQZjoFTdm6LNEYEwwuqY', '2024-04-03 05:19:58', '2024-04-03 06:12:22', NULL, NULL),
(14, 'a@0612', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyMiwiRW1haWwiOiJhQGdtYWlsLmNvbSIsIklzc3RhZmYiOnRydWUsImlhdCI6MTcxMjM4NzcyNCwiZXhwIjoxNzEyNDc0MTI0fQ.XCbunMg2tExC8z9MR65IU26eS3Uv9Q66sB4emoTmvV0', '2024-04-05 06:15:51', '2024-04-06 07:15:24', NULL, NULL),
(15, 'ani@06', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyOSwiRW1haWwiOiJhQGdtYWlsLmNvbSIsIklzc3RhZmYiOmZhbHNlLCJpYXQiOjE3MTgyNjgzNTIsImV4cCI6MTcxODM1NDc1Mn0.Djy3aRq5ZbEFDAZZFGSvnosUdVYce84sBvR4jCzFHfs', '2024-04-11 12:27:34', '2024-06-13 08:45:52', NULL, NULL),
(17, 'tiariaadmin', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyNSwiRW1haWwiOiJ0aWFyaWFhZG1pbkBnbWFpbC5jb20iLCJJc3N0YWZmIjp0cnVlLCJpYXQiOjE3MTI5MDU5MDYsImV4cCI6MTcxMjk5MjMwNn0.5Wc4H236lR7OZRGHJ-pFNEl7K-_Gj2yfwwFwmt0rNX8', '2024-04-12 07:11:46', '2024-04-12 07:11:46', NULL, NULL),
(18, 'tiaraadmin', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyNiwiRW1haWwiOiJ0aWFyYWFkbWluQGdtYWlsLmNvbSIsIklzc3RhZmYiOnRydWUsImlhdCI6MTczMzEzNDEzOCwiZXhwIjoxNzMzMjIwNTM4fQ.U8kVphlka7mpzNIl6K0aIVW4bhqv-K9egBPSR6lCADU', '2024-04-12 07:26:55', '2024-12-02 10:08:58', NULL, NULL),
(19, 'tiaraclothing', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyOCwiRW1haWwiOiJtdXRoaWFoMTAwNkBnbWFpbC5jb20iLCJJc3N0YWZmIjpmYWxzZSwiaWF0IjoxNzE0NDU4OTIzLCJleHAiOjE3MTQ1NDUzMjN9.K2qwhv-N2apqjQthQV2iVnBp8SUqVQZsh0CPRigUHDw', '2024-04-30 06:20:38', '2024-04-30 06:35:23', NULL, NULL),
(20, 'samplePasswordk18', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEzMSwiRW1haWwiOiJzYW1wbGVQYXNzd29yZGsxOEBleGFtcGxlLmNvbSIsIklzc3RhZmYiOmZhbHNlLCJpYXQiOjE3MTg2MTQxMzMsImV4cCI6MTcxODcwMDUzM30.Peyh3E2TzTEI5KbXiFAkHFZattRyQVg_4NQtUWUZ2X4', '2024-06-07 07:22:26', '2024-06-17 08:48:53', NULL, NULL),
(22, 'anitha', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEzMywiRW1haWwiOiJhbmlAZ21haWwuY29tIiwiSXNzdGFmZiI6ZmFsc2UsImlhdCI6MTcyMDQyNjM3NSwiZXhwIjoxNzIwNTEyNzc1fQ.48TimShugKEM_X2aou4ITfqjOzCoS9Os_Nb15ZiTCiI', '2024-06-11 06:27:38', '2024-07-08 08:12:55', NULL, NULL),
(23, 'ahtina', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEzNCwiRW1haWwiOiIiLCJJc3N0YWZmIjpmYWxzZSwiaWF0IjoxNzE4MDkwMzA4LCJleHAiOjE3MTgxNzY3MDh9.Sb7ySFD8JeIGGcAsdzFKH2S_Zlz4Kr5IqzefgR0aUEc', '2024-06-11 06:28:04', '2024-06-11 07:18:28', NULL, NULL),
(24, 'alex', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEzNSwiRW1haWwiOiJhbkBnbWFpbC5jb20iLCJJc3N0YWZmIjpmYWxzZSwiaWF0IjoxNzE4MDkwMjkzLCJleHAiOjE3MTgxNzY2OTN9.2IqmYU6t1YEufp5KT1j6KNuY_GZbtL2mjkmOEttEUbw', '2024-06-11 06:37:59', '2024-06-11 07:18:13', NULL, NULL),
(25, 'amul', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEzNiwiRW1haWwiOiJhYUBnbWFpbC5jb20iLCJJc3N0YWZmIjpmYWxzZSwiaWF0IjoxNzE4MDg5MjAyLCJleHAiOjE3MTgxNzU2MDJ9.WqZ4oVnxdGd_TBP_CjgTxfSM21bfclbU7HdFeQ3FwFM', '2024-06-11 06:52:59', '2024-06-11 07:00:02', NULL, NULL),
(26, 'anitha06', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEzNywiRW1haWwiOiJsYWtAZ21haWwuY29tIiwiSXNzdGFmZiI6ZmFsc2UsImlhdCI6MTcxODA5Mjc2OSwiZXhwIjoxNzE4MTc5MTY5fQ.9g6XY-t3NbQqB4Damnd7wf4LxCP0TdXR7W5LiVIIr_w', '2024-06-11 07:24:26', '2024-06-11 07:59:29', NULL, NULL),
(28, 'tiaraadmin', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyNiwiRW1haWwiOiJ0aWFyYWFkbWluQGdtYWlsLmNvbSIsIklzc3RhZmYiOnRydWUsImlhdCI6MTczMzEzNDEzOCwiZXhwIjoxNzMzMjIwNTM4fQ.U8kVphlka7mpzNIl6K0aIVW4bhqv-K9egBPSR6lCADU', '2024-06-22 18:36:20', '2024-12-02 10:08:58', NULL, NULL),
(29, 'mukilan', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE1MSwiRW1haWwiOiJtdWtpbGFuQGdtYWlsLmNvbSIsIklzc3RhZmYiOnRydWUsImlhdCI6MTcxOTA4MjUwNCwiZXhwIjoxNzE5MTY4OTA0fQ.MlMYbZ6SUW8y5ZyzXko2esstIaQj8sDpUE7QGc2vrhg', '2024-06-22 18:55:04', '2024-06-22 18:55:04', NULL, NULL),
(30, 'ganesh', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE1MiwiRW1haWwiOiJnYW5lc2hAZ21haWwuY29tIiwiSXNzdGFmZiI6dHJ1ZSwiaWF0IjoxNzE5MjA2NzI3LCJleHAiOjE3MTkyOTMxMjd9.F74ORtWs9PnuREQ9TeSsRibmBhKC9sT3TZLk7yx0Htg', '2024-06-24 05:25:27', '2024-06-24 05:25:27', NULL, NULL),
(36, '1234', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE2MCwiRW1haWwiOiJ4eUBnbWFpbC5jb20iLCJJc3N0YWZmIjp0cnVlLCJpYXQiOjE3MjUzNzMzNDQsImV4cCI6MTcyNTQ1OTc0NH0.K_pvT233eLj99qebIaeB49y4sslv_whAKEl2Sm--0XE', '2024-09-03 14:22:24', '2024-09-03 14:22:24', NULL, NULL),
(37, 'tiarabangalore', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE2MSwiRW1haWwiOiJhcnVubXV0aGlhaDEwMDY5OUBnbWFpbC5jb20iLCJJc3N0YWZmIjpmYWxzZSwiaWF0IjoxNzI1NDQ4NTkwLCJleHAiOjE3MjU1MzQ5OTB9.u4EJukET2TVNuPst9Ex85SsRdP6DsYgVBaUOO1g9oVg', '2024-09-04 06:39:21', '2024-09-04 11:16:30', NULL, NULL),
(44, 'tiarapacked', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE2OCwiRW1haWwiOiJ0aWFyYXBhY2tlZEBnbWFpbC5jb20iLCJJc3N0YWZmIjp0cnVlLCJpYXQiOjE3MjcxNTg3MDgsImV4cCI6MTcyNzI0NTEwOH0.PKNzNUaelEwbWzFq1I2hZWgWb28L66R05UAuKGqNJPc', '2024-09-06 07:29:54', '2024-09-24 06:18:28', NULL, NULL),
(46, 'tiarashipped', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE3MCwiRW1haWwiOiJ0aWFyYXNoaXBwZWRAZ21haWwuY29tIiwiSXNzdGFmZiI6dHJ1ZSwiaWF0IjoxNzI1Njg0NTIxLCJleHAiOjE3MjU3NzA5MjF9.c8mphA7FpM8VtZ_DfQh9sFruFhdPXFQJ6YltRKNTTaE', '2024-09-06 08:04:25', '2024-09-07 04:48:41', NULL, NULL),
(47, '1', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE3MSwiRW1haWwiOiJnQGdtYWlsLmNvbSIsIklzc3RhZmYiOnRydWUsImlhdCI6MTcyNTY0NzIyMywiZXhwIjoxNzI1NzMzNjIzfQ.VAQqT8H0UvSLDv5jbqiDdau491YnMlPUjLyUeLlIWvk', '2024-09-06 10:57:43', '2024-09-06 18:27:03', NULL, NULL),
(48, 'onlineschoolcustomer', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE3MiwiRW1haWwiOiIyY3FyMjAxMUBnbWFpbC5jb20iLCJJc3N0YWZmIjpmYWxzZSwiaWF0IjoxNzI1Njg3MDc4LCJleHAiOjE3MjU3NzM0Nzh9.y1mjg2dvvdpBxrTW7MJw5g95HbITWMQjOmEXO0qaPek', '2024-09-07 05:19:22', '2024-09-07 05:31:19', NULL, NULL),
(49, 'tiara', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE3MywiRW1haWwiOiJ0ZXN0MTIzQGdtYWlsLmNvbSIsIklzc3RhZmYiOmZhbHNlLCJpYXQiOjE3MjU2OTAzNTQsImV4cCI6MTcyNTc3Njc1NH0.E9XMQ2H_UQ-Om57tohL9ZoPkKymM9A-0YY_pw0LbPUg', '2024-09-07 05:59:02', '2024-09-07 06:25:55', NULL, NULL),
(51, 'aravindotp', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE4NiwiRW1haWwiOiJhcmF2aW5kb3RwQG1haWwuY29tIiwiSXNzdGFmZiI6ZmFsc2UsImlhdCI6MTcyNzQzNzkyMiwiZXhwIjoxNzI3NTI0MzIyfQ.SMYXqobuOBqkoeFbCCHl_MWVrGloEC3DC7xG4w28j2A', '2024-09-27 11:46:32', '2024-09-27 11:52:02', NULL, NULL),
(54, 'hari', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE5MywiRW1haWwiOiJoQGdtYWlsLmNvbSIsIklzc3RhZmYiOmZhbHNlLCJpYXQiOjE3Mjc4MDg4NzQsImV4cCI6MTcyNzg5NTI3NH0.8b12px1WMt8PZZaqHfLMSLhlIPTai4Dti1JjJ_jzrlg', '2024-10-01 18:54:03', '2024-10-01 18:54:34', NULL, NULL),
(55, 'test', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE5MiwiRW1haWwiOiJiQGdtYWlsLmNvbSIsIklzc3RhZmYiOmZhbHNlLCJpYXQiOjE3Mjc4MDg4NjAsImV4cCI6MTcyNzg5NTI2MH0.KeIKXS6DNuMsiO_okpIveD4bkO2khSJ0QsepPg2juSc', '2024-10-01 18:54:20', '2024-10-01 18:54:20', NULL, NULL),
(57, 'arunMuthiah', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE5NywiRW1haWwiOiJhYmNAZ21haWwuY29tIiwiSXNzdGFmZiI6ZmFsc2UsImlhdCI6MTczMTI5ODgzNCwiZXhwIjoxNzMxMzg1MjM0fQ.remYk30JgNrFsL5HqMsKCWII2CqRsFfD6_OZ2ga3UYY', '2024-10-28 05:11:28', '2024-11-11 04:20:34', NULL, NULL),
(62, 'msarun199@gmail.com', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIwMiwiRW1haWwiOiIyY3FyMjAyNEBnbWFpbC5jb20iLCJJc3N0YWZmIjpmYWxzZSwiaWF0IjoxNzMyMTg4MzM4LCJleHAiOjE3MzIyNzQ3Mzh9._xtspx_2ChQVi1LET8gpXcvdbE1n0uT5AnndldVO7Zg', '2024-11-05 15:39:26', '2024-11-21 11:25:39', NULL, NULL),
(64, 'testing', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIwNCwiRW1haWwiOiJ0ZXN0aW5nQGdtYWlsLmNvbSIsIklzc3RhZmYiOmZhbHNlLCJpYXQiOjE3MzA4ODE0MzcsImV4cCI6MTczMDk2NzgzN30.BarYIimuazrmzQ1CYb94YNpWHJhStIGmy62Rued5Bxs', '2024-11-06 08:21:39', '2024-11-06 08:23:57', NULL, NULL),
(65, 'admin06', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIwNSwiRW1haWwiOiJhQGdtYWlsLmNvbSIsIklzc3RhZmYiOmZhbHNlLCJpYXQiOjE3MzMxMjgzMjQsImV4cCI6MTczMzIxNDcyNH0.LI-EaGcXaPiKF-ZpRgMJb7cW0WOntYdqGtuxcYd95eo', '2024-11-07 08:10:24', '2024-12-02 08:32:04', NULL, NULL),
(67, 'test12', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIwNywiRW1haWwiOiJiaGFyYXRoaUAyY3FyLmluIiwiSXNzdGFmZiI6ZmFsc2UsImlhdCI6MTczMjE3ODgyNSwiZXhwIjoxNzMyMjY1MjI1fQ.-Lt-87jf7LPn9vCrNwFAXhuOdwBw5T6-ZpO5fY7HHYM', '2024-11-11 10:25:08', '2024-11-21 08:47:05', NULL, NULL),
(69, 'admin12', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIyNywiRW1haWwiOiJhcnVsa3VtYXJhbnJhbXVAZ21haWwuY29tIiwiSXNzdGFmZiI6ZmFsc2UsImlhdCI6MTczMzEyNDg0MSwiZXhwIjoxNzMzMjExMjQxfQ.vY4rTFPBcFNl524rGp4Brfinb3RpjzjsaBfFkCfnXUQ', '2024-11-19 10:06:20', '2024-12-02 07:34:01', NULL, NULL),
(70, 'admin99', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIyOCwiRW1haWwiOiJhbml0aGFhbGV4OTU4QGdtYWlsLmNvbSIsIklzc3RhZmYiOmZhbHNlLCJpYXQiOjE3MzI3MDg5NTcsImV4cCI6MTczMjc5NTM1N30.EnRq4N_7Uvaofj7t3p_Arfbr795YG48alDiHfWftQUM', '2024-11-20 07:43:53', '2024-11-27 12:02:37', NULL, NULL),
(71, 'arun', 0, NULL, NULL, 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIzMCwiRW1haWwiOiJtdXRoaWFoMTAwNkBnbWFpbC5jb20iLCJJc3N0YWZmIjpmYWxzZSwiaWF0IjoxNzMyNjE4MDg4LCJleHAiOjE3MzI3MDQ0ODh9.ixnWh99EL0WrdTJ1IqnXf5nkM1H4dN_2lJfhba7qkuA', '2024-11-21 11:29:08', '2024-11-26 10:48:08', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `variant`
--

CREATE TABLE `variant` (
  `id` bigint NOT NULL,
  `productid` bigint DEFAULT NULL,
  `size` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `imageid` int DEFAULT NULL,
  `weight` float DEFAULT NULL,
  `status` int NOT NULL DEFAULT '1',
  `createdby` bigint DEFAULT NULL,
  `createdon` datetime DEFAULT NULL,
  `lastmodifiedby` int DEFAULT NULL,
  `lastmodifiedon` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `variant`
--

INSERT INTO `variant` (`id`, `productid`, `size`, `color`, `price`, `quantity`, `imageid`, `weight`, `status`, `createdby`, `createdon`, `lastmodifiedby`, `lastmodifiedon`) VALUES
(294, 305, 'Extra small', 'Black', 34, 33, 1, 0, 1, NULL, NULL, NULL, NULL),
(295, 305, 'Extra small', 'blue', 34, 33, 1, 0, 1, NULL, NULL, NULL, NULL),
(296, 305, 'extra large', 'Black', 34, 33, 1, 0, 1, NULL, NULL, NULL, NULL),
(297, 305, 'extra large', 'blue', 34, 33, 1, 0, 1, NULL, NULL, NULL, NULL),
(322, 306, 'Extra small', 'orange', 678, 67, 1, 0, 1, NULL, NULL, NULL, NULL),
(323, 306, 'Extra small', 'blue', 678, 67, 1, 0, 1, NULL, NULL, NULL, NULL),
(324, 306, 'small', 'orange', 678, 67, 1, 0, 1, NULL, NULL, NULL, NULL),
(325, 306, 'small', 'blue', 678, 67, 1, 0, 1, NULL, NULL, NULL, NULL),
(326, 306, 'medium', 'orange', 678, 67, 1, 0, 1, NULL, NULL, NULL, NULL),
(327, 306, 'medium', 'blue', 678, 67, 1, 0, 1, NULL, NULL, NULL, NULL),
(328, 307, 'Extra small', 'Black', 567, 678, 1, 567, 1, NULL, NULL, NULL, NULL),
(329, 307, 'Extra small', 'green', 567, 678, 1, 567, 1, NULL, NULL, NULL, NULL),
(330, 307, 'extra large', 'Black', 567, 678, 1, 567, 1, NULL, NULL, NULL, NULL),
(331, 307, 'extra large', 'green', 567, 678, 1, 567, 1, NULL, NULL, NULL, NULL),
(401, 308, 'Extra small', 'orange', 6789, 78789, 1, 0, 1, NULL, NULL, NULL, NULL),
(402, 308, 'Extra small', 'green', 6789, 78789, 1, 0, 1, NULL, NULL, NULL, NULL),
(403, 308, 'extra large', 'orange', 6789, 78789, 1, 0, 1, NULL, NULL, NULL, NULL),
(404, 308, 'extra large', 'green', 6789, 78789, 1, 0, 1, NULL, NULL, NULL, NULL),
(405, 315, 'small', 'Black', 456, 455, 1, 0, 1, NULL, NULL, NULL, NULL),
(406, 315, 'medium', 'Black', 456, 455, 1, 0, 1, NULL, NULL, NULL, NULL),
(455, 319, 'small', 'orange', 123, 123, 1, 0, 1, NULL, NULL, NULL, NULL),
(456, 319, 'small', 'green', 123, 123, 1, 0, 1, NULL, NULL, NULL, NULL),
(457, 319, 'extra large', 'orange', 123, 123, 1, 0, 1, NULL, NULL, NULL, NULL),
(458, 319, 'extra large', 'green', 123, 123, 1, 0, 1, NULL, NULL, NULL, NULL),
(465, 321, 'small', 'orange', 3, 3432, 1, 424, 1, NULL, NULL, NULL, NULL),
(466, 321, 'small', 'green', 3, 3432, 1, 424, 1, NULL, NULL, NULL, NULL),
(467, 321, 'large', 'orange', 3, 3432, 1, 424, 1, NULL, NULL, NULL, NULL),
(468, 321, 'large', 'green', 3, 3432, 1, 424, 1, NULL, NULL, NULL, NULL),
(481, 326, 'small', 'Black', 512, 5, 1, 1, 1, NULL, NULL, NULL, NULL),
(482, 326, 'small', 'green', 365, 5, 1, 1, 1, NULL, NULL, NULL, NULL),
(483, 326, 'Extra small', 'Black', 496, 5, 1, 1, 1, NULL, NULL, NULL, NULL),
(484, 326, 'Extra small', 'green', 598, 5, 1, 1, 1, NULL, NULL, NULL, NULL),
(485, 327, 'small', 'Black', 512, 5, 1, 1, 1, NULL, NULL, NULL, NULL),
(486, 327, 'small', 'green', 365, 5, 1, 1, 1, NULL, NULL, NULL, NULL),
(487, 327, 'Extra small', 'Black', 496, 5, 1, 1, 1, NULL, NULL, NULL, NULL),
(488, 327, 'Extra small', 'green', 598, 5, 1, 1, 1, NULL, NULL, NULL, NULL),
(493, 329, 'small', 'orange', 876, 54, 1, 1, 1, NULL, NULL, NULL, NULL),
(494, 329, 'small', 'Black', 876, 4, 1, 1, 1, NULL, NULL, NULL, NULL),
(495, 329, 'Extra small', 'orange', 876, 4, 1, 1, 1, NULL, NULL, NULL, NULL),
(496, 329, 'Extra small', 'Black', 876, 5, 1, 1, 1, NULL, NULL, NULL, NULL),
(503, 331, 'small', 'Black', 876, 0, 1, 1, 1, NULL, NULL, NULL, NULL),
(510, 320, 'Extra small', 'orange', 456, 45, 1, 0, 1, NULL, NULL, NULL, NULL),
(511, 320, 'Extra small', 'green', 456, 45, 1, 0, 1, NULL, NULL, NULL, NULL),
(512, 320, 'extra large', 'orange', 456, 45, 1, 0, 1, NULL, NULL, NULL, NULL),
(513, 320, 'extra large', 'green', 456, 45, 1, 0, 1, NULL, NULL, NULL, NULL),
(514, 320, 'Extra small', 'Black', 456, 45, 1, 0, 1, NULL, NULL, NULL, NULL),
(515, 320, 'extra large', 'Black', 456, 45, 1, 0, 1, NULL, NULL, NULL, NULL),
(516, 332, 'small', 'blue', 564, 24, 1, 1, 1, NULL, NULL, NULL, NULL),
(525, 318, 'small', 'Black', 875, 10, 1, 0, 1, NULL, NULL, NULL, NULL),
(526, 318, 'small', 'orange', 986, 10, 1, 0, 1, NULL, NULL, NULL, NULL),
(527, 318, 'extra large', 'Black', 678, 10, 1, 0, 1, NULL, NULL, NULL, NULL),
(528, 318, 'extra large', 'orange', 999, 10, 1, 0, 1, NULL, NULL, NULL, NULL),
(529, 318, 'large', 'Black', 987, 10, 1, 0, 1, NULL, NULL, NULL, NULL),
(530, 318, 'large', 'orange', 576, 10, 1, 0, 1, NULL, NULL, NULL, NULL),
(531, 318, 'Extra small', 'Black', 898, 10, 1, 0, 1, NULL, NULL, NULL, NULL),
(532, 318, 'Extra small', 'orange', 909, 10, 1, 0, 1, NULL, NULL, NULL, NULL),
(533, 333, 'small', 'Black', 675, 10, 1, 2, 1, NULL, NULL, NULL, NULL),
(534, 334, 'small', 'orange', 56, 0, 1, 45, 1, NULL, NULL, NULL, NULL),
(535, 334, 'small', 'blue', 56, 34, 1, 45, 1, NULL, NULL, NULL, NULL),
(536, 334, 'large', 'orange', 56, 36, 1, 45, 1, NULL, NULL, NULL, NULL),
(537, 334, 'large', 'blue', 56, 41, 1, 45, 1, NULL, NULL, NULL, NULL),
(538, 335, 'small', 'Black', 12, 10, 1, 100, 1, NULL, NULL, NULL, NULL),
(539, 336, 'small', 'Black', 12, 0, 1, 100, 1, NULL, NULL, NULL, NULL),
(540, 336, 'small', 'green', 120, 109, 1, 100, 1, NULL, NULL, NULL, NULL),
(541, 336, 'small', 'blue', 129, 34, 1, 100, 1, NULL, NULL, NULL, NULL),
(542, 337, 'small', 'orange', 786, 285, 1, 1, 1, NULL, NULL, NULL, NULL),
(543, 337, 'small', 'blue', 786, 12, 1, 1, 1, NULL, NULL, NULL, NULL),
(544, 338, 'small', 'orange', 12, 0, 1, 12, 1, NULL, NULL, NULL, NULL),
(545, 338, 'medium', 'orange', 12, 12, 1, 12, 1, NULL, NULL, NULL, NULL),
(546, 339, 'small', 'orange', 34, 32, 1, 34, 1, NULL, NULL, NULL, NULL),
(547, 339, 'large', 'orange', 34, 34, 1, 34, 1, NULL, NULL, NULL, NULL),
(548, 340, 'Extra small', 'orange', 34, 31, 1, 34, 1, NULL, NULL, NULL, NULL),
(549, 340, 'Extra small', 'blue', 34, 34, 1, 34, 1, NULL, NULL, NULL, NULL),
(550, 340, 'small', 'orange', 34, 34, 1, 34, 1, NULL, NULL, NULL, NULL),
(551, 340, 'small', 'blue', 34, 34, 1, 34, 1, NULL, NULL, NULL, NULL),
(552, 341, 'small', 'Black', 43, 34, 1, 34, 1, NULL, NULL, NULL, NULL),
(553, 341, 'small', 'green', 43, 34, 1, 34, 1, NULL, NULL, NULL, NULL),
(554, 341, 'extra large', 'Black', 43, 34, 1, 34, 1, NULL, NULL, NULL, NULL),
(555, 341, 'extra large', 'green', 43, 34, 1, 34, 1, NULL, NULL, NULL, NULL),
(559, 343, 'small', 'Black', 674, 20000, 1, 5, 1, NULL, NULL, NULL, NULL),
(560, 343, 'small', 'blue', 674, 20000, 1, 5, 1, NULL, NULL, NULL, NULL),
(561, 343, 'small', 'red', 674, 20000, 1, 5, 1, NULL, NULL, NULL, NULL),
(562, 343, 'extra large', 'Black', 674, 20000, 1, 5, 1, NULL, NULL, NULL, NULL),
(563, 343, 'extra large', 'blue', 674, 20000, 1, 5, 1, NULL, NULL, NULL, NULL),
(564, 343, 'extra large', 'red', 674, 20000, 1, 5, 1, NULL, NULL, NULL, NULL),
(565, 343, 'large', 'Black', 674, 20000, 1, 5, 1, NULL, NULL, NULL, NULL),
(566, 343, 'large', 'blue', 674, 20000, 1, 5, 1, NULL, NULL, NULL, NULL),
(567, 343, 'large', 'red', 674, 20000, 1, 5, 1, NULL, NULL, NULL, NULL),
(568, 343, 'Extra small', 'Black', 674, 20000, 1, 5, 1, NULL, NULL, NULL, NULL),
(569, 343, 'Extra small', 'blue', 674, 20000, 1, 5, 1, NULL, NULL, NULL, NULL),
(570, 343, 'Extra small', 'red', 674, 20000, 1, 5, 1, NULL, NULL, NULL, NULL),
(571, 343, 'medium', 'Black', 674, 20000, 1, 5, 1, NULL, NULL, NULL, NULL),
(572, 343, 'medium', 'blue', 674, 20000, 1, 5, 1, NULL, NULL, NULL, NULL),
(573, 343, 'medium', 'red', 674, 20000, 1, 5, 1, NULL, NULL, NULL, NULL),
(574, 344, 'Extra small', 'Black', 34, 324, 1, 324, 1, NULL, NULL, NULL, NULL),
(575, 344, 'small', 'Black', 34, 324, 1, 324, 1, NULL, NULL, NULL, NULL),
(576, 344, 'medium', 'Black', 34, 324, 1, 324, 1, NULL, NULL, NULL, NULL),
(577, 345, 'small', 'orange', 34, 43, 1, 342, 1, NULL, NULL, NULL, NULL),
(578, 345, 'large', 'orange', 34, 43, 1, 342, 1, NULL, NULL, NULL, NULL),
(579, 346, 'Extra small', 'default color', 453, 39, 1, 45, 1, NULL, NULL, NULL, NULL),
(580, 346, 'small', 'default color', 453, 43, 1, 45, 1, NULL, NULL, NULL, NULL),
(581, 346, 'medium', 'default color', 453, 43, 1, 45, 1, NULL, NULL, NULL, NULL),
(582, 347, 'small', 'default color', 34, 34, 1, 34, 1, NULL, NULL, NULL, NULL),
(583, 347, 'medium', 'default color', 34, 34, 1, 34, 1, NULL, NULL, NULL, NULL),
(584, 347, 'large', 'default color', 34, 34, 1, 34, 1, NULL, NULL, NULL, NULL),
(585, 348, 'small', 'default color', 405, 95, 1, 1, 1, NULL, NULL, NULL, NULL),
(586, 348, 'extra large', 'default color', 405, 20, 1, 1, 1, NULL, NULL, NULL, NULL),
(587, 348, 'large', 'default color', 405, 19, 1, 1, 1, NULL, NULL, NULL, NULL),
(588, 348, 'Extra small', 'default color', 405, 19, 1, 1, 1, NULL, NULL, NULL, NULL),
(589, 348, 'medium', 'default color', 405, 20, 1, 1, 1, NULL, NULL, NULL, NULL),
(590, 349, 'small', 'default color', 0, 0, 1, 0, 1, NULL, NULL, NULL, NULL),
(591, 349, 'Extra small', 'default color', 0, 0, 1, 0, 1, NULL, NULL, NULL, NULL),
(592, 349, 'extra large', 'default color', 0, 0, 1, 0, 1, NULL, NULL, NULL, NULL),
(593, 349, 'large', 'default color', 0, 0, 1, 0, 1, NULL, NULL, NULL, NULL),
(594, 349, 'medium', 'default color', 0, 0, 1, 0, 1, NULL, NULL, NULL, NULL),
(595, 350, 'small', 'default color', 566, 67, 1, 6, 1, NULL, NULL, NULL, NULL),
(596, 350, 'extra large', 'default color', 566, 67, 1, 6, 1, NULL, NULL, NULL, NULL),
(597, 350, 'large', 'default color', 566, 67, 1, 6, 1, NULL, NULL, NULL, NULL),
(598, 350, 'Extra small', 'default color', 566, 67, 1, 6, 1, NULL, NULL, NULL, NULL),
(599, 350, 'medium', 'default color', 566, 67, 1, 6, 1, NULL, NULL, NULL, NULL),
(600, 351, 'Extra small', 'default color', 490, 0, 1, 1, 1, NULL, NULL, NULL, NULL),
(601, 351, 'small', 'default color', 490, 20, 1, 1, 1, NULL, NULL, NULL, NULL),
(602, 351, 'extra large', 'default color', 490, 20, 1, 1, 1, NULL, NULL, NULL, NULL),
(603, 351, 'large', 'default color', 490, 20, 1, 1, 1, NULL, NULL, NULL, NULL),
(604, 351, 'medium', 'default color', 490, 20, 1, 1, 1, NULL, NULL, NULL, NULL),
(615, 354, 'Extra small', 'default color', 555, 8, 1, 1, 1, NULL, NULL, NULL, NULL),
(616, 354, 'small', 'default color', 555, 20, 1, 1, 1, NULL, NULL, NULL, NULL),
(617, 354, 'extra large', 'default color', 555, 20, 1, 1, 1, NULL, NULL, NULL, NULL),
(618, 354, 'large', 'default color', 555, 20, 1, 1, 1, NULL, NULL, NULL, NULL),
(619, 354, 'medium', 'default color', 555, 20, 1, 1, 1, NULL, NULL, NULL, NULL),
(620, 355, 'Extra small', 'default color', 500, 20, 1, 1, 1, NULL, NULL, NULL, NULL),
(621, 355, 'small', 'default color', 500, 20, 1, 1, 1, NULL, NULL, NULL, NULL),
(622, 355, 'extra large', 'default color', 500, 20, 1, 1, 1, NULL, NULL, NULL, NULL),
(623, 355, 'large', 'default color', 500, 20, 1, 1, 1, NULL, NULL, NULL, NULL),
(624, 355, 'medium', 'default color', 500, 20, 1, 1, 1, NULL, NULL, NULL, NULL),
(625, 356, 'Extra small', 'default color', 899, 25, 1, 5, 1, NULL, NULL, NULL, NULL),
(626, 356, 'small', 'default color', 899, 25, 1, 5, 1, NULL, NULL, NULL, NULL),
(627, 356, 'extra large', 'default color', 899, 25, 1, 5, 1, NULL, NULL, NULL, NULL),
(628, 356, 'medium', 'default color', 899, 21, 1, 5, 1, NULL, NULL, NULL, NULL),
(629, 356, 'large', 'default color', 899, 25, 1, 5, 1, NULL, NULL, NULL, NULL),
(630, 357, 'Extra small', 'default color', 765, 10, 1, 2, 1, NULL, NULL, NULL, NULL),
(631, 357, 'small', 'default color', 765, 10, 1, 2, 1, NULL, NULL, NULL, NULL),
(632, 357, 'extra large', 'default color', 765, 10, 1, 2, 1, NULL, NULL, NULL, NULL),
(633, 357, 'large', 'default color', 765, 10, 1, 2, 1, NULL, NULL, NULL, NULL),
(634, 357, 'medium', 'default color', 765, 10, 1, 2, 1, NULL, NULL, NULL, NULL),
(637, 359, 'small', 'orange', 56, 0, 1, 0, 1, NULL, NULL, NULL, NULL),
(638, 359, 'medium', 'orange', 56, 0, 1, 0, 1, NULL, NULL, NULL, NULL),
(662, 352, 'Extra small', 'default color', 550, 20, 1, 0, 1, NULL, NULL, NULL, NULL),
(663, 352, 'small', 'default color', 550, 20, 1, 0, 1, NULL, NULL, NULL, NULL),
(664, 352, 'extra large', 'default color', 550, 20, 1, 0, 1, NULL, NULL, NULL, NULL),
(665, 352, 'large', 'default color', 550, 20, 1, 0, 1, NULL, NULL, NULL, NULL),
(666, 352, 'medium', 'default color', 550, 20, 1, 0, 1, NULL, NULL, NULL, NULL),
(676, 360, 'small', 'default color', 324, 0, 1, 0, 1, NULL, NULL, NULL, NULL),
(677, 360, 'medium', 'default color', 324, 234, 1, 0, 1, NULL, NULL, NULL, NULL),
(678, 360, 'large', 'default color', 324, 234, 1, 0, 1, NULL, NULL, NULL, NULL),
(679, 362, '34', 'white', 20000, 1, 2, 60, 1, NULL, NULL, NULL, NULL),
(680, 362, '36', 'red', 15000, 3, 3, 65, 1, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `weightmasters`
--

CREATE TABLE `weightmasters` (
  `id` int NOT NULL,
  `weight` int DEFAULT NULL,
  `charge` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `weightmasters`
--

INSERT INTO `weightmasters` (`id`, `weight`, `charge`) VALUES
(5, 1000, '100.00'),
(6, 999, '53.00'),
(8, 2000, '150.00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`addressid`);

--
-- Indexes for table `addtocarttable`
--
ALTER TABLE `addtocarttable`
  ADD PRIMARY KEY (`atcartid`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `color`
--
ALTER TABLE `color`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `daily_reset_counter`
--
ALTER TABLE `daily_reset_counter`
  ADD PRIMARY KEY (`counter_date`);

--
-- Indexes for table `gender`
--
ALTER TABLE `gender`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `grade`
--
ALTER TABLE `grade`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gst`
--
ALTER TABLE `gst`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `masters`
--
ALTER TABLE `masters`
  ADD PRIMARY KEY (`masterid`);

--
-- Indexes for table `mastersdata`
--
ALTER TABLE `mastersdata`
  ADD PRIMARY KEY (`dataid`);

--
-- Indexes for table `module`
--
ALTER TABLE `module`
  ADD PRIMARY KEY (`moduleid`);

--
-- Indexes for table `otpsmslog`
--
ALTER TABLE `otpsmslog`
  ADD PRIMARY KEY (`logid`);

--
-- Indexes for table `otptable`
--
ALTER TABLE `otptable`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_otp_userid` (`userid`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`productid`);

--
-- Indexes for table `productimage`
--
ALTER TABLE `productimage`
  ADD PRIMARY KEY (`autoid`);

--
-- Indexes for table `productschoolmap`
--
ALTER TABLE `productschoolmap`
  ADD PRIMARY KEY (`autoid`),
  ADD KEY `fk_product_schoolmap` (`productid`),
  ADD KEY `fk_school_schoolmap` (`schoolid`);

--
-- Indexes for table `producttext`
--
ALTER TABLE `producttext`
  ADD PRIMARY KEY (`extautoid`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`rolesid`);

--
-- Indexes for table `school`
--
ALTER TABLE `school`
  ADD PRIMARY KEY (`schoolid`),
  ADD KEY `fk_createdby_school` (`createdby`),
  ADD KEY `fk_updatedby_school` (`updatedby`);

--
-- Indexes for table `schoolgrademap`
--
ALTER TABLE `schoolgrademap`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `size`
--
ALTER TABLE `size`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `states_names`
--
ALTER TABLE `states_names`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `temp_register`
--
ALTER TABLE `temp_register`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `test_timezone`
--
ALTER TABLE `test_timezone`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `transactionlog`
--
ALTER TABLE `transactionlog`
  ADD PRIMARY KEY (`logid`),
  ADD KEY `createdby` (`createdby`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `productid` (`productid`),
  ADD KEY `userid` (`userid`),
  ADD KEY `addressid` (`addressid`);

--
-- Indexes for table `transaction_billing`
--
ALTER TABLE `transaction_billing`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaction_error_logs`
--
ALTER TABLE `transaction_error_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_userlog_userid` (`userid`);

--
-- Indexes for table `usermodulemap`
--
ALTER TABLE `usermodulemap`
  ADD PRIMARY KEY (`userid`,`moduleid`),
  ADD KEY `fk_usermodulemap_moduleid` (`moduleid`);

--
-- Indexes for table `userrolemap`
--
ALTER TABLE `userrolemap`
  ADD PRIMARY KEY (`userid`,`roleid`),
  ADD KEY `roleid` (`roleid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `usersschoolmap`
--
ALTER TABLE `usersschoolmap`
  ADD PRIMARY KEY (`autoid`),
  ADD KEY `fk_usersschoolmap_schoolid` (`schoolid`);

--
-- Indexes for table `user_status`
--
ALTER TABLE `user_status`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `fk_user_status_username` (`username`) USING BTREE;

--
-- Indexes for table `variant`
--
ALTER TABLE `variant`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `weightmasters`
--
ALTER TABLE `weightmasters`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `addressid` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=235;

--
-- AUTO_INCREMENT for table `addtocarttable`
--
ALTER TABLE `addtocarttable`
  MODIFY `atcartid` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=332;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `color`
--
ALTER TABLE `color`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `gender`
--
ALTER TABLE `gender`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `grade`
--
ALTER TABLE `grade`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `gst`
--
ALTER TABLE `gst`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `masters`
--
ALTER TABLE `masters`
  MODIFY `masterid` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=198;

--
-- AUTO_INCREMENT for table `mastersdata`
--
ALTER TABLE `mastersdata`
  MODIFY `dataid` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=198;

--
-- AUTO_INCREMENT for table `module`
--
ALTER TABLE `module`
  MODIFY `moduleid` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `otpsmslog`
--
ALTER TABLE `otpsmslog`
  MODIFY `logid` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `otptable`
--
ALTER TABLE `otptable`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=539;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `productid` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=363;

--
-- AUTO_INCREMENT for table `productimage`
--
ALTER TABLE `productimage`
  MODIFY `autoid` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=205;

--
-- AUTO_INCREMENT for table `productschoolmap`
--
ALTER TABLE `productschoolmap`
  MODIFY `autoid` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=212;

--
-- AUTO_INCREMENT for table `producttext`
--
ALTER TABLE `producttext`
  MODIFY `extautoid` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1087;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `rolesid` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `school`
--
ALTER TABLE `school`
  MODIFY `schoolid` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=229;

--
-- AUTO_INCREMENT for table `schoolgrademap`
--
ALTER TABLE `schoolgrademap`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `size`
--
ALTER TABLE `size`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `states_names`
--
ALTER TABLE `states_names`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `temp_register`
--
ALTER TABLE `temp_register`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT for table `test_timezone`
--
ALTER TABLE `test_timezone`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `transactionlog`
--
ALTER TABLE `transactionlog`
  MODIFY `logid` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=362;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=272;

--
-- AUTO_INCREMENT for table `transaction_billing`
--
ALTER TABLE `transaction_billing`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=134;

--
-- AUTO_INCREMENT for table `transaction_error_logs`
--
ALTER TABLE `transaction_error_logs`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2876;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userid` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=231;

--
-- AUTO_INCREMENT for table `usersschoolmap`
--
ALTER TABLE `usersschoolmap`
  MODIFY `autoid` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `user_status`
--
ALTER TABLE `user_status`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `variant`
--
ALTER TABLE `variant`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=681;

--
-- AUTO_INCREMENT for table `weightmasters`
--
ALTER TABLE `weightmasters`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `otptable`
--
ALTER TABLE `otptable`
  ADD CONSTRAINT `otptable_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`userid`);

--
-- Constraints for table `school`
--
ALTER TABLE `school`
  ADD CONSTRAINT `school_ibfk_1` FOREIGN KEY (`createdby`) REFERENCES `users` (`userid`),
  ADD CONSTRAINT `school_ibfk_2` FOREIGN KEY (`updatedby`) REFERENCES `users` (`userid`);

--
-- Constraints for table `usermodulemap`
--
ALTER TABLE `usermodulemap`
  ADD CONSTRAINT `usermodulemap_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`userid`),
  ADD CONSTRAINT `usermodulemap_ibfk_2` FOREIGN KEY (`moduleid`) REFERENCES `module` (`moduleid`);

--
-- Constraints for table `user_status`
--
ALTER TABLE `user_status`
  ADD CONSTRAINT `fk_user_status_username` FOREIGN KEY (`username`) REFERENCES `users` (`username`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
