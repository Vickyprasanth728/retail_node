

// const SID = JSON.parse(schoolid)
//         console.log('SID', SID);
        
//         let thisQueryS = ` SELECT s.* FROM school as s WHERE s.schoolid `
//         const dataS = await db.query(thisQueryS);
//         const schoolInititalCheck = dataS[0].map(i => i.schoolid)
//         console.log('schoolInititalCheck',schoolInititalCheck);

        // const schoolCheck = SID.every(value => schoolInititalCheck.includes(value));


// Get View Products (Type / Status)
export const getViewProducts = async (req, res) => {
    try {
        
        await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

        const filters = req.query;

        let thisQuery = `SELECT 
        p.productid as id,
        p.*, 
        pm.imageseq as imageseq
        FROM product as p
        LEFT JOIN productimage as pm ON (p.productid = pm.productid)
        WHERE p.productid IS NOT NULL 
        `

        // STATUS
        if (filters?.status == 'product') {
            thisQuery += ` AND pm.imageseq = 1 `
        }
        if (filters?.status == 'instock') {
            thisQuery += ` AND p.productstatus = 'instock' and pm.imageseq = 1 `
        }
        if (filters?.status == 'published') {
            thisQuery += ` AND p.published = 1 and pm.imageseq = 1 `
        }
        if (filters?.status == 'unpublished') {
            thisQuery += ` AND p.published = 0 and pm.imageseq = 1 `
        }

        // SEARCH TERMS
        if (filters?.searchterm) {
            thisQuery += ` AND p.name LIKE '%${filters?.searchterm}%' `
        }
 
        thisQuery += `
        GROUP BY p.productid 
        ORDER BY p.productid DESC
        `

        if (filters?.limit && !filters?.searchterm) {
            thisQuery += ` limit ${filters?.limit},10 `
        }

        const dataMain = await db.query(thisQuery);
        // console.log(JSON.stringify(dataMain[0], null, 2));
       
        const data = dataMain[0];

        const productRows = data.map(item => `
            <tr>
                <td>${item?.productid}</td>
                <td><img src="${`http://localhost:5001/uploads/product/image/678/1/6dfc509280cc9bf376566c52c29a784b.jpeg`}" alt="${item.name}" style="width: 50px; height: auto;"></td>
                <td>${item?.name}</td>
                <td>${item?.description}</td>
                <td>${item?.price}</td>
            </tr>
        `).join('');

        // TYPE
        if(filters?.type == 'excel') {
            try {
                const worksheet = xlsx.utils.json_to_sheet(data);
                const workbook = xlsx.utils.book_new();
            
                xlsx.utils.book_append_sheet(workbook, worksheet, 'Sheet1');
                const outputPath = path.join(__dirname,'output.xlsx');
                xlsx.writeFile(workbook, outputPath);
                console.log('File written successfully');

            } catch (error) {
                console.error('Error writing file:', error);
            }
        }

        if(filters?.type == 'pdf') {
            try {
            console.log('Initial PDF Generated');

            // const browser = await puppeteer.launch();
            const browser = await puppeteer.launch({ headless: false, args: ['--no-sandbox', '--disable-setuid-sandbox'] });
            const page = await browser.newPage();
            await page.setContent(`  <html>
        <head>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    margin: 20px;
                }
                h1 {
                    text-align: center;
                }
                .table-responsive {
                    overflow-x: auto;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                }
                th, td {
                    border: 1px solid #ddd;
                    padding: 8px;
                    text-align: left;
                }
                th {
                    background-color: #f2f2f2;
                }
            </style>
        </head>
        <body>
            <h1>Product List</h1>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Image</th>
                            <th>Product Name</th>
                            <th>Description</th>
                            <th>Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${productRows}
                    </tbody>
                </table>
            </div>
        </body>
        </html>`);
            await page.pdf({ path: 'test.pdf', format: 'A4', timeout: 6000 });
          
            await browser.close();

            console.log('PDF Generated');
            }
            catch (error) {
                console.error('PDF ERROR:', error);
                console.log('Pdf not generated');
            }
        }

        if (data) {
            // res.status(200).json({ issuccess: true, message: 'success', ProductData });
            res.status(200).send({
                status: true, 
                message: 'success', 
                count : data?.length,
                data
            });
        }
        else {
            res.status(400).json({status:false, message: 'Error specification. Please retry' });
        }

    } catch (error) {
        console.log(error);
        res.status(500).json({ status:false, error: 'Internal Server Error', message: error.message });
    }
};

const getAddress = async (req, res) => {
    const userid = req.body.userid || 0;

    try {
        // Check if the address exists for the given user ID
        const addressCheckQuery = `SELECT COUNT(*) AS count FROM address WHERE userid = ?`;
        const [checkResult] = await db.query(addressCheckQuery, [userid]);
        const addressExists = checkResult[0].count;

        if (addressExists === 0) {
            return res.status(200).json({
                status: 'SUCCESS',
                message: 'No data found',
                empty_result: null
            });
        } else {
            // Retrieve the address details
            const addressQuery = `SELECT addressid, name, locationdetails, fulladdress, Landmark, city, state, country, pincode, email, mobileno 
                                  FROM address WHERE userid = ?`;
            const addressData = await db.query(addressQuery, [userid]);

            return res.status(200).json({
                status: 'SUCCESS',
                message: 'Address retrieved',
                data: addressData
            });
        }
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            status: 'ERROR',
            message: 'An error occurred while retrieving the address'
        });
    }
};


const getUserRoleDetails = async (req, res) => {
    const userid = req.body.userid || 0;

    try {
        // Initialize response status and message
        let sp_status = 'SUCCESS';
        let sp_result = 'User role details retrieved successfully';
        
        // Check if the user role details exist
        const roleCheckQuery = `SELECT COUNT(*) AS count FROM userrolemap WHERE userid = ?`;
        const [checkResult] = await db.query(roleCheckQuery, [userid]);
        const row_count = checkResult[0].count;

        if (row_count > 0) {
            // Fetch user role details
            const roleDetailsQuery = `
                SELECT
                    u.userid AS UserID,
                    r.rolesid,
                    r.name AS role_name,
                    BIN(r.role) AS role,
                    r.status AS role_status,
                    r.defaultmodule AS default_module_id,
                    COALESCE(usm.schoolid, '') AS schoolid
                FROM
                    users u
                JOIN
                    userrolemap urm ON u.userid = urm.userid
                JOIN
                    roles r ON urm.roleid = r.rolesid
                LEFT JOIN
                    usersschoolmap usm ON u.userid = usm.userid
                WHERE
                    u.userid = ?`;

            const roleData = await db.query(roleDetailsQuery, [userid]);

            return res.status(200).json({
                status: sp_status,
                message: sp_result,
                data: roleData
            });
        } else {
            // No user role details found
            sp_status = 'SUCCESS';
            sp_result = 'No user role details found for the specified user ID';
            return res.status(200).json({
                status: sp_status,
                message: sp_result,
                data: null
            });
        }
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            status: 'ERROR',
            message: 'An error occurred while retrieving user role details'
        });
    }
};



async function generateAndSaveOTP(mobileno) {
    // Generate random 6-digit OTP
    const otpcode = Math.floor(100000 + Math.random() * 900000);
    try {
        const mobileno = req.params.mobileno;
        const otpcode = req.body.otpcode;
        const currentDateTime = new Date();
    
        // Convert times based on your timezone adjustment logic
        const transtime = new Date(currentDateTime.toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }));
        const validity = new Date(currentDateTime.setMinutes(currentDateTime.getMinutes() + 10));
    
        // Step 1: Fetch user ID based on mobileno
        let userQuery = `SELECT userid FROM users WHERE mobileno = '${mobileno}'`;
        const userResult = await db.query(userQuery);
        const user = userResult[0][0];
        
        if (!user) {
            return res.status(404).send({
                status: false,
                message: "User not found",
            });
        }
    
        const userId = user.userid;
    
        let otpDataResults;
        // Step 2: Check OTP record for the given mobileno
        let otpCheckQuery = `SELECT COUNT(*) AS count FROM otptable WHERE mobileno = '${mobileno}'`;
        const otpCheckResult = await db.query(otpCheckQuery);
        const recordCount = otpCheckResult[0][0].count;
    
        // Step 3: If OTP record exists, update it, otherwise insert a new record
        if (recordCount > 0) {
            // Update existing OTP record
            let updateQuery = `
                UPDATE otptable
                SET otpcode = '${otpcode}', validity = '${validity.toISOString()}', transtime = '${transtime.toISOString()}', 
                    userid = ${userId}, status = 1
                WHERE mobileno = '${mobileno}'
                ORDER BY id DESC LIMIT 1
            `;
            otpDataResults = await db.query(updateQuery);
    
            res.status(200).send({
                status: true,
                message: 'OTP record updated successfully'
            });
        } 
        else {
            // Insert new OTP record
            let insertQuery = `
                INSERT INTO otptable (mobileno, otpcode, validity, transtime, userid)
                VALUES ('${mobileno}', '${otpcode}', '${validity.toISOString()}', '${transtime.toISOString()}', ${userId})
            `;
            otpDataResults = await db.query(insertQuery);
    
            res.status(200).send({
                status: true,
                message: 'OTP record created successfully'
            });
        }

    
      if (otpDataResults && otpDataResults.status === true) {
        const { mobileno, otpcode, senttime, status, email } = req.body;

        // Validate mobile number format
        const mobileRegex = /^[0-9]{10}$/;
        if (!mobileRegex.test(mobileno)) {
            return res.status(400).send({
                status: false,
                message: 'Invalid mobile number format',
            });
        }
    
        // Step 1: Check if the OTP record exists for the given mobile number and OTP code
        let otpCheckQuery = `SELECT 1 FROM otpsmslog WHERE mobileno = '${mobileno}' AND otpcode = '${otpcode}'`;
        const otpCheckResult = await db.query(otpCheckQuery);
        
        if (otpCheckResult[0].length > 0) {
            // Record exists, so update it
            let updateQuery = `
                UPDATE otpsmslog
                SET senttime = '${senttime}', status = '${status}'
                WHERE mobileno = '${mobileno}' AND otpcode = '${otpcode}'
            `;
            const LogResults = await db.query(updateQuery);
    
            return res.status(200).send({
                status: true,
                message: 'Record updated successfully',
            });
        } else {
            // Record does not exist, so insert a new record
            let insertQuery = `
                INSERT INTO otpsmslog (mobileno, email, otpcode, senttime, status)
                VALUES ('${mobileno}', '${email}', '${otpcode}', '${senttime}', '${status}')
            `;
            const LogResults = await db.query(insertQuery);
    
            return res.status(200).send({
                status: true,
                message: 'Record inserted successfully',
            });
        }
        return otpcode; // Return the generated OTP
      }
      else {
        // Handle errors (e.g., log, throw)
        console.error(error);
        console.error('Error generating and saving OTP:', error);
        return null; // Return null in case of an error
      }
    } catch (error) {
      // Handle errors (e.g., log, throw)
      console.error(error);
      console.error('Error generating and saving OTP:', error);    
    }
    return null; // Return null in case of an error
  }


  let thisQueryOrderSummary = `
  SELECT
      COUNT(DISTINCT atc.productid) AS Count,
      COALESCE(SUM(product.price), 0) AS Total,
      JSON_ARRAY(
          JSON_OBJECT(
              'productid', product.productid,
              'price', product.price,
              'images', (
                  SELECT JSON_ARRAY(
                      JSON_OBJECT(
                          'imageseq', productimage.imageseq,
                          'image', productimage.image
                      )
                  )
                  FROM productimage
                  WHERE productimage.productid = product.productid
              ),
              'name', product.name
          )
      ) AS product
  FROM addtocarttable as atc
  LEFT JOIN product ON (atc.productid = product.productid)
  WHERE atc.userid = '${userid}' AND atc.status = 'incart'
  GROUP BY atc.userid
`

const orderSummary = await db.query(thisQueryOrderSummary);






`
SELECT
COALESCE(SUM(p.price), 0) AS total_price,
COALESCE(SUM(atc.quantity), 0) AS total_quantity,
GROUP_CONCAT(COALESCE(atc.quantity, 0)) as quantity1,
GROUP_CONCAT(COALESCE(p.price, 0)) as price,
GROUP_CONCAT(COALESCE(p.name, ''))  as name,
GROUP_CONCAT(COALESCE(p.productid, 0)) as productid,
(
    SELECT JSON_ARRAYAGG(
        JSON_OBJECT(
            'image', pi.image,
            'imageseq', pi.imageseq,
            'productid', pi.productid
        )
    )
    FROM productimage as pi
    WHERE pi.productid IN (p.productid) AND pi.imageseq = 1
    ORDER BY pi.imageseq ASC


    FROM productimage AS pi
    WHERE pi.productid IN (SELECT DISTINCT atc.productid FROM addtocarttable as atc WHERE atc.userid = '${userid}' AND atc.status = 'incart') AND pi.imageseq = 1
    ORDER BY pi.imageseq ASC
    
) AS images

FROM addtocarttable as atc
LEFT JOIN product as p ON (atc.productid = p.productid)
WHERE atc.userid = '${userid}' AND atc.status = 'incart'
GROUP BY atc.userid`




`JSON_OBJECT(
    "addressid", IFNULL(MAX(ad.addressid), ""),
    "address_name", IFNULL(MAX(ad.name), ""),
    "city", IFNULL(MAX(ad.city), ""),
    "pincode", IFNULL(MAX(ad.pincode), "")
) AS address_details`


`GROUP BY tra.id, tra.transid, tra.ordernumber, tra.status, tra.createdon, p.name, p.description, p.price, pi.image
        ORDER BY MAX(tra.lastmodifiedat) DESC`


        // SELECT 
        // tra.id,
        // tra.transid,
        // tra.ordernumber,
        // tra.status,
        // tra.createdon,
        // p.name,
        // p.description,
        // p.price,
        // (
        //     SELECT JSON_ARRAYAGG(
        //         JSON_OBJECT(
        //             'productid', p.productid,
        //             'name', p.name,
        //             'description', p.description,
        //             'price', p.price
        //         )
        //     )
        //     FROM product as p
        //     WHERE FIND_IN_SET(p.productid, tra.productid) > 0            
        //     GROUP BY p.productid
        // ) AS product_details,
        // (
        //     SELECT JSON_ARRAYAGG(
        //         JSON_OBJECT(
        //             'image', pi.image,
        //             'imageseq', pi.imageseq,
        //             'productid', pi.productid
        //         )
        //     )
        //     FROM productimage as pi
        //     WHERE pi.productid IN (p.productid) AND pi.imageseq = 1
        //     GROUP BY pi.productid
        // ) AS image_details,
        // (
        //     SELECT 
        //         JSON_OBJECT(
        //             'addressid', ad.addressid,
        //             'address_name', ad.name,
        //             'city', ad.city,
        //             'pincode', ad.pincode
        //         )
        //     FROM address as ad
        //     WHERE ad.addressid IN (tra.addressid)
        //     GROUP BY ad.addressid
        // ) AS address_details
        
        // FROM transactions as tra
        // LEFT JOIN product as p ON (tra.productid = p.productid)
        // LEFT JOIN productimage pi ON (pi.productid = p.productid AND pi.imageseq = 1)
        // LEFT JOIN address ad ON (ad.addressid = tra.addressid)
        // WHERE tra.status IN ('ordered', 'shipped', 'outfordelivery', 'delivered', 'deliverfail') AND tra.userid = 202
        // GROUP BY tra.id
        // ORDER BY MAX(tra.lastmodifiedat) DESC limit 0,10



        // SELECT id
        // FROM transactions
        // WHERE userid = '184'
        // AND (transaction_ids REGEXP '\\b(243|244)\\b')
        // LIMIT 1;



          // atcArray [{
        //     atcartid: 12,
        //     userid: 184,
        //     productid: 243,
        //     variantid: 3,
        //     quantity: 14,
        //     status: 'Ordered',
        //     createdby: null,
        //     createdon: 2024-11-12T12:12:38.000Z,
        //     lastmodifiedby: null,
        //     lastmodifiedate: 2024-11-12T12:12:38.000Z
        //   }, {
        //     atcartid: 13,
        //     userid: 184,
        //     productid: 244,
        //     variantid: 4,
        //     quantity: 16,
        //     status: 'Ordered',
        //     createdby: null,
        //     createdon: 2024-11-12T12:12:49.000Z,
        //     lastmodifiedby: null,
        //     lastmodifiedate: 2024-11-12T12:12:49.000Z
        //   }]
        // variantID_data [
        //     {
        //       id: 3,
        //       productid: 174,
        //       size: '24',
        //       color: 'red',
        //       price: 550,
        //       quantity: 50,
        //       imageid: 3,
        //       weight: 50,
        //       status: 1,
        //       createdby: null,
        //       createdon: null,
        //       lastmodifiedby: null,
        //       lastmodifiedon: null
        //     },
        //     {
        //       id: 4,
        //       productid: 174,
        //       size: '30',
        //       color: 'green',
        //       price: 1020,
        //       quantity: 5,
        //       imageid: 0,
        //       weight: 0,
        //       status: 1,
        //       createdby: null,
        //       createdon: null,
        //       lastmodifiedby: null,
        //       lastmodifiedon: null
        //     }
        //   ]
          
        //   atcArray variant id to check the variantID_data id and minus the atcArray quantity to variantID_data quantity and update the quantity where variantID_data id


        // check ATC_ID[0] quantity =  variantID[0] quantity 













        // Insert Transaction --- TESTING
// ===========================================
export const insertTransaction12 = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
    await db.query('START TRANSACTION');

    try {
        const { userid, addressid, gst_data, quantity, cgst, sgst, igst, shipping_charges, total_amount, status } = req.body;

        const productid = req.body.productid
        console.log('productid', productid);
        const gstStringify = JSON.stringify(gst_data)
        setTimeout(() => {
            console.log('gst_data_request', gst_data);
            console.log('gstStringify', gstStringify);
        }, 1000)

        // const productidArray = JSON.parse(productid).length == 0 ? 0 : JSON.parse(productid);
        const productidArray = productid.length == 0 ? 0 : productid;
        console.log('productidArray', productidArray);
        
        let userCheckQuery = `SELECT userid FROM users WHERE userid = '${userid}' LIMIT 1`;
        const userCheckData = await db.query(userCheckQuery);
        const userExists = userCheckData[0][0] ? userCheckData[0][0]?.userid : 0

        console.log('userExists', userExists);
    
        if (userExists == 0 || !userExists) {
            console.log('User-ID not found');
            return res.status(404).send({
                status: false,
                message: 'User-ID not found',
            });
        }
    
        let productCheckQuery = `SELECT productid FROM product WHERE productid IN (${productidArray}) LIMIT 1`;
        const productCheckData = await db.query(productCheckQuery);
        const productExists = productCheckData[0][0] ? productCheckData[0][0]?.productid : 0

        console.log('productExists', productExists);

        if (productExists == 0 || !productExists) {
            console.log('Product-ID not found');
            return res.status(404).send({
                status: false,
                message: 'Product-ID not found',
            });
        }

        // const arrayReplace = productidArray.join(',').replace(/[]/g, '');
        // console.log('arrayReplace', arrayReplace);

        let getATC = ` SELECT * FROM addtocarttable WHERE userid = '${userid}' AND status = 'incart' AND productid IN (${productidArray}) `
        const ATC_ID = await db.query(getATC);
        console.log('ATC_ID data', ATC_ID[0]);       
        
        const variant_array = ATC_ID[0]?.map(i => i.variantid);
        const variantData =  variant_array.length != 0 ? variant_array?.join(',') : 0
        console.log('variant_array', variantData);
        console.log('variant_array_length', variant_array.length);

        let variantQuery = ` SELECT * FROM variant WHERE id IN (${variantData}) `
        const variantID = await db.query(variantQuery);
        console.log('variantID data', variantID[0]);  

        const transArray = []

        for (const productId of productidArray) {

            const productVariant = ATC_ID[0].find(item => item.productid === productId);
            const productQuantity = productVariant ? productVariant.quantity : 0;
            const productVariantID = productVariant ? productVariant.variantid : 0;
            console.log('productVariant', productVariant);        
            console.log('productQuantity', productQuantity);        
            console.log('productVariantID', productVariantID);        

            const today = new Date().toISOString().slice(0, 10);
            console.log('today', today);
    
            let counterQuery = `
            INSERT INTO daily_reset_counter (counter_date, counter_value) VALUES ('${today}', 1) ON DUPLICATE KEY UPDATE counter_value = counter_value + 1 `;
            const counterInsert = await db.query(counterQuery);
        
            let counterSelectQuery = `SELECT counter_value FROM daily_reset_counter WHERE counter_date = '${today}' `;
            const counterData = await db.query(counterSelectQuery);
            const counterValue = counterData[0][0] ? counterData[0][0]?.counter_value : 0
    
            console.log('counterValue', counterValue);

            const orderNumber = `2CQR-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
            const transId = `Trans-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
    
            console.log('orderNumber', orderNumber);
            console.log('transId', transId);
            
            let transactionInsertQuery = `
            INSERT INTO transactions (productid, userid, transid, addressid, ordernumber, quantity, variant, gst_data, cgst, sgst, igst, shipping_charges, total_amount, status) VALUES ('${productId}', '${userid}', '${transId}', '${addressid}', '${orderNumber}', '${productQuantity}', '${productVariantID}', '${gstStringify}','${cgst}','${sgst}','${igst}','${shipping_charges}', '${total_amount}', '${status}')`;
            const transactionResult = await db.query(transactionInsertQuery);

            console.log('transactionResult', transactionResult);

            transArray?.push(transactionResult[0])
            
            let transactionLogQuery = `
            INSERT INTO transactionlog (transtableid, status, createdby) VALUES ('${transactionResult[0]}', '${status}', '${userid}')`;
            const transactionResultLog = await db.query(transactionLogQuery);
            
            console.log('transactionResultLog', transactionResultLog);
        }
        
        console.log('Transaction inserted successfully'); 

        let uAddToCart = `UPDATE addtocarttable SET status = 'Ordered' WHERE userid = '${userid}' AND productid IN (${productidArray}) `
        const addToCartUpdate = await db.query(uAddToCart);

        ATC_ID[0]?.forEach(atcItem => {
            let variant = variantID[0].find(variant => variant.id === atcItem.variantid);
            
            if (variant) {
                variant.quantity -= atcItem.quantity;                
                variant.quantity = Math.max(0, variant.quantity);
            }
        });
        
        console.log('finalArray[0]',variantID[0]);

        for (const atcArray of variantID[0]) {
            console.log('atcArray', atcArray);
            
            let variantQuery = `UPDATE variant SET quantity = '${atcArray.quantity}' WHERE id = '${atcArray.id}' `
            const variantUpdate = await db.query(variantQuery);
        }

        console.log('transArray', transArray);

        const transArrayID = transArray?.length != 0 ? transArray.join(',') : 0
        console.log('transArrayID', transArrayID);
        
        let orderListQuery = ` SELECT 
        tra.*,
        p.name as product_name,
        us.username as username
        FROM transactions as tra
        LEFT JOIN product as p on (p.productid = tra.productid)
        LEFT JOIN users as us on (us.userid = tra.userid)
        WHERE tra.id IN (${transArrayID}) `
        const orderList = await db.query(orderListQuery);
        console.log('transArrayID', transArrayID);

        console.log('orderList', orderList[0]);
        

        const orders = [
            {
              orderNumber: 12345,
              customerName: "John Doe",
              items: [
                { productId: "P001", name: "Item 1", quantity: 2, price: 10.99 },
                { productId: "P002", name: "Item 2", quantity: 1, price: 24.99 }
              ]
            },
            {
              orderNumber: 67890,
              customerName: "Jane Smith",
              items: [
                { productId: "P003", name: "Item 3", quantity: 3, price: 5.49 },
                { productId: "P004", name: "Item 4", quantity: 1, price: 19.99 }
              ]
            }
          ];
          
          // Generate HTML content for each order
          const htmlContent = orderList[0]?.map(order => {
            const total = order.reduce((sum, item) => sum + item.quantity * item.price, 0).toFixed(2);
          
            return `
            <div class="order">
                <div class="header" style="background-color: #4CAF50; color: white; padding: 10px 0; text-align: center;">
                    <h1>Order Confirmation</h1>
                    <p>Order Number: #${orderList[0]?.ordernumber}</p>
                </div>
                <div class="content" style="margin: 20px;">
                    <p>Hi ${orderList[0]?.username},</p>
                    <p>Thank you for your order! Here are the details:</p>
                    <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
                        <thead>
                            <tr>
                                <th>Item</th>
                                <th>Quantity</th>
                                <th>Total Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>${orderList[0]?.product_name}</td>
                                <td>${orderList[0]?.quantity}</td>
                                <td>$${orderList[0]?.total_amount}</td>
                            </tr>
                        </tbody>
                    </table>
                    <p><strong>Total: $${total}</strong></p>
                    <p>If you have any questions, feel free to contact us.</p>
                </div>
                <div class="footer" style="text-align: center; margin-top: 20px; font-size: 0.8em; color: #888;">
                    <p>&copy; ${new Date().getFullYear()} Your Company. All rights reserved.</p>
                </div>
            </div>
            `;
          }).join('');
                  

        function saveHTMLToFile(htmlContent, fileName) {
            const filePath = path.join(__dirname, fileName);
            fs.writeFile(filePath, htmlContent, (err) => {
              if (err) {
                console.error('Error saving HTML file:', err);
              } else {
                console.log(`HTML file saved: ${filePath}`);
              }
            });
          }
          saveHTMLToFile(htmlContent, 'order-confirmation.html');

        // const mailOptions = {
        //     from: 'yourmail@gmail.com',
        //     to: 'myemail@gmail.com',
        //     subject: `Order Confirmation - #${orderNumber}`,
        //     // text: 'text',
        //     html: htmlContent
        //   };

        // mailer.sendMail(mailOptions, (error, info) => {
        //     if (error) {
        //         console.error('Error sending email:', error);
        //     } else {
        //         console.log('Email sent:', info.response);
        //     }
        // });

        res.status(200).send({
            status: true,
            data: orderList[0],
            message: 'Transaction inserted successfully',
        });
    
        await db.query('COMMIT');

    } catch (error) {
        console.log('error', error);
        res.status(500).json({
            status: false,
            message: 'Internal Server Error',
            error: error.message,
        });

        await db.query('ROLLBACK');
    }
}




// Email trigger

        // Generate HTML content for each order
        const htmlContent = orderList[0]?.map(order => {
            // const total = order.reduce((sum, item) => sum + item.quantity * item.price, 0).toFixed(2);
    
                return `
                <div class="order">
                    <div class="header" style="background-color: #4CAF50; color: white; padding: 10px 0; text-align: center;">
                        <h1>Order Confirmation</h1>
                        <p>Order Number: #${order?.ordernumber}</p>
                    </div>
                    <div class="content" style="margin: 20px;">
                        <p>Hi ${order?.username},</p>
                        <p>Thank you for your order! Here are the details:</p>
                        <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
                            <thead>
                                <tr>
                                    <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">Item</th>
                                    <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">Quantity</th>
                                    <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">Shipping charges</th>
                                    <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td style="padding: 8px; border: 1px solid #ddd;">${order?.product_name}</td>
                                    <td style="padding: 8px; border: 1px solid #ddd;">${order?.quantity}</td>
                                    <td style="padding: 8px; border: 1px solid #ddd;">$${order?.shipping_charges}</td>
                                    <td style="padding: 8px; border: 1px solid #ddd;">${order?.status}</td>
                                </tr>
                            </tbody>
                        </table>
                        <p><strong>Total: $${order?.total_amount}</strong></p>
                        <p>If you have any questions, feel free to contact us.</p>
                    </div>
                    <div class="footer" style="text-align: center; margin-top: 20px; font-size: 0.8em; color: #888;">
                        <p>&copy; ${new Date().getFullYear()} Your Company. All rights reserved.</p>
                    </div>
                </div>
                `;
            }).join('');
    
            const htmlContent1 = `
            <div class="order" style="max-width: 1200px; margin: 0 auto;">
                <div class="header" style="background-color: #4CAF50; color: white; padding: 10px 0; text-align: center;">
                    <h1>Order Confirmation</h1>
                </div>
                <div class="content" style="margin: 20px;">
                    <p>Hi ${orderList[0][0]?.username},</p>
                    <p>Thank you for your order! Here are the details:</p>
                    <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
                        <thead>
                            <tr>
                                <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">S.No</th>
                                <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">Order Number</th>
                                <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">Item</th>
                                <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">Quantity</th>
                                <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">Shipping Charges</th>
                                <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">Status</th>
                                <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${orderList[0]?.map((order, i) => `
                                <tr>
                                    <td style="padding: 8px; border: 1px solid #ddd;">${i+1}</td>
                                    <td style="padding: 8px; border: 1px solid #ddd;">#${order?.ordernumber}</td>
                                    <td style="padding: 8px; border: 1px solid #ddd;">${order?.product_name}</td>
                                    <td style="padding: 8px; border: 1px solid #ddd;">${order?.quantity}</td>
                                    <td style="padding: 8px; border: 1px solid #ddd;">$${order?.shipping_charges}</td>
                                    <td style="padding: 8px; border: 1px solid #ddd;">${order?.status}</td>
                                    <td style="padding: 8px; border: 1px solid #ddd;">$${order?.total_amount}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                    <p>If you have any questions, feel free to contact us.</p>
                </div>
                <div class="footer" style="text-align: center; margin-top: 20px; font-size: 0.8em; color: #888;">
                    <p>&copy; ${new Date().getFullYear()} 2CQR Pvt Ltd. All rights reserved.</p>
                </div>
            </div> `;
                      
            function saveHTMLToFile(htmlContent1, fileName) {
                const filePath = path.join(__dirname, fileName);
                fs.writeFile(filePath, htmlContent1, (err) => {
                  if (err) {
                    console.error('Error saving HTML file:', err);
                  } else {
                    console.log(`HTML file saved: ${filePath}`);
                  }
                });
            }
            saveHTMLToFile(htmlContent1, 'order-confirmation.html');
    
            const EmailID = orderList[0][0] ? orderList[0][0]?.email : ""
            console.log('EmailID', EmailID);
    
            emailTrigger(orderList)
            
            // const mailOptions = {
            //     from: 'vickyprasanth728@gmail.com',
            //     to: `${EmailID}`,
            //     subject: `Order Confirmation`,
            //     // text: 'text',
            //     html: htmlContent
            //   };
    
            // mailer.sendMail(mailOptions, (error, info) => {
            //     if (error) {
            //         console.error('Error sending email:', error);
            //     } else {
            //         console.log('Email sent:', info.response);
            //     }
            // });



// DATE - 16-11-2024
export const insertTransaction1122 = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
    await db.query('START TRANSACTION');

    try {
        const { userid, addressid, quantity, cgst, sgst, igst, shipping_charges, total_amount, status } = req.body;

        const productid = req.body.productid
        console.log('productid', productid);

        // const productidArray = JSON.parse(productid).length == 0 ? 0 : JSON.parse(productid);
        const productidArray = productid.length == 0 ? 0 : productid;
        console.log('productidArray', productidArray);
        
        let userCheckQuery = `SELECT userid FROM users WHERE userid = '${userid}' LIMIT 1`;
        const userCheckData = await db.query(userCheckQuery);
        const userExists = userCheckData[0][0] ? userCheckData[0][0]?.userid : 0

        console.log('userExists', userExists);
    
        if (userExists == 0 || !userExists) {
            console.log('User-ID not found');
            return res.status(404).send({
                status: false,
                message: 'User-ID not found',
            });
        }
    
        let productCheckQuery = `SELECT productid FROM product WHERE productid IN (${productidArray}) LIMIT 1`;
        const productCheckData = await db.query(productCheckQuery);
        const productExists = productCheckData[0][0] ? productCheckData[0][0]?.productid : 0

        console.log('productExists', productExists);

        if (productExists == 0 || !productExists) {
            console.log('Product-ID not found');
            return res.status(404).send({
                status: false,
                message: 'Product-ID not found',
            });
        }

        // const arrayReplace = productidArray.join(',').replace(/[]/g, '');
        // console.log('arrayReplace', arrayReplace);

        let getATC = ` SELECT * FROM addtocarttable WHERE userid = '${userid}' AND status != 'Ordered' AND productid IN (${productidArray}) `
        const ATC_ID = await db.query(getATC);
        console.log('ATC_ID data', ATC_ID[0]);       
        
        const variant_array = ATC_ID[0]?.map(i => i.variantid);
        const variantData =  variant_array.length != 0 ? variant_array?.join(',') : 0
        console.log('variant_array', variantData);
        console.log('variant_array_length', variant_array.length);

        let variantQuery = ` SELECT * FROM variant WHERE id IN (${variantData}) `
        const variantID = await db.query(variantQuery);
        console.log('variantID data', variantID[0]);  

        const transArray = []

        for (const productId of productidArray) {

            const productVariant = ATC_ID[0].find(item => item.productid === productId);
            const productQuantity = productVariant ? productVariant.quantity : 0;
            const productVariantID = productVariant ? productVariant.variantid : 0;
            console.log('productVariant', productVariant);        
            console.log('productQuantity', productQuantity);        
            console.log('productVariantID', productVariantID);        

            const today = new Date().toISOString().slice(0, 10);
            console.log('today', today);
    
            let counterQuery = `
            INSERT INTO daily_reset_counter (counter_date, counter_value) VALUES ('${today}', 1) ON DUPLICATE KEY UPDATE counter_value = counter_value + 1 `;
            const counterInsert = await db.query(counterQuery);
        
            let counterSelectQuery = `SELECT counter_value FROM daily_reset_counter WHERE counter_date = '${today}' `;
            const counterData = await db.query(counterSelectQuery);
            const counterValue = counterData[0][0] ? counterData[0][0]?.counter_value : 0
    
            console.log('counterValue', counterValue);

            const orderNumber = `2CQR-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
            const transId = `Trans-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
    
            console.log('orderNumber', orderNumber);
            console.log('transId', transId);

            let transactionInsertQuery = `
            INSERT INTO transactions (productid, userid, transid, addressid, ordernumber, quantity, variant, cgst, sgst, igst, shipping_charges, total_amount, status) VALUES ('${productId}', '${userid}', '${transId}', '${addressid}', '${orderNumber}', '${productQuantity}','${productVariantID}','${cgst}','${sgst}','${igst}','${shipping_charges}', '${total_amount}', '${status}')`;
            const transactionResult = await db.query(transactionInsertQuery);

            console.log('transactionResult', transactionResult);

            transArray?.push(transactionResult[0])
            
            let transactionLogQuery = `
            INSERT INTO transactionlog (transtableid, status, createdby) VALUES ('${transactionResult[0]}', '${status}', '${userid}')`;
            const transactionResultLog = await db.query(transactionLogQuery);
            
            console.log('transactionResultLog', transactionResultLog);
        }
        
        console.log('Transaction inserted successfully'); 

        let uAddToCart = `UPDATE addtocarttable SET status = 'Ordered' WHERE userid = '${userid}' AND productid IN (${productidArray}) `
        const addToCartUpdate = await db.query(uAddToCart);

        ATC_ID[0]?.forEach(atcItem => {
            let variant = variantID[0].find(variant => variant.id === atcItem.variantid);
            
            if (variant) {
                variant.quantity -= atcItem.quantity;                
                variant.quantity = Math.max(0, variant.quantity);
            }
        });
        
        console.log('finalArray[0]',variantID[0]);

        for (const atcArray of variantID[0]) {
            console.log('atcArray', atcArray);
            
            let variantQuery = `UPDATE variant SET quantity = '${atcArray.quantity}' WHERE id = '${atcArray.id}' `
            const variantUpdate = await db.query(variantQuery);
        }

        const transArrayID = transArray?.length != 0 ? transArray.join(',') : 0
        console.log('transArrayID', transArrayID);

        // Recent Insert Transaction List
        let thisQueryOrd = `
        SELECT 
        tra.id,
        tra.transid,
        tra.productid,
        tra.userid,
        us.username,
        tra.ordernumber,
        tra.status,
        tra.createdon,
        tra.cgst, 
        tra.sgst, 
        tra.igst, 
        tra.quantity, 
        tra.shipping_charges, 
        tra.total_amount,
        tra.productid as trans_product_id,
        (JSON_ARRAY(
                JSON_OBJECT(
                    'productid', p.productid,
                    'name', p.name,
                    'description', p.description,
                    'price', v.price,
                    'quantity', tra.quantity
                )
            )
        ) AS product_details,
        (JSON_ARRAY(
                JSON_OBJECT(
                    'image', pi.image,
                    'imageseq', pi.imageseq,
                    'productid', pi.productid
                )
            )
        ) AS image_details,
        (
            SELECT 
                JSON_OBJECT(
                    'addressid', COALESCE(ad.addressid,''),
                    'address_name', COALESCE(ad.name,''),
                    'fullAddress', COALESCE(ad.fullAddress,''),
                    'locationDetails', COALESCE(ad.locationDetails,''),
                    'landmark', COALESCE(ad.landmark,''),
                    'city', COALESCE(ad.city,''),
                    'state', COALESCE(ad.state,''),
                    'country', COALESCE(ad.country,''),
                    'pincode', COALESCE(ad.pincode,''),
                    'email', COALESCE(ad.email,''),
                    'mobileno', COALESCE(ad.mobileno,''),
                    'alternatemobileno', COALESCE(ad.alternatemobileno,'')
                )
            FROM address as ad
            WHERE ad.addressid IN (tra.addressid)
            GROUP BY ad.addressid
        ) AS address_details
        
        FROM transactions as tra
        LEFT JOIN users as us ON (us.userid = tra.userid)
        LEFT JOIN product as p ON (tra.productid = p.productid)
        LEFT JOIN variant as v ON (v.id = tra.variant)
        LEFT JOIN productimage pi ON (pi.productid = p.productid AND pi.imageseq = 1)
        LEFT JOIN address ad ON (ad.addressid = tra.addressid)
        WHERE tra.status IN ('ordered', 'shipped', 'outfordelivery', 'delivered', 'deliverfail')
        AND tra.userid = '${userid}' AND tra.id IN (${transArrayID})
        GROUP BY tra.id, tra.transid, tra.ordernumber, tra.status, tra.createdon, p.name, p.description, p.price, pi.image
        ORDER BY MAX(tra.lastmodifiedat) DESC
        `
        const ordersData = await db.query(thisQueryOrd);

        let orderListQuery = ` SELECT 
        tra.*,
        p.name as product_name,
        us.username as username,
        us.email as email
        FROM transactions as tra
        LEFT JOIN product as p on (p.productid = tra.productid)
        LEFT JOIN users as us on (us.userid = tra.userid)
        WHERE tra.id IN (${transArrayID}) `
        const orderList = await db.query(orderListQuery);
        console.log('transArrayID', transArrayID);

        console.log('orderList', orderList[0]);

        emailTrigger(orderList);

        res.status(200).send({
            status: true,
            message: 'Transaction inserted successfully',
            insert_count:ordersData[0]?.length,
            insert_output: ordersData[0]
        });
    
        await db.query('COMMIT');

    } catch (error) {
        console.log('error', error);
        res.status(500).json({
            status: false,
            message: 'Internal Server Error',
            error: error.message,
        });

        await db.query('ROLLBACK');
    }
};

// DATE - 16-11-2024
export const getOrderDetails12 = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

    try {

        const filters = req.query
        const UserID = filters?.userid || 0

        let thisQueryCheckUserExists = `SELECT id FROM transactions WHERE userid = '${filters?.userid}' LIMIT 1`;
        const userExists = await db.query(thisQueryCheckUserExists);

        const userExistCheck = userExists[0][0] ? userExists[0][0]?.id : 0
        console.log('userExistCheck', userExistCheck);

        if (userExistCheck == 0 || !userExistCheck) {
            return res.status(404).json({
                status: false,
                message: 'This user has no orders'
            });
        }

        let thisQuery = `
        SELECT 
        tra.id,
        tra.transid,
        tra.productid,
        tra.userid,
        us.username,
        tra.ordernumber,
        tra.status,
        tra.createdon,
        (
            SELECT JSON_ARRAYAGG(
                JSON_OBJECT(
                    'productid', p.productid,
                    'name', p.name,
                    'description', p.description,
                    'price', p.price,
                    'quantity', atc.quantity
                )
            )
            FROM product as p
            LEFT JOIN addtocarttable atc ON (p.productid = atc.productid)
            WHERE FIND_IN_SET(p.productid, tra.productid) > 0 AND atc.userid IN (${UserID})        
        ) AS product_details,
        (
            SELECT JSON_ARRAYAGG(
                JSON_OBJECT(
                    'image', pi.image,
                    'imageseq', pi.imageseq,
                    'productid', pi.productid
                )
            )
            FROM productimage as pi
            WHERE FIND_IN_SET(pi.productid, tra.productid) > 0  AND pi.imageseq = 1
        ) AS image_details,
        (
            SELECT 
                JSON_OBJECT(
                    'addressid', COALESCE(ad.addressid,''),
                    'address_name', COALESCE(ad.name,''),
                    'fullAddress', COALESCE(ad.fullAddress,''),
                    'locationDetails', COALESCE(ad.locationDetails,''),
                    'landmark', COALESCE(ad.landmark,''),
                    'city', COALESCE(ad.city,''),
                    'state', COALESCE(ad.state,''),
                    'country', COALESCE(ad.country,''),
                    'pincode', COALESCE(ad.pincode,''),
                    'email', COALESCE(ad.email,''),
                    'mobileno', COALESCE(ad.mobileno,''),
                    'alternatemobileno', COALESCE(ad.alternatemobileno,'')
                )
            FROM address as ad
            WHERE ad.addressid IN (tra.addressid)
            GROUP BY ad.addressid
        ) AS address_details
        
        FROM transactions as tra
        LEFT JOIN users as us ON (us.userid = tra.userid)
        LEFT JOIN product as p ON (tra.productid = p.productid)
        LEFT JOIN productimage pi ON (pi.productid = p.productid AND pi.imageseq = 1)
        LEFT JOIN address ad ON (ad.addressid = tra.addressid)
        WHERE tra.status IN ('ordered', 'shipped', 'outfordelivery', 'delivered', 'deliverfail')
        `
        if (filters?.userid) {
            thisQuery += ` AND tra.userid = '${filters?.userid}' `
        }

        thisQuery += ` 
        GROUP BY tra.id, tra.transid, tra.ordernumber, tra.status, tra.createdon, p.name, p.description, p.price, pi.image
        ORDER BY MAX(tra.lastmodifiedat) DESC
        `
        if (filters?.limit) {
            thisQuery += ` limit ${filters?.limit},10 `
        }

        const orders = await db.query(thisQuery);

        return res.status(200).json({
            status: true,
            message: 'Order details retrieved successfully',
            data: orders[0]
        });

    } catch (error) {
        console.log('error', error);
        return res.status(500).json({
            status: false,
            message: error.message || 'Internal Server Error'
        });
    }

};



try {
    const response = await axios.post(ccavenueUrl, paymentData);
    if (response.status === 200) {
      // console.log('CCAvenue Response:', response.data);
      res.status(response.status).json({
        status: true,
        message: 'Transaction initiated successfully',
        redirectUrl: response.data,        
      });
    } else {
      res.status(response.status).json({
        status: false,
        message: 'Error processing payment',
        error: response.data,
      });
    }
  } catch (error) {
    console.error('Axios Error:', error);
    res.status(500).send({
      status: false,
      message: 'Error processing payment',
      error: error.message || error,
    });
  }


// 20-11-2024

export const insertTransaction = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
    await db.query('START TRANSACTION');

    try {
        const { userid, addressid, gst_id, tax_amount, quantity,shipping_charges, total_amount, status } = req.body;

        const productid = req.body.productid
        console.log('productid', productid);

        // const productidArray = JSON.parse(productid).length == 0 ? 0 : JSON.parse(productid);
        const productidArray = productid.length == 0 ? 0 : productid;
        console.log('productidArray', productidArray);
        
        let userCheckQuery = `SELECT userid FROM users WHERE userid = '${userid}' LIMIT 1`;
        const userCheckData = await db.query(userCheckQuery);
        const userExists = userCheckData[0][0] ? userCheckData[0][0]?.userid : 0

        console.log('userExists', userExists);
    
        if (userExists == 0 || !userExists) {
            console.log('User-ID not found');
            return res.status(404).send({
                status: false,
                message: 'User-ID not found',
            });
        }
    
        let productCheckQuery = `SELECT productid FROM product WHERE productid IN (${productidArray}) LIMIT 1`;
        const productCheckData = await db.query(productCheckQuery);
        const productExists = productCheckData[0][0] ? productCheckData[0][0]?.productid : 0

        console.log('productExists', productExists);

        if (productExists == 0 || !productExists) {
            console.log('Product-ID not found');
            return res.status(404).send({
                status: false,
                message: 'Product-ID not found',
            });
        }

        // const arrayReplace = productidArray.join(',').replace(/[]/g, '');
        // console.log('arrayReplace', arrayReplace);

        let getATC = ` SELECT * FROM addtocarttable WHERE userid = '${userid}' AND status != 'Ordered' AND productid IN (${productidArray}) `
        const ATC_ID = await db.query(getATC);
        console.log('ATC_ID data', ATC_ID[0]);      
        
        const ATCEmpty = ATC_ID[0][0] ? ATC_ID[0][0]?.atcartid : 0
        
        if (ATCEmpty == 0 || !ATCEmpty) {
            console.log('Add To Cart Empty');
            return res.status(404).send({
                status: false,
                message: 'Add To Cart Empty',
            });
        }
        
        const variant_array = ATC_ID[0]?.map(i => i.variantid);
        const variantData =  variant_array.length != 0 ? variant_array?.join(',') : 0
        console.log('variant_array', variantData);
        console.log('variant_array_length', variant_array.length);

        let variantQuery = ` SELECT * FROM variant WHERE id IN (${variantData}) `
        const variantID = await db.query(variantQuery);
        console.log('variantID data', variantID[0]);  

        // space for payment confirmations

        const transArray = []

        let index = 0; 

        for (const productId of productidArray) {

            const productVariant = ATC_ID[0].find(item => item.productid === productId);
            const productQuantity = productVariant ? productVariant.quantity : 0;
            const productVariantID = productVariant ? productVariant.variantid : 0;

            const variantList = variantID[0].find(item => item.productid === productId);
            console.log('variantList', variantList);  

            const productVariantPrice = variantList ? variantList.price : 0;

            const gstArray = gst_id[index];
            const taxAmountArray = tax_amount[index];

            console.log('gstArray', gstArray);
            console.log('taxAmountArray', taxAmountArray);

            console.log('productVariant', productVariant);        
            console.log('productQuantity', productQuantity);        
            console.log('productVariantID', productVariantID);        
            console.log('productVariantPrice', productVariantPrice);        

            const today = new Date().toISOString().slice(0, 10);
            console.log('today', today);
    
            let counterQuery = `
            INSERT INTO daily_reset_counter (counter_date, counter_value) VALUES ('${today}', 1) ON DUPLICATE KEY UPDATE counter_value = counter_value + 1 `;
            const counterInsert = await db.query(counterQuery);
        
            let counterSelectQuery = `SELECT counter_value FROM daily_reset_counter WHERE counter_date = '${today}' `;
            const counterData = await db.query(counterSelectQuery);
            const counterValue = counterData[0][0] ? counterData[0][0]?.counter_value : 0
    
            console.log('counterValue', counterValue);

            const orderNumber = `2CQR-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
            const transId = `Trans-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
    
            console.log('orderNumber', orderNumber);
            console.log('transId', transId);

            let transactionInsertQuery = `
            INSERT INTO transactions (productid, userid, transid, addressid, ordernumber, quantity, variant, gst_id, status) VALUES ('${productId}', '${userid}', '${transId}', '${addressid}', '${orderNumber}', '${productQuantity}','${productVariantID}','${gstArray}', '${status}')`;
            const transactionResult = await db.query(transactionInsertQuery);

            console.log('transactionResult', transactionResult);

            transArray?.push(transactionResult[0])
            
            let transactionBillingQuery = `
            INSERT INTO transaction_billing (trans_id, gst_id, tax_amount, price, shipping_charges, total_amount, createdon, lastmodifiedate) VALUES ('${transId}', '${gstArray}', '${taxAmountArray}', '${productVariantPrice}', '${shipping_charges}', '${total_amount}', '${formattedDateTime}', '${formattedDateTime}')`;
            const transactionResultBilling = await db.query(transactionBillingQuery);

            console.log('transactionResultBilling', transactionResultBilling);

            let transactionLogQuery = `
            INSERT INTO transactionlog (transtableid, status, createdby) VALUES ('${transactionResult[0]}', '${status}', '${userid}')`;
            const transactionResultLog = await db.query(transactionLogQuery);
            
            console.log('transactionResultLog', transactionResultLog);

            index++;
        }
        
        console.log('Transaction inserted successfully'); 

        let uAddToCart = `UPDATE addtocarttable SET status = 'Ordered' WHERE userid = '${userid}' AND productid IN (${productidArray}) `
        const addToCartUpdate = await db.query(uAddToCart);

        ATC_ID[0]?.forEach(atcItem => {
            let variant = variantID[0].find(variant => variant.id === atcItem.variantid);
            
            if (variant) {
                variant.quantity -= atcItem.quantity;                
                variant.quantity = Math.max(0, variant.quantity);
            }
        });
        
        console.log('finalArray[0]',variantID[0]);

        for (const atcArray of variantID[0]) {
            console.log('atcArray', atcArray);
            
            let variantQuery = `UPDATE variant SET quantity = '${atcArray.quantity}' WHERE id = '${atcArray.id}' `
            const variantUpdate = await db.query(variantQuery);
        }

        const transArrayID = transArray?.length != 0 ? transArray.join(',') : 0
        console.log('transArrayID', transArrayID);

        let thisQueryOrd = `
        SELECT 
        tra.id,
        tra.transid,
        tra.productid,
        tra.userid,
        us.username,
        tra.ordernumber,
        tra.status,
        tra.createdon, 
        tra.quantity, 
        tra.productid as trans_product_id,
        (JSON_ARRAYAGG(
                JSON_OBJECT(
                    'productid', p.productid,
                    'name', p.name,
                    'description', p.description,
                    'price', v.price,
                    'quantity', tra.quantity
                )
            )
        ) AS product_details,
        (JSON_ARRAYAGG(
                JSON_OBJECT(
                    'trans_id', tb.trans_id,
                    'tax_amount', tb.tax_amount,
                    'gst_id', tb.gst_id,
                    'price', tb.price,
                    'shipping_charges', tb.shipping_charges,
                    'total_amount', tb.total_amount,
                    'name', gst.name,
                    'cgst', gst.cgst,
                    'igst', gst.igst,
                    'sgst', gst.sgst,
                    'igst', gst.igst
                )
            )
        ) AS billing_details,
        (JSON_ARRAYAGG(
                JSON_OBJECT(
                    'image', pi.image,
                    'imageseq', pi.imageseq,
                    'productid', pi.productid
                )
            )
        ) AS image_details,
        (
            SELECT 
                JSON_OBJECT(
                    'addressid', COALESCE(ad.addressid,''),
                    'address_name', COALESCE(ad.name,''),
                    'fullAddress', COALESCE(ad.fullAddress,''),
                    'locationDetails', COALESCE(ad.locationDetails,''),
                    'landmark', COALESCE(ad.landmark,''),
                    'city', COALESCE(ad.city,''),
                    'state', COALESCE(ad.state,''),
                    'country', COALESCE(ad.country,''),
                    'pincode', COALESCE(ad.pincode,''),
                    'email', COALESCE(ad.email,''),
                    'mobileno', COALESCE(ad.mobileno,''),
                    'alternatemobileno', COALESCE(ad.alternatemobileno,'')
                )
            FROM address as ad
            WHERE ad.addressid IN (tra.addressid)
            GROUP BY ad.addressid
        ) AS address_details
        
        FROM transactions as tra
        LEFT JOIN transaction_billing as tb ON (tra.transid = tb.trans_id)
        LEFT JOIN users as us ON (us.userid = tra.userid)
        LEFT JOIN product as p ON (tra.productid = p.productid)
        LEFT JOIN variant as v ON (v.id = tra.variant)
        LEFT JOIN productimage pi ON (pi.productid = p.productid AND pi.imageseq = 1)
        LEFT JOIN address ad ON (ad.addressid = tra.addressid)
        LEFT JOIN gst as gst ON (gst.id = tb.gst_id)
        WHERE tra.status IN ('ordered', 'shipped', 'outfordelivery', 'delivered', 'deliverfail')
        AND tra.userid = '${userid}' AND tra.id IN (${transArrayID})
        `

        thisQueryOrd += ` 
        GROUP BY tra.id, tra.transid, tra.ordernumber, tra.status, tra.createdon, p.name, p.description, p.price, pi.image
        ORDER BY MAX(tra.lastmodifiedat) DESC
        `
        const ordersData = await db.query(thisQueryOrd);

        let orderListQuery = ` SELECT 
        tra.*,
        p.name as product_name,
        us.username as username,
        v.price as variant_price,
        tb.shipping_charges as shipping_charges,
        tb.total_amount as total_amount,
        us.email as email
        FROM transactions as tra
        LEFT JOIN transaction_billing as tb ON (tra.transid = tb.trans_id)
        LEFT JOIN gst as gst ON (gst.id = tb.gst_id)
        LEFT JOIN product as p on (p.productid = tra.productid)
        LEFT JOIN users as us on (us.userid = tra.userid)
        LEFT JOIN variant as v on (v.id = tra.variant)
        WHERE tra.id IN (${transArrayID}) `
        const orderList = await db.query(orderListQuery);
        console.log('transArrayID', transArrayID);

        console.log('orderList', orderList[0]);

        emailTrigger(orderList)

        res.status(200).send({
            status: true,
            message: 'Transaction inserted successfully',
            insert_count:ordersData[0]?.length,
            insert_output: ordersData[0]
        });
    
        await db.query('COMMIT');

    } catch (error) {
        console.log('error', error);
        res.status(500).json({
            status: false,
            message: 'Internal Server Error',
            error: error.message,
        });

        await db.query('ROLLBACK');
    }
};

export const processOrder = async (req, res) => {
    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
    await db.query('START TRANSACTION');

    try {
        const { userid, productid, variantid, gst_id, address, quantity, shipping_charges, total_amount, status } = req.body;

        // Validate Inputs
        if (!userid || !productid || !variantid || !gst_id || !address) {
            return res.status(400).send({
                status: false,
                message: 'Invalid user id, product id, variant id, GST id, or address'
            });
        }

        // Check if the user exists
        let userCheckQuery = `SELECT userid FROM users WHERE userid = '${userid}' LIMIT 1`;
        const userCheckData = await db.query(userCheckQuery);
        const userExists = userCheckData[0][0] ? userCheckData[0][0]?.userid : null;

        if (!userExists) {
            return res.status(404).send({
                status: false,
                message: 'User-ID not found'
            });
        }

        // Validate Product
        const productidArray = Array.isArray(productid) && productid.length > 0 ? productid : [productid];
        let productCheckQuery = `SELECT productid FROM product WHERE productid IN (${productidArray.join(',')}) LIMIT 1`;
        const productCheckData = await db.query(productCheckQuery);
        const productExists = productCheckData[0][0] ? productCheckData[0][0]?.productid : null;

        if (!productExists) {
            return res.status(404).send({
                status: false,
                message: 'Product-ID not found'
            });
        }

        // Check if the product is in the user's cart
        let getATC = `SELECT * FROM addtocarttable WHERE userid = '${userid}' AND productid IN (${productidArray.join(',')})`;
        const ATC_ID = await db.query(getATC);
        const ATCEmpty = ATC_ID[0][0] ? ATC_ID[0][0]?.atcartid : null;

        if (!ATCEmpty) {
            return res.status(404).send({
                status: false,
                message: 'Add To Cart Empty'
            });
        }

        // Insert into billing table
        const transactionBillingQuery = `
            INSERT INTO transaction_billing (ccavenue_transid, createdon, lastmodifiedate) 
            VALUES ('', NOW(), NOW())`;
        const transactionResultBilling = await db.query(transactionBillingQuery);
        const billAutoId = transactionResultBilling[0];

        // Insert transaction records for each product
        let totalPriceGst = 0; 
        let totalWeight = 0;

        for (const productId of productidArray) {
            // Insert individual transactions
            let transactionInsertQuery = `
                INSERT INTO transactions (productid, userid, childbillid, status) 
                VALUES ('${productId}', '${userid}', '${billAutoId}', '${status || 'Initiated'}')`;
            const transactionResult = await db.query(transactionInsertQuery);

            // Get the total weight and price (mock example, replace with actual data)
            // Simulate getting weight and price based on the product (replace with your logic)
            const productDetailsQuery = `SELECT weight, price_gst FROM product WHERE productid = '${productId}'`;
            const productDetails = await db.query(productDetailsQuery);
            const { weight, price_gst } = productDetails[0][0];

            totalPriceGst += price_gst;
            totalWeight += weight;

            // Log transaction
            let transactionLogQuery = `
                INSERT INTO transactionlog (transtableid, status, createdby) 
                VALUES ('${transactionResult[0]}', '${status}', '${userid}')`;
            await db.query(transactionLogQuery);
        }

        // Calculate shipping charges based on weight
        const shippingChargeQuery = `
            SELECT charge FROM weightmasters WHERE weight < ${totalWeight} ORDER BY weight DESC LIMIT 1`;
        const shippingChargeResult = await db.query(shippingChargeQuery);
        const shippingCharge = shippingChargeResult[0][0]?.charge || 0;

        // Calculate actual price
        const actualPrice = totalPriceGst + shippingCharge;

        // Update billing table with total price, weight, shipping charge, and other details
        const updateBillingQuery = `
            UPDATE transaction_billing 
            SET totalpricegst = ?, totalweight = ?, shippingcharge = ?, actualprice = ?, type = 'purchase', transactionprice = ?, paymenttype = 'ccavenue' 
            WHERE billauto_id = ?`;
        await db.query(updateBillingQuery, [totalPriceGst, totalWeight, shippingCharge, actualPrice, actualPrice, billAutoId]);

        // Simulate initiating CCAvenue payment (replace with real API integration)
        const paymentLink = `https://www.ccavenue.com/payment?bill_id=${billAutoId}&amount=${actualPrice}`; // Mock URL

        // Commit the transaction
        await db.query('COMMIT');

        // Return response with payment link and billauto_id
        res.status(200).send({
            status: true,
            message: 'Transaction inserted successfully',
            paymentLink: paymentLink,
            billAutoId: billAutoId
        });
        
    } catch (error) {
        // Rollback the transaction in case of an error
        await db.query('ROLLBACK');
        console.error('Error during order processing:', error.message);

        res.status(500).send({
            status: false,
            message: 'Internal Server Error',
            error: error.message
        });
    }
};


// 21-11-2024
export const insertTransactionMain = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
    await db.query('START TRANSACTION');

    try {
        const { userid, addressid, gst_id, tax_amount, quantity,shipping_charges, total_amount, status } = req.body;

        const productid = req.body.productid
        console.log('productid', productid);

        // const productidArray = JSON.parse(productid).length == 0 ? 0 : JSON.parse(productid);
        const productidArray = productid.length == 0 ? 0 : productid;
        console.log('productidArray', productidArray);
        
        let userCheckQuery = `SELECT userid FROM users WHERE userid = '${userid}' LIMIT 1`;
        const userCheckData = await db.query(userCheckQuery);
        const userExists = userCheckData[0][0] ? userCheckData[0][0]?.userid : 0

        console.log('userExists', userExists);
    
        if (userExists == 0 || !userExists) {
            console.log('User-ID not found');
            return res.status(404).send({
                status: false,
                message: 'User-ID not found',
            });
        }
    
        let productCheckQuery = `SELECT productid FROM product WHERE productid IN (${productidArray}) LIMIT 1`;
        const productCheckData = await db.query(productCheckQuery);
        const productExists = productCheckData[0][0] ? productCheckData[0][0]?.productid : 0

        console.log('productExists', productExists);

        if (productExists == 0 || !productExists) {
            console.log('Product-ID not found');
            return res.status(404).send({
                status: false,
                message: 'Product-ID not found',
            });
        }

        // const arrayReplace = productidArray.join(',').replace(/[]/g, '');
        // console.log('arrayReplace', arrayReplace);

        let getATC = ` SELECT * FROM addtocarttable WHERE userid = '${userid}' AND status != 'Ordered' AND productid IN (${productidArray}) `
        const ATC_ID = await db.query(getATC);
        console.log('ATC_ID data', ATC_ID[0]);      
        
        const ATCEmpty = ATC_ID[0][0] ? ATC_ID[0][0]?.atcartid : 0
        
        if (ATCEmpty == 0 || !ATCEmpty) {
            console.log('Add To Cart Empty');
            return res.status(404).send({
                status: false,
                message: 'Add To Cart Empty',
            });
        }
        
        const variant_array = ATC_ID[0]?.map(i => i.variantid);
        const variantData =  variant_array.length != 0 ? variant_array?.join(',') : 0
        console.log('variant_array', variantData);
        console.log('variant_array_length', variant_array.length);

        let variantQuery = ` SELECT * FROM variant WHERE id IN (${variantData}) `
        const variantID = await db.query(variantQuery);
        console.log('variantID data', variantID[0]);  

        // space for payment confirmations

        const transArray = []

        let index = 0; 

        for (const productId of productidArray) {

            const productVariant = ATC_ID[0].find(item => item.productid === productId);
            const productQuantity = productVariant ? productVariant.quantity : 0;
            const productVariantID = productVariant ? productVariant.variantid : 0;

            const variantList = variantID[0].find(item => item.productid === productId);
            console.log('variantList', variantList);  

            const productVariantPrice = variantList ? variantList.price : 0;

            const gstArray = gst_id[index];
            const taxAmountArray = tax_amount[index];

            console.log('gstArray', gstArray);
            console.log('taxAmountArray', taxAmountArray);

            console.log('productVariant', productVariant);        
            console.log('productQuantity', productQuantity);        
            console.log('productVariantID', productVariantID);        
            console.log('productVariantPrice', productVariantPrice);        

            const today = new Date().toISOString().slice(0, 10);
            console.log('today', today);
    
            let counterQuery = `
            INSERT INTO daily_reset_counter (counter_date, counter_value) VALUES ('${today}', 1) ON DUPLICATE KEY UPDATE counter_value = counter_value + 1 `;
            const counterInsert = await db.query(counterQuery);
        
            let counterSelectQuery = `SELECT counter_value FROM daily_reset_counter WHERE counter_date = '${today}' `;
            const counterData = await db.query(counterSelectQuery);
            const counterValue = counterData[0][0] ? counterData[0][0]?.counter_value : 0
    
            console.log('counterValue', counterValue);

            const orderNumber = `2CQR-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
            const transId = `Trans-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
    
            console.log('orderNumber', orderNumber);
            console.log('transId', transId);

            let transactionInsertQuery = `
            INSERT INTO transactions (productid, userid, transid, addressid, ordernumber, quantity, variant, gst_id, status) VALUES ('${productId}', '${userid}', '${transId}', '${addressid}', '${orderNumber}', '${productQuantity}','${productVariantID}','${gstArray}', '${status}')`;
            const transactionResult = await db.query(transactionInsertQuery);

            console.log('transactionResult', transactionResult);

            transArray?.push(transactionResult[0])
            
            let transactionBillingQuery = `
            INSERT INTO transaction_billing (trans_id, gst_id, tax_amount, price, shipping_charges, total_amount, createdon, lastmodifiedate) VALUES ('${transId}', '${gstArray}', '${taxAmountArray}', '${productVariantPrice}', '${shipping_charges}', '${total_amount}', '${formattedDateTime}', '${formattedDateTime}')`;
            const transactionResultBilling = await db.query(transactionBillingQuery);

            console.log('transactionResultBilling', transactionResultBilling);

            let transactionLogQuery = `
            INSERT INTO transactionlog (transtableid, status, createdby) VALUES ('${transactionResult[0]}', '${status}', '${userid}')`;
            const transactionResultLog = await db.query(transactionLogQuery);
            
            console.log('transactionResultLog', transactionResultLog);

            index++;
        }
        
        console.log('Transaction inserted successfully'); 

        let uAddToCart = `UPDATE addtocarttable SET status = 'Ordered' WHERE userid = '${userid}' AND productid IN (${productidArray}) `
        const addToCartUpdate = await db.query(uAddToCart);

        ATC_ID[0]?.forEach(atcItem => {
            let variant = variantID[0].find(variant => variant.id === atcItem.variantid);
            
            if (variant) {
                variant.quantity -= atcItem.quantity;                
                variant.quantity = Math.max(0, variant.quantity);
            }
        });
        
        console.log('finalArray[0]',variantID[0]);

        for (const atcArray of variantID[0]) {
            console.log('atcArray', atcArray);
            
            let variantQuery = `UPDATE variant SET quantity = '${atcArray.quantity}' WHERE id = '${atcArray.id}' `
            const variantUpdate = await db.query(variantQuery);
        }

        const transArrayID = transArray?.length != 0 ? transArray.join(',') : 0
        console.log('transArrayID', transArrayID);

        let thisQueryOrd = `
        SELECT 
        tra.id,
        tra.transid,
        tra.productid,
        tra.userid,
        us.username,
        tra.ordernumber,
        tra.status,
        tra.createdon, 
        tra.quantity, 
        tra.productid as trans_product_id,
        (JSON_ARRAYAGG(
                JSON_OBJECT(
                    'productid', p.productid,
                    'name', p.name,
                    'description', p.description,
                    'price', v.price,
                    'quantity', tra.quantity
                )
            )
        ) AS product_details,
        (JSON_ARRAYAGG(
                JSON_OBJECT(
                    'trans_id', tb.trans_id,
                    'tax_amount', tb.tax_amount,
                    'gst_id', tb.gst_id,
                    'price', tb.price,
                    'shipping_charges', tb.shipping_charges,
                    'total_amount', tb.total_amount,
                    'name', gst.name,
                    'cgst', gst.cgst,
                    'igst', gst.igst,
                    'sgst', gst.sgst,
                    'igst', gst.igst
                )
            )
        ) AS billing_details,
        (JSON_ARRAYAGG(
                JSON_OBJECT(
                    'image', pi.image,
                    'imageseq', pi.imageseq,
                    'productid', pi.productid
                )
            )
        ) AS image_details,
        (
            SELECT 
                JSON_OBJECT(
                    'addressid', COALESCE(ad.addressid,''),
                    'address_name', COALESCE(ad.name,''),
                    'fullAddress', COALESCE(ad.fullAddress,''),
                    'locationDetails', COALESCE(ad.locationDetails,''),
                    'landmark', COALESCE(ad.landmark,''),
                    'city', COALESCE(ad.city,''),
                    'state', COALESCE(ad.state,''),
                    'country', COALESCE(ad.country,''),
                    'pincode', COALESCE(ad.pincode,''),
                    'email', COALESCE(ad.email,''),
                    'mobileno', COALESCE(ad.mobileno,''),
                    'alternatemobileno', COALESCE(ad.alternatemobileno,'')
                )
            FROM address as ad
            WHERE ad.addressid IN (tra.addressid)
            GROUP BY ad.addressid
        ) AS address_details
        
        FROM transactions as tra
        LEFT JOIN transaction_billing as tb ON (tra.transid = tb.trans_id)
        LEFT JOIN users as us ON (us.userid = tra.userid)
        LEFT JOIN product as p ON (tra.productid = p.productid)
        LEFT JOIN variant as v ON (v.id = tra.variant)
        LEFT JOIN productimage pi ON (pi.productid = p.productid AND pi.imageseq = 1)
        LEFT JOIN address ad ON (ad.addressid = tra.addressid)
        LEFT JOIN gst as gst ON (gst.id = tb.gst_id)
        WHERE tra.status IN ('ordered', 'shipped', 'outfordelivery', 'delivered', 'deliverfail')
        AND tra.userid = '${userid}' AND tra.id IN (${transArrayID})
        `

        thisQueryOrd += ` 
        GROUP BY tra.id, tra.transid, tra.ordernumber, tra.status, tra.createdon, p.name, p.description, p.price, pi.image
        ORDER BY MAX(tra.lastmodifiedat) DESC
        `
        const ordersData = await db.query(thisQueryOrd);

        let orderListQuery = ` SELECT 
        tra.*,
        p.name as product_name,
        us.username as username,
        v.price as variant_price,
        tb.shipping_charges as shipping_charges,
        tb.total_amount as total_amount,
        us.email as email
        FROM transactions as tra
        LEFT JOIN transaction_billing as tb ON (tra.transid = tb.trans_id)
        LEFT JOIN gst as gst ON (gst.id = tb.gst_id)
        LEFT JOIN product as p on (p.productid = tra.productid)
        LEFT JOIN users as us on (us.userid = tra.userid)
        LEFT JOIN variant as v on (v.id = tra.variant)
        WHERE tra.id IN (${transArrayID}) `
        const orderList = await db.query(orderListQuery);
        console.log('transArrayID', transArrayID);

        console.log('orderList', orderList[0]);

        emailTrigger(orderList)

        res.status(200).send({
            status: true,
            message: 'Transaction inserted successfully',
            insert_count:ordersData[0]?.length,
            insert_output: ordersData[0]
        });
    
        await db.query('COMMIT');

    } catch (error) {
        console.log('error', error);
        res.status(500).json({
            status: false,
            message: 'Internal Server Error',
            error: error.message,
        });

        await db.query('ROLLBACK');
    }
};
export const buyNow = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
    await db.query('START TRANSACTION');

    try {
        const { userid, transactionid, addressid, quantity, variantid, tax_amount, gst_id, shipping_charges, total_amount, status } = req.body;

        const productid = req.body.productid
        console.log('productid', productid);
        
        let userCheckQuery = `SELECT userid FROM users WHERE userid = '${userid}' LIMIT 1`;
        const userCheckData = await db.query(userCheckQuery);
        const userExists = userCheckData[0][0] ? userCheckData[0][0]?.userid : 0

        console.log('userExists', userExists);
    
        if (userExists == 0 || !userExists) {
            console.log('User-ID not found');
            return res.status(404).send({
                status: false,
                message: 'User-ID not found',
            });
        }
    
        let productCheckQuery = `SELECT productid FROM product WHERE productid IN (${productid}) LIMIT 1`;
        const productCheckData = await db.query(productCheckQuery);
        const productExists = productCheckData[0][0] ? productCheckData[0][0]?.productid : 0

        console.log('productExists', productExists);

        if (productExists == 0 || !productExists) {
            console.log('Product-ID not found');
            return res.status(404).send({
                status: false,
                message: 'Product-ID not found',
            });
        }

        let variantQuery = ` SELECT * FROM variant WHERE id IN (${variantid || 0}) `
        const variantID = await db.query(variantQuery);
        console.log('variantID data', variantID[0]);  

        const variantCheck = variantID[0][0] ? variantID[0][0]?.id : 0
        const variantPrice = variantID[0][0] ? variantID[0][0]?.price : 0

        if (variantCheck == 0 || !variantCheck) {
            console.log('Variant-ID not found');
            return res.status(404).send({
                status: false,
                message: 'Variant-ID not found',
            });
        }

        let transIdQuery = `SELECT * FROM transactions WHERE transid = '${transactionid}' `;
        const transQuery = await db.query(transIdQuery);
        const transQueryInsert = transQuery[0][0] ? transQuery[0][0]?.transid : 0
        const transQueryProduct = transQuery[0][0] ? transQuery[0][0]?.productid : 0

        console.log('transQueryInsert', transQueryInsert);
        console.log('transQueryProduct', transQueryProduct);

        if (productid != transQueryProduct) {
            console.log('Exchanging with a different product is not allowed');
            return res.status(400).send({
                status: false,
                message: 'Exchanging with a different product is not allowed',
            });
        }

        // space for payment confirmations

        const today = new Date().toISOString().slice(0, 10);
        console.log('today', today);

        let counterQuery = `
        INSERT INTO daily_reset_counter (counter_date, counter_value) VALUES ('${today}', 1) ON DUPLICATE KEY UPDATE counter_value = counter_value + 1 `;
        const counterInsert = await db.query(counterQuery);
    
        let counterSelectQuery = `SELECT counter_value FROM daily_reset_counter WHERE counter_date = '${today}' `;
        const counterData = await db.query(counterSelectQuery);
        const counterValue = counterData[0][0] ? counterData[0][0]?.counter_value : 0
        console.log('counterValue', counterValue);

        const orderNumber = `2CQR-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
        const transId = `Trans-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;

        console.log('orderNumber', orderNumber);
        console.log('transId', transId);

        const gstArray = gst_id[0]
        const taxAmountArray = tax_amount[0]
        
        let transactionInsertQuery = `
        INSERT INTO transactions (productid, userid, transid, addressid, ordernumber, quantity, variant, gst_id, status) VALUES ('${productid}', '${userid}', '${transId}', '${addressid}', '${orderNumber}', '${quantity}','${variantid}', '${gstArray}', '${status}')`;
        const transactionResult = await db.query(transactionInsertQuery);

        console.log('transactionResult', transactionResult);

        let transactionBillingQuery = `
        INSERT INTO transaction_billing (trans_id, gst_id, tax_amount, price, shipping_charges, total_amount, createdon, lastmodifiedate) VALUES ('${transId}', '${gstArray}', '${taxAmountArray}', '${variantPrice}', '${shipping_charges}', '${total_amount}', '${formattedDateTime}', '${formattedDateTime}')`;
        const transactionResultBilling = await db.query(transactionBillingQuery);

        console.log('transactionResultBilling', transactionResultBilling);

        let transactionLogQuery = `
        INSERT INTO transactionlog (transtableid, status, createdby) VALUES ('${transactionResult[0]}', '${status}', '${userid}')`;
        const transactionResultLog = await db.query(transactionLogQuery);
        
        console.log('transactionResultLog', transactionResultLog);
        console.log('Transaction inserted successfully'); 

        let variant = variantID[0]?.find(variant => variant.id === variantid);
        
        if (variant) {
            variant.quantity -= quantity;                
            variant.quantity = Math.max(0, variant.quantity);
        }
        
        console.log('finalArray[0]',variantID[0]);

        let variantQuantityQuery = `UPDATE variant SET quantity = '${variantID[0][0]?.quantity}' WHERE id = '${variantID[0][0]?.id}' `
        const variantUpdate = await db.query(variantQuantityQuery);

        const transArrayID = transactionResult?.length != 0 ? transactionResult.join(',') : 0
        console.log('transArrayID', transArrayID);

        let thisQueryOrd = `
        SELECT 
        tra.id,
        tra.transid,
        tra.productid,
        tra.userid,
        us.username,
        tra.ordernumber,
        tra.status,
        tra.createdon,
        tra.quantity, 
        tra.productid as trans_product_id,
        (JSON_ARRAYAGG(
                JSON_OBJECT(
                    'productid', p.productid,
                    'name', p.name,
                    'description', p.description,
                    'price', v.price,
                    'quantity', tra.quantity
                )
            )
        ) AS product_details,
          (JSON_ARRAYAGG(
                JSON_OBJECT(
                    'trans_id', tb.trans_id,
                    'tax_amount', tb.tax_amount,
                    'gst_id', tb.gst_id,
                    'price', tb.price,
                    'shipping_charges', tb.shipping_charges,
                    'total_amount', tb.total_amount,
                    'name', gst.name,
                    'cgst', gst.cgst,
                    'igst', gst.igst,
                    'sgst', gst.sgst,
                    'igst', gst.igst
                )
            )
        ) AS billing_details,
        (JSON_ARRAYAGG(
                JSON_OBJECT(
                    'image', pi.image,
                    'imageseq', pi.imageseq,
                    'productid', pi.productid
                )
            )
        ) AS image_details,
        (
            SELECT 
                JSON_OBJECT(
                    'addressid', COALESCE(ad.addressid,''),
                    'address_name', COALESCE(ad.name,''),
                    'fullAddress', COALESCE(ad.fullAddress,''),
                    'locationDetails', COALESCE(ad.locationDetails,''),
                    'landmark', COALESCE(ad.landmark,''),
                    'city', COALESCE(ad.city,''),
                    'state', COALESCE(ad.state,''),
                    'country', COALESCE(ad.country,''),
                    'pincode', COALESCE(ad.pincode,''),
                    'email', COALESCE(ad.email,''),
                    'mobileno', COALESCE(ad.mobileno,''),
                    'alternatemobileno', COALESCE(ad.alternatemobileno,'')
                )
            FROM address as ad
            WHERE ad.addressid IN (tra.addressid)
            GROUP BY ad.addressid
        ) AS address_details
        
        FROM transactions as tra
        LEFT JOIN transaction_billing as tb ON (tra.transid = tb.trans_id)
        LEFT JOIN users as us ON (us.userid = tra.userid)
        LEFT JOIN product as p ON (tra.productid = p.productid)
        LEFT JOIN variant as v ON (v.id = tra.variant)
        LEFT JOIN productimage pi ON (pi.productid = p.productid AND pi.imageseq = 1)
        LEFT JOIN address ad ON (ad.addressid = tra.addressid)
        LEFT JOIN gst as gst ON (gst.id = tb.gst_id)
        WHERE tra.status IN ('ordered', 'shipped', 'outfordelivery', 'delivered', 'deliverfail')
        AND tra.userid = '${userid}' AND tra.id IN (${transArrayID})

        GROUP BY tra.id
        ORDER BY MAX(tra.lastmodifiedat) DESC
        `
        const ordersData = await db.query(thisQueryOrd);

        if (transactionid == '' || transactionid != undefined || transactionid == 0) {

            let thisQueryExchange = ` Update transactions SET status = 'exchange' WHERE status = 'Ordered' AND id = '${transactionid}' `
            const exchangeDatai = await db.query(thisQueryExchange);
            console.log('exchangeDatai', exchangeDatai);
            console.log('Transaction status updated to exchange');
        }

        res.status(200).send({
            status: true,
            message: 'Transaction inserted successfully',
            insert_count : ordersData[0]?.length,
            insert_output : ordersData[0]
        });
    
        await db.query('COMMIT');

    } catch (error) {
        console.log('error', error);
        res.status(500).json({
            status: false,
            message: 'Internal Server Error',
            error: error.message,
        });

        await db.query('ROLLBACK');
    }
};

export const proceedOrder = async (req, res) => {
    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
    await db.query('START TRANSACTION');

    try {
        const { userid, transactionid, addressid, quantity, variantid, tax_amount, gst_id, shipping_charges, total_amount, status, productid } = req.body;

        console.log('Request Body:', req.body);

        const userCheckQuery = `SELECT userid FROM users WHERE userid = '${userid}' LIMIT 1`;
        const userCheckData = await db.query(userCheckQuery);
        if (!userCheckData[0][0]) {
            return res.status(404).send({ 
                status: false, 
                message: 'User-ID not found' 
            });
        }

        const productCheckQuery = `SELECT productid FROM product WHERE productid = '${productid}' LIMIT 1`;
        const productCheckData = await db.query(productCheckQuery);
        if (!productCheckData[0][0]) {
            return res.status(404).send({ 
                status: false, 
                message: 'Product-ID not found' 
            });
        }

        const variantQuery = `SELECT * FROM variant WHERE id = '${variantid}' LIMIT 1`;
        const variantData = await db.query(variantQuery);
        const variant = variantData[0][0];
        if (!variant) {
            return res.status(404).send({ 
                status: false, 
                message: 'Variant-ID not found' 
            });
        }

        const transQuery = `SELECT * FROM transactions WHERE transid = '${transactionid}'`;
        const oldTransaction = await db.query(transQuery);
        if (!oldTransaction[0][0]) {
            return res.status(404).send({ 
                status: false, 
                message: 'Transaction not found' 
            });
        }

        if (oldTransaction[0][0].status !== 'delivered') {
            return res.status(400).send({ 
                status: false, 
                message: 'Old transaction must be delivered to proceed' 
            });
        }

        if (productid !== oldTransaction[0][0]?.productid) {
            return res.status(400).send({ 
                status: false, 
                message: 'Exchanging with a different product is not allowed' 
            });
        }

        const totalWeight = variant.weight * quantity;
        const weightChargeQuery = `
            SELECT charge 
            FROM weightmasters 
            WHERE weight <= '${totalWeight}' 
            ORDER BY weight DESC 
            LIMIT 1`;
        const weightChargeData = await db.query(weightChargeQuery);
        const shippingCharge = weightChargeData[0][0]?.charge || 0;
        const newTotalPrice = total_amount + shippingCharge;

        const oldTotalPrice = oldTransaction[0][0] ? oldTransaction[0][0]?.totalpricegst : 0
        const priceDifference = newTotalPrice - oldTotalPrice;

        let billingType, actualPrice, transactionPrice;
        if (priceDifference > 0) {
            billingType = 'purchase';
            actualPrice = priceDifference;
            transactionPrice = newTotalPrice;

            const childBillID = oldTransaction[0][0] ? oldTransaction[0][0]?.childbillid : 0
            const updateChildBillQuery = `UPDATE transactions SET childbillid = '${childBillID}' WHERE transid = '${transactionid}'`;
            await db.query(updateChildBillQuery);

            const billingInsertQuery = `
                INSERT INTO billingtable (status, ccavenueid, type, actualprice, transactionprice, parentbillid) 
                VALUES ('Initiated', '', '${billingType}', '${actualPrice}', '${transactionPrice}', '${childBillID}')`;
            const billingResult = await db.query(billingInsertQuery);

            console.log('Billing Record Inserted:', billingResult);

        } else if (priceDifference < 0) {
            billingType = 'refund';
            actualPrice = Math.abs(priceDifference);
            transactionPrice = newTotalPrice;

            const childBillID = oldTransaction[0][0].childbillid;
            const billingInsertQuery = `
                INSERT INTO billingtable (status, ccavenueid, type, actualprice, transactionprice, parentbillid) 
                VALUES ('Initiated', '', '${billingType}', '${actualPrice}', '${transactionPrice}', '${childBillID}')`;
            const billingResult = await db.query(billingInsertQuery);

            console.log('Refund Billing Record Inserted:', billingResult);

        } else {
            console.log('No price difference, proceeding with transaction update.');
        }

        const updateOldTransactionQuery = `UPDATE transactions SET status = 'return initiated' WHERE transid = '${transactionid}'`;
        await db.query(updateOldTransactionQuery);

        const updatedQuantity = Math.max(variant.quantity - quantity, 0);
        const updateVariantQuery = `UPDATE variant SET quantity = '${updatedQuantity}' WHERE id = '${variantid}'`;
        await db.query(updateVariantQuery);

        await db.query('COMMIT');
        res.status(200).send({ 
            status: true, 
            message: 'Transaction processed successfully' 
        });
    } catch (error) {
        console.error('Error:', error);
        await db.query('ROLLBACK');
        res.status(500).send({ 
            status: false, 
            message: 'Internal Server Error', 
            error: error.message 
        });
    }
};


// 22-11-2024
// Insert Exchange
export const insertExchange = async (req, res) => {
    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
    await db.query('START TRANSACTION');

    try {
        const { userid, transactionid, addressid, quantity, variantid, tax_amount, gst_id, shipping_charges, total_amount, status, productid } = req.body;

        console.log('Request Body:', req.body);

        const userCheckQuery = `SELECT userid FROM users WHERE userid = '${userid}' LIMIT 1`;
        const userCheckData = await db.query(userCheckQuery);
        if (!userCheckData[0][0]) {
            return res.status(404).send({ 
                status: false, 
                message: 'User-ID not found' 
            });
        }

        const productCheckQuery = `SELECT productid FROM product WHERE productid = '${productid}' LIMIT 1`;
        const productCheckData = await db.query(productCheckQuery);
        if (!productCheckData[0][0]) {
            return res.status(404).send({ 
                status: false, 
                message: 'Product-ID not found' 
            });
        }

        const variantQuery = `SELECT * FROM variant WHERE id = '${variantid}' LIMIT 1`;
        const variantData = await db.query(variantQuery);
        const variant = variantData[0][0];
        if (!variant) {
            return res.status(404).send({ 
                status: false, 
                message: 'Variant-ID not found' 
            });
        }

        const transQuery = `SELECT * FROM transactions WHERE transid = '${transactionid}'`;
        const oldTransaction = await db.query(transQuery);

        console.log('oldTransaction', oldTransaction[0]);
        
        if (!oldTransaction[0][0]) {
            return res.status(404).send({ 
                status: false, 
                message: 'Transaction not found' 
            });
        }

        if (oldTransaction[0][0]?.status !== 'delivered') {
            return res.status(400).send({ 
                status: false, 
                message: 'Old transaction must be delivered to proceed' 
            });
        }

        if (productid != oldTransaction[0][0]?.productid) {
            return res.status(400).send({ 
                status: false, 
                message: 'Exchanging with a different product is not allowed' 
            });
        }

        const totalWeight = variant.weight * quantity;
        const totalPrice = variant.price * quantity;
        console.log('total Weight', totalWeight,' = ', variant.weight,' * ', quantity );
        console.log('total price', totalPrice,' = ',  variant.price,' * ',quantity );
        
        const weightChargeQuery = `
            SELECT charge 
            FROM weightmasters 
            WHERE weight <= '${totalWeight}' 
            ORDER BY weight DESC 
            LIMIT 1`;
        const weightChargeData = await db.query(weightChargeQuery);
        const shippingCharge = weightChargeData[0][0]?.charge || 0;
        const newTotalPrice = totalPrice + shippingCharge;

        const oldTotalPrice = oldTransaction[0][0] ? oldTransaction[0][0]?.tpricegst : 0
        const priceDifference = newTotalPrice - oldTotalPrice;
        console.log('newTotalPrice', newTotalPrice, oldTotalPrice );
        console.log('shippingCharge', shippingCharge);
        console.log('priceDifference', priceDifference);

        let billingType, actualPrice, transactionPrice, newBillID;
        if (priceDifference > 0) {
            billingType = 'purchase';
            actualPrice = priceDifference;
            transactionPrice = newTotalPrice;

            const childBillID = oldTransaction[0][0] ? oldTransaction[0][0]?.childbillid : 0
            console.log('inside', oldTransaction[0][0]);
            
            // const updateChildBillQuery = `UPDATE transactions SET childbillid = '${childBillID}' WHERE transid = '${transactionid}'`;
            // await db.query(updateChildBillQuery);

            const billingInsertQuery = `
                INSERT INTO transaction_billing (status, ccavenue_transid, tpricegst, tweight, shipping_charges, type, actual_price, transaction_price, parent_bill_id) 
                VALUES ('Initiated', ${null}, '${totalPrice}', '${totalWeight}', '${shippingCharge}', '${billingType}', '${actualPrice}', '${transactionPrice}', '${childBillID}')`;
            const billingResult = await db.query(billingInsertQuery);
            newBillID = billingResult[0];

            console.log('Billing Record Inserted:', billingResult);

            await db.query(`UPDATE transactions SET childbillid = '${newBillID}', status = 'return initiated' WHERE transid = '${transactionid}'`)

        } else if (priceDifference < 0) {
            billingType = 'refund';
            actualPrice = Math.abs(priceDifference);
            transactionPrice = newTotalPrice;

            const childBillID = oldTransaction[0][0] ? oldTransaction[0][0]?.childbillid : 0
            const billingInsertQuery = `
                INSERT INTO transaction_billing (status, ccavenue_transid, tpricegst, tweight, shipping_charges, type, actual_price, transaction_price, parent_bill_id) 
                VALUES ('Initiated', ${null}, '${totalPrice}', '${totalWeight}', '${shippingCharge}', '${billingType}', '${actualPrice}', '${transactionPrice}', '${childBillID}')`;
            const billingResult = await db.query(billingInsertQuery);
            newBillID = billingResult[0];

            console.log('Refund Billing Record Inserted:', billingResult);

            await db.query(`UPDATE transactions SET childbillid = '${newBillID}',status = 'return initiated' WHERE transid = '${transactionid}'`)

        } else {
            console.log('No price difference, proceeding with transaction update.');
        }

        // const updateOldTransactionQuery = `UPDATE transactions SET status = 'return initiated' WHERE transid = '${transactionid}'`;
        // await db.query(updateOldTransactionQuery);

        const updatedQuantity = Math.max(variant.quantity - quantity, 0);
        const updateVariantQuery = `UPDATE variant SET quantity = '${updatedQuantity}' WHERE id = '${variantid}'`;
        await db.query(updateVariantQuery);

        await db.query('COMMIT');
        res.status(200).send({ 
            status: true, 
            message: 'Transaction processed successfully' 
        });
    } catch (error) {
        console.error('Error:', error);
        await db.query('ROLLBACK');
        res.status(500).send({ 
            status: false, 
            message: 'Internal Server Error', 
            error: error.message 
        });
    }
};
// Get Exchange Transaction
export const getExchangeTransaction = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
    await db.query('START TRANSACTION');

    const TransID = req.params.transactionid;
    const variantID = req.body.variantid;

    try {

        const filters = req.query

        if (variantID != undefined) {
            let thisQueryVarQuery = ` UPDATE transactions SET variant = '${variantID}' WHERE transid = '${TransID}' `;
            const varUpdate = await db.query(thisQueryVarQuery);
        } 

        let thisQueryCheckUserExists = `SELECT id FROM transactions WHERE transid = '${TransID}' LIMIT 1`;
        const userExists = await db.query(thisQueryCheckUserExists);

        const userExistCheck = userExists[0][0] ? userExists[0][0]?.id : 0
        console.log('userExistCheck', userExistCheck);

        if (userExistCheck == 0 || !userExistCheck) {
            return res.status(404).json({
                status: false,
                message: 'There is no transaction'
            });
        }

        let thisQuery = `
        SELECT 
        tra.*,
        tra.variant as variantid,
        DATE_FORMAT(tra.createdon, '%Y-%m-%d %H:%i:%s') as createdon,
        COALESCE(p.weight, 0) AS weight,
        p.name as name,
        p.description as description,
        gst.name as gst_name,
        CAST(COALESCE(v.price, 0) AS SIGNED) AS price,
         (JSON_ARRAYAGG(
                JSON_OBJECT(
                    'trans_id', tb.trans_id,
                    'tax_amount', tb.tax_amount,
                    'gst_id', tb.gst_id,
                    'price', tb.price,
                    'shipping_charges', tb.shipping_charges,
                    'total_amount', tb.total_amount,
                    'quantity', tra.quantity,
                    'name', gst.name,
                    'cgst', gst.cgst,
                    'igst', gst.igst,
                    'sgst', gst.sgst,
                    'igst', gst.igst
                )
            )
        ) AS billing_details,
        (
            SELECT JSON_ARRAYAGG(
                JSON_OBJECT(
                    'image', pi.image,
                    'imageseq', pi.imageseq,
                    'productid', pi.productid
                )
            )
            FROM productimage as pi
            WHERE pi.productid IN (p.productid) AND pi.imageseq = 1
            GROUP BY pi.productid
        ) AS images


        FROM transactions as tra
        LEFT JOIN transaction_billing as tb ON (tra.transid = tb.trans_id)
        LEFT JOIN product AS p ON (p.productid = tra.productid)
        LEFT JOIN variant AS v ON (v.id = tra.variant)
        LEFT JOIN gst as gst ON (gst.id = tb.gst_id)
        WHERE tra.transid = '${TransID}'
        `

        thisQuery += ` 
        GROUP BY tra.id
        ORDER BY MAX(tra.lastmodifiedat) DESC
        `
        const exchangeData = await db.query(thisQuery);
        console.log('exchangeData', exchangeData[0]);

        res.status(200).send({
            status: true,
            message: 'Exchange details listed successfully',
            data: exchangeData[0]
        });

    } catch (error) {
        console.log('error', error);
        res.status(500).json({
            status: false,
            message: 'Internal Server Error',
            error: error.message,
        });

        await db.query('ROLLBACK');
    }

}


// 25-11-2024
export const insertTransaction25 = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
    await db.query('START TRANSACTION');

    try {
        const { userid, addressid, gst_id, tax_amount, quantity,shipping_charges, total_amount, status } = req.body;

        const productid = req.body.productid
        console.log('productid', productid);

        // const productidArray = JSON.parse(productid).length == 0 ? 0 : JSON.parse(productid);
        const productidArray = productid.length == 0 ? 0 : productid;
        console.log('productidArray', productidArray);
        
        let userCheckQuery = `SELECT userid FROM users WHERE userid = '${userid}' LIMIT 1`;
        const userCheckData = await db.query(userCheckQuery);
        const userExists = userCheckData[0][0] ? userCheckData[0][0]?.userid : 0

        console.log('userExists', userExists);
    
        if (userExists == 0 || !userExists) {
            console.log('User-ID not found');
            return res.status(404).send({
                status: false,
                message: 'User-ID not found',
            });
        }
    
        let productCheckQuery = `SELECT productid FROM product WHERE productid IN (${productidArray}) LIMIT 1`;
        const productCheckData = await db.query(productCheckQuery);
        const productExists = productCheckData[0][0] ? productCheckData[0][0]?.productid : 0

        console.log('productExists', productExists);

        if (productExists == 0 || !productExists) {
            console.log('Product-ID not found');
            return res.status(404).send({
                status: false,
                message: 'Product-ID not found',
            });
        }
        // AND status != 'Ordered'

        let getATC = ` SELECT * FROM addtocarttable WHERE userid = '${userid}' AND productid IN (${productidArray}) `
        const ATC_ID = await db.query(getATC);
        console.log('ATC_ID data', ATC_ID[0]);      
        
        const ATCEmpty = ATC_ID[0][0] ? ATC_ID[0][0]?.atcartid : 0
        
        if (ATCEmpty == 0 || !ATCEmpty) {
            console.log('Add To Cart Empty');
            return res.status(404).send({
                status: false,
                message: 'Add To Cart Empty',
            });
        }
        
        const variant_array = ATC_ID[0]?.map(i => i.variantid);
        const variantData =  variant_array.length != 0 ? variant_array?.join(',') : 0
        console.log('variant_array', variantData);
        console.log('variant_array_length', variant_array.length);

        let variantQuery = ` SELECT * FROM variant WHERE id IN (${variantData}) `
        const variantID = await db.query(variantQuery);
        console.log('variantID data', variantID[0]);  

        let transactionBillingQuery = `
        INSERT INTO transaction_billing (ccavenue_transid, status, createdon, lastmodifiedate) VALUES (${null},'${status}','${formattedDateTime}','${formattedDateTime}') `;
        const transactionResultBilling = await db.query(transactionBillingQuery);
        const billAutoId = transactionResultBilling[0];
        console.log('transactionResultBilling', transactionResultBilling);

        // let totalPriceGst = 0; 
        // let totalWeight = 0;

        let TBillingPrice = 0;
        let TBillingWeight = 0;

        let index = 0; 

        for (const productId of productidArray) {

            const productVariant = ATC_ID[0].find(item => item.productid === productId);
            let ATCvariantQuantity = productVariant ? productVariant.quantity : 0;
            const productVariantID = productVariant ? productVariant.variantid : 0;

            const variantList = variantID[0].find(item => item.productid === productId);
            console.log('variantList', variantList);  

            const productVariantPrice = variantList ? variantList.price : 0;
            const productVariantWeight = variantList ? variantList.weight : 0;
            let productVariantQuantity = variantList ? variantList.quantity : 0;

            const gstArray = 1;

            console.log('ATCvariantQuantity', ATCvariantQuantity);  
            console.log('productVariantQuantity', productVariantQuantity);  

            const today = new Date().toISOString().slice(0, 10);
            console.log('today', today);
    
            // let counterQuery = `
            // INSERT INTO daily_reset_counter (counter_date, counter_value) VALUES ('${today}', 1) ON DUPLICATE KEY UPDATE counter_value = counter_value + 1 `;
            // const counterInsert = await db.query(counterQuery);
        
            // let counterSelectQuery = `SELECT counter_value FROM daily_reset_counter WHERE counter_date = '${today}' `;
            // const counterData = await db.query(counterSelectQuery);
            // let counterValue = counterData[0][0] ? counterData[0][0]?.counter_value : 0
    
            // console.log('counterValue', counterValue);

            // const orderNumber = `2CQR-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
            // const transId = `Trans-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;

            // let transactionInsertQuery = `
            // INSERT INTO transactions (productid, userid, childbillid, status) VALUES ('${productId}', '${userid}', '${transactionResultBilling[0]}','${status || 'Initiated '}')`;
            // const transactionResult = await db.query(transactionInsertQuery);

            if (productVariantQuantity > 0) {
                let counterQuery = `
                INSERT INTO daily_reset_counter (counter_date, counter_value) VALUES ('${today}', 1) ON DUPLICATE KEY UPDATE counter_value = counter_value + 1 `;
                const counterInsert = await db.query(counterQuery);
            
                let counterSelectQuery = `SELECT counter_value FROM daily_reset_counter WHERE counter_date = '${today}' `;
                const counterData = await db.query(counterSelectQuery);
                let counterValue = counterData[0][0] ? counterData[0][0]?.counter_value : 0
        
                const orderNumber = `2CQR-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
                const transId = `Trans-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
                let inStockQuantity = Math.min(productVariantQuantity, ATCvariantQuantity);

                let TVariantPrice = productVariantPrice * inStockQuantity
                let TVariantWeight = productVariantWeight * inStockQuantity
    
                console.log('TVariantPrice', TVariantPrice);  
                console.log('TVariantWeight', TVariantWeight);  

                TBillingPrice += TVariantPrice;
                TBillingWeight += TVariantWeight;        

                let inStockQuery = `
                    INSERT INTO transactions (productid, userid, addressid, transid, ordernumber, variant, tpricegst, tweight, childbillid, gst_id, quantity, status) 
                    VALUES ('${productId}', '${userid}', '${addressid}', '${transId}', '${orderNumber}', '${productVariantID}', '${TVariantPrice}', '${TVariantWeight}', '${transactionResultBilling[0]}','${gstArray}','${inStockQuantity}', 'instock')
                `;
                await db.query(inStockQuery);
                console.log('jgfhghfgghfh', ATCvariantQuantity,inStockQuantity );
                ATCvariantQuantity -= inStockQuantity;
            }
            
            if (ATCvariantQuantity > 0) {
                let counterQuery = `
                INSERT INTO daily_reset_counter (counter_date, counter_value) VALUES ('${today}', 1) ON DUPLICATE KEY UPDATE counter_value = counter_value + 1 `;
                const counterInsert = await db.query(counterQuery);
            
                let counterSelectQuery = `SELECT counter_value FROM daily_reset_counter WHERE counter_date = '${today}' `;
                const counterData = await db.query(counterSelectQuery);
                let counterValue = counterData[0][0] ? counterData[0][0]?.counter_value : 0
        
                const orderNumber = `2CQR-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
                const transId = `Trans-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;

                let TVariantPrice = productVariantPrice * ATCvariantQuantity
                let TVariantWeight = productVariantWeight * ATCvariantQuantity
    
                console.log('TVariantPrice', TVariantPrice);  
                console.log('TVariantWeight', TVariantWeight);  

                TBillingPrice += TVariantPrice;
                TBillingWeight += TVariantWeight;        

                let outOfStockQuery = `
                    INSERT INTO transactions (productid, userid, addressid, transid, ordernumber, variant, tpricegst, tweight, childbillid, gst_id, quantity, status) 
                    VALUES ('${productId}', '${userid}', '${addressid}', '${transId}', '${orderNumber}','${productVariantID}', '${TVariantPrice}', '${TVariantWeight}', '${transactionResultBilling[0]}', '${gstArray}', '${ATCvariantQuantity}', 'outofstock')
                `;
                await db.query(outOfStockQuery);
            }

            console.log('product Variant Price & Weight ', productVariantPrice, productVariantWeight );

            // totalPriceGst += productVariantPrice;
            // totalWeight += productVariantWeight;

            // let transactionLogQuery = `
            // INSERT INTO transactionlog (transtableid, status, createdby) VALUES ('${transactionResult[0]}', '${status}', '${userid}')`;
            // const transactionResultLog = await db.query(transactionLogQuery);
            
            // console.log('transactionResultLog', transactionResultLog);

            index++;
        }
        
            console.log('Order initiated successfully'); 

            const shippingChargeQuery = `
            SELECT charge FROM weightmasters WHERE weight < ${TBillingWeight} ORDER BY weight DESC LIMIT 1`;
            const shippingChargeResult = await db.query(shippingChargeQuery);
            const shippingCharge = shippingChargeResult[0][0] ? shippingChargeResult[0][0]?.charge : 0;
   
           // Calculate actual price
           const actualPrice = TBillingPrice + shippingCharge;

           console.log('TBillingPrice', TBillingPrice, TBillingWeight);

           const updateBillingQuery = `
            UPDATE transaction_billing 
            SET tpricegst = '${TBillingPrice}', tweight = '${TBillingWeight}', shipping_charges = '${shippingCharge}', actual_price = '${actualPrice}', transaction_price = '${actualPrice}', payment_type = 'ccavenue' 
            WHERE id = '${billAutoId}'`;
            const updateBillData = await db.query(updateBillingQuery);
         
            await db.query('COMMIT');

    } catch (error) {
        console.log('error', error);
        res.status(500).json({
            status: false,
            message: 'Internal Server Error',
            error: error.message,
        });

        await db.query('ROLLBACK');
    }
};
export const updateTransaction25 = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
    await db.query('START TRANSACTION');

    try {
        const { billautoid , status, userid} = req.body;

        const productid = req.body.productid
        console.log('productid', productid);

        // const productidArray = JSON.parse(productid).length == 0 ? 0 : JSON.parse(productid);
        const productidArray = productid.length == 0 ? 0 : productid;
        console.log('productidArray', productidArray);

        let getATC = ` SELECT * FROM addtocarttable WHERE userid = '${userid}' AND status != 'Ordered' AND productid IN (${productidArray}) `
        const ATC_ID = await db.query(getATC);
        console.log('ATC_ID data', ATC_ID[0]);      
        
        const variant_array = ATC_ID[0]?.map(i => i.variantid);
        const variantData =  variant_array.length != 0 ? variant_array?.join(',') : 0
        console.log('variant_array', variantData);
        console.log('variant_array_length', variant_array.length);

        let variantQuery = ` SELECT * FROM variant WHERE id IN (${variantData}) `
        const variantID = await db.query(variantQuery);
        console.log('variantID data', variantID[0]);  

        let transactionBillingQuery = ` UPDATE transaction_billing SET status = '${status}' WHERE id = '${billautoid}' `;
        const transactionResultBilling = await db.query(transactionBillingQuery);

        let transactionInsertQuery = ` UPDATE transactions SET status = 'Ordered' WHERE childbillid = '${billautoid}' AND status = 'instock' ` ;
        const transactionResult = await db.query(transactionInsertQuery);

        let transactionInsertQuery1 = ` UPDATE transactions SET status = 'outofstock_o' WHERE childbillid = '${billautoid}' AND status = 'outofstock' ` ;
        const transactionResult1 = await db.query(transactionInsertQuery1);
        
        // let uAddToCart = `UPDATE addtocarttable SET status = 'Ordered' WHERE userid = '${userid}' AND productid IN (${productidArray}) `
        // const addToCartUpdate = await db.query(uAddToCart);

        ATC_ID[0]?.forEach(atcItem => {
            let variant = variantID[0].find(variant => variant.id === atcItem.variantid);
            
            if (variant) {
                variant.quantity -= atcItem.quantity;                
                variant.quantity = Math.max(0, variant.quantity);
            }
        });
        
        console.log('finalArray[0]',variantID[0]);

        for (const atcArray of variantID[0]) {
            console.log('atcArray', atcArray);
            
            let variantQuery = `UPDATE variant SET quantity = '${atcArray.quantity}' WHERE id = '${atcArray.id}' `
            const variantUpdate = await db.query(variantQuery);
        }

        let thisQueryOrd = `
        SELECT 
        tra.id,
        tra.transid,
        tra.productid,
        tra.userid,
        us.username,
        tra.ordernumber,
        tra.status,
        tra.createdon, 
        tra.quantity, 
        tra.productid as trans_product_id,
        (JSON_ARRAYAGG(
                JSON_OBJECT(
                    'productid', p.productid,
                    'name', p.name,
                    'description', p.description,
                    'price', v.price,
                    'quantity', tra.quantity
                )
            )
        ) AS product_details,
        (JSON_ARRAYAGG(
                JSON_OBJECT(
                    'ccavenue_transid', tb.ccavenue_transid,
                    'status', tb.status,
                    'tpricegst', tb.tpricegst,
                    'tweight', tb.tweight,
                    'shipping_charges', tb.shipping_charges,
                    'type', tb.type,
                    'actual_price', tb.actual_price,
                    'transaction_price', tb.transaction_price,
                    'payment_type', tb.payment_type
                )
            )
        ) AS billing_details,
        (JSON_ARRAYAGG(
                JSON_OBJECT(
                    'image', pi.image,
                    'imageseq', pi.imageseq,
                    'productid', pi.productid
                )
            )
        ) AS image_details,
        (
            SELECT 
                JSON_OBJECT(
                    'addressid', COALESCE(ad.addressid,''),
                    'address_name', COALESCE(ad.name,''),
                    'fullAddress', COALESCE(ad.fullAddress,''),
                    'locationDetails', COALESCE(ad.locationDetails,''),
                    'landmark', COALESCE(ad.landmark,''),
                    'city', COALESCE(ad.city,''),
                    'state', COALESCE(ad.state,''),
                    'country', COALESCE(ad.country,''),
                    'pincode', COALESCE(ad.pincode,''),
                    'email', COALESCE(ad.email,''),
                    'mobileno', COALESCE(ad.mobileno,''),
                    'alternatemobileno', COALESCE(ad.alternatemobileno,'')
                )
            FROM address as ad
            WHERE ad.addressid IN (tra.addressid)
            GROUP BY ad.addressid
        ) AS address_details
        
        FROM transactions as tra
        LEFT JOIN transaction_billing as tb ON (tb.id = tra.childbillid)
        LEFT JOIN users as us ON (us.userid = tra.userid)
        LEFT JOIN product as p ON (tra.productid = p.productid)
        LEFT JOIN variant as v ON (v.id = tra.variant)
        LEFT JOIN productimage pi ON (pi.productid = p.productid AND pi.imageseq = 1)
        LEFT JOIN address ad ON (ad.addressid = tra.addressid)
        LEFT JOIN gst as gst ON (gst.id = tra.gst_id)
        WHERE tra.status IN ('ordered', 'shipped', 'outfordelivery', 'delivered', 'deliverfail')
        AND tra.userid = '${userid}' AND tra.childbillid IN (${billautoid})
        GROUP BY tra.id, tra.transid, tra.ordernumber, tra.status, tra.createdon, p.name, p.description, p.price, pi.image
        ORDER BY MAX(tra.lastmodifiedat) DESC
        `
        const ordersData = await db.query(thisQueryOrd);

        let orderListQuery = ` SELECT 
        tra.*,
        p.name as product_name,
        us.username as username,
        v.price as variant_price,
        us.email as email
        FROM transactions as tra
        LEFT JOIN transaction_billing as tb ON (tb.id = tra.childbillid)
        LEFT JOIN gst as gst ON (gst.id = tra.gst_id)
        LEFT JOIN product as p on (p.productid = tra.productid)
        LEFT JOIN users as us on (us.userid = tra.userid)
        LEFT JOIN variant as v on (v.id = tra.variant)
        WHERE tra.childbillid IN (${billautoid})`
        const orderList = await db.query(orderListQuery);

        console.log('orderList', orderList[0]);

        // emailTrigger(orderList)

        res.status(200).send({
            status: true,
            message: 'Order placed successfully',
            insert_count:ordersData[0]?.length,
            insert_output: ordersData[0]
        });
    
        await db.query('COMMIT');

    } catch (error) {
        console.log('error', error);
        res.status(500).json({
            status: false,
            message: 'Internal Server Error',
            error: error.message,
        });

        await db.query('ROLLBACK');
    }
};


// 26-11-2024
// Insert Transaction --- TESTING
// ===========================================
export const insertTransaction26 = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
    await db.query('START TRANSACTION');

    try {
        const { userid, addressid, gst_id, tax_amount, quantity,shipping_charges, total_amount, status } = req.body;

        const productid = req.body.productid
        console.log('productid', productid);

        // const productidArray = JSON.parse(productid).length == 0 ? 0 : JSON.parse(productid);
        const productidArray = productid.length == 0 ? 0 : productid;
        console.log('productidArray', productidArray);
        
        let userCheckQuery = `SELECT userid FROM users WHERE userid = '${userid}' LIMIT 1`;
        const userCheckData = await db.query(userCheckQuery);
        const userExists = userCheckData[0][0] ? userCheckData[0][0]?.userid : 0

        console.log('userExists', userExists);
    
        if (userExists == 0 || !userExists) {
            console.log('User-ID not found');
            return res.status(404).send({
                status: false,
                message: 'User-ID not found',
            });
        }
    
        let productCheckQuery = `SELECT productid FROM product WHERE productid IN (${productidArray}) LIMIT 1`;
        const productCheckData = await db.query(productCheckQuery);
        const productExists = productCheckData[0][0] ? productCheckData[0][0]?.productid : 0

        console.log('productExists', productExists);

        if (productExists == 0 || !productExists) {
            console.log('Product-ID not found');
            return res.status(404).send({
                status: false,
                message: 'Product-ID not found',
            });
        }
        // AND status != 'Ordered'

        let getATC = ` SELECT * FROM addtocarttable WHERE userid = '${userid}' AND productid IN (${productidArray}) `
        const ATC_ID = await db.query(getATC);
        console.log('ATC_ID data', ATC_ID[0]);      
        
        const ATCEmpty = ATC_ID[0][0] ? ATC_ID[0][0]?.atcartid : 0
        
        if (ATCEmpty == 0 || !ATCEmpty) {
            console.log('Add To Cart Empty');
            return res.status(404).send({
                status: false,
                message: 'Add To Cart Empty',
            });
        }
        
        const variant_array = ATC_ID[0]?.map(i => i.variantid);
        const variantData =  variant_array.length != 0 ? variant_array?.join(',') : 0
        console.log('variant_array', variantData);
        console.log('variant_array_length', variant_array.length);

        let variantQuery = ` SELECT * FROM variant WHERE id IN (${variantData}) `
        const variantID = await db.query(variantQuery);
        console.log('variantID data', variantID[0]);  

        let transactionBillingQuery = `
        INSERT INTO transaction_billing (ccavenue_transid, status, createdon, lastmodifiedate) VALUES (${null},'${status}','${formattedDateTime}','${formattedDateTime}') `;
        const transactionResultBilling = await db.query(transactionBillingQuery);
        const billAutoId = transactionResultBilling[0];
        console.log('transactionResultBilling', transactionResultBilling);

        // let totalPriceGst = 0; 
        // let totalWeight = 0;

        let TBillingPrice = 0;
        let TBillingWeight = 0;

        let index = 0; 

        for (const productId of productidArray) {

            const productVariant = ATC_ID[0].find(item => item.productid === productId);
            let ATCvariantQuantity = productVariant ? productVariant.quantity : 0;
            const productVariantID = productVariant ? productVariant.variantid : 0;

            const variantList = variantID[0].find(item => item.productid === productId);
            console.log('variantList', variantList);  

            const productVariantPrice = variantList ? variantList.price : 0;
            const productVariantWeight = variantList ? variantList.weight : 0;
            let productVariantQuantity = variantList ? variantList.quantity : 0;

            const gstArray = 1;

            console.log('ATCvariantQuantity', ATCvariantQuantity);  
            console.log('productVariantQuantity', productVariantQuantity);  

            const today = new Date().toISOString().slice(0, 10);
            console.log('today', today);
    
            // let counterQuery = `
            // INSERT INTO daily_reset_counter (counter_date, counter_value) VALUES ('${today}', 1) ON DUPLICATE KEY UPDATE counter_value = counter_value + 1 `;
            // const counterInsert = await db.query(counterQuery);
        
            // let counterSelectQuery = `SELECT counter_value FROM daily_reset_counter WHERE counter_date = '${today}' `;
            // const counterData = await db.query(counterSelectQuery);
            // let counterValue = counterData[0][0] ? counterData[0][0]?.counter_value : 0
    
            // console.log('counterValue', counterValue);

            // const orderNumber = `2CQR-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
            // const transId = `Trans-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;

            // let transactionInsertQuery = `
            // INSERT INTO transactions (productid, userid, childbillid, status) VALUES ('${productId}', '${userid}', '${transactionResultBilling[0]}','${status || 'Initiated '}')`;
            // const transactionResult = await db.query(transactionInsertQuery);

            if (productVariantQuantity > 0) {
                let counterQuery = `
                INSERT INTO daily_reset_counter (counter_date, counter_value) VALUES ('${today}', 1) ON DUPLICATE KEY UPDATE counter_value = counter_value + 1 `;
                const counterInsert = await db.query(counterQuery);
            
                let counterSelectQuery = `SELECT counter_value FROM daily_reset_counter WHERE counter_date = '${today}' `;
                const counterData = await db.query(counterSelectQuery);
                let counterValue = counterData[0][0] ? counterData[0][0]?.counter_value : 0
        
                const orderNumber = `2CQR-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
                const transId = `Trans-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
                let inStockQuantity = Math.min(productVariantQuantity, ATCvariantQuantity);

                let TVariantPrice = productVariantPrice * inStockQuantity
                let TVariantWeight = productVariantWeight * inStockQuantity
    
                console.log('TVariantPrice', TVariantPrice);  
                console.log('TVariantWeight', TVariantWeight);  

                TBillingPrice += TVariantPrice;
                TBillingWeight += TVariantWeight;        

                let inStockQuery = `
                    INSERT INTO transactions (productid, userid, addressid, transid, ordernumber, variant, tpricegst, tweight, childbillid, gst_id, quantity, status) 
                    VALUES ('${productId}', '${userid}', '${addressid}', '${transId}', '${orderNumber}', '${productVariantID}', '${TVariantPrice}', '${TVariantWeight}', '${transactionResultBilling[0]}','${gstArray}','${inStockQuantity}', 'instock')
                `;
                await db.query(inStockQuery);
                console.log('jgfhghfgghfh', ATCvariantQuantity,inStockQuantity );
                ATCvariantQuantity -= inStockQuantity;
            }
            
            if (ATCvariantQuantity > 0) {
                let counterQuery = `
                INSERT INTO daily_reset_counter (counter_date, counter_value) VALUES ('${today}', 1) ON DUPLICATE KEY UPDATE counter_value = counter_value + 1 `;
                const counterInsert = await db.query(counterQuery);
            
                let counterSelectQuery = `SELECT counter_value FROM daily_reset_counter WHERE counter_date = '${today}' `;
                const counterData = await db.query(counterSelectQuery);
                let counterValue = counterData[0][0] ? counterData[0][0]?.counter_value : 0
        
                const orderNumber = `2CQR-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
                const transId = `Trans-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;

                let TVariantPrice = productVariantPrice * ATCvariantQuantity
                let TVariantWeight = productVariantWeight * ATCvariantQuantity
    
                console.log('TVariantPrice', TVariantPrice);  
                console.log('TVariantWeight', TVariantWeight);  

                TBillingPrice += TVariantPrice;
                TBillingWeight += TVariantWeight;        

                let outOfStockQuery = `
                    INSERT INTO transactions (productid, userid, addressid, transid, ordernumber, variant, tpricegst, tweight, childbillid, gst_id, quantity, status) 
                    VALUES ('${productId}', '${userid}', '${addressid}', '${transId}', '${orderNumber}','${productVariantID}', '${TVariantPrice}', '${TVariantWeight}', '${transactionResultBilling[0]}', '${gstArray}', '${ATCvariantQuantity}', 'outofstock')
                `;
                await db.query(outOfStockQuery);
            }

            console.log('product Variant Price & Weight ', productVariantPrice, productVariantWeight );

            // totalPriceGst += productVariantPrice;
            // totalWeight += productVariantWeight;

            // let transactionLogQuery = `
            // INSERT INTO transactionlog (transtableid, status, createdby) VALUES ('${transactionResult[0]}', '${status}', '${userid}')`;
            // const transactionResultLog = await db.query(transactionLogQuery);
            
            // console.log('transactionResultLog', transactionResultLog);

            index++;
        }
        
            console.log('Order initiated successfully'); 

            const shippingChargeQuery = `
            SELECT charge FROM weightmasters WHERE weight < ${TBillingWeight} ORDER BY weight DESC LIMIT 1`;
            const shippingChargeResult = await db.query(shippingChargeQuery);
            const shippingCharge = shippingChargeResult[0][0] ? shippingChargeResult[0][0]?.charge : 0;
   
           // Calculate actual price
           const actualPrice = TBillingPrice + shippingCharge;

           console.log('TBillingPrice', TBillingPrice, TBillingWeight);

           const updateBillingQuery = `
            UPDATE transaction_billing 
            SET tpricegst = '${TBillingPrice}', tweight = '${TBillingWeight}', shipping_charges = '${shippingCharge}', actual_price = '${actualPrice}', transaction_price = '${actualPrice}', payment_type = 'ccavenue' 
            WHERE id = '${billAutoId}'`;
            const updateBillData = await db.query(updateBillingQuery);

            const workingKey = '0BF202BFD501907C9D76C5443211629C';
            const accessCode = 'ATAD06LK05BU10DAUB';
            const merchantId = '204980';
            const currency = 'INR';
            const amount = actualPrice;
            const language = 'EN';

            const formData = {
                merchant_id: merchantId,
                order_id: billAutoId,
                currency: currency,
                amount: amount,
                redirect_url: "http://localhost:5001/ccvPayment",
                cancel_url: "http://localhost:5001/ccvPayment",
                language: language
            };
  
            const params = new URLSearchParams(formData);
            const bodyData  = params.toString();  
            const encRequest = encrypt(bodyData, workingKey);

            const paymentLink = `https://test.ccavenue.com/transaction/transaction.do?command=initiateTransaction&encRequest=${encRequest}&access_code=${accessCode}`;

            res.status(200).send({
                status: true,
                message: 'Order initiated successfully',
                billAutoId: billAutoId,
                paymentLink: paymentLink
            });

            const updateProbs = {productidArray, userid, billAutoId, status}

            updateTransaction(updateProbs)
        
            await db.query('COMMIT');

    } catch (error) {
        console.log('error', error);
        res.status(500).json({
            status: false,
            message: 'Internal Server Error',
            error: error.message,
        });

        await db.query('ROLLBACK');
    }
};
async function updateTransaction26 (updateProbs) {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
    await db.query('START TRANSACTION');

    try {
        const { billAutoId, userid} = updateProbs;
        const status = 'Ordered'
        const productid = updateProbs.productidArray

        console.log('updateProbs', updateProbs);
        console.log('productid', productid);

        // const productidArray = JSON.parse(productid).length == 0 ? 0 : JSON.parse(productid);
        const productidArray = productid.length == 0 ? 0 : productid;
        console.log('productidArray', productidArray);

        let getATC = ` SELECT * FROM addtocarttable WHERE userid = '${userid}' AND status != 'Ordered' AND productid IN (${productidArray}) `
        const ATC_ID = await db.query(getATC);
        console.log('ATC_ID data', ATC_ID[0]);      
        
        const variant_array = ATC_ID[0]?.map(i => i.variantid);
        const variantData =  variant_array.length != 0 ? variant_array?.join(',') : 0
        console.log('variant_array', variantData);
        console.log('variant_array_length', variant_array.length);

        let variantQuery = ` SELECT * FROM variant WHERE id IN (${variantData}) `
        const variantID = await db.query(variantQuery);
        console.log('variantID data', variantID[0]);  

        let transactionBillingQuery = ` UPDATE transaction_billing SET status = '${status}' WHERE id = '${billAutoId}' `;
        const transactionResultBilling = await db.query(transactionBillingQuery);

        let transactionInsertQuery = ` UPDATE transactions SET status = 'Ordered' WHERE childbillid = '${billAutoId}' AND status = 'instock' ` ;
        const transactionResult = await db.query(transactionInsertQuery);

        let transactionInsertQuery1 = ` UPDATE transactions SET status = 'outofstock_o' WHERE childbillid = '${billAutoId}' AND status = 'outofstock' ` ;
        const transactionResult1 = await db.query(transactionInsertQuery1);
        
        // let uAddToCart = `UPDATE addtocarttable SET status = 'Ordered' WHERE userid = '${userid}' AND productid IN (${productidArray}) `
        // const addToCartUpdate = await db.query(uAddToCart);

        ATC_ID[0]?.forEach(atcItem => {
            let variant = variantID[0].find(variant => variant.id === atcItem.variantid);
            
            if (variant) {
                variant.quantity -= atcItem.quantity;                
                variant.quantity = Math.max(0, variant.quantity);
            }
        });
        
        console.log('finalArray[0]',variantID[0]);

        for (const atcArray of variantID[0]) {
            console.log('atcArray', atcArray);
            
            let variantQuery = `UPDATE variant SET quantity = '${atcArray.quantity}' WHERE id = '${atcArray.id}' `
            const variantUpdate = await db.query(variantQuery);
        }

        let thisQueryOrd = `
        SELECT 
        tra.id,
        tra.transid,
        tra.productid,
        tra.userid,
        us.username,
        tra.ordernumber,
        tra.status,
        tra.createdon, 
        tra.quantity, 
        tra.productid as trans_product_id,
        (JSON_ARRAY(
                JSON_OBJECT(
                    'productid', p.productid,
                    'name', p.name,
                    'description', p.description,
                    'price', v.price,
                    'quantity', tra.quantity
                )
            )
        ) AS product_details,
        (JSON_ARRAY(
                JSON_OBJECT(
                    'ccavenue_transid', tb.ccavenue_transid,
                    'status', tb.status,
                    'tpricegst', tb.tpricegst,
                    'tweight', tb.tweight,
                    'shipping_charges', tb.shipping_charges,
                    'type', tb.type,
                    'actual_price', tb.actual_price,
                    'transaction_price', tb.transaction_price,
                    'payment_type', tb.payment_type
                )
            )
        ) AS billing_details,
        (JSON_ARRAY(
                JSON_OBJECT(
                    'image', pi.image,
                    'imageseq', pi.imageseq,
                    'productid', pi.productid
                )
            )
        ) AS image_details,
        (
            SELECT 
                JSON_OBJECT(
                    'addressid', COALESCE(ad.addressid,''),
                    'address_name', COALESCE(ad.name,''),
                    'fullAddress', COALESCE(ad.fullAddress,''),
                    'locationDetails', COALESCE(ad.locationDetails,''),
                    'landmark', COALESCE(ad.landmark,''),
                    'city', COALESCE(ad.city,''),
                    'state', COALESCE(ad.state,''),
                    'country', COALESCE(ad.country,''),
                    'pincode', COALESCE(ad.pincode,''),
                    'email', COALESCE(ad.email,''),
                    'mobileno', COALESCE(ad.mobileno,''),
                    'alternatemobileno', COALESCE(ad.alternatemobileno,'')
                )
            FROM address as ad
            WHERE ad.addressid IN (tra.addressid)
            GROUP BY ad.addressid
        ) AS address_details
        
        FROM transactions as tra
        LEFT JOIN transaction_billing as tb ON (tb.id = tra.childbillid)
        LEFT JOIN users as us ON (us.userid = tra.userid)
        LEFT JOIN product as p ON (tra.productid = p.productid)
        LEFT JOIN variant as v ON (v.id = tra.variant)
        LEFT JOIN productimage pi ON (pi.productid = p.productid AND pi.imageseq = 1)
        LEFT JOIN address ad ON (ad.addressid = tra.addressid)
        LEFT JOIN gst as gst ON (gst.id = tra.gst_id)
        WHERE tra.status IN ('ordered', 'shipped', 'outfordelivery', 'delivered', 'deliverfail')
        AND tra.userid = '${userid}' AND tra.childbillid IN (${billAutoId})
        GROUP BY tra.id, tra.transid, tra.ordernumber, tra.status, tra.createdon, p.name, p.description, p.price, pi.image
        ORDER BY MAX(tra.lastmodifiedat) DESC
        `
        const ordersData = await db.query(thisQueryOrd);

        let orderListQuery = ` SELECT 
        tra.*,
        p.name as product_name,
        us.username as username,
        v.price as variant_price,
        us.email as email
        FROM transactions as tra
        LEFT JOIN transaction_billing as tb ON (tb.id = tra.childbillid)
        LEFT JOIN gst as gst ON (gst.id = tra.gst_id)
        LEFT JOIN product as p on (p.productid = tra.productid)
        LEFT JOIN users as us on (us.userid = tra.userid)
        LEFT JOIN variant as v on (v.id = tra.variant)
        WHERE tra.childbillid IN (${billAutoId})`
        const orderList = await db.query(orderListQuery);

        console.log('orderList', orderList[0]);

        // emailTrigger(orderList)

        // res.status(200).send({
        //     status: true,
        //     message: 'Order placed successfully',
        //     insert_count:ordersData[0]?.length,
        //     insert_output: ordersData[0]
        // });
    
        await db.query('COMMIT');

    } catch (error) {
        console.log('error', error);

        await db.query('ROLLBACK');
    }
};

// 27-11-2024
const calculateGstBreakdown = () => {
    const breakdown = {};
    const selectedAddress =
      JSON.parse(localStorage.getItem("selectedAddress")) || [];
    const isKarnataka =
      selectedAddress[0]?.state?.toLowerCase() === "karnataka";

    orderSummary.forEach((item) => {
      let gstName = item.gst_name;
      if (gstName === "Zee School Tax") {
        gstName = "GST 12%"; // Set to "GST 12%" if it's "Zee School Tax"
      }

      const gstMatch = gstName?.match(/\d+/);
      const gstRate = gstMatch ? parseFloat(gstMatch[0]) : 0;

      const itemTotal =
        item.price && item.quantity ? item.price * item.quantity : 0;

    //   const gstKey =
        // gstRate === 0
        //   ? "No GST"
        //   : isKarnataka
        //   ? SGST ${gstRate / 2}% + CGST ${gstRate / 2}%
        //   : IGST ${gstRate}%;

      if (!breakdown[gstKey]) {
        breakdown[gstKey] = { total: 0, gstAmount: 0, gstRate };
      }

      breakdown[gstKey].total += itemTotal;
      const gstAmount = (itemTotal * gstRate) / 100;
      breakdown[gstKey].gstAmount += gstAmount;
    });

    setGstBreakdown(breakdown);
    localStorage.setItem("gstBreakdown", JSON.stringify(breakdown));
  };


//   27-11-2024
export const insertTransaction27 = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
    await db.query('START TRANSACTION');

    try {
        const { userid, addressid, gst_id, tax_amount, quantity,shipping_charges, total_amount, status } = req.body;

        const productid = req.body.productid
        console.log('productid', productid);

        // const productidArray = JSON.parse(productid).length == 0 ? 0 : JSON.parse(productid);
        const productidArray = productid.length == 0 ? 0 : productid;
        console.log('productidArray', productidArray);
        
        let userCheckQuery = `SELECT userid FROM users WHERE userid = '${userid}' LIMIT 1`;
        const userCheckData = await db.query(userCheckQuery);
        const userExists = userCheckData[0][0] ? userCheckData[0][0]?.userid : 0

        console.log('userExists', userExists);
    
        if (userExists == 0 || !userExists) {
            console.log('User-ID not found');
            return res.status(404).send({
                status: false,
                message: 'User-ID not found',
            });
        }
    
        let productCheckQuery = `SELECT productid FROM product WHERE productid IN (${productidArray}) LIMIT 1`;
        const productCheckData = await db.query(productCheckQuery);
        const productExists = productCheckData[0][0] ? productCheckData[0][0]?.productid : 0

        console.log('productExists', productExists);

        if (productExists == 0 || !productExists) {
            console.log('Product-ID not found');
            return res.status(404).send({
                status: false,
                message: 'Product-ID not found',
            });
        }
        // AND status != 'Ordered'

        let getATC = ` SELECT * FROM addtocarttable WHERE userid = '${userid}' AND productid IN (${productidArray}) `
        const ATC_ID = await db.query(getATC);
        console.log('ATC_ID data', ATC_ID[0]);      
        
        const ATCEmpty = ATC_ID[0][0] ? ATC_ID[0][0]?.atcartid : 0
        
        if (ATCEmpty == 0 || !ATCEmpty) {
            console.log('Add To Cart Empty');
            return res.status(404).send({
                status: false,
                message: 'Add To Cart Empty',
            });
        }
        
        const variant_array = ATC_ID[0]?.map(i => i.variantid);
        const variantData =  variant_array.length != 0 ? variant_array?.join(',') : 0
        console.log('variant_array', variantData);
        console.log('variant_array_length', variant_array.length);

        let variantQuery = ` SELECT * FROM variant WHERE id IN (${variantData}) `
        const variantID = await db.query(variantQuery);
        console.log('variantID data', variantID[0]);  

        let transactionBillingQuery = `
        INSERT INTO transaction_billing (ccavenue_transid, status, createdon, lastmodifiedate) VALUES (${null},'${status}','${formattedDateTime}','${formattedDateTime}') `;
        const transactionResultBilling = await db.query(transactionBillingQuery);
        const billAutoId = transactionResultBilling[0];
        console.log('transactionResultBilling', transactionResultBilling);

        // let totalPriceGst = 0; 
        // let totalWeight = 0;

        let TBillingPrice = 0;
        let TBillingWeight = 0;
        let TotalGstPercent = 0;

        let index = 0; 

        for (const productId of productidArray) {

            const productVariant = ATC_ID[0].find(item => item.productid === productId);
            let ATCvariantQuantity = productVariant ? productVariant.quantity : 0;
            const productVariantID = productVariant ? productVariant.variantid : 0;

            const variantList = variantID[0].find(item => item.productid === productId);
            console.log('variantList', variantList);  

            const productVariantPrice = variantList ? variantList.price : 0;
            const productVariantWeight = variantList ? variantList.weight : 0;
            let productVariantQuantity = variantList ? variantList.quantity : 0;

            // const gstArray = 1;
            const gstArray = (!gst_id || gst_id.length == 0) ? undefined : gst_id[index];
            console.log('gst_array', gstArray);

            console.log('ATCvariantQuantity', ATCvariantQuantity);  
            console.log('productVariantQuantity', productVariantQuantity);  

            const today = new Date().toISOString().slice(0, 10);
            console.log('today', today);
    
            // let counterQuery = `
            // INSERT INTO daily_reset_counter (counter_date, counter_value) VALUES ('${today}', 1) ON DUPLICATE KEY UPDATE counter_value = counter_value + 1 `;
            // const counterInsert = await db.query(counterQuery);
        
            // let counterSelectQuery = `SELECT counter_value FROM daily_reset_counter WHERE counter_date = '${today}' `;
            // const counterData = await db.query(counterSelectQuery);
            // let counterValue = counterData[0][0] ? counterData[0][0]?.counter_value : 0
    
            // console.log('counterValue', counterValue);

            // const orderNumber = `2CQR-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
            // const transId = `Trans-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;

            // let transactionInsertQuery = `
            // INSERT INTO transactions (productid, userid, childbillid, status) VALUES ('${productId}', '${userid}', '${transactionResultBilling[0]}','${status || 'Initiated '}')`;
            // const transactionResult = await db.query(transactionInsertQuery);

            if (productVariantQuantity > 0) {
                let counterQuery = `
                INSERT INTO daily_reset_counter (counter_date, counter_value) VALUES ('${today}', 1) ON DUPLICATE KEY UPDATE counter_value = counter_value + 1 `;
                const counterInsert = await db.query(counterQuery);
            
                let counterSelectQuery = `SELECT counter_value FROM daily_reset_counter WHERE counter_date = '${today}' `;
                const counterData = await db.query(counterSelectQuery);
                let counterValue = counterData[0][0] ? counterData[0][0]?.counter_value : 0
        
                const orderNumber = `2CQR-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
                const transId = `Trans-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
                let inStockQuantity = Math.min(productVariantQuantity, ATCvariantQuantity);

                let TVariantPrice = productVariantPrice * inStockQuantity
                let TVariantWeight = productVariantWeight * inStockQuantity
    
                console.log('TVariantPrice', TVariantPrice);  
                console.log('TVariantWeight', TVariantWeight);  

                TBillingPrice += TVariantPrice;
                TBillingWeight += TVariantWeight;        

                let inStockQuery = `
                    INSERT INTO transactions (productid, userid, addressid, transid, ordernumber, variant, tpricegst, tweight, childbillid, gst_id, quantity, status) 
                    VALUES ('${productId}', '${userid}', '${addressid}', '${transId}', '${orderNumber}', '${productVariantID}', '${TVariantPrice}', '${TVariantWeight}', '${transactionResultBilling[0]}','${gstArray}','${inStockQuantity}', 'instock')
                `;
                const transactionResult = await db.query(inStockQuery);

                let transactionLogQuery = `
                INSERT INTO transactionlog (transtableid, status, createdby) VALUES ('${transactionResult[0]}', 'instock', '${userid}')`;
                const transactionResultLog = await db.query(transactionLogQuery);
                console.log('transactionResultLog', transactionResultLog);

                console.log('jgfhghfgghfh', ATCvariantQuantity,inStockQuantity );
                ATCvariantQuantity -= inStockQuantity;
            }
            
            if (ATCvariantQuantity > 0) {
                let counterQuery = `
                INSERT INTO daily_reset_counter (counter_date, counter_value) VALUES ('${today}', 1) ON DUPLICATE KEY UPDATE counter_value = counter_value + 1 `;
                const counterInsert = await db.query(counterQuery);
            
                let counterSelectQuery = `SELECT counter_value FROM daily_reset_counter WHERE counter_date = '${today}' `;
                const counterData = await db.query(counterSelectQuery);
                let counterValue = counterData[0][0] ? counterData[0][0]?.counter_value : 0
        
                const orderNumber = `2CQR-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
                const transId = `Trans-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;

                let TVariantPrice = productVariantPrice * ATCvariantQuantity
                let TVariantWeight = productVariantWeight * ATCvariantQuantity
    
                console.log('TVariantPrice', TVariantPrice);  
                console.log('TVariantWeight', TVariantWeight);  

                TBillingPrice += TVariantPrice;
                TBillingWeight += TVariantWeight;        

                let outOfStockQuery = `
                    INSERT INTO transactions (productid, userid, addressid, transid, ordernumber, variant, tpricegst, tweight, childbillid, gst_id, quantity, status) 
                    VALUES ('${productId}', '${userid}', '${addressid}', '${transId}', '${orderNumber}','${productVariantID}', '${TVariantPrice}', '${TVariantWeight}', '${transactionResultBilling[0]}', '${gstArray}', '${ATCvariantQuantity}', 'outofstock')
                `;
                const transactionResult = await db.query(outOfStockQuery);

                let transactionLogQuery = `
                INSERT INTO transactionlog (transtableid, status, createdby) VALUES ('${transactionResult[0]}', 'outofstock', '${userid}')`;
                const transactionResultLog = await db.query(transactionLogQuery);
                console.log('transactionResultLog', transactionResultLog);
            }

            console.log('product Variant Price & Weight ', productVariantPrice, productVariantWeight );

            const GSTChargeQuery = `
            SELECT (cgst + igst + sgst) AS total_tax FROM gst WHERE id = ${gstArray} ORDER BY id DESC `;
            const GSTChargeResult = await db.query(GSTChargeQuery);
            let GSTCharge = GSTChargeResult[0][0] ? GSTChargeResult[0][0]?.total_tax : 0;
            TotalGstPercent += GSTCharge

            // totalPriceGst += productVariantPrice;
            // totalWeight += productVariantWeight;

            // let transactionLogQuery = `
            // INSERT INTO transactionlog (transtableid, status, createdby) VALUES ('${transactionResult[0]}', '${status}', '${userid}')`;
            // const transactionResultLog = await db.query(transactionLogQuery);
            
            // console.log('transactionResultLog', transactionResultLog);

            index++;
        }
        
            console.log('Order initiated successfully'); 

            const shippingChargeQuery = `
            SELECT charge FROM weightmasters WHERE weight < ${TBillingWeight} ORDER BY weight DESC LIMIT 1`;
            const shippingChargeResult = await db.query(shippingChargeQuery);
            const shippingCharge = shippingChargeResult[0][0] ? shippingChargeResult[0][0]?.charge : 0;
   
           // Calculate actual price
           const actualPrice = TBillingPrice;
        //    const GSTPrice = (TBillingPrice / TotalGstPercent);
           const GSTPrice = (TBillingPrice * TotalGstPercent) / 100;
           const GSTRoundPrice = Math.ceil(GSTPrice);
           const shippingChargeINT = parseInt(shippingCharge, 10);
           const transactionPrice = TBillingPrice + GSTRoundPrice + shippingChargeINT;

           console.log('TBillingPrice', TBillingPrice, TBillingWeight);
           console.log('actualPrice = ' , actualPrice, 'GSTRoundPrice = ', GSTRoundPrice, 'transactionPrice = ', transactionPrice, 'TotalGstPercent = ', TotalGstPercent, 'shippingChargeINT', shippingChargeINT, shippingCharge);

           const updateBillingQuery = `
            UPDATE transaction_billing 
            SET tpricegst = '${GSTRoundPrice}', tweight = '${TBillingWeight}', shipping_charges = '${shippingChargeINT}', actual_price = '${TBillingPrice}', transaction_price = '${transactionPrice}', payment_type = 'ccavenue' 
            WHERE id = '${billAutoId}'`;
            const updateBillData = await db.query(updateBillingQuery);

            const workingKey = '0BF202BFD501907C9D76C5443211629C';
            const accessCode = 'ATAD06LK05BU10DAUB';
            const merchantId = '204980';
            const currency = 'INR';
            const amount = transactionPrice;
            const language = 'EN';

            const formData = {
                merchant_id: merchantId,
                order_id: billAutoId,
                currency: currency,
                amount: amount,
                userid: userid,
                productid: productid,
                redirect_url: "http://localhost:5001/api/v1/Order/updateTransaction",
                cancel_url: "http://localhost:5001/api/v1/Order/updateTransaction",
                language: language
            };
  
            const params = new URLSearchParams(formData);
            const bodyData  = params.toString();  
            const encRequest = encrypt(bodyData, workingKey);

            const paymentLink = `https://test.ccavenue.com/transaction/transaction.do?command=initiateTransaction&encRequest=${encRequest}&access_code=${accessCode}`;

            res.status(200).send({
                status: true,
                message: 'Order initiated successfully',
                billAutoId: billAutoId,
                paymentLink: paymentLink
            });

            // const updateProbs = {productidArray, userid, billAutoId, status}

            // updateTransaction()
        
            await db.query('COMMIT');

    } catch (error) {
        console.log('error', error);
        res.status(500).json({
            status: false,
            message: 'Internal Server Error',
            error: error.message,
        });

        await db.query('ROLLBACK');
    }
};

// Separate GST Concept
export const insertTransaction27_1 = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
    await db.query('START TRANSACTION');

    try {
        const { userid, addressid, gst_id, tax_amount, quantity,shipping_charges, total_amount, status } = req.body;

        const productid = req.body.productid
        console.log('productid', productid);

        // const productidArray = JSON.parse(productid).length == 0 ? 0 : JSON.parse(productid);
        const productidArray = productid.length == 0 ? 0 : productid;
        console.log('productidArray', productidArray);
        
        let userCheckQuery = `SELECT userid FROM users WHERE userid = '${userid}' LIMIT 1`;
        const userCheckData = await db.query(userCheckQuery);
        const userExists = userCheckData[0][0] ? userCheckData[0][0]?.userid : 0

        console.log('userExists', userExists);
    
        if (userExists == 0 || !userExists) {
            console.log('User-ID not found');
            return res.status(404).send({
                status: false,
                message: 'User-ID not found',
            });
        }
    
        let productCheckQuery = `SELECT productid FROM product WHERE productid IN (${productidArray}) LIMIT 1`;
        const productCheckData = await db.query(productCheckQuery);
        const productExists = productCheckData[0][0] ? productCheckData[0][0]?.productid : 0

        console.log('productExists', productExists);

        if (productExists == 0 || !productExists) {
            console.log('Product-ID not found');
            return res.status(404).send({
                status: false,
                message: 'Product-ID not found',
            });
        }
        // AND status != 'Ordered'

        let getATC = ` SELECT * FROM addtocarttable WHERE userid = '${userid}' AND productid IN (${productidArray}) `
        const ATC_ID = await db.query(getATC);
        console.log('ATC_ID data', ATC_ID[0]);      
        
        const ATCEmpty = ATC_ID[0][0] ? ATC_ID[0][0]?.atcartid : 0
        
        if (ATCEmpty == 0 || !ATCEmpty) {
            console.log('Add To Cart Empty');
            return res.status(404).send({
                status: false,
                message: 'Add To Cart Empty',
            });
        }
        
        const variant_array = ATC_ID[0]?.map(i => i.variantid);
        const variantData =  variant_array.length != 0 ? variant_array?.join(',') : 0
        console.log('variant_array', variantData);
        console.log('variant_array_length', variant_array.length);

        let variantQuery = ` SELECT * FROM variant WHERE id IN (${variantData}) `
        const variantID = await db.query(variantQuery);
        console.log('variantID data', variantID[0]);  

        let transactionBillingQuery = `
        INSERT INTO transaction_billing (ccavenue_transid, status, createdon, lastmodifiedate) VALUES (${null},'${status}','${formattedDateTime}','${formattedDateTime}') `;
        const transactionResultBilling = await db.query(transactionBillingQuery);
        const billAutoId = transactionResultBilling[0];
        console.log('transactionResultBilling', transactionResultBilling);

        // let totalPriceGst = 0; 
        // let totalWeight = 0;

        let TBillingPrice = 0;
        let TBillingWeight = 0;
        let TotalGstPercent = 0;

        let index = 0; 

        for (const productId of productidArray) {

            const productVariant = ATC_ID[0].find(item => item.productid === productId);
            let ATCvariantQuantity = productVariant ? productVariant.quantity : 0;
            const productVariantID = productVariant ? productVariant.variantid : 0;

            const variantList = variantID[0].find(item => item.productid === productId);
            console.log('variantList', variantList);  

            const productVariantPrice = variantList ? variantList.price : 0;
            const productVariantWeight = variantList ? variantList.weight : 0;
            let productVariantQuantity = variantList ? variantList.quantity : 0;

            // const gstArray = 1;
            const gstArray = (!gst_id || gst_id.length == 0) ? undefined : gst_id[index];
            console.log('gst_array', gstArray);

            console.log('ATCvariantQuantity', ATCvariantQuantity);  
            console.log('productVariantQuantity', productVariantQuantity);  

            const today = new Date().toISOString().slice(0, 10);
            console.log('today', today);
    
            // let counterQuery = `
            // INSERT INTO daily_reset_counter (counter_date, counter_value) VALUES ('${today}', 1) ON DUPLICATE KEY UPDATE counter_value = counter_value + 1 `;
            // const counterInsert = await db.query(counterQuery);
        
            // let counterSelectQuery = `SELECT counter_value FROM daily_reset_counter WHERE counter_date = '${today}' `;
            // const counterData = await db.query(counterSelectQuery);
            // let counterValue = counterData[0][0] ? counterData[0][0]?.counter_value : 0
    
            // console.log('counterValue', counterValue);

            // const orderNumber = `2CQR-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
            // const transId = `Trans-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;

            // let transactionInsertQuery = `
            // INSERT INTO transactions (productid, userid, childbillid, status) VALUES ('${productId}', '${userid}', '${transactionResultBilling[0]}','${status || 'Initiated '}')`;
            // const transactionResult = await db.query(transactionInsertQuery);

            
            let TVariantPrice1 = 0;
            let TVariantWeight1 = 0;

            if (productVariantQuantity > 0) {
                let counterQuery = `
                INSERT INTO daily_reset_counter (counter_date, counter_value) VALUES ('${today}', 1) ON DUPLICATE KEY UPDATE counter_value = counter_value + 1 `;
                const counterInsert = await db.query(counterQuery);
            
                let counterSelectQuery = `SELECT counter_value FROM daily_reset_counter WHERE counter_date = '${today}' `;
                const counterData = await db.query(counterSelectQuery);
                let counterValue = counterData[0][0] ? counterData[0][0]?.counter_value : 0
        
                const orderNumber = `2CQR-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
                const transId = `Trans-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
                let inStockQuantity = Math.min(productVariantQuantity, ATCvariantQuantity);

                let TVariantPrice = productVariantPrice * inStockQuantity
                let TVariantWeight = productVariantWeight * inStockQuantity
    
                console.log('TVariantPrice', TVariantPrice);  
                console.log('TVariantWeight', TVariantWeight);  

                TBillingPrice += TVariantPrice;
                TBillingWeight += TVariantWeight;    
                
                TVariantPrice1 += TVariantPrice
                TVariantWeight1 += TVariantWeight

                let inStockQuery = `
                    INSERT INTO transactions (productid, userid, addressid, transid, ordernumber, variant, tpricegst, tweight, childbillid, gst_id, quantity, status) 
                    VALUES ('${productId}', '${userid}', '${addressid}', '${transId}', '${orderNumber}', '${productVariantID}', '${TVariantPrice}', '${TVariantWeight}', '${transactionResultBilling[0]}','${gstArray}','${inStockQuantity}', 'instock')
                `;
                const transactionResult = await db.query(inStockQuery);

                let transactionLogQuery = `
                INSERT INTO transactionlog (transtableid, status, createdby) VALUES ('${transactionResult[0]}', 'instock', '${userid}')`;
                const transactionResultLog = await db.query(transactionLogQuery);
                console.log('transactionResultLog', transactionResultLog);

                console.log('jgfhghfgghfh', ATCvariantQuantity,inStockQuantity );
                ATCvariantQuantity -= inStockQuantity;
            }
            
            if (ATCvariantQuantity > 0) {
                let counterQuery = `
                INSERT INTO daily_reset_counter (counter_date, counter_value) VALUES ('${today}', 1) ON DUPLICATE KEY UPDATE counter_value = counter_value + 1 `;
                const counterInsert = await db.query(counterQuery);
            
                let counterSelectQuery = `SELECT counter_value FROM daily_reset_counter WHERE counter_date = '${today}' `;
                const counterData = await db.query(counterSelectQuery);
                let counterValue = counterData[0][0] ? counterData[0][0]?.counter_value : 0
        
                const orderNumber = `2CQR-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
                const transId = `Trans-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;

                let TVariantPrice = productVariantPrice * ATCvariantQuantity
                let TVariantWeight = productVariantWeight * ATCvariantQuantity
    
                console.log('TVariantPrice', TVariantPrice);  
                console.log('TVariantWeight', TVariantWeight);  

                TBillingPrice += TVariantPrice;
                TBillingWeight += TVariantWeight;   
                
                TVariantPrice1 += TVariantPrice
                TVariantWeight1 += TVariantWeight

                let outOfStockQuery = `
                    INSERT INTO transactions (productid, userid, addressid, transid, ordernumber, variant, tpricegst, tweight, childbillid, gst_id, quantity, status) 
                    VALUES ('${productId}', '${userid}', '${addressid}', '${transId}', '${orderNumber}','${productVariantID}', '${TVariantPrice}', '${TVariantWeight}', '${transactionResultBilling[0]}', '${gstArray}', '${ATCvariantQuantity}', 'outofstock')
                `;
                const transactionResult = await db.query(outOfStockQuery);

                let transactionLogQuery = `
                INSERT INTO transactionlog (transtableid, status, createdby) VALUES ('${transactionResult[0]}', 'outofstock', '${userid}')`;
                const transactionResultLog = await db.query(transactionLogQuery);
                console.log('transactionResultLog', transactionResultLog);
            }

            console.log('product Variant Price & Weight ', productVariantPrice, productVariantWeight );

            const GSTChargeQuery = `
            SELECT (cgst + igst + sgst) AS total_tax FROM gst WHERE id = ${gstArray} ORDER BY id DESC `;
            const GSTChargeResult = await db.query(GSTChargeQuery);
            let GSTCharge = GSTChargeResult[0][0] ? GSTChargeResult[0][0]?.total_tax : 0;
            // TotalGstPercent += GSTCharge
            const productGSTAmount = (TVariantPrice1 * GSTCharge) / 100;
            console.log('TVariantPrice1', TVariantPrice1);
            
            TotalGstPercent += productGSTAmount;

            console.log('Product GST Amount:', productGSTAmount, 'GST Charge Percent:', GSTCharge);


            // totalPriceGst += productVariantPrice;
            // totalWeight += productVariantWeight;

            // let transactionLogQuery = `
            // INSERT INTO transactionlog (transtableid, status, createdby) VALUES ('${transactionResult[0]}', '${status}', '${userid}')`;
            // const transactionResultLog = await db.query(transactionLogQuery);
            
            // console.log('transactionResultLog', transactionResultLog);

            index++;
        }
        
            console.log('Order initiated successfully'); 

            const shippingChargeQuery = `
            SELECT charge FROM weightmasters WHERE weight < ${TBillingWeight} ORDER BY weight DESC LIMIT 1`;
            const shippingChargeResult = await db.query(shippingChargeQuery);
            const shippingCharge = shippingChargeResult[0][0] ? shippingChargeResult[0][0]?.charge : 0;
   
           // Calculate actual price
           const actualPrice = TBillingPrice;
        //    const GSTPrice = (TBillingPrice / TotalGstPercent);
        //    const GSTPrice = (TBillingPrice * TotalGstPercent) / 100;
           const GSTRoundPrice = Math.ceil(TotalGstPercent);
           const shippingChargeINT = parseInt(shippingCharge, 10);
           const transactionPrice = TBillingPrice + GSTRoundPrice + shippingChargeINT;

           console.log('TBillingPrice', TBillingPrice, TBillingWeight);
           console.log('actualPrice = ' , actualPrice, 'GSTRoundPrice = ', GSTRoundPrice, 'transactionPrice = ', transactionPrice, 'TotalGstPercent = ', TotalGstPercent, 'shippingChargeINT', shippingChargeINT, shippingCharge);

           const updateBillingQuery = `
            UPDATE transaction_billing 
            SET tpricegst = '${GSTRoundPrice}', tweight = '${TBillingWeight}', shipping_charges = '${shippingChargeINT}', actual_price = '${TBillingPrice}', transaction_price = '${transactionPrice}', payment_type = 'ccavenue' 
            WHERE id = '${billAutoId}'`;
            const updateBillData = await db.query(updateBillingQuery);

            const workingKey = '0BF202BFD501907C9D76C5443211629C';
            const accessCode = 'ATAD06LK05BU10DAUB';
            const merchantId = '204980';
            const currency = 'INR';
            const amount = transactionPrice;
            const language = 'EN';

            const formData = {
                merchant_id: merchantId,
                order_id: billAutoId,
                currency: currency,
                amount: amount,
                userid: userid,
                productid: productid,
                redirect_url: "http://localhost:5001/api/v1/Order/updateTransaction",
                cancel_url: "http://localhost:5001/api/v1/Order/updateTransaction",
                language: language
            };
  
            const params = new URLSearchParams(formData);
            const bodyData  = params.toString();  
            const encRequest = encrypt(bodyData, workingKey);

            const paymentLink = `https://test.ccavenue.com/transaction/transaction.do?command=initiateTransaction&encRequest=${encRequest}&access_code=${accessCode}`;

            res.status(200).send({
                status: true,
                message: 'Order initiated successfully',
                billAutoId: billAutoId,
                paymentLink: paymentLink
            });

            // const updateProbs = {productidArray, userid, billAutoId, status}

            // updateTransaction()
        
            await db.query('COMMIT');

    } catch (error) {
        console.log('error', error);
        res.status(500).json({
            status: false,
            message: 'Internal Server Error',
            error: error.message,
        });

        await db.query('ROLLBACK');
    }
};


// 28-11-2024

const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
const nameRegex = /^[a-zA-Z0-9]{3,5}$/;

if (!emailRegex.test(email)) {
    console.log('Invalid email format');
    res.status(400).send({ 
        status:false,
        message:'Invalid email format' 
    });
} 
else if (!nameRegex.test(name)) {
    console.log('Name must be alphanumeric and between 3 to 5 characters long');
    res.status(400).send({ 
        status:false,
        message:'Name must be alphanumeric and between 3 to 5 characters long' 
    });               }


// 29-11-2024
export const salesDashboard1 = async (req, res) => {
    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
    
    try {
        const query = `
        SELECT 
            SUM(CASE WHEN online = 1 THEN online ELSE 0 END) AS online_sales,
            SUM(CASE WHEN online = 0 THEN online ELSE 0 END) AS store_sales,
            JSON_ARRAY(
            JSON_OBJECT(
                'month', DATE_FORMAT(createdon, '%b'),
                'online_sales', SUM(CASE WHEN online = 1 THEN online ELSE 0 END),
                'store_sales', SUM(CASE WHEN online = 0 THEN online ELSE 0 END)
            )
            ) AS sales_by_month,
            JSON_ARRAY(
            JSON_OBJECT(
                'day', DATE(createdon),
                'online_sales', SUM(CASE WHEN online = 1 THEN online ELSE 0 END),
                'store_sales', SUM(CASE WHEN online = 0 THEN online ELSE 0 END)
            )
            ) AS sales_by_day
        FROM transactions
        GROUP BY
            CASE 
            WHEN DATE_FORMAT(createdon, '%Y-%m') IS NOT NULL THEN DATE_FORMAT(createdon, '%Y-%m')
            WHEN DATE(createdon) IS NOT NULL THEN DATE(createdon)
            ELSE NULL
            END `
    
        const [result] = await db.query(query);
    
        if (!result.length) {
        return res.status(200).send({
            status: true,
            data: {
            online_sales: 0,
            store_sales: 0,
            total_sales: 0,
            sales_by_month: [],
            sales_by_day: [],
            },
        });
        }
    
        const onlineSales = result[0]?.online_sales || 0;
        const storeSales = result[0]?.store_sales || 0;
        const totalSalesSum = parseInt(onlineSales) + parseInt(storeSales);
    
        res.status(200).send({
        status: true,
        data: {
            online_sales: onlineSales,
            store_sales: storeSales,
            total_sales: totalSalesSum,
            sales_by_month: JSON.parse(result[0]?.sales_by_month || '[]'),
            sales_by_day: JSON.parse(result[0]?.sales_by_day || '[]'),
        },
        });
    } catch (error) {
        console.error(error);
        res.status(500).send({
        error: 'Internal Server Error',
        message: error.message,
        });
    }
};

export const salesDashboard = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");

    const mastername = req.params.mastername;
    const filters = req.query;

    try {

        let thisQuery = ` SELECT
            SUM(CASE WHEN online = 1 THEN online ELSE 0 END) AS online_sales,
            SUM(CASE WHEN online = 0 THEN online ELSE 0 END) AS store_sales
        FROM transactions
        `
        const totalSales = await db.query(thisQuery)

        const onlineSales = totalSales[0][0] ? totalSales[0][0].online_sales : 0;
        const storeSales = totalSales[0][0] ? totalSales[0][0].store_sales : 0;
        const totalSalesSum = parseInt(onlineSales) + parseInt(storeSales);

        let thisQueryMonth = ` SELECT 
        DATE_FORMAT(createdon, '%b') AS month,
        SUM(CASE WHEN online = 1 THEN online ELSE 0 END) AS online_sales,
        SUM(CASE WHEN online = 0 THEN online ELSE 0 END) AS store_sales
        FROM transactions
        GROUP BY DATE_FORMAT(createdon, '%Y-%m')
        ORDER BY DATE_FORMAT(createdon, '%Y-%m') DESC`

        let thisQueryDay = `  SELECT 
        DATE(createdon) AS day,
        SUM(CASE WHEN online = 1 THEN online ELSE 0 END) AS online_sales,
        SUM(CASE WHEN online = 0 THEN online ELSE 0 END) AS store_sales
        FROM transactions
        GROUP BY DATE(createdon)
        ORDER BY DATE(createdon) DESC `

        const salesByMonth = await db.query(thisQueryMonth)
        const salesByDay = await db.query(thisQueryDay)
        res.status(200).send({
            status: true,
            data: {
                online_sales: onlineSales,
                store_sales: storeSales,
                total_sales: totalSalesSum,
                sales_by_month: salesByMonth[0],
                sales_by_day: salesByDay[0],
              },
        })
    } 
      catch (error) {
        console.log(error);
        res.status(500).send({ 
            error: 'Internal Server Error', 
            message: error.message 
        });
    }
};

// 02-12-2024
export const productLineChart1 = async (req, res) => {
    const { start_date, end_date } = req.query;
  
    try {
        let instockQuery = `
        SELECT 
            MONTH(createdon) AS month,
            COUNT(*) AS instock_count
        FROM product
        WHERE productid IS NOT NULL AND productstatus = 'instock'
        `;
        
        if (start_date && end_date) {
            instockQuery += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}' `;
        }
        
        instockQuery += `
        GROUP BY MONTH(createdon)
        ORDER BY MONTH(createdon) ASC
        `;
  
        let outofstockQuery = `
        SELECT 
            MONTH(createdon) AS month,
            COUNT(*) AS out_of_stock_count
        FROM product
        WHERE productid IS NOT NULL AND productstatus != 'instock'
        `;
        
        if (start_date && end_date) {
            outofstockQuery += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}' `;
        }
  
        outofstockQuery += `
        GROUP BY MONTH(createdon)
        ORDER BY MONTH(createdon) ASC
        `;
  
        const inStockData = await db.query(instockQuery);
        const outOfStockData = await db.query(outofstockQuery);
  
        const months = [
            "Jan", "Feb", "Mar", "Apr", "May", "Jun",
            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
        ];
  
        console.log('inStockData', inStockData[0]);
        console.log('outOfStockData', outOfStockData[0]);
  
        const inStockD = Array(12).fill(0);
        const outOfStockD = Array(12).fill(0);
  
        inStockData[0].forEach(row => {
          const monthIndex = new Date(row.month + "-01").getMonth();
          inStockD[monthIndex] = row.instock_count || 0;
        });
  
        outOfStockData[0].forEach(row => {
          const monthIndex = new Date(row.month + "-01").getMonth();
          outOfStockD[monthIndex] = row.out_of_stock_count || 0;
        });
  
        res.status(200).send({
          status: "success",
          data: {
            months,
            instock: inStockD,
            out_of_stock: outOfStockD,
          },
        });
        
  
        // const inStockD = inStockData[0].map(row => row.instock_count || 0);
        // const outOfStockD = outOfStockData[0].map(row => row.out_of_stock_count || 0);
  
        // res.status(200).send({
        //     status: "success",
        //     data: {
        //         months,
        //         instock: inStockD,
        //         out_of_stock: outOfStockD,
        //     },
        // });
    } catch (error) {
        console.log(error);
        res.status(500).send({
            status: "error",
            message: error.message,
        });
    }
};

// Insert Transaction
export const insertTransactionM = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
    await db.query('START TRANSACTION');

    try {
        const { userid, addressid, gst_id, tax_amount, quantity,shipping_charges, total_amount, status } = req.body;

        const productid = req.body.productid
        console.log('productid', productid);

        // const productidArray = JSON.parse(productid).length == 0 ? 0 : JSON.parse(productid);
        const productidArray = productid.length == 0 ? 0 : productid;
        console.log('productidArray', productidArray);
        
        let userCheckQuery = `SELECT userid FROM users WHERE userid = '${userid}' LIMIT 1`;
        const userCheckData = await db.query(userCheckQuery);
        const userExists = userCheckData[0][0] ? userCheckData[0][0]?.userid : 0

        console.log('userExists', userExists);
    
        if (userExists == 0 || !userExists) {
            console.log('User-ID not found');
            return res.status(404).send({
                status: false,
                message: 'User-ID not found',
            });
        }
    
        let productCheckQuery = `SELECT productid FROM product WHERE productid IN (${productidArray}) LIMIT 1`;
        const productCheckData = await db.query(productCheckQuery);
        const productExists = productCheckData[0][0] ? productCheckData[0][0]?.productid : 0

        console.log('productExists', productExists);

        if (productExists == 0 || !productExists) {
            console.log('Product-ID not found');
            return res.status(404).send({
                status: false,
                message: 'Product-ID not found',
            });
        }

        // const arrayReplace = productidArray.join(',').replace(/[]/g, '');
        // console.log('arrayReplace', arrayReplace);

        let getATC = ` SELECT * FROM addtocarttable WHERE userid = '${userid}' AND status != 'Ordered' AND productid IN (${productidArray}) `
        const ATC_ID = await db.query(getATC);
        console.log('ATC_ID data', ATC_ID[0]);      
        
        const ATCEmpty = ATC_ID[0][0] ? ATC_ID[0][0]?.atcartid : 0
        
        if (ATCEmpty == 0 || !ATCEmpty) {
            console.log('Add To Cart Empty');
            return res.status(404).send({
                status: false,
                message: 'Add To Cart Empty',
            });
        }
        
        const variant_array = ATC_ID[0]?.map(i => i.variantid);
        const variantData =  variant_array.length != 0 ? variant_array?.join(',') : 0
        console.log('variant_array', variantData);
        console.log('variant_array_length', variant_array.length);

        let variantQuery = ` SELECT * FROM variant WHERE id IN (${variantData}) `
        const variantID = await db.query(variantQuery);
        console.log('variantID data', variantID[0]);  

        // space for payment confirmations

        const transArray = []

        let index = 0; 

        for (const productId of productidArray) {

            const productVariant = ATC_ID[0].find(item => item.productid === productId);
            const productQuantity = productVariant ? productVariant.quantity : 0;
            const productVariantID = productVariant ? productVariant.variantid : 0;

            const variantList = variantID[0].find(item => item.productid === productId);
            console.log('variantList', variantList);  

            const productVariantPrice = variantList ? variantList.price : 0;

            const gstArray = gst_id[index];
            const taxAmountArray = tax_amount[index];

            console.log('gstArray', gstArray);
            console.log('taxAmountArray', taxAmountArray);

            console.log('productVariant', productVariant);        
            console.log('productQuantity', productQuantity);        
            console.log('productVariantID', productVariantID);        
            console.log('productVariantPrice', productVariantPrice);        

            const today = new Date().toISOString().slice(0, 10);
            console.log('today', today);
    
            let counterQuery = `
            INSERT INTO daily_reset_counter (counter_date, counter_value) VALUES ('${today}', 1) ON DUPLICATE KEY UPDATE counter_value = counter_value + 1 `;
            const counterInsert = await db.query(counterQuery);
        
            let counterSelectQuery = `SELECT counter_value FROM daily_reset_counter WHERE counter_date = '${today}' `;
            const counterData = await db.query(counterSelectQuery);
            const counterValue = counterData[0][0] ? counterData[0][0]?.counter_value : 0
    
            console.log('counterValue', counterValue);

            const orderNumber = `2CQR-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
            const transId = `Trans-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
    
            console.log('orderNumber', orderNumber);
            console.log('transId', transId);

            let transactionInsertQuery = `
            INSERT INTO transactions (productid, userid, transid, addressid, ordernumber, quantity, variant, gst_id, status) VALUES ('${productId}', '${userid}', '${transId}', '${addressid}', '${orderNumber}', '${productQuantity}','${productVariantID}','${gstArray}', '${status}')`;
            const transactionResult = await db.query(transactionInsertQuery);

            console.log('transactionResult', transactionResult);

            transArray?.push(transactionResult[0])
            
            let transactionBillingQuery = `
            INSERT INTO transaction_billing (trans_id, gst_id, tax_amount, price, shipping_charges, total_amount, createdon, lastmodifiedate) VALUES ('${transId}', '${gstArray}', '${taxAmountArray}', '${productVariantPrice}', '${shipping_charges}', '${total_amount}', '${formattedDateTime}', '${formattedDateTime}')`;
            const transactionResultBilling = await db.query(transactionBillingQuery);

            console.log('transactionResultBilling', transactionResultBilling);

            let transactionLogQuery = `
            INSERT INTO transactionlog (transtableid, status, createdby) VALUES ('${transactionResult[0]}', '${status}', '${userid}')`;
            const transactionResultLog = await db.query(transactionLogQuery);
            
            console.log('transactionResultLog', transactionResultLog);

            index++;
        }
        
        console.log('Transaction inserted successfully'); 

        let uAddToCart = `UPDATE addtocarttable SET status = 'Ordered' WHERE userid = '${userid}' AND productid IN (${productidArray}) `
        const addToCartUpdate = await db.query(uAddToCart);

        ATC_ID[0]?.forEach(atcItem => {
            let variant = variantID[0].find(variant => variant.id === atcItem.variantid);
            
            if (variant) {
                variant.quantity -= atcItem.quantity;                
                variant.quantity = Math.max(0, variant.quantity);
            }
        });
        
        console.log('finalArray[0]',variantID[0]);

        for (const atcArray of variantID[0]) {
            console.log('atcArray', atcArray);
            
            let variantQuery = `UPDATE variant SET quantity = '${atcArray.quantity}' WHERE id = '${atcArray.id}' `
            const variantUpdate = await db.query(variantQuery);
        }

        const transArrayID = transArray?.length != 0 ? transArray.join(',') : 0
        console.log('transArrayID', transArrayID);

        let thisQueryOrd = `
        SELECT 
        tra.id,
        tra.transid,
        tra.productid,
        tra.userid,
        us.username,
        tra.ordernumber,
        tra.status,
        tra.createdon, 
        tra.quantity, 
        tra.productid as trans_product_id,
        (JSON_ARRAYAGG(
                JSON_OBJECT(
                    'productid', p.productid,
                    'name', p.name,
                    'description', p.description,
                    'price', v.price,
                    'quantity', tra.quantity
                )
            )
        ) AS product_details,
        (JSON_ARRAYAGG(
                JSON_OBJECT(
                    'trans_id', tb.trans_id,
                    'tax_amount', tb.tax_amount,
                    'gst_id', tb.gst_id,
                    'price', tb.price,
                    'shipping_charges', tb.shipping_charges,
                    'total_amount', tb.total_amount,
                    'name', gst.name,
                    'cgst', gst.cgst,
                    'igst', gst.igst,
                    'sgst', gst.sgst,
                    'igst', gst.igst
                )
            )
        ) AS billing_details,
        (JSON_ARRAYAGG(
                JSON_OBJECT(
                    'image', pi.image,
                    'imageseq', pi.imageseq,
                    'productid', pi.productid
                )
            )
        ) AS image_details,
        (
            SELECT 
                JSON_OBJECT(
                    'addressid', COALESCE(ad.addressid,''),
                    'address_name', COALESCE(ad.name,''),
                    'fullAddress', COALESCE(ad.fullAddress,''),
                    'locationDetails', COALESCE(ad.locationDetails,''),
                    'landmark', COALESCE(ad.landmark,''),
                    'city', COALESCE(ad.city,''),
                    'state', COALESCE(ad.state,''),
                    'country', COALESCE(ad.country,''),
                    'pincode', COALESCE(ad.pincode,''),
                    'email', COALESCE(ad.email,''),
                    'mobileno', COALESCE(ad.mobileno,''),
                    'alternatemobileno', COALESCE(ad.alternatemobileno,'')
                )
            FROM address as ad
            WHERE ad.addressid IN (tra.addressid)
            GROUP BY ad.addressid
        ) AS address_details
        
        FROM transactions as tra
        LEFT JOIN transaction_billing as tb ON (tra.transid = tb.trans_id)
        LEFT JOIN users as us ON (us.userid = tra.userid)
        LEFT JOIN product as p ON (tra.productid = p.productid)
        LEFT JOIN variant as v ON (v.id = tra.variant)
        LEFT JOIN productimage pi ON (pi.productid = p.productid AND pi.imageseq = 1)
        LEFT JOIN address ad ON (ad.addressid = tra.addressid)
        LEFT JOIN gst as gst ON (gst.id = tb.gst_id)
        WHERE tra.status IN ('ordered', 'shipped', 'outfordelivery', 'delivered', 'deliverfail')
        AND tra.userid = '${userid}' AND tra.id IN (${transArrayID})
        `

        thisQueryOrd += ` 
        GROUP BY tra.id, tra.transid, tra.ordernumber, tra.status, tra.createdon, p.name, p.description, p.price, pi.image
        ORDER BY MAX(tra.lastmodifiedat) DESC
        `
        const ordersData = await db.query(thisQueryOrd);

        let orderListQuery = ` SELECT 
        tra.*,
        p.name as product_name,
        us.username as username,
        v.price as variant_price,
        tb.shipping_charges as shipping_charges,
        tb.total_amount as total_amount,
        us.email as email
        FROM transactions as tra
        LEFT JOIN transaction_billing as tb ON (tra.transid = tb.trans_id)
        LEFT JOIN gst as gst ON (gst.id = tb.gst_id)
        LEFT JOIN product as p on (p.productid = tra.productid)
        LEFT JOIN users as us on (us.userid = tra.userid)
        LEFT JOIN variant as v on (v.id = tra.variant)
        WHERE tra.id IN (${transArrayID}) `
        const orderList = await db.query(orderListQuery);
        console.log('transArrayID', transArrayID);

        console.log('orderList', orderList[0]);

        emailTrigger(orderList)

        res.status(200).send({
            status: true,
            message: 'Transaction inserted successfully',
            insert_count:ordersData[0]?.length,
            insert_output: ordersData[0]
        });
    
        await db.query('COMMIT');

    } catch (error) {
        console.log('error', error);
        res.status(500).json({
            status: false,
            message: 'Internal Server Error',
            error: error.message,
        });

        await db.query('ROLLBACK');
    }
};

// {
//     "status": "success",
//     "data": {
//         "instock": {"Jan": 0,"Feb": 0,"Mar": 0,"Apr": 0,"May": 0,"Jun": 0,"Jul": 0,"Aug": 0,"Sep": 0,"Oct": 3,"Nov": 34,"Dec": 0},
//         "out_of_stock": {"Jan": 0,"Feb": 0,"Mar": 0,"Apr": 0,"May": 0,"Jun": 0,"Jul": 0,"Aug": 0,"Sep": 0,"Oct": 1,"Nov": 0,"Dec": 0}
//     }
// }




// 03-12-2024

// Sales Line Chart
export const salesLineChart = async (req, res) => {
    const { start_date, end_date } = req.query;
  
    try {
        let dailySalesQuery = `
        SELECT 
            DATE(createdon) AS day,
            COUNT(*) AS daily_sales
        FROM transactions
        WHERE id IS NOT NULL
        `;
        
        if (start_date && end_date) {
            dailySalesQuery += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}' `;
        }
        
        dailySalesQuery += `
        GROUP BY DATE(createdon)
        ORDER BY DATE(createdon) ASC
        `;
  
        let monthlySalesQuery = `
        SELECT 
            DATE_FORMAT(createdon, '%Y-%m') AS month,
            COUNT(*) AS monthly_sales
        FROM transactions
        WHERE id IS NOT NULL
        `;
        
        if (start_date && end_date) {
            monthlySalesQuery += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}' `;
        }
  
        monthlySalesQuery += `
        GROUP BY DATE_FORMAT(createdon, '%Y-%m')
        ORDER BY DATE_FORMAT(createdon, '%Y-%m') ASC
        `;
  
        const dailySalesData = await db.query(dailySalesQuery);
        const monthlySalesData = await db.query(monthlySalesQuery);
  
        const months = [
            "Jan", "Feb", "Mar", "Apr", "May", "Jun",
            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
        ];
  
        // const dailySales = dailySalesData[0].map(row => row.daily_sales || 0);
  
        // const monthlySales = Object.fromEntries(months.map(month => [month, 0]));
        // monthlySalesData[0].forEach(row => {
        //   const monthIndex = new Date(row.month + "-01").getMonth();
        //   monthlySales[months[monthIndex]] = row.monthly_sales || 0;
        // });
        const monthlySales = months.map(month => {
            const monthRow = monthlySalesData[0].find(row => {
                const date = new Date(row.month + "-01");
                return date.toLocaleString("default", { month: "short" }) === month;
            });
            return monthRow ? monthRow.monthly_sales : 0;
        });
  
        let thisQuery = `
        SELECT 
        DATE_FORMAT(createdon, '%Y-%m') AS month,
        COUNT(CASE WHEN online = 1 THEN 0 END) AS online_sales,
        COUNT(CASE WHEN online = 0 THEN 0 END) AS store_sales
        FROM transactions
        WHERE id IS NOT NULL `
        if (start_date && end_date) {
            thisQuery += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}'`
        }
        thisQuery += `
        GROUP BY DATE_FORMAT(createdon, '%Y-%m')
        ORDER BY DATE_FORMAT(createdon, '%Y-%m') ASC `
      
      const salesData = await db.query(thisQuery, [start_date, end_date]);
  
        let thisQuery1 = `
        SELECT 
        DATE(createdon) AS day,
        COUNT(CASE WHEN online = 1 THEN 0 END) AS online_sales,
        COUNT(CASE WHEN online = 0 THEN 0 END) AS store_sales
        FROM transactions
        WHERE id IS NOT NULL `
        if (start_date && end_date) {
            thisQuery1 += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}'`
        }
        thisQuery1 += `
        GROUP BY DATE(createdon)
        ORDER BY DATE(createdon) ASC `
      
      const salesData1 = await db.query(thisQuery1, [start_date, end_date]);
  
      // const months1 = [];
      // const onlineSales = [];
      // const storeSales = [];
  
      // salesData[0].forEach(row => {
      //   const month = new Date(row.month + "-01").toLocaleString('default', { month: 'long' });
      //   months1.push(month);
      //   onlineSales.push(row.online_sales);
      //   storeSales.push(row.store_sales);
      // });
  
        const monthlySales1 = Object.fromEntries(months.map(month => [month, 0]));
        monthlySalesData[0].forEach(row => {
          const monthIndex = new Date(row.month + "-01").getMonth();
          monthlySales1[months[monthIndex]] = row.monthly_sales || 0;
        });
        
        const onlinemonthlySales = Object.fromEntries(months.map(month => [month, 0]));
        salesData[0].forEach(row => {
          const monthIndex = new Date(row.month + "-01").getMonth();
          onlinemonthlySales[months[monthIndex]] = row.online_sales || 0;
        });
        const storemonthlySales = Object.fromEntries(months.map(month => [month, 0]));
        salesData[0].forEach(row => {
          const monthIndex = new Date(row.month + "-01").getMonth();
          storemonthlySales[months[monthIndex]] = row.store_sales || 0;
        });
  
        res.status(200).send({
            status: "success",
            data: {
                months,
                daily_sales: dailySalesData[0],
                monthly_sales: monthlySales1,
                monthly_online_sales: onlinemonthlySales,
                monthly_store_sales: storemonthlySales,
                daily_overall_sales: salesData1[0]  
            },
        });
    } catch (error) {
        console.log(error);
        res.status(500).send({
            status: "error",
            message: error.message,
        });
    }
};

export const salesLineChart1 = async (req, res) => {
const { start_date, end_date } = req.query;

try {
    // Query for daily sales
    let dailySalesQuery = `
    SELECT 
        DATE(createdon) AS day,
        COUNT(*) AS daily_sales
    FROM transactions
    WHERE id IS NOT NULL
    `;
    if (start_date && end_date) {
    dailySalesQuery += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}' `;
    }
    dailySalesQuery += `
    GROUP BY DATE(createdon)
    ORDER BY DATE(createdon) ASC
    `;

    // Query for monthly sales
    let monthlySalesQuery = `
    SELECT 
        DATE_FORMAT(createdon, '%Y-%m') AS month,
        COUNT(*) AS monthly_sales
    FROM transactions
    WHERE id IS NOT NULL
    `;
    if (start_date && end_date) {
    monthlySalesQuery += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}' `;
    }
    monthlySalesQuery += `
    GROUP BY DATE_FORMAT(createdon, '%Y-%m')
    ORDER BY DATE_FORMAT(createdon, '%Y-%m') ASC
    `;

    // Fetch data from the database
    const dailySalesData = await db.query(dailySalesQuery);
    const monthlySalesData = await db.query(monthlySalesQuery);

    const months = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    ];

    // Query for online and store sales
    let salesQuery = `
    SELECT 
        DATE_FORMAT(createdon, '%Y-%m') AS month,
        COUNT(CASE WHEN online = 1 THEN 1 END) AS online_sales,
        COUNT(CASE WHEN online = 0 THEN 1 END) AS store_sales
    FROM transactions
    WHERE id IS NOT NULL
    `;
    if (start_date && end_date) {
    salesQuery += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}' `;
    }
    salesQuery += `
    GROUP BY DATE_FORMAT(createdon, '%Y-%m')
    ORDER BY DATE_FORMAT(createdon, '%Y-%m') ASC
    `;
    const salesData = await db.query(salesQuery);

    // Initialize result objects
    const monthlyOnlineSales = {};
    const monthlyStoreSales = {};
    const detailedSales = [];

    months.forEach(month => {
    monthlyOnlineSales[month] = 0;
    monthlyStoreSales[month] = 0;
    });

    // Populate data
    salesData[0].forEach(row => {
    const date = new Date(row.month + "-01");
    const monthName = date.toLocaleString("default", { month: "short" });
    monthlyOnlineSales[monthName] = row.online_sales || 0;
    monthlyStoreSales[monthName] = row.store_sales || 0;

    detailedSales.push({
        month: monthName,
        online_sales: row.online_sales || 0,
        store_sales: row.store_sales || 0
    });
    });

    // Ensure all months are present in detailed sales
    months.forEach(month => {
    if (!detailedSales.some(row => row.month === month)) {
        detailedSales.push({
        month,
        online_sales: 0,
        store_sales: 0
        });
    }
    });

    detailedSales.sort((a, b) => months.indexOf(a.month) - months.indexOf(b.month));

    res.status(200).send({
    status: "success",
    data: {
        months,
        daily_sales: dailySalesData[0],
        monthly_sales: monthlySalesData[0],
        monthly_online_sales: monthlyOnlineSales,
        monthly_store_sales: monthlyStoreSales,
        detailed_monthly_sales: detailedSales
    }
    });
} catch (error) {
    console.log(error);
    res.status(500).send({
    status: "error",
    message: error.message
    });
}
};


// 04-12-2024

export const verifyOTP = async (req, res) => {
    try {
        const { mobileno, otpcode } = req.body;

        const currentTime = new Date();
        let resultStatus = '';
        let resultMessage = '';

        // Verify the OTP validity
        const otpQuery = `
            SELECT validity 
            FROM otptable 
            WHERE mobileno = ? AND otpcode = ? AND STATUS = 1 
            ORDER BY id DESC LIMIT 1
        `;
        const [otpResult] = await db.query(otpQuery, [mobileno, otpcode]);

        if (otpResult.length === 0 || new Date(otpResult[0].validity) <= currentTime) {
            resultStatus = 'ERROR';
            resultMessage = otpResult.length === 0 ? 'Invalid OTP or OTP expired' : 'OTP expired';
            return res.status(400).json({ status: resultStatus, message: resultMessage });
        }

        // Fetch user data from temp_register
        const tempDataQuery = `
            SELECT json_data 
            FROM temp_register 
            WHERE mobileno = ? AND deleted_at IS NULL 
            LIMIT 1
        `;
        const [tempDataResult] = await db.query(tempDataQuery, [mobileno]);

        if (tempDataResult.length === 0) {
            resultStatus = 'ERROR';
            resultMessage = 'User Details Not Found. Try Again Later.';
            return res.status(400).json({ status: resultStatus, message: resultMessage });
        }

        const jsonData = JSON.parse(tempDataResult[0].json_data);

        // Mark OTP as used and temp_register entry as deleted
        await db.query(`UPDATE otptable SET STATUS = 0 WHERE mobileno = ? AND otpcode = ?`, [mobileno, otpcode]);
        await db.query(`UPDATE temp_register SET deleted_at = CURRENT_TIMESTAMP WHERE mobileno = ? AND deleted_at IS NULL`, [mobileno]);

        // Extract JSON data
        const {
            username, password, name, email, schoolcodes, fullAddress, locationDetails,
            landmark, city, state, country, pincode, alternatemobileno
        } = jsonData;

        // Insert user data into the `users` table
        const userInsertQuery = `
            INSERT INTO users (username, password, name, email, mobileno) 
            VALUES (?, ?, ?, ?, ?)
        `;
        const [userInsertResult] = await db.query(userInsertQuery, [username, password, name, email, mobileno]);
        const userId = userInsertResult.insertId;

        // Map schools for the user
        for (const schoolCode of schoolcodes || []) {
            const schoolQuery = `SELECT schoolid FROM school WHERE schoolcode = ?`;
            const [schoolResult] = await db.query(schoolQuery, [schoolCode]);

            if (schoolResult.length > 0) {
                const schoolId = schoolResult[0].schoolid;

                const mappingExistsQuery = `
                    SELECT 1 
                    FROM usersschoolmap 
                    WHERE userid = ? AND schoolid = ?
                `;
                const [mappingExistsResult] = await db.query(mappingExistsQuery, [userId, schoolId]);

                if (mappingExistsResult.length === 0) {
                    await db.query(`INSERT INTO usersschoolmap (userid, schoolid) VALUES (?, ?)`, [userId, schoolId]);
                }
            }
        }

        // Insert address data
        const addressInsertQuery = `
            INSERT INTO address (
                userid, name, fullAddress, locationDetails, landmark, city, state, country, 
                pincode, email, mobileno, alternatemobileno, status, createdby, createdon, lastmodifiedby, lastmodifiedate
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?)
        `;
        const currentTimestamp = currentTime.toISOString();
        await db.query(addressInsertQuery, [
            userId, name, fullAddress, locationDetails, landmark, city, state, country,
            pincode, email, mobileno, alternatemobileno, userId, currentTimestamp, userId, currentTimestamp
        ]);

        // Assign "online" role to the user
        const roleQuery = `SELECT rolesid FROM roles WHERE name = 'online' LIMIT 1`;
        const [roleResult] = await db.query(roleQuery);

        if (roleResult.length > 0) {
            const roleId = roleResult[0].rolesid;
            await db.query(`INSERT INTO userrolemap (userid, roleid) VALUES (?, ?)`, [userId, roleId]);
        }

        resultStatus = 'SUCCESS';
        resultMessage = 'OTP verification successful';

        res.status(200).json({ status: resultStatus, message: resultMessage });

    } catch (error) {
        console.error('Error in verifyOTP:', error);
        res.status(500).json({ status: 'ERROR', message: 'Internal Server Error', error: error.message });
    }
};


// BEGIN
   
//     DECLARE v_user_id BIGINT;
//     DECLARE v_validity DATETIME;
//     DECLARE v_json_data JSON;
//     DECLARE p_transtime DATETIME;
//     DECLARE v_username VARCHAR(50);
//     DECLARE v_password VARCHAR(150);
//     DECLARE v_name VARCHAR(100);
//     DECLARE v_email VARCHAR(50);
//     DECLARE v_schoolcodes JSON;
//     DECLARE v_fullAddress TEXT;
//     DECLARE v_locationDetails TEXT;
//     DECLARE v_landmark VARCHAR(255);
//     DECLARE v_city VARCHAR(100);
//     DECLARE v_state VARCHAR(100);
//     DECLARE v_country VARCHAR(100);
//     DECLARE v_pincode VARCHAR(6);
//     DECLARE v_alternatemobileno VARCHAR(10);
//     DECLARE v_isprimary BIT;
//     DECLARE v_iswork BIT;
//     DECLARE v_status BIT;
//     DECLARE code VARCHAR(255);
//     DECLARE school_id INT;
//     DECLARE idxinsert INT DEFAULT 0;
//     DECLARE p_roleid BIGINT;

//     SET p_transtime = CONVERT_TZ(NOW(), '+00:00', '+05:30');

//     -- Verify the OTP validity
//     SELECT validity INTO v_validity
//     FROM otptable
//     WHERE mobileno = p_mobileno AND otpcode = p_otpcode AND STATUS = 1
//     ORDER BY id DESC
//     LIMIT 1;
    
//             -- Fetch the JSON data from temp_register where 'deleted_at' is NULL
//     SELECT json_data INTO v_json_data 
//     FROM temp_register
//     WHERE mobileno = p_mobileno AND deleted_at IS NULL LIMIT 1;
// IF v_json_data IS NOT NULL THEN
//     IF v_validity IS NOT NULL AND v_validity > p_transtime THEN
//         -- OTP success, mark as used
//         UPDATE otptable
//         SET STATUS = 0
//         WHERE mobileno = p_mobileno AND otpcode = p_otpcode;

//     -- Update the 'deleted_at' column with the current timestamp
//     UPDATE temp_register
//     SET deleted_at = CURRENT_TIMESTAMP
//     WHERE mobileno = p_mobileno AND deleted_at IS NULL;

        
//         -- Extract JSON values into variables
//         SET v_username = JSON_UNQUOTE(JSON_EXTRACT(v_json_data, '$.username'));
//         SET v_password = JSON_UNQUOTE(JSON_EXTRACT(v_json_data, '$.password'));
//         SET v_name = JSON_UNQUOTE(JSON_EXTRACT(v_json_data, '$.name'));
//         SET v_email = JSON_UNQUOTE(JSON_EXTRACT(v_json_data, '$.email'));
//         SET v_schoolcodes = JSON_EXTRACT(v_json_data, '$.schoolcodes');
//         SET v_fullAddress = JSON_UNQUOTE(JSON_EXTRACT(v_json_data, '$.fullAddress'));
//         SET v_locationDetails = JSON_UNQUOTE(JSON_EXTRACT(v_json_data, '$.locationDetails'));
//         SET v_landmark = JSON_UNQUOTE(JSON_EXTRACT(v_json_data, '$.landmark'));
//         SET v_city = JSON_UNQUOTE(JSON_EXTRACT(v_json_data, '$.city'));
//         SET v_state = JSON_UNQUOTE(JSON_EXTRACT(v_json_data, '$.state'));
//         SET v_country = JSON_UNQUOTE(JSON_EXTRACT(v_json_data, '$.country'));
//         SET v_pincode = JSON_UNQUOTE(JSON_EXTRACT(v_json_data, '$.pincode'));
//         SET v_alternatemobileno = JSON_UNQUOTE(JSON_EXTRACT(v_json_data, '$.alternatemobileno'));
//         SET v_status = 1;

//         -- Insert into users table
//         INSERT INTO users (username, password, name, email, mobileno)
//         VALUES (v_username, v_password, v_name, v_email, p_mobileno);
        
//          -- Get the user ID of the newly created user
//         SELECT userid INTO v_user_id FROM users WHERE email = v_email LIMIT 1;

//         -- Insert school mappings for the user
//         WHILE idxinsert < JSON_LENGTH(v_schoolcodes) DO
//             SET code = JSON_UNQUOTE(JSON_EXTRACT(v_schoolcodes, CONCAT('$[', idxinsert, ']')));

//             SELECT schoolid INTO school_id FROM school WHERE schoolcode = code;

//             IF school_id IS NOT NULL THEN
//                 IF NOT EXISTS (SELECT 1 FROM usersschoolmap WHERE userid = v_user_id AND schoolid = school_id) THEN
//                     INSERT INTO usersschoolmap (userid, schoolid) VALUES (v_user_id, school_id);
//                 END IF;
//             END IF;

//             SET idxinsert = idxinsert + 1;
//         END WHILE;
        
//             -- Insert into address table including fullAddress and locationDetails
//     INSERT INTO address (
//         userid, name, fullAddress, locationDetails,landmark, city, state, country, 
//         pincode, email, mobileno, alternatemobileno, status, 
//         createdby, createdon, lastmodifiedby, lastmodifiedate
//     )
//     VALUES (
//         v_user_id, v_name, v_fullAddress, v_locationDetails,v_landmark, v_city, v_state, 
//         v_country, v_pincode, v_email, p_mobileno, v_alternatemobileno, v_status, v_user_id, p_transtime, v_user_id, p_transtime
//     );
//      -- Retrieve the role ID from the roles table
//     SELECT rolesid INTO p_roleid
//     FROM roles
//     WHERE name = 'online' LIMIT 1;
    
//     -- Check if the role ID exists and assign the role
//        -- IF p_roleid IS NOT NULL THEN
//            INSERT INTO userrolemap (userid, roleid)
//             VALUES (v_user_id, p_roleid);
//       --  ELSE
//       --      SET p_result_status = 'FAILURE';
//       --      SET p_result_message = 'Role ID for "online" not found';
//       --  END IF;
//       --      INSERT INTO userrolemap (userid, roleid)
//       --      VALUES (v_user_id, p_roleid);
//         -- Success response
//         SET p_result_status = 'SUCCESS';
//         SET p_result_message = 'OTP verification successful';

//     ELSE
//         -- OTP verification failed
//         SET p_result_status = 'ERROR';
//         SET p_result_message = 'Invalid OTP or OTP expired';
//     END IF;
//     ELSE
//         -- OTP verification failed
//         SET p_result_status = 'ERROR';
//         SET p_result_message = 'User Details Not Found Try After Sometimes';
//     END IF;
//     -- Output the result
//     SELECT p_result_status AS status, p_result_message AS message;
    
//     SELECT * FROM users;
   
// END


// 04-12-2024
import { PDFDocument } from 'pdfkit';
import fs from 'fs';
import path from 'path';

if (filters?.type == 'pdf') {
  try {
    console.log('Initial PDF Generated');

    // Create a PDF document
    const doc = new PDFDocument({ size: 'A4' });

    // Output path
    const outputPath = path.join(__dirname, 'output.pdf');
    doc.pipe(fs.createWriteStream(outputPath));

    // Add title to PDF
    doc.fontSize(18).text('Product List', { align: 'center' });
    doc.moveDown(1); // Space after title

    // Define table structure
    const tableTop = doc.y + 20;
    const columnWidth = [100, 100, 150, 200, 80]; // Width of each column

    // Table Headers
    doc.fontSize(10).text('Id', columnWidth[0], tableTop);
    doc.text('Image', columnWidth[1], tableTop);
    doc.text('Product Name', columnWidth[2], tableTop);
    doc.text('Description', columnWidth[3], tableTop);
    doc.text('Price', columnWidth[4], tableTop);

    // Add a horizontal line under the headers
    doc.moveTo(columnWidth[0], doc.y + 5).lineTo(columnWidth[4] + columnWidth[4] - 20, doc.y + 5).stroke();

    // Loop through the products and add rows to the table
    const productRows = [
      // Example product data: replace this with your dynamic data
      { id: 1, image: 'image1.png', name: 'Product 1', description: 'Description 1', price: '$10' },
      { id: 2, image: 'image2.png', name: 'Product 2', description: 'Description 2', price: '$20' },
      // Add more products as needed
    ];

    let yPosition = tableTop + 20;
    productRows.forEach(product => {
      doc.fontSize(10).text(product.id.toString(), columnWidth[0], yPosition);
      doc.text(product.image, columnWidth[1], yPosition);
      doc.text(product.name, columnWidth[2], yPosition);
      doc.text(product.description, columnWidth[3], yPosition);
      doc.text(product.price, columnWidth[4], yPosition);

      yPosition += 20; // Move down for the next row

      // Add a horizontal line under each row
      doc.moveTo(columnWidth[0], yPosition - 5).lineTo(columnWidth[4] + columnWidth[4] - 20, yPosition - 5).stroke();
    });

    // Finalize the document and save it
    doc.end();

    // Send the PDF file to the user
    const pdfBuffer = fs.readFileSync(outputPath);
    res.setHeader('Content-Disposition', 'attachment; filename=output.pdf');
    res.setHeader('Content-Type', 'application/pdf');
    return res.send(pdfBuffer);

  } catch (error) {
    console.error('PDF ERROR:', error);
    console.log('Pdf not generated');
  }
}


// 05-12-2024
// HTML-PDF
if (filters?.type == 'pdf') {
    try {
        console.log('Initial PDF Generation Started');

        // Sample product rows, this should be dynamically populated
        const productRows = `
            <tr>
                <td>1</td>
                <td><img src="https://via.placeholder.com/50" alt="Product Image" /></td>
                <td>Product 1</td>
                <td>This is a description of Product 1.</td>
                <td>$10.00</td>
            </tr>
            <tr>
                <td>2</td>
                <td><img src="https://via.placeholder.com/50" alt="Product Image" /></td>
                <td>Product 2</td>
                <td>This is a description of Product 2.</td>
                <td>$15.00</td>
            </tr>
        `;

        // Prepare the HTML content
        const htmlContent = `
        <html>
        <head>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    margin: 20px;
                }
                h1 {
                    text-align: center;
                }
                .table-responsive {
                    overflow-x: auto;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                }
                th, td {
                    border: 1px solid #ddd;
                    padding: 8px;
                    text-align: left;
                }
                th {
                    background-color: #f2f2f2;
                }
            </style>
        </head>
        <body>
            <h1>Product List</h1>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Image</th>
                            <th>Product Name</th>
                            <th>Description</th>
                            <th>Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${productRows} <!-- This should be populated dynamically -->
                    </tbody>
                </table>
            </div>
        </body>
        </html>`;

        // Define output path
        const outputPath = path.join(__dirname, 'Omg.pdf');

        // Generate the PDF from HTML using html-pdf
        pdf.create(htmlContent).toFile(outputPath, (err, resPdf) => {
            if (err) {
                console.error('PDF ERROR:', err);
                return res.status(500).send('Failed to generate PDF');
            }
            console.log('PDF generated:', resPdf.filename);

            // Read the generated PDF file
            const pdfBuffer = fs.readFileSync(outputPath);

            // Send the PDF response with appropriate headers
            res.setHeader('Content-Disposition', 'attachment; filename=output.pdf');
            res.setHeader('Content-Type', 'application/pdf');
            res.send(pdfBuffer);
        });

    } catch (error) {
        console.error('Error in PDF Generation:', error);
        return res.status(500).send('An error occurred during PDF generation');
    }
}



// 06-12-2024
// Product Bar Chart
export const productBarChart = async (req, res) => {
    const { start_date, end_date } = req.query;
  
    try {
      let thisQuery = `
        SELECT SUM(quantity) as instock 
        FROM variant  
        WHERE id IS NOT NULL `
        if (start_date && end_date) {
            thisQuery += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}'`
        }
        thisQuery += `
        GROUP BY DATE_FORMAT(createdon, '%Y-%m')
        ORDER BY DATE_FORMAT(createdon, '%Y-%m') ASC `
      
      const salesData = await db.query(thisQuery, [start_date, end_date]);    
  
      let thisQuery1 = `
         SELECT SUM(quantity) as out_of_stock 
        FROM transactions 
        WHERE status = 'outofstock_o'  `
        if (start_date && end_date) {
            thisQuery1 += ` AND DATE(createdon) BETWEEN '${start_date}' AND '${end_date}'`
        }
        thisQuery1 += `
        GROUP BY DATE_FORMAT(createdon, '%Y-%m')
        ORDER BY DATE_FORMAT(createdon, '%Y-%m') ASC `
      
      const salesData1 = await db.query(thisQuery1, [start_date, end_date]);
  
      console.log('salesData', salesData[0]);
      console.log('salesData1', salesData1[0]);
  
      const months = [];
      const instockD = [];
      const outOfStockD = [];
  
      salesData[0].forEach(row => {
        const month = new Date(row.month + "-01").toLocaleString('default', { month: 'long' });
        months.push(month);
        instockD.push(row.instock);
      });
      salesData1[0].forEach(row => {
        const month = new Date(row.month + "-01").toLocaleString('default', { month: 'long' });
        months.push(month);
        outOfStockD.push(row.out_of_stock);
      });
  
      // const months = [
      //   "Jan", "Feb", "Mar", "Apr", "May", "Jun",
      //   "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
      // ];
  
      // const instockD = Object.fromEntries(months.map(month => [month, 0]));
      // const outOfStockD = Object.fromEntries(months.map(month => [month, 0]));
  
      // salesData[0].forEach(row => {
      //   const monthIndex = new Date(row.month + "-01").getMonth();
      //   instockD[months[monthIndex]] = row.instock|| 0;
      // });
      // salesData[0].forEach(row => {
      //   const monthIndex = new Date(row.month + "-01").getMonth();
      //   outOfStockD[months[monthIndex]] = row.out_of_stock|| 0;
      // });
  
      res.status(200).send({
        status: "success",
        data: {
          months,
          instock: instockD,
          out_of_stock: outOfStockD
        }
      });
    } catch (error) {
      console.log(error);
      res.status(500).send({
        status: "error",
        message: error.message
      });
    }
  };



export const TempRegister = async (req, res) => {
const { 
    p_username, 
    p_mobileno, 
    p_email, 
    p_password, 
    p_name, 
    p_schoolcodes, 
    p_fullAddress, 
    p_locationDetails, 
    p_landmark, 
    p_city, 
    p_state, 
    p_country, 
    p_pincode, 
    p_alternatemobileno, 
    p_isprimary, 
    p_iswork, 
    p_status 
} = req.body;

try {
    console.log('Received TempRegister request with data:', req.body);

    // Check if required parameters exist
    if (!p_username || !p_mobileno || !p_email || !p_password) {
        return res.status(400).send({
            status: 'FAILURE',
            message: 'Missing required fields'
        });
    }

    // Retrieve role ID
    const roleResult = await db.query(`SELECT rolesid FROM roles WHERE name = 'online'`);
    const p_roleid = roleResult[0]?.rolesid;

    if (!p_roleid) {
        return res.status(404).send({
            status: 'FAILURE',
            message: 'Role not found'
        });
    }

    // Check for existing user data
    const [usernameCount] = await db.query(`SELECT COUNT(*) as count FROM users WHERE username = ?`, [p_username]);
    const [mobilenoCount] = await db.query(`SELECT COUNT(*) as count FROM users WHERE mobileno = ?`, [p_mobileno]);
    const [emailCount] = await db.query(`SELECT COUNT(*) as count FROM users WHERE email = ?`, [p_email]);

    if (usernameCount.count > 0) {
        return res.status(400).send({ status: 'FAILURE', message: 'Username already exists' });
    }
    if (mobilenoCount.count > 0) {
        return res.status(400).send({ status: 'FAILURE', message: 'Mobile number already exists' });
    }
    if (emailCount.count > 0) {
        return res.status(400).send({ status: 'FAILURE', message: 'Email already exists' });
    }

    // Validate mobile number and pin code
    if (p_mobileno.length !== 10) {
        return res.status(400).send({ status: 'FAILURE', message: 'Mobile number must be 10 digits' });
    }
    if (p_pincode.length !== 6) {
        return res.status(400).send({ status: 'FAILURE', message: 'Pin code must be 6 digits' });
    }
    if (p_email && !/^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}$/.test(p_email)) {
        return res.status(400).send({ status: 'FAILURE', message: 'Invalid email format' });
    }

    // Validate school codes
    const schoolCodes = JSON.parse(p_schoolcodes);
    let validSchools = true;

    for (let code of schoolCodes) {
        const [school] = await db.query(`SELECT schoolid FROM school WHERE schoolcode = ?`, [code]);
        if (!school) {
            validSchools = false;
            break;
        }
    }

    if (!validSchools) {
        return res.status(400).send({
            status: 'FAILURE',
            message: 'One or more school codes not found'
        });
    }

    // Mark old registrations as deleted
    await db.query(
        `UPDATE temp_register SET deleted_at = CURRENT_TIMESTAMP WHERE mobileno = ? AND deleted_at IS NULL`,
        [p_mobileno]
    );

    // Insert new temp registration
    const result = await db.query(
        `INSERT INTO temp_register (mobileno, json_data) VALUES (?, ?)`,
        [
            p_mobileno,
            JSON.stringify({
                username: p_username,
                password: p_password,
                name: p_name,
                email: p_email,
                schoolcodes: p_schoolcodes,
                fullAddress: p_fullAddress,
                locationDetails: p_locationDetails,
                landmark: p_landmark,
                city: p_city,
                state: p_state,
                country: p_country,
                pincode: p_pincode,
                alternatemobileno: p_alternatemobileno,
                isprimary: p_isprimary,
                iswork: p_iswork,
                status: p_status,
                roleid: p_roleid
            })
        ]
    );

    if (result.affectedRows > 0) {
        res.status(200).send({
            status: 'SUCCESS',
            message: 'Data temporarily registered, pending OTP verification'
        });
    } else {
        res.status(500).send({
            status: 'FAILURE',
            message: 'Failed to register data'
        });
    }
} catch (error) {
    console.error('Error in TempRegister:', error);
    res.status(500).send({
        status: 'FAILURE',
        message: 'Internal Server Error'
    });
}
};


export const registerUser = async (req, res) => {
    const {
        username: p_username,
        password: p_password,
        name: p_name,
        email: p_email,
        mobileno: p_mobileno,
        schoolcodes: p_schoolcodes,
        Address1: p_Address1,
        Address2: p_Address2,
        Address3: p_Address3,
        Address4: p_Address4,
        Address5: p_Address5,
        Address6: p_Address6,
        Address7: p_Address7,
        Address8: p_Address8,
        Landmark: p_Landmark,
        city: p_city,
        state: p_state,
        country: p_country,
        pincode: p_pincode,
        alternatemobileno: p_alternatemobileno,
        isprimary: p_isprimary,
        iswork: p_iswork,
        status: p_status,
        createdby: p_createdby,
        createdon: p_createdon,
    } = req.body;

    let p_result_status = "FAILURE";
    let p_result_message = "";

    try {
        // Check if username, mobile number, or email already exists
        const usernameCount = await db.query(`SELECT COUNT(*) AS count FROM users WHERE username = ?`, [p_username]);
        const mobileCount = await db.query(`SELECT COUNT(*) AS count FROM users WHERE mobileno = ?`, [p_mobileno]);
        const emailCount = await db.query(`SELECT COUNT(*) AS count FROM users WHERE email = ?`, [p_email]);

        if (usernameCount[0]?.count > 0) {
            return res.status(400).json({ status: "FAILURE", message: "Username already exists" });
        }

        if (mobileCount[0]?.count > 0) {
            return res.status(400).json({ status: "FAILURE", message: "Mobile number already exists" });
        }

        if (emailCount[0]?.count > 0) {
            return res.status(400).json({ status: "FAILURE", message: "Email already exists" });
        }

        // Validate phone number and pincode
        if (p_mobileno.length !== 10) {
            return res.status(400).json({ status: "FAILURE", message: "Mobile number must be a 10-digit number" });
        }

        if (p_pincode.length !== 6) {
            return res.status(400).json({ status: "FAILURE", message: "Pincode must be a 6-digit number" });
        }

        // Validate email format
        const emailRegex = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
        if (p_email && !emailRegex.test(p_email)) {
            return res.status(400).json({ status: "FAILURE", message: "Invalid email format" });
        }

        // Check and validate school codes
        const schoolCodes = JSON.parse(p_schoolcodes);
        for (const code of schoolCodes) {
            const school = await db.query(`SELECT schoolid FROM school WHERE schoolcode = ?`, [code]);
            if (school.length === 0) {
                return res.status(400).json({ status: "FAILURE", message: `Invalid school code: ${code}` });
            }
        }

        // Insert new user
        const userInsert = await db.query(
            `INSERT INTO users (username, password, name, email, mobileno) VALUES (?, ?, ?, ?, ?)`,
            [p_username, p_password, p_name, p_email, p_mobileno]
        );
        const v_user_id = userInsert.insertId;

        // Insert school mappings
        for (const code of schoolCodes) {
            const school = await db.query(`SELECT schoolid FROM school WHERE schoolcode = ?`, [code]);
            const schoolId = school[0]?.schoolid;
            if (schoolId) {
                await db.query(`INSERT INTO usersschoolmap (userid, schoolid) VALUES (?, ?)`, [v_user_id, schoolId]);
            }
        }

        // Insert address via stored procedure
        const addressInsert = await db.query(
            `CALL SP_InsertAddress(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, @v_result_status, @v_result_message)`,
            [
                v_user_id,
                p_name,
                p_Address1,
                p_Address2,
                p_Address3,
                p_Address4,
                p_Address5,
                p_Address6,
                p_Address7,
                p_Address8,
                p_Landmark,
                p_city,
                p_state,
                p_country,
                p_pincode,
                p_email,
                p_mobileno,
                p_alternatemobileno,
                p_isprimary,
                p_iswork,
                p_status,
                p_createdby,
                p_createdon,
            ]
        );

        // Assign role to user
        const roleIdQuery = await db.query(`SELECT rolesid FROM roles WHERE name = 'online'`);
        const p_roleid = roleIdQuery[0]?.rolesid;

        if (p_roleid) {
            await db.query(`CALL SP_AssignRoleToUser(?, ?, @v_result_status, @v_result_message)`, [v_user_id, p_roleid]);
        } else {
            return res.status(400).json({ status: "FAILURE", message: 'Role "online" not found' });
        }

        // Return success response
        p_result_status = "SUCCESS";
        p_result_message = "Signup Successful";
        res.status(200).json({ status: p_result_status, message: p_result_message });
    } catch (error) {
        console.error("Error in registerUser:", error);
        res.status(500).json({ status: "FAILURE", message: "Internal Server Error" });
    }
};


export const verifyOTPAndRegisterUser = async (req, res) => {
    const { mobileno: p_mobileno, otpcode: p_otpcode } = req.body;

    const p_transtime = new Date().toLocaleString("en-US", { timeZone: "Asia/Kolkata" });
    let p_result_status = "ERROR";
    let p_result_message = "";

    try {
        // Verify OTP validity
        const otpResult = await db.query(
            `SELECT validity FROM otptable WHERE mobileno = ? AND otpcode = ? AND status = 1 ORDER BY id DESC LIMIT 1`,
            [p_mobileno, p_otpcode]
        );

        if (otpResult.length === 0 || new Date(otpResult[0].validity) <= new Date(p_transtime)) {
            return res.status(400).json({ status: "ERROR", message: "Invalid OTP or OTP expired" });
        }

        // Fetch user JSON data
        const tempRegisterResult = await db.query(
            `SELECT json_data FROM temp_register WHERE mobileno = ? AND deleted_at IS NULL LIMIT 1`,
            [p_mobileno]
        );

        if (tempRegisterResult.length === 0) {
            return res.status(400).json({ status: "ERROR", message: "User details not found. Try again later." });
        }

        const v_json_data = JSON.parse(tempRegisterResult[0].json_data);

        // Extract JSON data into variables
        const {
            username: v_username,
            password: v_password,
            name: v_name,
            email: v_email,
            schoolcodes: v_schoolcodes,
            fullAddress: v_fullAddress,
            locationDetails: v_locationDetails,
            landmark: v_landmark,
            city: v_city,
            state: v_state,
            country: v_country,
            pincode: v_pincode,
            alternatemobileno: v_alternatemobileno,
        } = v_json_data;

        const v_status = 1;

        // Mark OTP as used
        await db.query(`UPDATE otptable SET status = 0 WHERE mobileno = ? AND otpcode = ?`, [p_mobileno, p_otpcode]);

        // Mark the temp_register entry as deleted
        await db.query(`UPDATE temp_register SET deleted_at = ? WHERE mobileno = ? AND deleted_at IS NULL`, [
            p_transtime,
            p_mobileno,
        ]);

        // Insert into the users table
        const userInsertResult = await db.query(
            `INSERT INTO users (username, password, name, email, mobileno) VALUES (?, ?, ?, ?, ?)`,
            [v_username, v_password, v_name, v_email, p_mobileno]
        );

        const v_user_id = userInsertResult.insertId;

        // Insert school mappings
        for (const code of v_schoolcodes) {
            const schoolResult = await db.query(`SELECT schoolid FROM school WHERE schoolcode = ?`, [code]);
            if (schoolResult.length > 0) {
                const schoolId = schoolResult[0].schoolid;
                await db.query(
                    `INSERT IGNORE INTO usersschoolmap (userid, schoolid) VALUES (?, ?)`,
                    [v_user_id, schoolId]
                );
            }
        }

        // Insert into the address table
        await db.query(
            `INSERT INTO address (
                userid, name, fullAddress, locationDetails, landmark, city, state, country, 
                pincode, email, mobileno, alternatemobileno, status, 
                createdby, createdon, lastmodifiedby, lastmodifiedate
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                v_user_id,
                v_name,
                v_fullAddress,
                v_locationDetails,
                v_landmark,
                v_city,
                v_state,
                v_country,
                v_pincode,
                v_email,
                p_mobileno,
                v_alternatemobileno,
                v_status,
                v_user_id,
                p_transtime,
                v_user_id,
                p_transtime,
            ]
        );

        // Assign role to the user
        const roleResult = await db.query(`SELECT rolesid FROM roles WHERE name = 'online' LIMIT 1`);
        if (roleResult.length > 0) {
            const p_roleid = roleResult[0].rolesid;
            await db.query(`INSERT INTO userrolemap (userid, roleid) VALUES (?, ?)`, [v_user_id, p_roleid]);
        } else {
            return res.status(400).json({ status: "ERROR", message: 'Role "online" not found' });
        }

        // Success response
        p_result_status = "SUCCESS";
        p_result_message = "OTP verification successful";

        res.status(200).json({ status: p_result_status, message: p_result_message });
    } catch (error) {
        console.error("Error in verifyOTPAndRegisterUser:", error);
        res.status(500).json({ status: "ERROR", message: "Internal Server Error" });
    }
};


// 10-12-2024
// Insert Transaction
export const insertTransaction_10_12_2024 = async (req, res) => {

    await db.query("SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))");
    await db.query('START TRANSACTION');

    try {
        const { userid, addressid, gst_id, tax_amount, quantity,shipping_charges, total_amount, status } = req.body;

        const productid = req.body.productid
        console.log('productid', productid);

        // const productidArray = JSON.parse(productid).length == 0 ? 0 : JSON.parse(productid);
        const productidArray = productid.length == 0 ? 0 : productid;
        console.log('productidArray', productidArray);
        
        let userCheckQuery = `SELECT userid FROM users WHERE userid = '${userid}' LIMIT 1`;
        const userCheckData = await db.query(userCheckQuery);
        const userExists = userCheckData[0][0] ? userCheckData[0][0]?.userid : 0

        console.log('userExists', userExists);
    
        if (userExists == 0 || !userExists) {
            console.log('User-ID not found');
            return res.status(404).send({
                status: false,
                message: 'User-ID not found',
            });
        }
    
        let productCheckQuery = `SELECT productid FROM product WHERE productid IN (${productidArray}) LIMIT 1`;
        const productCheckData = await db.query(productCheckQuery);
        const productExists = productCheckData[0][0] ? productCheckData[0][0]?.productid : 0

        console.log('productExists', productExists);

        if (productExists == 0 || !productExists) {
            console.log('Product-ID not found');
            return res.status(404).send({
                status: false,
                message: 'Product-ID not found',
            });
        }
        // AND status != 'Ordered'

        let getATC = ` SELECT * FROM addtocarttable WHERE userid = '${userid}' AND status != 'Ordered' AND productid IN (${productidArray}) `
        const ATC_ID = await db.query(getATC);
        console.log('ATC_ID data', ATC_ID[0]);      
        
        const ATCEmpty = ATC_ID[0][0] ? ATC_ID[0][0]?.atcartid : 0
        
        if (ATCEmpty == 0 || !ATCEmpty) {
            console.log('Add To Cart Empty');
            return res.status(404).send({
                status: false,
                message: 'Add To Cart Empty',
            });
        }
        
        const variant_array = ATC_ID[0]?.map(i => i.variantid);
        const variantData =  variant_array.length != 0 ? variant_array?.join(',') : 0
        console.log('variant_array', variantData);
        console.log('variant_array_length', variant_array.length);

        let variantQuery = ` SELECT * FROM variant WHERE id IN (${variantData}) `
        const variantID = await db.query(variantQuery);
        console.log('variantID data', variantID[0]);  

        let transactionBillingQuery = `
        INSERT INTO transaction_billing (ccavenue_transid, status, createdon, lastmodifiedate) VALUES (${null},'${status}','${formattedDateTime}','${formattedDateTime}') `;
        const transactionResultBilling = await db.query(transactionBillingQuery);
        const billAutoId = transactionResultBilling[0];
        console.log('transactionResultBilling', transactionResultBilling);

        // let totalPriceGst = 0; 
        // let totalWeight = 0;

        let TBillingPrice = 0;
        let TBillingWeight = 0;
        let TotalGstPercent = 0;

        let index = 0; 

        for (const productId of productidArray) {

            const productVariant = ATC_ID[0].find(item => item.productid === productId);

            console.log('productVariant', productVariant);
            
            let ATCvariantQuantity = productVariant ? productVariant.quantity : 0;
            const productVariantID = productVariant ? productVariant.variantid : 0;

            const variantList = variantID[0].find(item => item.productid === productId);
            console.log('variantList', variantList);  

            const productVariantPrice = variantList ? variantList.price : 0;
            const productVariantWeight = variantList ? variantList.weight : 0;
            let productVariantQuantity = variantList ? variantList.quantity : 0;

            // const gstArray = 1;
            const gstArray = (!gst_id || gst_id.length == 0) ? undefined : gst_id[index];
            console.log('gst_array', gstArray);

            console.log('ATCvariantQuantity', ATCvariantQuantity);  
            console.log('productVariantQuantity', productVariantQuantity);  

            const today = new Date().toISOString().slice(0, 10);
            console.log('today', today);
    
            // let counterQuery = `
            // INSERT INTO daily_reset_counter (counter_date, counter_value) VALUES ('${today}', 1) ON DUPLICATE KEY UPDATE counter_value = counter_value + 1 `;
            // const counterInsert = await db.query(counterQuery);
        
            // let counterSelectQuery = `SELECT counter_value FROM daily_reset_counter WHERE counter_date = '${today}' `;
            // const counterData = await db.query(counterSelectQuery);
            // let counterValue = counterData[0][0] ? counterData[0][0]?.counter_value : 0
    
            // console.log('counterValue', counterValue);

            // const orderNumber = `2CQR-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
            // const transId = `Trans-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;

            // let transactionInsertQuery = `
            // INSERT INTO transactions (productid, userid, childbillid, status) VALUES ('${productId}', '${userid}', '${transactionResultBilling[0]}','${status || 'Initiated '}')`;
            // const transactionResult = await db.query(transactionInsertQuery);

            
            let TVariantPrice1 = 0;
            let TVariantWeight1 = 0;

            if (productVariantQuantity > 0) {
                let counterQuery = `
                INSERT INTO daily_reset_counter (counter_date, counter_value) VALUES ('${today}', 1) ON DUPLICATE KEY UPDATE counter_value = counter_value + 1 `;
                const counterInsert = await db.query(counterQuery);
            
                let counterSelectQuery = `SELECT counter_value FROM daily_reset_counter WHERE counter_date = '${today}' `;
                const counterData = await db.query(counterSelectQuery);
                let counterValue = counterData[0][0] ? counterData[0][0]?.counter_value : 0
        
                const orderNumber = `2CQR-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
                const transId = `Trans-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
                let inStockQuantity = Math.min(productVariantQuantity, ATCvariantQuantity);

                console.log('productVariantQuantity', productVariantQuantity);  
                console.log('ATCvariantQuantity', ATCvariantQuantity);  
                console.log('inStockQuantity', inStockQuantity);  

                let TVariantPrice = productVariantPrice * inStockQuantity
                let TVariantWeight = productVariantWeight * inStockQuantity
    
                console.log('TVariantPrice', TVariantPrice);  
                console.log('TVariantWeight', TVariantWeight);  

                TBillingPrice += TVariantPrice;
                TBillingWeight += TVariantWeight;    
                
                TVariantPrice1 += TVariantPrice
                TVariantWeight1 += TVariantWeight

                let inStockQuery = `
                    INSERT INTO transactions (productid, userid, addressid, transid, ordernumber, variant, tpricegst, tweight, childbillid, gst_id, quantity, status, online) 
                    VALUES ('${productId}', '${userid}', '${addressid}', '${transId}', '${orderNumber}', '${productVariantID}', '${TVariantPrice}', '${TVariantWeight}', '${transactionResultBilling[0]}','${gstArray}','${inStockQuantity}', 'instock',1)
                `;
                const transactionResult = await db.query(inStockQuery);

                let transactionLogQuery = `
                INSERT INTO transactionlog (transtableid, status, createdby) VALUES ('${transactionResult[0]}', 'instock', '${userid}')`;
                const transactionResultLog = await db.query(transactionLogQuery);
                console.log('transactionResultLog', transactionResultLog);

                console.log('jgfhghfgghfh', ATCvariantQuantity,inStockQuantity );
                ATCvariantQuantity -= inStockQuantity;
            }
            
            if (ATCvariantQuantity > 0) {
                let counterQuery = `
                INSERT INTO daily_reset_counter (counter_date, counter_value) VALUES ('${today}', 1) ON DUPLICATE KEY UPDATE counter_value = counter_value + 1 `;
                const counterInsert = await db.query(counterQuery);
            
                let counterSelectQuery = `SELECT counter_value FROM daily_reset_counter WHERE counter_date = '${today}' `;
                const counterData = await db.query(counterSelectQuery);
                let counterValue = counterData[0][0] ? counterData[0][0]?.counter_value : 0
        
                const orderNumber = `2CQR-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
                const transId = `Trans-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;

                console.log('inStockQuantity', ATCvariantQuantity);  

                let TVariantPrice = productVariantPrice * ATCvariantQuantity
                let TVariantWeight = productVariantWeight * ATCvariantQuantity
    
                console.log('TVariantPrice', TVariantPrice);  
                console.log('TVariantWeight', TVariantWeight);  

                TBillingPrice += TVariantPrice;
                TBillingWeight += TVariantWeight;   
                
                TVariantPrice1 += TVariantPrice
                TVariantWeight1 += TVariantWeight

                let outOfStockQuery = `
                    INSERT INTO transactions (productid, userid, addressid, transid, ordernumber, variant, tpricegst, tweight, childbillid, gst_id, quantity, status, online) 
                    VALUES ('${productId}', '${userid}', '${addressid}', '${transId}', '${orderNumber}','${productVariantID}', '${TVariantPrice}', '${TVariantWeight}', '${transactionResultBilling[0]}', '${gstArray}', '${ATCvariantQuantity}', 'outofstock', 1)
                `;
                const transactionResult = await db.query(outOfStockQuery);

                let transactionLogQuery = `
                INSERT INTO transactionlog (transtableid, status, createdby) VALUES ('${transactionResult[0]}', 'outofstock', '${userid}')`;
                const transactionResultLog = await db.query(transactionLogQuery);
                console.log('transactionResultLog', transactionResultLog);
            }

            console.log('product Variant Price & Weight ', productVariantPrice, productVariantWeight );

            const GSTChargeQuery = `
            SELECT tax AS total_tax FROM gst WHERE id = ${gstArray} ORDER BY id DESC `;
            const GSTChargeResult = await db.query(GSTChargeQuery);
            let GSTCharge = GSTChargeResult[0][0] ? GSTChargeResult[0][0]?.total_tax : 0;
            // TotalGstPercent += GSTCharge
            const productGSTAmount = (TVariantPrice1 * GSTCharge) / 100;
            console.log('TVariantPrice1', TVariantPrice1);
            
            TotalGstPercent += productGSTAmount;

            console.log('Product GST Amount:', productGSTAmount, 'GST Charge Percent:', GSTCharge);


            // totalPriceGst += productVariantPrice;
            // totalWeight += productVariantWeight;

            // let transactionLogQuery = `
            // INSERT INTO transactionlog (transtableid, status, createdby) VALUES ('${transactionResult[0]}', '${status}', '${userid}')`;
            // const transactionResultLog = await db.query(transactionLogQuery);
            
            // console.log('transactionResultLog', transactionResultLog);

            index++;
        }
        
            console.log('Order initiated successfully'); 

            // const shippingChargeQuery = `
            // SELECT charge FROM weightmasters WHERE weight <= ${TBillingWeight} ORDER BY weight DESC LIMIT 1`;
            const shippingChargeQuery = `
            SELECT id, charge 
            FROM weightmasters 
            WHERE ${TBillingWeight} BETWEEN startweightrange AND endweightrange 
            ORDER BY id DESC 
            LIMIT 1 `
            const shippingChargeResult = await db.query(shippingChargeQuery);
            const shippingCharge = shippingChargeResult[0][0] ? shippingChargeResult[0][0]?.charge : 0;
   
           // Calculate actual price
           const actualPrice = TBillingPrice;
        //    const GSTPrice = (TBillingPrice / TotalGstPercent);
        //    const GSTPrice = (TBillingPrice * TotalGstPercent) / 100;
           const GSTRoundPrice = Math.ceil(TotalGstPercent);
           const shippingChargeINT = parseInt(shippingCharge, 10);
           const transactionPrice = TBillingPrice + GSTRoundPrice + shippingChargeINT;

           console.log('TBillingPrice', TBillingPrice, TBillingWeight);
           console.log('actualPrice = ' , actualPrice, 'GSTRoundPrice = ', GSTRoundPrice, 'transactionPrice = ', transactionPrice, 'TotalGstPercent = ', TotalGstPercent, 'shippingChargeINT', shippingChargeINT, shippingCharge);

           const updateBillingQuery = `
            UPDATE transaction_billing 
            SET tpricegst = '${GSTRoundPrice}', tweight = '${TBillingWeight}', shipping_charges = '${shippingChargeINT}', actual_price = '${TBillingPrice}', transaction_price = '${transactionPrice}', payment_type = 'ccavenue' 
            WHERE id = '${billAutoId}'`;
            const updateBillData = await db.query(updateBillingQuery);

            const workingKey = '0BF202BFD501907C9D76C5443211629C';
            const accessCode = 'ATAD06LK05BU10DAUB';
            const merchantId = '204980';
            const currency = 'INR';
            const amount = transactionPrice;
            const language = 'EN';

            const formData = {
                merchant_id: merchantId,
                order_id: billAutoId,
                currency: currency,
                amount: amount,
                userid: userid,
                productid: productid,
                redirect_url: "http://localhost:5001/api/v1/Order/updateTransaction",
                cancel_url: "http://localhost:5001/api/v1/Order/updateTransaction",
                language: language
            };
  
            const params = new URLSearchParams(formData);
            const bodyData  = params.toString();  
            const encRequest = encrypt(bodyData, workingKey);

            const paymentLink = `https://test.ccavenue.com/transaction/transaction.do?command=initiateTransaction&encRequest=${encRequest}&access_code=${accessCode}`;

            res.status(200).send({
                status: true,
                message: 'Order initiated successfully',
                billAutoId: billAutoId,
                paymentLink: paymentLink
            });

            // const updateProbs = {productidArray, userid, billAutoId, status}

            // updateTransaction()
        
            await db.query('COMMIT');

    } catch (error) {
        console.log('error', error);
        res.status(500).json({
            status: false,
            message: 'Internal Server Error',
            error: error.message,
        });

        await db.query('ROLLBACK');
    }
};

for (const productId of productidArray) {
    const productVariants = ATC_ID[0].filter(item => item.productid === productId);

    console.log('productVariants', productVariants);

    // Iterate through each variant for the current productId
    for (const productVariant of productVariants) {
        const productVariantID = productVariant.variantid;
        const ATCvariantQuantity = productVariant.quantity;

        // Get variant details (price, weight, etc.)
        const variantList = variantID[0].find(item => item.id === productVariantID);
        console.log('variantList', variantList);

        const productVariantPrice = variantList ? variantList.price : 0;
        const productVariantWeight = variantList ? variantList.weight : 0;
        const productVariantQuantityInStock = variantList ? variantList.quantity : 0;

        const gstArray = gst_id.length > 0 ? gst_id[0] : undefined;  // Assuming a single GST id for each variant

        console.log('gst_array', gstArray);
        console.log('productVariantQuantity', productVariantQuantityInStock);

        const today = new Date().toISOString().slice(0, 10);
        let counterQuery = `
            INSERT INTO daily_reset_counter (counter_date, counter_value) 
            VALUES ('${today}', 1) ON DUPLICATE KEY UPDATE counter_value = counter_value + 1`;
        const counterInsert = await db.query(counterQuery);

        let counterSelectQuery = `SELECT counter_value FROM daily_reset_counter WHERE counter_date = '${today}'`;
        const counterData = await db.query(counterSelectQuery);
        let counterValue = counterData[0][0] ? counterData[0][0]?.counter_value : 0;

        const orderNumber = `2CQR-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;
        const transId = `Trans-${today.replace(/-/g, '')}-${String(counterValue).padStart(4, '0')}`;

        let inStockQuantity = Math.min(productVariantQuantityInStock, ATCvariantQuantity);
        console.log('inStockQuantity', inStockQuantity);

        let TVariantPrice = productVariantPrice * inStockQuantity;
        let TVariantWeight = productVariantWeight * inStockQuantity;

        TBillingPrice += TVariantPrice;
        TBillingWeight += TVariantWeight;

        const GSTChargeQuery = `SELECT tax AS total_tax FROM gst WHERE id = ${gstArray} ORDER BY id DESC`;
        const GSTChargeResult = await db.query(GSTChargeQuery);
        let GSTCharge = GSTChargeResult[0][0] ? GSTChargeResult[0][0]?.total_tax : 0;
        const productGSTAmount = (TVariantPrice * GSTCharge) / 100;

        TotalGstPercent += productGSTAmount;

        console.log('Product GST Amount:', productGSTAmount, 'GST Charge Percent:', GSTCharge);

        // Insert into transactions table
        let inStockQuery = `
            INSERT INTO transactions (productid, userid, addressid, transid, ordernumber, variant, tpricegst, tweight, childbillid, gst_id, quantity, status, online) 
            VALUES ('${productId}', '${userid}', '${addressid}', '${transId}', '${orderNumber}', '${productVariantID}', '${TVariantPrice}', '${TVariantWeight}', '${transactionResultBilling[0]}', '${gstArray}', '${inStockQuantity}', 'instock', 1)`;

        const transactionResult = await db.query(inStockQuery);

        let transactionLogQuery = `
            INSERT INTO transactionlog (transtableid, status, createdby) 
            VALUES ('${transactionResult[0]}', 'instock', '${userid}')`;
        const transactionResultLog = await db.query(transactionLogQuery);
        console.log('transactionResultLog', transactionResultLog);

        // Decrease the ATC quantity for this variant
        ATCvariantQuantity -= inStockQuantity;

        // If there is still remaining quantity, handle as out of stock
        if (ATCvariantQuantity > 0) {
            let outOfStockQuery = `
                INSERT INTO transactions (productid, userid, addressid, transid, ordernumber, variant, tpricegst, tweight, childbillid, gst_id, quantity, status, online) 
                VALUES ('${productId}', '${userid}', '${addressid}', '${transId}', '${orderNumber}', '${productVariantID}', '${TVariantPrice}', '${TVariantWeight}', '${transactionResultBilling[0]}', '${gstArray}', '${ATCvariantQuantity}', 'outofstock', 1)`;

            const outOfStockTransactionResult = await db.query(outOfStockQuery);

            let outOfStockTransactionLogQuery = `
                INSERT INTO transactionlog (transtableid, status, createdby) 
                VALUES ('${outOfStockTransactionResult[0]}', 'outofstock', '${userid}')`;
            const outOfStockTransactionResultLog = await db.query(outOfStockTransactionLogQuery);
            console.log('outOfStockTransactionResultLog', outOfStockTransactionResultLog);
        }
    }
}

// Calculate total shipping charges
const shippingChargeQuery = `
    SELECT id, charge 
    FROM weightmasters 
    WHERE ${TBillingWeight} BETWEEN startweightrange AND endweightrange 
    ORDER BY id DESC 
    LIMIT 1`;
const shippingChargeResult = await db.query(shippingChargeQuery);
const shippingCharge = shippingChargeResult[0][0] ? shippingChargeResult[0][0]?.charge : 0;

// Calculate actual price and transaction price
const GSTRoundPrice = Math.ceil(TotalGstPercent);
const shippingChargeINT = parseInt(shippingCharge, 10);
const transactionPrice = TBillingPrice + GSTRoundPrice + shippingChargeINT;

console.log('TBillingPrice', TBillingPrice, TBillingWeight);
console.log('transactionPrice = ', transactionPrice, 'shippingChargeINT', shippingChargeINT);

// Update billing information in transaction_billing table
const updateBillingQuery = `
    UPDATE transaction_billing 
    SET tpricegst = '${GSTRoundPrice}', tweight = '${TBillingWeight}', shipping_charges = '${shippingChargeINT}', actual_price = '${TBillingPrice}', transaction_price = '${transactionPrice}', payment_type = 'ccavenue' 
    WHERE id = '${billAutoId}'`;

const updateBillData = await db.query(updateBillingQuery);

// Proceed with generating payment link
const workingKey = '0BF202BFD501907C9D76C5443211629C';
const accessCode = 'ATAD06LK05BU10DAUB';
const merchantId = '204980';
const currency = 'INR';
const amount = transactionPrice;
const language = 'EN';

const formData = {
    merchant_id: merchantId,
    order_id: billAutoId,
    currency: currency,
    amount: amount,
    userid: userid,
    productid: productid,
    redirect_url: "http://localhost:5001/api/v1/Order/updateTransaction",
    cancel_url: "http://localhost:5001/api/v1/Order/updateTransaction",
    language: language
};

const params = new URLSearchParams(formData);
const bodyData = params.toString();
const encRequest = encrypt(bodyData, workingKey);

const paymentLink = `https://test.ccavenue.com/transaction/transaction.do?command=initiateTransaction&encRequest=${encRequest}&access_code=${accessCode}`;

res.status(200).send({
    status: true,
    message: 'Order initiated successfully',
    billAutoId: billAutoId,
    paymentLink: paymentLink
});

await db.query('COMMIT');

// const workingKey = '0BF202BFD501907C9D76C5443211629C';
// const accessCode = 'ATAD06LK05BU10DAUB';
// const merchantId = '204980';
// const currency = 'INR';
// const amount = transactionPrice;
// const language = 'EN';


// 12-12-2024
// Add Product
export const addProduct = async (req, res) => {

    await db.query('START TRANSACTION');
    // [{size: 24, color: "red", price: 550, quantity: 50, imageid: 3, weight: 50},{size: 30, color: "green", price: 1020, quantity: 5}
    // ]

    // [{"size": 24, "color": "red", "price": 550, "quantity": 50, "imageid": 3, "weight": 50},{"size": 30, "color": "green", "price": 1020, "quantity": 5}
    // ]

    try {
        
        const { barcode, masterid, name, description, price, gst, gender, weight, discount, productstatus, published, quantity, createdon, createdby } = req.body;

        const { schoolid, imageseq, schoolgrade } = req.body;

        const variants = req.body.variants
        // const pOutput = JSON.parse(variants);
        const parsedOutput = JSON.parse(variants);
        // const parsedOutput = variants;

        const schoolgradeArray = JSON.parse(schoolgrade).length == 0 ? 0 : JSON.parse(schoolgrade);
        const schoolIdArray = JSON.parse(schoolid).length == 0 ? 0 : JSON.parse(schoolid);

        console.log('schoolgradeArray',schoolgradeArray);
        console.log('schoolIdArray',schoolIdArray);
        console.log('schoolgrade',schoolgrade.length);

        let thisQueryS = ` SELECT DISTINCT sgm.gradeid as gradeid FROM schoolgrademap as sgm WHERE sgm.schoolid IN (${schoolIdArray}) `
        const dataSCH = await db.query(thisQueryS);
        const getSchoolGradeID = dataSCH[0].map(i => i.gradeid)

        let thisQueryGra = ` SELECT DISTINCT sgm.gradeid as gradeid FROM schoolgrademap as sgm WHERE sgm.gradeid IN (${schoolgradeArray}) `
        const dataGra = await db.query(thisQueryGra);
        const getGradeID = dataGra[0].map(i => i.gradeid)
        console.log('getGradeID', getGradeID);
        console.log('getSchoolGradeID', getSchoolGradeID);
        
        const schoolCheck = getGradeID.every(value => getSchoolGradeID.includes(value));
        console.log('schoolCheck', schoolCheck);

        let thisQueryP = ` SELECT p.* FROM product as p WHERE p.name = "${name}" `
        const dataP = await db.query(thisQueryP);

        let thisQueryM = ` SELECT m.* FROM category as m WHERE m.id = "${masterid}" `
        const dataM = await db.query(thisQueryM);

        let thisQueryGST = ` SELECT * FROM gst WHERE id = '${gst}' `
        const dataGST = await db.query(thisQueryGST);

        let thisQueryG = ` SELECT md.* FROM gender as md WHERE md.id = "${gender}" `
        const dataG = await db.query(thisQueryG);

        const FieldCheck = dataP[0][0] ? dataP[0][0]?.name : 0
        const masterCheck = dataM[0][0] ? dataM[0][0]?.masterid : 0
        // const schoolCheck = dataS[0][0] ? dataS[0][0]?.schoolid : 0
        const gstCheck = dataGST[0][0] ? dataGST[0][0]?.id : 0
        const genCheck = dataG[0][0] ? dataG[0][0]?.dataid : 0

        if (FieldCheck != 0) {
            console.log(`Product name already exists`);
            res.status(409).send({
                status: false,
                message: `product name already exists`,
            });
        } 
        else if (masterCheck == 0 || masterid == undefined) {
            res.status(404).send({
                status: false,
                message: `master-id not found`,
            });
        }
        else if (genCheck == 0 || gender == undefined) {
            res.status(404).send({
                status: false,
                message: `gender-id not found`,
            });
        }
        else if (gstCheck == 0 || gst == undefined) {
            res.status(404).send({
                status: false,
                message: `gst-id not found`,
            });
        }
        else if (schoolCheck == false || schoolIdArray == 0 || schoolgradeArray == 0) {
            res.status(404).send({
                status: false,
                message: `school not found`,
            });
        }
        else {

        // [{"size":"6","color":"red","price":5.00,"quantity":89,"weight":6}]
        // "[{\"size\":\"6\",\"color\":\"red\",\"price\":5.00,\"quantity\":89,\"weight\":6}]"
        // [ { size: '6', color: 'red', price: 5, quantity: 89, weight: 6 } ]
        // console.log(pOutput);

        // const parsedOutput = JSON.parse(pOutput).map(item => ({
        //     size: item.size,
        //     color: item.color,
        //     price: item.price,
        //     quantity: item.quantity,
        //     ...(item.imageid !== undefined && { imageid: item.imageid }),
        //     ...(item.weight !== undefined && { weight: item.weight })
        //   }));
          
        console.log(parsedOutput);

        let image = "";
  
        if (req.files.image) {
          const extension = req.files.image[0]["mimetype"].split('/')[1]
          image = req.files.image[0]["filename"] + '.' + extension
        }

        let thisQuery = ` INSERT INTO product ( masterid, name, description, price, gst, gender, weight, productstatus, published, quantity, createdon, lastmodifiedate, lastmodifiedby, createdby)
        VALUES ( '${masterid}', "${name}", "${description}", '${price}', '${gst}', '${gender}', '${weight}', "${productstatus ? productstatus : 'instock'}", '${published ? published : 0}', '${quantity}', '${formattedDateTime}', '${formattedDateTime}','${createdby ? createdby : 0}', '${createdby ? createdby : 0}' ) `
 
        const data = await db.query(thisQuery); 

        console.log(data[0]);
        
        const InsertId = data[0]; 

        // let thisQueryNew = `INSERT INTO variant (productid, size) VALUES (${InsertId}, '001') `
        // const dataNew = await db.query(thisQueryNew); 

        const schoolidArr = JSON.parse(schoolgrade);
        const schoolLength = schoolidArr?.length;
        console.log(schoolLength);

        for (const num of schoolidArr) {
            let thisQueryPSM = ` INSERT INTO productschoolmap (productid, schoolid) VALUES ( '${InsertId}', '${num}' ) `
            const dataPSM = await db.query(thisQueryPSM); 
            console.log(num);
        }

        if (req.files.image) {
            if (req.files.image.length > 0) {
                // Parse the image sequence
                const imageseqArr = JSON.parse(imageseq);
                
                for (let i = 0; i < req.files.image.length; i++) {
                    if (req.files.image[i]) {
                        const extension = req.files.image[i]["mimetype"].split('/')[1];
                        const image = `${req.files.image[i]["filename"]}.${extension}`;
                        
                        console.log(image);
                        console.log(req.files.image.length);
                        console.log(imageseqArr.length);
        
                        // Check if we have enough sequence numbers for the images
                        if (imageseqArr.length > i) {
                            const num2 = imageseqArr[i];  // Get the corresponding sequence number
                            const thisQueryPimage = `INSERT INTO productimage (productid, imageseq, image) VALUES ('${InsertId}', '${num2}', '${image}')`;
                            await db.query(thisQueryPimage);
        
                            console.log(num2);
        
                            const currentPath = path.join(process.cwd(), "uploads", req.files.image[i]["filename"]);
                            const destinationPath = path.join(process.cwd(), "uploads/product/image/" + `${InsertId}` + `/${num2}`, image);
                            const baseUrl = path.join(process.cwd(), "uploads/product/image", `${InsertId}`, `${num2}`);
                            fs.mkdirSync(baseUrl, { recursive: true });
        
                            fs.rename(currentPath, destinationPath, function (err) {
                                if (err) {
                                    throw err;
                                } else {
                                    console.log("Successfully image Uploaded!");
                                }
                            });
                        } else {
                            console.warn(`Not enough sequence numbers for image ${image}. Expected index ${i}, but got ${imageseqArr?.length}.`);
                        }
                    }
                }
            }
        }

        // for (const variant of parsedOutput) {
        //     const thisQueryVariant = `
        //         INSERT INTO variant (productid, size, color, price, quantity, imageid, weight)
        //         VALUES (
        //             '${InsertId}',
        //             '${variant?.size}', 
        //             '${variant?.color}', 
        //             '${variant?.price}', 
        //             '${variant?.quantity}', 
        //             '${variant?.imageid != undefined ? variant?.imageid : 0}', 
        //             '${variant?.weight != undefined ? variant?.weight : 0}'
        //         )
        //     `;
        //     const dataVariant = await db.query(thisQueryVariant); 
        // }

        // for (const variant of parsedOutput) {
        //     const size = variant?.size;
        //     const color = variant?.color;
        //     const price = variant?.price;
        //     const quantity = variant?.quantity;
        //     const imageid = variant?.imageid !== undefined ? variant?.imageid : 0;
        //     const weight = variant?.weight !== undefined ? variant?.weight : 0;
        
        //     // Check if the record already exists
        //     const checkQuery = `
        //         SELECT COUNT(*) AS count 
        //         FROM variant 
        //         WHERE productid = '${InsertId}' AND size = '${size}' AND color = '${color}'
        //     `;
        //     const checkResult = await db.query(checkQuery);
        //     console.log('checkResult', checkResult, checkResult[0][0]?.count);
            
            
        //     if (checkResult[0][0]?.count === 0) {
        //         let insertQuery = `
        //             INSERT INTO variant (productid, size, color, price, quantity, imageid, weight)
        //             VALUES (
        //                 '${InsertId}',
        //                 '${size}', 
        //                 '${color}', 
        //                 '${price}', 
        //                 '${quantity}', 
        //                 '${imageid}', 
        //                 '${weight}'
        //             )
        //         `;
        //         const dataVariant = await db.query(insertQuery);
        //     }
        // }

        for (const variant of parsedOutput) {
            // Check if the variant already exists
            let checkVariantQuery = `
                SELECT COUNT(*) as count 
                FROM variant 
                WHERE productid = '${InsertId}' 
                AND size = '${variant?.size}' 
                AND color = '${variant?.color}'
            `;
            const existingVariant = await db.query(checkVariantQuery);
            
            if (existingVariant[0][0].count > 0) {
                return res.status(409).send({
                    status: false,
                    message: `Variant with size : ${variant?.size} and color : ${variant?.color} already exists for this product.`,
                });
            } else {
                const thisQueryVariant = `
                    INSERT INTO variant (productid, size, color, price, quantity, imageid, weight)
                    VALUES (
                        '${InsertId}',
                        '${variant?.size}', 
                        '${variant?.color}', 
                        '${variant?.price}', 
                        '${variant?.quantity}', 
                        '${variant?.imageid != undefined ? variant?.imageid : 0}', 
                        '${variant?.weight != undefined ? variant?.weight : 0}'
                    )
                `;
                await db.query(thisQueryVariant); 
            }
        }
        
        
        // let insertQueryD = ` DELETE FROM variant WHERE productid = ${InsertId} AND size = '001' `
        // const dataDelete = await db.query(insertQueryD);
        
        res.status(200).send({
          issuccess: true, 
          p_result_status : 'SUCCESS',
          p_result_message : 'Product added successfully',
        //   ProductData:dataResult[0]
        });
        await db.query('COMMIT');
      } 
      } 
      catch (error) {
        console.log(error);
        res.status(500).json({ error: 'Internal Server Error', message: error.message });

        await db.query('ROLLBACK');
    }
};


for (const variant of parsedOutput) {
    let checkVariantQuery = `
    SELECT COUNT(*) as count 
    FROM variant 
    WHERE productid = '${InsertId}' 
    AND size = '${variant?.size}' 
    AND color = '${variant?.color}'
`;
    const existingVariant = await db.query(checkVariantQuery);    
    console.log('variant Loop', variant)        

    if (existingVariant[0][0].count > 0) {
        return res.status(409).send({
            status: false,
            message: `Variant with size : ${variant?.size} and color : ${variant?.color} already exists for this product.`,
        });
    } else {

        console.log('timeX', variant);
        
        for (let i = 0; i < req.files.variant_image.length; i++) {
            console.log('samevalue', req.files.variant_image.length);
            console.log('ffffXXXXX', req.files.variant_image[i]);
            if (req.files.variant_image[i]) {
                const extension = req.files.variant_image[i]["mimetype"].split('/')[1];
                const variant_image = `${req.files.variant_image[i]["filename"]}.${extension}`;

                console.log(variant_image);
                console.log(req.files.variant_image.length);
                const thisQueryVariant = `
        INSERT INTO variant (productid, size, color, price, quantity, imageid, weight)
        VALUES (
            '${InsertId}',
            '${variant?.size}', 
            '${variant?.color}', 
            '${variant?.price}', 
            '${variant?.quantity}', 
            '${variant_image != undefined ? variant_image : ''}', 
            '${variant?.weight != undefined ? variant?.weight : 0}'
            )
        `;
                const [variantData] = await db.query(thisQueryVariant);
                console.log('variantData', variantData);

                const currentPath = path.join(process.cwd(), "uploads", req.files.variant_image[i]["filename"]);
                const destinationDir = path.join(process.cwd(), "uploads/product/variants/image", `${InsertId}`, `${variantData}`);

                fs.mkdirSync(destinationDir, { recursive: true });

                const destinationPath = path.join(destinationDir, variant_image);
                fs.rename(currentPath, destinationPath, function (err) {
                    if (err) {
                        console.error("Error moving file: ", err);
                        throw err;
                    } else {
                        console.log("Successfully variant image uploaded!");
                    }
                });
            }
        }
    }
}


// 13-12-2024

// Get Order Page
export const getOrderPage = async (req, res) => {
    await db.query(
      "SET sql_mode = (SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''))"
    );
  
    try {
      const filters = req.query;
  
      let thisQuery = `
        SELECT 
        tra.id,
        tra.productid,
        tra.userid,
        tra.transid,
        tra.ordernumber,
        tra.childbillid,
        tra.addressid,
        tra.gst_id,
        tra.status,
        IF(tra.online = 1, 'online', 'store') as online,
        gst.name as gst_name,
        gst.tax as total_tax,
        tra.productid as trans_product_id,
        tra.variant as variantid,
        tb.tpricegst as tpricegst,
        tb.tweight as tweight,
        tb.shipping_charges as shipping_charges,
        tb.type as type,
        tb.actual_price as actual_price,
        tb.transaction_price as transaction_price,
        tb.payment_type as payment_type,
        tb.parent_bill_id as parent_bill_id,
        us.email as email,
        DATE_FORMAT(tra.createdon, '%Y-%m-%d %H:%i:%s') as createdon,
        (JSON_ARRAY(
                JSON_OBJECT(
                    'name', '',
                    'email', ''
                )
            )
        ) AS seller,
          (JSON_ARRAY(
                JSON_OBJECT(
                'name', us.username,
                'email', us.email,
                'phone', us.mobileno,
                'address', ad.locationDetails,
                'country', ad.country
                )
            )
        ) AS customer,
        tb.status as financialStatus,
        tb.billing_status as billing_status
        
        FROM transactions as tra
        LEFT JOIN transaction_billing as tb ON (tb.id = tra.childbillid)
        LEFT JOIN users as us ON (us.userid = tra.userid)
        LEFT JOIN product as p ON (tra.productid = p.productid)
        LEFT JOIN variant as v ON (v.id = tra.variant)
        LEFT JOIN productimage pi ON (pi.productid = p.productid AND pi.imageseq = 1)
        LEFT JOIN address ad ON (ad.addressid = tra.addressid)
        LEFT JOIN gst as gst ON (gst.id = tra.gst_id)
        WHERE tra.id IS NOT NULL
        `;
      if (filters?.status) {
        thisQuery += ` AND tra.status = '${filters?.status}' `;
      }
      if (filters?.id) {
        thisQuery += ` AND tra.ordernumber = '${filters?.id}' `;
      }
      if (filters?.transid) {
        thisQuery += ` AND tra.transid = '${filters?.transid}' `
      }
      if (filters?.searchterm) {
        const searchTerm = filters?.searchterm.replace(/'/g, "''");
        thisQuery += ` AND (us.email LIKE '%${searchTerm}%' OR tra.ordernumber LIKE '%${searchTerm}%') `;
      }
  
      thisQuery += ` 
        GROUP BY tra.id
        ORDER BY MAX(tra.lastmodifiedat) DESC
        `;
      if (filters?.limit) {
        thisQuery += ` limit ${filters?.limit},10 `;
      }
  
      const orders = await db.query(thisQuery);
  
      return res.status(200).json({
        status: true,
        count: orders[0].length,
        message: "Order page list",
        data: orders[0],
      });
    } catch (error) {
      console.log("error", error);
      return res.status(500).json({
        status: false,
        message: error.message || "Internal Server Error",
      });
    }
  };